# Hints for OS/2, based on Sylvia's reports of the few config.h
# tweaks she's had to do
d_random='define'
d_lrand48='define'
d_gettblsz='define'
tablesize='ulimit(4,0)'
