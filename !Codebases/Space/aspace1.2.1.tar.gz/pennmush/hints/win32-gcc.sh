# Hints for win32 with gcc
cc='gcc'
ccflags='-DWIN32'
usenm='n'
h_fcntl='false'
d_ipv6='undef'
d_setlocale='undef'
