nm_opt='-B'
ccflags='-D__USE_POSIX'
libswanted='nsl m c crypt intl resolv'
echo "I suggest using sysmalloc when you edit options.h."
