ccflags="-taso"
echo "You will want to use the native malloc."
