usenm="n"
cdecl=''
so='dylib'

