usenm=false
inclwanted='/usr/local/include'
i_malloc='undef'
d_force_ipv4='define'
