usenm="n"
cdecl=''
so='dylib'
osname='darwin'
loclibpth='/sw/lib'
ccflags='-I/sw/include'

