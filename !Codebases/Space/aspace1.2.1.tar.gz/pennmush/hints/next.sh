ccflags="-W -Wreturn-type -Wunused -Wswitch -Wshadow -Wwrite-strings"
echo 
echo "NeXT note: You may have to use the native malloc rather than"
echo "smalloc.c or gmalloc.c"
echo 
