usenm=false
i_malloc='undef'
i_values='undef'
ccflags='-D_POSIX_C_SOURCE=2 -D__XSI_VISIBLE=1000 -D__BSD_VISIBLE -I/usr/local/include'
d_attribut=true
d_force_ipv4='define'
