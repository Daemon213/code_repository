cc='gcc'
usenm='n'
libs='-lwsock32'
osname='mingw32'
