ccflags="-ZB"
libs="-lbsd"
