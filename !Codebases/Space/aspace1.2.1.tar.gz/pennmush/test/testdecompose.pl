use PennMUSH;
use MUSHConnection;
use TestHarness;

$mush = PennMUSH->new();
$god = $mush->loginGod();

test('decompose.1', $god, 'think decompose([ansi(hr,b[ansi(f,la)]h)])', '\[ansi\(hr,b\[ansi\(f,la\)\]\)\]\[ansi\(hr,h\)\]');
test('decompose.2', $god, 'think decompose(a\ \ \ \ b)', 'a %b %bb');
test('decompose.3', $god, 'think decompose(s(tab%treturn%r))', 'tab%treturn%r');
test('decompose.4', $god, 'think decompose(before(ansi(h,x),x)hello)', '\[ansi\(h,hello\)\]');
test('decompose.5', $god, 'think decompose([before(ansi(h,blah),\[)])', '!.');
