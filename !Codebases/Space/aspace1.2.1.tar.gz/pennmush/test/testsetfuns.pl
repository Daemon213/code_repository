use PennMUSH;
use MUSHConnection;
use TestHarness;

$mush = PennMUSH->new();
$god = $mush->loginGod();

test('setunion.1', $god, 'think setunion(,)', '^$');
test('setunion.2', $god, 'think setunion( a,a)', '^a\r$');
test('setunion.3', $god, 'think setunion(c a b a,a b c c)', '^a b c\r$');
test('setunion.4', $god, 'think setunion(a a a,)', '^a\r$');
test('setunion.5', $god, 'think setunion(,a a a)', '^a\r$');
