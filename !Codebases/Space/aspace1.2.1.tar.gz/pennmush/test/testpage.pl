use PennMUSH;
use MUSHConnection;
use TestHarness;

$mush = PennMUSH->new();
$god = $mush->loginGod();

test('page.1', $god, 'page/noeval %# \= =',"I can't find"); # Former crasher
