use PennMUSH;
use MUSHConnection;
use TestHarness;

$mush = PennMUSH->new();
$god = $mush->loginGod();

test('digest.1', $god, 'think digest(md2,foo)', 'd11f8ce29210b4b50c5e67533b699d02');
test('digest.2', $god, 'think digest(md5,foo)', 'acbd18db4cc2f85cedef654fccc4a4d8');
test('digest.3', $god, 'think digest(sha,foo)', '752678a483e77799a3651face01d064f9ca86779');
test('digest.4', $god, 'think digest(sha1,foo)', '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33');
test('digest.5', $god, 'think digest(dss1,foo)', '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33');
test('digest.6', $god, 'think digest(ripemd160,foo)', '42cfa211018ea492fdee45ac637b7972a0ad6873');
test('digest.7', $god, 'think digest(md4,foo)', '0ac6700c491d70fb8650940b1ca1e4b2');
