use PennMUSH;
use MUSHConnection;
use TestHarness;

$mush = PennMUSH->new();
$god = $mush->loginGod();

test('hastype.1', $god, 'think hastype(#0, room)', ['1', '!#-1']);
test('hastype.2', $god, 'think hastype(#1, player)', ['1', '!#-1']);
test('hastype.3', $god, '@create foo', []);
test('hastype.4', $god, 'think hastype(foo, thing)', ['1', '!#-1']);
test('hastype.5', $god, '@rec foo', []);
test('hastype.6', $god, '@rec foo', []);
test('hastype.7', $god, 'think hastype(#3, garbage)', ['1', '!#-1']);
test('hastype.8', $god, '@open foo', []);
test('hastype.9', $god, 'think hastype(#3, exit)', ['1', '!#-1']);

