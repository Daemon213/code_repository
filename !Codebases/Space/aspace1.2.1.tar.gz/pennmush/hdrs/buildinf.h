/* This file generated automatically from Makefile */
#define BUILDDATE "Wed Dec 20 18:06:36 WST 2006"
#define COMPILER "cc"
#define CCFLAGS "-g -I.. -I../hdrs -I../aspace -D__USE_POSIX  "
#define RDEFS ""
#define IDEFS ""
