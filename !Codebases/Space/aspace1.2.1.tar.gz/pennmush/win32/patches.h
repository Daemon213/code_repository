#ifndef _PATCH_H
#define _PATCH_H
#undef PATCHES
#endif _PATCH_H
