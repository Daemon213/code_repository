#!/usr/local/bin/perl -pi~
$_ = "" if m#/usr/include#;
$_ = "" if m#/usr/lib#;

