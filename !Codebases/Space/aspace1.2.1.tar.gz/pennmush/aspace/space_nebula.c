/* space_nebula.c */

#include "config.h"
#include "space.h"


#ifdef ASPACE
/* ------------------------------------------------------------------------ */

static MYSQL *conn;

MYSQL_RES *getSpaceNebulae(char *sql)
{
   MYSQL_RES *result_set;
   
   if (!conn)
   {
	   conn = mysql_init(NULL);
	   mysql_real_connect(conn, SQL_HOST, SQL_USER, SQL_PASS, "aspace", 3306, 0, 0);
   }

   mysql_query(conn, sql);
   
   result_set = mysql_store_result(conn);
   
   return result_set;
}

int do_new_nebula_report (dbref enactor)
{
	MYSQL_RES *spaceNebulae;
	MYSQL_ROW row;
	static char buffer[BUFFER_LEN], nbuff[20];
	double px = sdb[n].coords.x / PARSEC;
	double py = sdb[n].coords.y / PARSEC;
	double pz = sdb[n].coords.z / PARSEC;
	double dx, dy, dz, radius, range, cx, cy, cz;
	register int x, y, z;

	spaceNebulae = getSpaceNebulae("SELECT nebulaName, radius, xCoord, yCoord, zCoord FROM nebulae");

	if (error_on_console(enactor)) {
		return 0;
	} else if (!sdb[n].sensor.lrs_exist) {
		notify(enactor, ansi_red(tprintf("%s has no long-range sensors.", Name(sdb[n].object))));
	} else if (!sdb[n].sensor.lrs_active) {
		notify(enactor, ansi_red("Long-range sensors are inactive."));
	} else {
		snprintf(buffer, sizeof(buffer),
		  "%s%s--[%sNebula Report%s]--------------------------------------------------------------%s\n%sNebulae              Bearing Range   Core Vis Core Coordinates%s\n%s-------------------- ------- ------- -------- ---------------------------------%s\n",
		  ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL,
		  ANSI_CYAN, ANSI_WHITE, ANSI_BLUE, ANSI_WHITE);

		if (mysql_num_rows(spaceNebulae) <= 0)
			return 0;
		else
		{
			while ((row = mysql_fetch_row(spaceNebulae)) != NULL)
			{
				dx = parse_number(row[2]) * PARSEC;
				dy = parse_number(row[3]) * PARSEC;
				dz = parse_number(row[4]) * PARSEC;
				cx = (dx - sdb[n].coords.x) * PARSEC;
				cy = (dy - sdb[n].coords.y) * PARSEC;
				cz = (dz - sdb[n].coords.z) * PARSEC;
				radius = parse_number(row[1]);

				snprintf(nbuff, sizeof(nbuff), "%s", row[0]);
					strncat(buffer, tprintf("%-20.20s %3d %-3d %-7.7s %7.3f%% %10.3f %10.3f %10.3f\n", nbuff,
					  (int) round(xy2bearing((dx - sdb[n].coords.x), (dy - sdb[n].coords.y))),
					  (int) round(xyz2elevation((dx - sdb[n].coords.x), (dy - sdb[n].coords.y), (dz - sdb[n].coords.z))),
					  unparse_range(xyz2range(sdb[n].coords.x, sdb[n].coords.y, sdb[n].coords.z, dx, dy, dz)),
					  xyz2vis(cx, cy, cz) * 100.0,
					  (dx - sdb[n].coords.xo) / PARSEC,
					  (dy - sdb[n].coords.yo) / PARSEC,
					  (dz - sdb[n].coords.zo) / PARSEC), sizeof(buffer) - 1);
			}
			strncat(buffer, format_l_line(), sizeof(buffer) - 1);
			strncat(buffer, format_Course(n), sizeof(buffer) - 1);
			strncat(buffer, format_Speed(n), sizeof(buffer) - 1);
			strncat(buffer, "\n", sizeof(buffer) - 1);
			strncat(buffer, format_Location(n), sizeof(buffer) - 1);
			strncat(buffer, format_Velocity(n), sizeof(buffer) - 1);
			strncat(buffer, "\n", sizeof(buffer) - 1);
			strncat(buffer, format_l_end(), sizeof(buffer) - 1);

			notify(enactor, buffer);
			mysql_free_result(spaceNebulae);
			return 1;
		}
	}
	mysql_free_result(spaceNebulae);

	return 0;
}

int do_nebula_report (dbref enactor)
{
	static char buffer[BUFFER_LEN], nbuff[20];
	double px = sdb[n].coords.x / PARSEC;
	double py = sdb[n].coords.y / PARSEC;
	double pz = sdb[n].coords.z / PARSEC;
	double cx[2], cy[2], cz[2];
	double dx, dy, dz;
	register int x, y, z;

	cx[0] = ceil(px / 100.0) * 100.0;
	cx[1] = floor(px / 100.0) * 100.0;
	cy[0] = ceil(py / 100.0) * 100.0;
	cy[1] = floor(py / 100.0) * 100.0;
	cz[0] = ceil(pz / 100.0) * 100.0;
	cz[1] = floor(pz / 100.0) * 100.0;

	if (error_on_console(enactor)) {
		return 0;
	} else if (!sdb[n].sensor.lrs_exist) {
		notify(enactor, ansi_red(tprintf("%s has no long-range sensors.", Name(sdb[n].object))));
	} else if (!sdb[n].sensor.lrs_active) {
		notify(enactor, ansi_red("Long-range sensors are inactive."));
	} else {
		snprintf(buffer, sizeof(buffer),
		  "%s%s--[%sNebula Report%s]--------------------------------------------------------------%s\n%sNebulae              Bearing Range   Core Vis Core Coordinates%s\n%s-------------------- ------- ------- -------- ---------------------------------%s\n",
		  ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL,
		  ANSI_CYAN, ANSI_WHITE, ANSI_BLUE, ANSI_WHITE);

		for (z = 0; z < 2; ++z) {
			for (y = 0; y < 2; ++y) {
				for (x = 0; x < 2; ++x) {
					snprintf(nbuff, sizeof(nbuff), "Nebula %d-%d-%d",
					  round(fabs(cx[x] / 100.0)), round(fabs(cy[y] / 100.0)), round(fabs(cz[z] / 100.0)));
					dx = cx[x] * PARSEC;
					dy = cy[y] * PARSEC;
					dz = cz[z] * PARSEC;
					strncat(buffer, tprintf("%-20.20s %3d %-3d %-7.7s %7.3f%% %10.3f %10.3f %10.3f\n", nbuff,
					  (int) round(xy2bearing((dx - sdb[n].coords.x), (dy - sdb[n].coords.y))),
					  (int) round(xyz2elevation((dx - sdb[n].coords.x), (dy - sdb[n].coords.y), (dz - sdb[n].coords.z))),
					  unparse_range(xyz2range(sdb[n].coords.x, sdb[n].coords.y, sdb[n].coords.z, dx, dy, dz)),
					  xyz2vis(dx, dy, dz) * 100.0,
					  cx[x] - sdb[n].coords.xo / PARSEC,
					  cy[y] - sdb[n].coords.yo / PARSEC,
					  cz[z] - sdb[n].coords.zo / PARSEC), sizeof(buffer) - 1);
				}
			}
		}

		strncat(buffer, format_l_line(), sizeof(buffer) - 1);
		strncat(buffer, format_Course(n), sizeof(buffer) - 1);
		strncat(buffer, format_Speed(n), sizeof(buffer) - 1);
		strncat(buffer, "\n", sizeof(buffer) - 1);
		strncat(buffer, format_Location(n), sizeof(buffer) - 1);
		strncat(buffer, format_Velocity(n), sizeof(buffer) - 1);
		strncat(buffer, "\n", sizeof(buffer) - 1);
		strncat(buffer, format_l_end(), sizeof(buffer) - 1);

		notify(enactor, buffer);
		return 1;
	}
	return 0;
}

/* ------------------------------------------------------------------------ */
#endif
