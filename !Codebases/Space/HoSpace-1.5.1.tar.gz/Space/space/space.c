/********************************************************************
 **                                                                 *
 * SPACE.C  -- Created 21 July 1992                                 *
 *                                                                  *
 * Original code, concept, and design by                            *
 *   Jason M. "Chuckles" Skiles and Donald J. "Euler" Bindner       *
 *                                                                  *
 * Copyright 1993  Jason M. Skiles - All rights reserved            *
 *                                                                  *
 ********************************************************************/
#define USE_HOSPACE /* Turn on Space */

#include "../hdrs/copyrite.h" /* JMS 19 Aug 93 */
#include "options.h"

#include <assert.h>
#ifdef I_STRING
#include <string.h>
#else
#include <strings.h>
#endif
#include <math.h>
#include <varargs.h>
#include <stdlib.h>
#if defined(unix)
#include <signal.h>
#endif
#include "mushtype.h"
#include "hdrs/ansi.h"
#include "Space/hdrs/jmalloc.h"
#include "config.h"
#include "mushdb.h"
#include "Space/hdrs/space.h"
#include "Space/hdrs/ship.h"
#include "externs.h"
#include "function.h"
#include "parse.h"
#include "match.h"
#include "dbdefs.h"
#include "flags.h"
#include "attrib.h"
#include "log.h"

#ifdef USE_HOSPACE /* */

#ifndef PI
#define PI 3.1415926535897
#endif

#define MAX_WARP 200

#ifndef MAXINT
#define MAXINT 20000000
#endif

#define FRAND ((float)( rand() & 65535 ) / 65536.0)
#define HOWIE 1

#define REAL 0
#define SIM  1
#define SPACE_LIMIT 12
#define COMPIN_LIMIT 1

static char *space_names[] =
{ 
        (char *)"real", 
        (char *)"sim1",
        (char *)"sim2",
        (char *)"sim3",
        (char *)"sim4",
        (char *)"sim5",
        (char *)"sim6",
        (char *)"sim7",
        (char *)"sim8",
        (char *)"sim9",
        (char *)"sim10",
        (char *)"sim11"
};

static char *system_names[] =
{
    (char *)"fore shield", 
    (char *)"aft shield",
    (char *)"port shield",
    (char *)"starboard shield", 
    (char *)"gun 0", 
    (char *)"gun 1", 
    (char *)"gun 2", 
    (char *)"gun 3", 
    (char *)"gun 4", 
    (char *)"gun 5",
    (char *)"gun 6",
    (char *)"gun 7",
    (char *)"gun 8",
    (char *)"gun 9",
    (char *)"gun 10",
    (char *)"gun 11",
    (char *)"gun 12",
    (char *)"gun 13",
    (char *)"gun 14",
    (char *)"gun 15",
    (char *)"gun 16",
    (char *)"gun 17",
    (char *)"gun 18",
    (char *)"gun 19",
    (char *)"photon 0", 
    (char *)"photon 1", 
    (char *)"photon 2", 
    (char *)"photon 3", 
    (char *)"photon 4", 
    (char *)"photon 5",
    (char *)"photon 6",
    (char *)"photon 7",
    (char *)"photon 8",
    (char *)"photon 9",
    (char *)"photon 10",
    (char *)"photon 11",
    (char *)"photon 12",
    (char *)"photon 13",
    (char *)"photon 14",
    (char *)"photon 15",
    (char *)"photon 16",
    (char *)"photon 17",
    (char *)"photon 18",
    (char *)"photon 19",
    (char *)"batteries", 
    (char *)"cloak", 
    (char *)"warp drive",
    (char *)"reactor", 
    (char *)"crystals", 
    (char *)"primary sensors",
    (char *)"scanners",
    (char *)"hull",
    (char *)"tractor beam",
    (char *)"paint job",
    (char *)"targetting",
    (char *)"landing gear",
    (char *)"transwarp drive",
    (char *)"warp dissipator",
    (char *)"aux. sensors",
    (char *)"transporters",
    (char *)"impulse engines",
    (char *)"thrusters",
    (char *)"plasma shields"
};

/*******************************
 * global linked list pointers *
 *******************************/
static char space_pause[SPACE_LIMIT] = { 0, 0, 0, 0, 0, 0, 0 ,0 ,0, 0, 0, 0 };

static SHIP *space_list[SPACE_LIMIT] = { NULL, NULL };
static SHIP *space_tail[SPACE_LIMIT] = { NULL, NULL };

static COMPIN *compin_list[COMPIN_LIMIT] = { NULL };
static COMPIN *compin_tail[COMPIN_LIMIT] = { NULL };

static struct planet_entry *planet_list[SPACE_LIMIT] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL };
static struct planet_entry *planet_tail[SPACE_LIMIT] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL };

static STAR *star_list[SPACE_LIMIT] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL};
static STAR *star_tail[SPACE_LIMIT] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,  
NULL};

static struct beacon_entry *beacon_list[SPACE_LIMIT] = { NULL, NULL };
static struct beacon_entry *beacon_tail[SPACE_LIMIT] = { NULL, NULL };

static struct wormhole_entry *wormhole_list[SPACE_LIMIT] = { NULL, NULL };
static struct wormhole_entry *wormhole_tail[SPACE_LIMIT] = { NULL, NULL };

static struct asteroids_entry *asteroids_list[SPACE_LIMIT] = { NULL, NULL };
static struct asteroids_entry *asteroids_tail[SPACE_LIMIT] = { NULL, NULL };

static struct nebula_entry *nebula_list[SPACE_LIMIT] = { NULL, NULL };
static struct nebula_entry *nebula_tail[SPACE_LIMIT] = { NULL, NULL };

static struct plasma_entry *plasma_list[SPACE_LIMIT] = { NULL, NULL};
static struct plasma_entry *plasma_tail[SPACE_LIMIT] = { NULL, NULL};

static SHOCKWAVE *shockwave_list[SPACE_LIMIT] = { NULL, NULL };
static SHOCKWAVE *shockwave_tail[SPACE_LIMIT] = { NULL, NULL };

static int current_space;

char writebuf[14096];  /* shouldn't ever be that long. */

static int space_lock[SPACE_LIMIT] = { SPACE_UNLOCKED, SPACE_UNLOCKED };

/* a few handy macros */
#define BRIDGE(x)       Location(x->nav)
#define ENGINE(x)       Location(x->damcon)
#define CONTROL(x)      Location(x->console)

static int tcount=0; /* moved from space_update() so other functions can 
                       use it */
static int hcount=0;
static long int dcount=0;

/* #define notify_room(xx,yy)        notify_except(db[xx].contents, NOTHING, yy) */

#define TURNING(x)      ((x)->motion.bearing!=(x)->course.bearing || (x)->motion.elevation!=(x)->course.elevation)

/* now include all the elements of the space code */

#include "Space/space/smain.c"
#include "Space/space/smisc.c"

#include "Space/space/helm.c"
#include "Space/space/watch.c"

#include "Space/space/nav.c"
#include "Space/space/dock.c"

#include "Space/space/eng.c"

#include "Space/space/commo.c"

#include "Space/space/damage.c"
#include "Space/space/damcon.c"

#include "Space/space/xport.c"

#include "Space/space/planets.c"
#include "Space/space/navhaz.c"

#include "Space/space/beacon.c"
#include "Space/space/spacegod.c"
#include "Space/space/stars.c"
#include "Space/space/wormhole.c" 
#include "Space/space/nebula.c"
#include "Space/space/shock.c"
#include "Space/space/transwarp.c"
#include "Space/space/cim.c"
// #include "Space/space/stars.c"
#endif /* USE_HOSPACE */
