/*
 * $Id: nav.c,v1.2 1993/09/25 20:39:40 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: nav.c,v $
 * Howie's Revisions: 1999/03/15
 * added warp_accleration to set_warp among other things
 *
 * Revision 1.2  1993/09/25  20:39:40  chuckles
 * keep track of size of and distance to closest planet for each ship.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS 24 May 93 - separated into nav.c
 * JMS/DJB ?? Jul 92 - original code
 */


/**************************************
 *
 * fun_nav_cmd()
 *
 *  input:
 *    standard fun_xxx stuff
 *
 *  purpose:
 *    parses and processes the function call
 *
 *  return value:
 *    none
 *
 * JMS/DJB 21 Jul 92
 * JMS 24 May 93 - cleanup
 * JMS 26 Aug 93 - use SHIP_OBJECT instead of XA
 *
 *************************************/

FUNCTION(fun_nav_cmd)
{
  SHIP *ship;
  dbref ship_object;

   if( !Wizard(executor) || args[0]==NULL )
   {
     safe_str("#-1 PERMISSION DENIED", buff, bp );
     return;
   }

  /* get the dbref of the ship object */
  ship_object = attrib_dbref( executor, "SHIP_OBJECT" );
  if( !GoodObject( ship_object )) {
    safe_str("#-1 BAD SHIP OBJECT", buff, bp );
    return;
  }

  /* now set the ship pointer to the proper ship and also set the
   * space list to the list that contains it (handled by cfind_ship).
   */
  ship = cfind_ship( ship_object );

  /* Everything is fine so far.  Switch on the command argument
   * note that some checks come before the active check, and some
   * come after.
   */

  if( !strcmp( args[0], "undock" ))
  {
    sprintf( writebuf, "#%d", undock( ship, executor, enactor ));
    safe_str(writebuf, buff, bp);
  }

    /* ACTIVE CHECK */
  else if( ship == NULL )
  {
   fnotify( enactor,"%sShip must be active to use that command.%s", ANSI_CYAN, ANSI_NORMAL); 
    return;
  }
  else if( !strcmp( args[0], "xyz" ))
  {
    sprintf( writebuf, "%.0f %.0f %.0f", ship->pos.x, ship->pos.y, ship->pos.z );
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "ber" ))
  {
    XYZ rel_pos;
    SPH sph;
    rel_pos.x = ship->pos.x - ship->origin.x;
    rel_pos.y = ship->pos.y - ship->origin.y;
    rel_pos.z = ship->pos.z - ship->origin.z;

    sph = xyz_to_sph( rel_pos );
   
    sprintf( writebuf, "%.0f %.0f %.0f", sph.bearing, sph.elevation, sph.range );
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "head" ))
  {
    sprintf( writebuf, "%.0f%+2.0f", ship->motion.bearing, ship->motion.elevation );
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "warp" ))
  {
    sprintf( writebuf, "%.1f", ship->warp_speed );
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "shields" ))
  {
   if( ship->cloak_status == CLOAK_ON )
   {
     sprintf( writebuf, "CLOAKED CLOAKED CLOAKED CLOAKED" );
     safe_str(writebuf, buff, bp);
   }
   else
   {
    static char *stat_str[] = {
      (char *)"READY",(char *) "   UP", (char *)"  DMGD", 
        (char *)"STBLE", (char *)"CHARG", (char *)"FALL ", (char *)"OVRLD", 
        (char *)"-----" };
    int i;
    char *s[8];
    for( i = 0; i < 4; i++ ) {
      s[2 * i] = stat_str[ship->shield_status[i] - SHLD_BASE];
      s[2 * i + 1] = ( ship->shield_status[i] == SHLD_DAMAGED )
                     ? stat_str[7] : stat_str[ship->shield_action[i]];
    }
    sprintf( writebuf, "%s:%s %s:%s %s:%s %s:%s", s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7] );
    safe_str(writebuf, buff, bp);
    }
  }
/* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
  else if( ship->flags[DEADMAN] )
  {
    fnotify( enactor, "%s%sShip is deadmanned. That command is unavailable.%s",
           ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
/* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
  else if( current_space==REAL && !Wizard(executor) )
  {
    safe_str("#-1 PERMISSION DENIED", buff, bp );
    return;
  }
  else if( !strcmp( args[0], "status" ))
  {
    nav_status( ship, enactor );
  }
  else if( !strcmp( args[0], "abridged_status"))
  {
  	abridged_nav_status( ship, enactor );
  }
  else if( !strcmp( args[0], "set_course" ))
  {
    if( !strcmp( args[2], "+" ) )
        nav_new_course( atoi( args[1] ), atoi( args[3] ), ship, enactor );
    else
        nav_new_course( atoi( args[1] ), -1 * atoi( args[3] ), ship, enactor );
  }
  else if( !strcmp( args[0], "allocate" ))
  {
    nav_allocate( ship, enactor, atoi( args[1] ), atoi( args[2] ),
                  atoi( args[3] ), atoi( args[4] ), atoi( args[5] ));
  }
  else if( !strcmp( args[0], "report_ship" ))
  {
    scan_ship( ship, enactor, args[1], SS_REPORT );
  }
  else if( !strcmp( args[0], "sensor_report" ))
  {
    helm_sensor_report( ship, enactor );
  }
  else if( !strcmp( args[0], "short_sensor_report" ))
  {
    short_sensor_report( ship, enactor );
  }
  else if( !strcmp( args[0], "qalloc" ))
  {
    nav_quick_alloc( ship, enactor, atoi( args[1] ), atoi( args[2] ));
  }
  else if( !strcmp( args[0], "warp_cost" ))
  {
    warp_cost( ship, enactor, atof( args[1] ));
  }
  else if( !strcmp( args[0], "warp_speed" ))
  {
    warp_speed( ship, enactor, atoi( args[1] ));
  } 
  else if( !strcmp( args[0], "warp_table" ))
  {
    warp_table( ship, enactor );
  }
  else if( !strcmp( args[0], "set_warp" ))
  {
    set_warp( ship, enactor, atof( args[1] ));
  }
  else if( !strcmp( args[0], "ship_specs" ))
  {
    ship_specs( ship, enactor );
  }
  else if( !strcmp( args[0], "raise_shield" ))
  {
    raise_shields( ship, enactor, args[1] );
  }
  else if( !strcmp( args[0], "lower_shield" ))
  {
    lower_shields( ship, enactor, args[1] );
  }
  else if( !strcmp( args[0], "cloak_on" ))
  {
    engage_cloak( ship, enactor );
  }
  else if( !strcmp( args[0], "cloak_off" ))
  {
    disengage_cloak( ship, enactor );
  }
  else if( !strcmp( args[0], "planet_list" ))
  {
    list_planets( ship, enactor );
  }
  else if( !strcmp( args[0], "coordinates" ))
  {
    set_coordinates( ship, enactor, args[1], args[2] );
  }
  else if( !strcmp( args[0], "reset_coordinates" ))
  {
    reset_coordinates( ship, enactor );
  }
  else if( !strcmp( args[0], "check_beacon" ))
  {
    list_beacons( ship, enactor );
  }
  else if( !strcmp( args[0], "dock" ))
  {
    sprintf( writebuf, "#%d", dock( ship, enactor, args[1] ));
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "land" ))
  {
    sprintf( writebuf, "#%d", land( ship, enactor, args[1] ));
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "land_ok") )
  { 
    land_ok( ship, enactor, match_planet(ship,args[1]), buff, bp );
  }
  else if( !strcmp( args[0], "dock_ok") )
  {
    dock_ok( ship, enactor, args[1], buff, bp );
  }
  else if( !strcmp( args[0], "orbit" ) )
  {
    orbit( ship, enactor, args[1] );
  }
  else if( !strcmp( args[0], "open_doors" ))
  {
    door_control( ship, enactor, 0 );
  }
  else if( !strcmp( args[0], "close_doors" ))
  {
    door_control( ship, enactor, 1 );
  }
  else if( !strcmp( args[0], "watch" ))
  {
    add_watch( ship, enactor, args[1], W_NAV );
  }
  else if( !strcmp( args[0], "unwatch" ))
  {
    remove_watch( ship, enactor, args[1], W_NAV );
  }
  else if( !strcmp( args[0], "listwatch" ))
  {
    list_watches( ship, enactor, W_NAV );
  }
  else if( !strcmp( args[0], "shortpos" ))
  {
    short_position( ship, enactor );
  }
  else if( !strcmp( args[0], "xyzpos" ))
  {
    xyz_position( ship, enactor );
  }
  else if( !strcmp( args[0], "autopilot" ))
  {
    engage_autopilot( ship, enactor, args[1], args[2], args[3], args[4] ); 
  }
  else if( !strcmp( args[0], "xyzautopilot" ))
  {
    engage_xyzautopilot( ship, enactor, args[1], args[2], args[3], args[4] );
  }
  else if( !strcmp( args[0], "kill_autopilot" ))
  {
    disengage_autopilot( ship, enactor );
  }
  else if( !strcmp( args[0], "wormhole_jump" ) )
  {
    wormhole_jump( ship, enactor );
  }
  else if( !strcmp( args[0], "sensor_sweep" ))
  {
    sensor_sweep( ship, enactor );
  }
  else if( !strcmp( args[0], "kamikaze" ) )
  {
    kamikaze_attack( ship, enactor, args[1] );
  }
  else if( !strcmp( args[0], "fire_shields" ) )
  {
    fire_shields( ship, enactor );
  }
  else if( !strcmp( args[0], "engage_transwarp" ) )
  {
    engage_transwarp( ship, enactor );
  }
  else if( !strcmp( args[0], "abort_transwarp" ) )
  {
    abort_transwarp( ship, enactor );
  }
  else if( !strcmp( args[0], "toggle_interdict" ) )
  {
    toggle_interdict( ship, enactor );
  }
  else if( !strcmp( args[0], "intercept") )
  {
    intercept( ship, enactor, args[1] );
  }
  else if(  !strcmp(args[0], "remote_down") )
  {
    remote_down( ship, enactor, args[1], args[2]);
  }
  else if( !strcmp( args[0], "remote_undock" ) )
  {
    remote_undock( enactor, ship_object, args[1] );
  }
  else if( !strcmp( args[0], "remote_up" ) )
  {
    remote_up( enactor, executor );
  }
  else if( !strcmp( args[0], "remote_raise_shields") )
  {
    remote_raise_shields( enactor, ship, args[1], args[2] );
  }
  else if( !strcmp( args[0], "remote_lower_shields") )
  {
    remote_lower_shields( enactor, ship, args[1], args[2] );
  }
  else if( !strcmp( args[0], "remote_decloak") )
  {
    remote_decloak( ship, enactor, args[1], args[2] );
  }
  else if( !strcmp( args[0], "remote_cloak") )
  {
    remote_cloak( ship, enactor, args[1], args[2] );
  }
  else if( !strcmp( args[0], "power") )
  {
    sprintf( writebuf, "%d %d %d %d %d %d", ship->alloc_nav, ship->nalloc_warp, ship->nalloc_fore, ship->nalloc_aft, ship->nalloc_port, ship->nalloc_starboard);
    safe_str( writebuf, buff, bp );
  }
  else if( !strcmp( args[0], "eta" ) )
  {
    eta( ship, enactor );
  }
  /*Testing commands*/
  else if( !strcmp( args[0], "list_stars") )
  {
  	list_stars( ship, enactor );
  }
  else
    /* unrecognized command */
    notify( enactor, "Unrecognized nav_cmd call." );
}


void xyz_position( SHIP *ship, dbref enactor )
{
  fnotify( enactor, "%sXYZ Position:     %sX:  %s%s%8.0f%s%s  Y:    %s%s%8.0f%s%s  Z:     %s%s%8.0f%s", 
         ANSI_CYAN, ANSI_WHITE, ANSI_HILITE, ANSI_RED, ship->pos.x,
ANSI_NORMAL, 
         ANSI_WHITE, ANSI_HILITE, ANSI_RED, ship->pos.y, ANSI_NORMAL,
         ANSI_WHITE, ANSI_HILITE, ANSI_RED, ship->pos.z, ANSI_NORMAL );
}

void short_position( SHIP *ship, dbref enactor )
{
  XYZ rel_pos;
  SPH sph;

  rel_pos.x = ship->pos.x - ship->origin.x;
  rel_pos.y = ship->pos.y - ship->origin.y;
  rel_pos.z = ship->pos.z - ship->origin.z;

  sph = xyz_to_sph( rel_pos );

  fnotify( enactor, "%sPosition(%s):    %sbearing: %s%s%3.0f%s%s  elevation: %s%s%+3.0f%s%s  range: %s%s%8.0f%s", 
         ANSI_CYAN, ship->origin_name, ANSI_WHITE, ANSI_HILITE, ANSI_RED,
sph.bearing, ANSI_NORMAL, 
         ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.elevation, ANSI_NORMAL, 
         ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.range, ANSI_NORMAL );
  fnotify( enactor, "%sOrientation:      %sheading: %s%s%3.0f%s%s  elevation: %s%s%+3.0f%s%s  warp:  %s%s%8.3f%s", 
         ANSI_CYAN, ANSI_WHITE, ANSI_HILITE, ANSI_RED,
ship->motion.bearing, ANSI_NORMAL,
         ANSI_WHITE, ANSI_HILITE, ANSI_RED, ship->motion.elevation,
ANSI_NORMAL,
         ANSI_WHITE, ANSI_HILITE, ANSI_RED, ship->warp_speed , ANSI_NORMAL
);
  if( ship->orbitting!=NULL )
  {
    fnotify( enactor, "%sCurrently %s%s%s %s.%s", ANSI_CYAN, ANSI_WHITE,
        ship->bombarding ? "bombarding" : "orbitting", ANSI_CYAN,
        ship->orbitting->name, ANSI_NORMAL );
  }
  /* autopilot display - Philip Aug 2/96 */
  if( ship->on_autopilot ) {
    fnotify( enactor, "\n%sAutopilot is engaged.%s", ANSI_CYAN,
ANSI_NORMAL );
    rel_pos.x = ship->autopilot_destination.x - ship->origin.x;
    rel_pos.y = ship->autopilot_destination.y - ship->origin.y;
    rel_pos.z = ship->autopilot_destination.z - ship->origin.z; 
    sph = xyz_to_sph( rel_pos );
    fnotify( enactor, "%sDestination(%s): %sbearing: %s%s%3.0f%s%s  elevation: %s%s%+3.0f%s%s  range: %s%s%8.0f%s", 
           ANSI_CYAN, ship->origin_name, ANSI_NORMAL, ANSI_HILITE,
ANSI_RED, sph.bearing, ANSI_NORMAL, 
           ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.elevation, ANSI_NORMAL, 
           ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.range, ANSI_NORMAL );
    notify( enactor, "" );
  }
}


/*
 * nav_status() -- Pass a pointer to the ship entry and the dbref of the
 * enactor.  Fctn will give doer a status report for nav and shields.  No
 * return value.  Newly coded by Howie 3/99!
 */


void nav_status( SHIP *ship, dbref enactor )
{
  XYZ rel_pos;
  SPH sph;
  static char *stat_str[] = {
    (char *)"READY",(char *) "   UP", (char *)"  DMGD", 
        (char *)"STBLE", (char *)"CHARG", (char *)"FALL ", (char *)"OVRLD", 
        (char *)"-----" };
  char *s[8];
  int i;

  rel_pos.x = ship->pos.x - ship->origin.x;
  rel_pos.y = ship->pos.y - ship->origin.y;
  rel_pos.z = ship->pos.z - ship->origin.z;

  sph = xyz_to_sph( rel_pos );

  fnotify( enactor,
"%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s[Navigation Status]%s~~%s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, 
ANSI_NORMAL);
fnotify( enactor, "%sXYZ Position:    X:  %s%8.0f%s  Y:   %s%8.0f%s   Z:   %s%8.0f%s", ANSI_CYAN, ANSI_WHITE, ship->pos.x, ANSI_CYAN,
ANSI_WHITE,
ship->pos.y, ANSI_CYAN, ANSI_WHITE, ship->pos.z, ANSI_NORMAL);
fnotify( enactor, "%sPosition(%s):   bearing: %s%3.0f%s elevation: %s%+3.0f%s  range: %s%8.0f%s", ANSI_CYAN, ship->origin_name, ANSI_WHITE,
sph.bearing, ANSI_CYAN, ANSI_WHITE, sph.elevation, ANSI_CYAN,
ANSI_WHITE, sph.range, ANSI_NORMAL );
if ( ship->impulse_max == 0) {
fnotify(enactor, "%sOrientation:     heading: %s%3.0f%s elevation: %s%+3.0f%s  speed: %2swarp %1.1f%s", ANSI_CYAN, ANSI_WHITE,
ship->motion.bearing,
ANSI_CYAN,ANSI_WHITE, ship->motion.elevation, ANSI_CYAN,ANSI_WHITE,
ship->warp_speed, ANSI_NORMAL );}
else {
if ( ship->warpset < 1 ){
fnotify(enactor, "%sOrientation:     heading: %s%3.0f%s elevation: %s%+3.0f%s  speed: %s%.0f%% impulse%s", ANSI_CYAN, ANSI_WHITE,
ship->motion.bearing,
ANSI_CYAN,ANSI_WHITE, ship->motion.elevation, ANSI_CYAN,ANSI_WHITE,
(100*ship->warp_speed)/ship->impulse_max, ANSI_NORMAL );}
else {
fnotify(enactor, "%sOrientation:     heading: %s%3.0f%s elevation: %s%+3.0f%s  speed: %2swarp %1.1f%s", ANSI_CYAN, ANSI_WHITE,
ship->motion.bearing,
ANSI_CYAN,ANSI_WHITE, ship->motion.elevation, ANSI_CYAN,ANSI_WHITE,
ship->warp_speed, ANSI_NORMAL );
  }
}
  if( ship->orbitting!=NULL )
  {
    fnotify( enactor, "%sCurrently %s %s%s%s.%s%s", ANSI_CYAN, ANSI_BLUE,
ship->bombarding ? "bombarding" : "orbitting", ship->orbitting->name,
ANSI_CYAN, ANSI_WHITE, ANSI_NORMAL );
  } 
    fnotify(
enactor,"%s--------------------------------------------------------------------%s",
ANSI_WHITE, ANSI_NORMAL ); 
 fnotify(enactor,"%sShip Name:%s %-15s      %sClass: %s%s%s",
ANSI_CYAN, ANSI_WHITE,
ship->name, ANSI_CYAN, ANSI_WHITE, ship->class, ANSI_NORMAL);
  fnotify( enactor, "%sEmpire:%s    %-15s      %sType:%s  %s%s",
ANSI_CYAN, ANSI_WHITE, ship->owner_name, ANSI_CYAN, ANSI_WHITE,
ship->type, ANSI_NORMAL);
fnotify(enactor, "%sCruise:%s    Warp %6.3f          %sMax:%s   Warp %6.3f%s",
ANSI_CYAN, ANSI_WHITE, calc_warp_speed( ship->current_warp_factor, (int)
(((float) ship->reactor_stress_level)*0.01*((float) ship->reactor_output_max)) ),
ANSI_CYAN, ANSI_WHITE, calc_warp_speed( ship->current_warp_factor, (int) (((float) ship->reactor_setting_limit)*0.01*((float)
ship->reactor_output_max)) ), ANSI_NORMAL);
fnotify(enactor, "%sSize:%s      %-5.2f                %sHull:%s  %-5d%s",ANSI_CYAN, ANSI_WHITE, ship->size, ANSI_CYAN, ANSI_WHITE,
ship->hull_integrity, ANSI_NORMAL);
fnotify(enactor,"%s--------------------------------------------------------------------%s",
ANSI_WHITE, ANSI_NORMAL );
  fnotify( enactor, "%sShields              Power       %%        Status%s",
ANSI_CYAN, ANSI_NORMAL);
  fnotify(enactor, " ");
for( i = 0; i < 4; i++ )
  {
      s[2 * i] = stat_str[ship->shield_status[i] - SHLD_BASE];
      s[2 * i + 1] = ( ship->shield_status[i] == SHLD_DAMAGED )
                     ? stat_str[7] : stat_str[ship->shield_action[i]];
  }
  fnotify( enactor, "%sFore%s                 %3d      %3i%%     %s:%s%s",
ANSI_CYAN, ANSI_WHITE, ship->shield_level[0], (int)
((float)ship->shield_level[0] / ship->shield_max[0]*100.0), s[0], s[1], ANSI_NORMAL);                         
  fnotify( enactor, "%sAft%s                  %3d      %3i%%     %s:%s%s",
ANSI_CYAN, ANSI_WHITE, ship->shield_level[1],
(int)((float)ship->shield_level[1] / ship->shield_max[1]*100.0), s[2],
s[3], ANSI_NORMAL);
  fnotify( enactor, "%sPort%s                 %3d      %3i%%     %s:%s",
ANSI_CYAN, ANSI_WHITE, ship->shield_level[2],
(int)((float)ship->shield_level[2] / ship->shield_max[2]*100.0), s[4],
s[5]);
  fnotify( enactor, "%sStarboard%s            %3d      %3i%%     %s:%s",
ANSI_CYAN, ANSI_WHITE, ship->shield_level[3],
(int)((float)ship->shield_level[3] / ship->shield_max[3]*100.0), s[6],
s[7]);
fnotify(
enactor,"%s--------------------------------------------------------------------%s",
ANSI_WHITE, ANSI_NORMAL ); 
  if( ship->cloak_status == CLOAK_ON )
  {
    fnotify( enactor, "%sCloak: %s%sEngaged%s", ANSI_CYAN, ANSI_HILITE,
ANSI_GREEN, ANSI_NORMAL); 
  }
  else
  {
    if( ship->cloak_status == CLOAK_OFF )
    {
      fnotify( enactor, "%sCloak: %s%sDisengaged%s", ANSI_CYAN,
ANSI_HILITE, ANSI_RED, ANSI_NORMAL); 
    }
    else
    {
      fnotify( enactor, "%sCloak: %s%sNot Present%s", ANSI_CYAN,
ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
    }
  }

  switch( ship->door_status ) {
    case DOORS_NONE:
      fnotify( enactor, "%sDocking bay doors: %s%sNot Present%s",
ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_NORMAL); 
      break;
    case DOORS_OPEN:
      fnotify( enactor, "%sDocking bay doors: %s%sOpen%s", ANSI_CYAN,
ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL); 
      break;
    case DOORS_CLOSED:
      fnotify( enactor, "%sDocking bay doors: %s%sClosed%s", ANSI_CYAN,
ANSI_HILITE, ANSI_RED, ANSI_NORMAL); 
    break;
  }
/* autopilot display - Philip Aug 2/96 then Howie 3/99 */
  if( ship->on_autopilot ) {
    rel_pos.x = ship->autopilot_destination.x - ship->origin.x;
    rel_pos.y = ship->autopilot_destination.y - ship->origin.y;
    rel_pos.z = ship->autopilot_destination.z - ship->origin.z; 
    sph = xyz_to_sph( rel_pos );
    fnotify( enactor, "%sDestination(%s): %sbearing: %s%s%3.0f%s%s elevation: %s%s%+3.0f%s%s  range: %s%s%8.0f%s", ANSI_CYAN,
ship->origin_name, ANSI_NORMAL, ANSI_HILITE, ANSI_RED, sph.bearing,
ANSI_NORMAL, ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.elevation,
ANSI_NORMAL, ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.range, ANSI_NORMAL );
    fnotify( enactor, "%sAutopilot: %s%sEngaged\n%s", ANSI_CYAN,
ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );

  }
  else {
    fnotify( enactor, "%sAutopilot: %s%sDisengaged\n%s", ANSI_CYAN,
ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
  }

  fnotify( enactor, "%sTotal available power: %s%d\n%sAllocations:%s",
ANSI_CYAN,
           ANSI_WHITE, ship->alloc_nav, ANSI_CYAN, ANSI_WHITE );
  fnotify( enactor, "%sWarp:%s%4d%s   Shields:  Fore:%s%4d%s  Aft:%s%4d%s Port:%s%4d%s  Starboard:%s%4d", 
         ANSI_CYAN, ANSI_WHITE, ship->nalloc_warp,
         ANSI_CYAN, ANSI_WHITE, ship->nalloc_fore,
           ANSI_CYAN, ANSI_WHITE, ship->nalloc_aft,
         ANSI_CYAN, ANSI_WHITE, ship->nalloc_port,
         ANSI_CYAN, ANSI_WHITE, ship->nalloc_starboard );
  fnotify( enactor, "%sUnused energy: %s%3d", ANSI_CYAN, ANSI_WHITE,
ship->alloc_nav
           - ship->nalloc_warp - ship->nalloc_fore - ship->nalloc_port
           - ship->nalloc_aft - ship->nalloc_starboard );
  if( ship->transwarp_engaging )
  {
      fnotify( enactor, "%sTranswarp drive engaging: %d/%d (%d%%).%s",
          ANSI_CYAN, ship->transwarp_charge, ship->transwarp_power,
          100*ship->transwarp_charge/ship->transwarp_power, ANSI_NORMAL );
  }
  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);


  return;
}

/* abridged_nav_status() -- Short status to use when battling or in a 
 * hurry.  Just the necessities on this one, nothing fancy. 
 */
 
void abridged_nav_status( SHIP *ship, dbref enactor )
 {
 	
  XYZ rel_pos;
  SPH sph;
  static char *stat_str[] = {
    (char *)"READY",(char *) "   UP", (char *)"  DMGD", 
        (char *)"STBLE", (char *)"CHARG", (char *)"FALL ", (char *)"OVRLD", 
        (char *)"-----" };
  char *s[8], *statchar[4];
  int i;

  rel_pos.x = ship->pos.x - ship->origin.x;
  rel_pos.y = ship->pos.y - ship->origin.y;
  rel_pos.z = ship->pos.z - ship->origin.z;

  sph = xyz_to_sph( rel_pos );

  fnotify( enactor,"%s%s~~~~~~%s[%-32s Abridged Navigation Status]%s~~%s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ship->name,ANSI_BLUE, 
		ANSI_NORMAL); 	
  fnotify( enactor, "%sPosition(%s):   bearing: %s%3.0f%s elevation: %s%+3.0f%s  range: %s%8.0f%s", ANSI_CYAN, ship->origin_name, ANSI_WHITE,
	sph.bearing, ANSI_CYAN, ANSI_WHITE, sph.elevation, ANSI_CYAN,
	ANSI_WHITE, sph.range, ANSI_NORMAL );
  fnotify( enactor, "%sXYZ Position:    X:  %s%8.0f%s  Y:   %s%8.0f%s   Z:   %s%8.0f%s", ANSI_CYAN, ANSI_WHITE, ship->pos.x, ANSI_CYAN,
	ANSI_WHITE, ship->pos.y, ANSI_CYAN, ANSI_WHITE, ship->pos.z, ANSI_NORMAL);
  if ( ship->impulse_max == 0) {
	fnotify(enactor, "%sOrientation:     heading: %s%3.0f%s elevation: %s%+3.0f%s  speed: %2swarp %1.1f%s", ANSI_CYAN, ANSI_WHITE,
	   ship->motion.bearing,
	   ANSI_CYAN,ANSI_WHITE, ship->motion.elevation, ANSI_CYAN,ANSI_WHITE,
	   ship->warp_speed, ANSI_NORMAL );}
  else {
	if ( ship->warpset < 1 ){
			fnotify(enactor, "%sOrientation:     heading: %s%3.0f%s elevation: %s%+3.0f%s  speed: %s%.0f%% impulse%s", ANSI_CYAN, ANSI_WHITE,
			ship->motion.bearing,
			ANSI_CYAN,ANSI_WHITE, ship->motion.elevation, ANSI_CYAN,ANSI_WHITE,
			(100*ship->warp_speed)/ship->impulse_max, ANSI_NORMAL );}
	else {
			fnotify(enactor, "%sOrientation:     heading: %s%3.0f%s elevation: %s%+3.0f%s  speed: %2swarp %1.1f%s", ANSI_CYAN, ANSI_WHITE,
				ship->motion.bearing,
				ANSI_CYAN,ANSI_WHITE, ship->motion.elevation, ANSI_CYAN,ANSI_WHITE,
				ship->warp_speed, ANSI_NORMAL );
         }
       } 	
	fnotify(enactor,"%s--------------------------------------------------------------------%s",
		ANSI_WHITE, ANSI_NORMAL ); 	
	
	for( i = 0; i < 4; i++ )
  {
      s[2 * i] = stat_str[ship->shield_status[i] - SHLD_BASE];
      s[2 * i + 1] = ( ship->shield_status[i] == SHLD_DAMAGED )
                     ? stat_str[7] : stat_str[ship->shield_action[i]];
      if(  s[2*i]==(char *) "   UP"  )
          statchar[i] = (char *) "^";
      else
      	statchar[i]=(char *)"v";
                     
  }
  
	fnotify(enactor, "%sShields:  F: %s%s %-5d %sA: %s%s %-5d %sP: %s%s %-5d %sS: %s%s %-5d%s", ANSI_CYAN, ANSI_WHITE, statchar[0], ship->shield_level[0], ANSI_CYAN, ANSI_WHITE, statchar[1], ship->shield_level[1], ANSI_CYAN, ANSI_WHITE, statchar[2], ship->shield_level[2],ANSI_CYAN, ANSI_WHITE, statchar[3], ship->shield_level[3],ANSI_NORMAL);

	   if( ship->cloak_status == CLOAK_ON )
  {
    fnotify( enactor, "%sCloak: %s%sEngaged%s", ANSI_CYAN, ANSI_HILITE,
ANSI_GREEN, ANSI_NORMAL); 
  }
  else
  {
    if( ship->cloak_status == CLOAK_OFF )
    {
      fnotify( enactor, "%sCloak: %s%sDisengaged%s", ANSI_CYAN,
ANSI_HILITE, ANSI_RED, ANSI_NORMAL); 
    }
    else
    {
      fnotify( enactor, "%sCloak: %s%sNot Present%s", ANSI_CYAN,
ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
    }
  }
  
    switch( ship->door_status ) {
    case DOORS_NONE:
      fnotify( enactor, "%sDocking bay doors: %s%sNot Present%s",
ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_NORMAL); 
      break;
    case DOORS_OPEN:
      fnotify( enactor, "%sDocking bay doors: %s%sOpen%s", ANSI_CYAN,
ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL); 
      break;
    case DOORS_CLOSED:
      fnotify( enactor, "%sDocking bay doors: %s%sClosed%s", ANSI_CYAN,
ANSI_HILITE, ANSI_RED, ANSI_NORMAL); 
    break;
  }

	  if( ship->on_autopilot )
	  {
		fnotify( enactor, "%sAutopilot: %s%sEngaged\n%s", ANSI_CYAN,
	ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );

	  }
	  else {
	    fnotify( enactor, "%sAutopilot: %s%sDisengaged\n%s", ANSI_CYAN,
	ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
 	 }
 	 
   fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);

}




/*
 * nav_new_course() -- Pass a heading, elevation, pointer to a ship, and
 * dbref of enactor.  Fctn sets the new course for the ship and notifies
 * enactor.  No return value.
 */

void nav_new_course( int heading, int elevation, SHIP *ship, dbref enactor )
{
    /* make sure the ship is active */
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip inactive.  Navigation controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL);
        return;
    }
    /* check for legal ship */
    if( ship->flags[STARBASE] )
    {
    	fnotify( enactor, "%s%sStarbases rotate, cannot control heading.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
    	return;
    }	
    /* check for legal headings */
    if( heading > 360 || heading < 0 )
    {
        fnotify( enactor, "%s%sValid headings are from 0 to 359.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
        return;
    }
    if( elevation > 90 || elevation < -90 )
    {
        fnotify( enactor, "%s%sValid elevation/depressions are from -90 to 90 inclusive.%s", 
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL); 
        return;
    }
    if( ship->flags[DISABLED] )
    {
        fnotify( enactor, "%s%sShip disabled, unable to change course.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* set the new course */
    ship->course.bearing = heading;
    ship->course.elevation = elevation;
    ship->course = fix_sph_coord( ship->course );

    ship->motion.bearing = heading;
    ship->motion.elevation = elevation;
    ship->motion = fix_sph_coord( ship->motion );

    /* update inc */
    ship->inc = sph_to_xyz( ship->motion );

    /* notify enactor */
    fnotify( enactor, "%sCourse set to %s%s%d%+d%s%s.%s", 
         ANSI_GREEN, ANSI_HILITE, ANSI_RED, heading, elevation,
         ANSI_NORMAL, ANSI_GREEN, ANSI_NORMAL );
    return;
}


/*
 * nav_allocate() -- Pass a pointer to a ship entry, a dbref of the enactor,
 * and five allocation values, warp, fore, aft, port, and starboard
 * shields.  Fctn scales the energy allocation if too much is designated,
 * and then performs the allocation and notifies the enactor.  No return value.
 */

void nav_allocate( SHIP *ship, dbref enactor, int warp, int fore, int aft, int port, int starboard )
{
    long total_allocation,shield_allocation;
    float power_ratio=1.0;
    int warp_cost2;
    float allowed_speed;
    float speed_squared;

    /* make sure the ship is active */
    if( ship == NULL )
    {
        fnotify( enactor, "%s%sNo energy is allocated to navigation.%s", ANSI_HILITE, ANSI_BLACK, ANSI_NORMAL );
        return;
    }
    /* set any negative allocations to zero */
    if( warp < 0 ) warp = 0;
    if( fore < 0 ) fore = 0;
    if( aft < 0 ) aft = 0;
    if( port < 0 ) port = 0;
    if( starboard < 0 ) starboard = 0;

    if( (warp > MAXINT/5) || (fore > MAXINT/5) || (aft > MAXINT/5)
    || (port > MAXINT/5) || (starboard > MAXINT/5) )
    {
        fnotify( enactor, "%s%sExcessive energy can be hazardous to your health.%s",
            ANSI_HILITE, ANSI_BLACK, ANSI_NORMAL); 
        return;
    }
    total_allocation = warp + fore + aft + port + starboard;
    /* check for overallocation */
    if( total_allocation > ship->alloc_nav )
    {
        power_ratio = (float)( ship->alloc_nav ) / (float)total_allocation;
        warp = (int)( (float)warp * power_ratio);
        fore = (int)( (float)fore * power_ratio);
        aft = (int)( (float)aft * power_ratio);
        port = (int)( (float)port * power_ratio);
        starboard = (int)( (float)starboard * power_ratio);
        if( ship->smart_alloc )
        {
            total_allocation = warp + fore + aft + port + starboard;
            warp += ship->alloc_nav - total_allocation;
        }
    }
    shield_allocation = fore + aft + port + starboard;
    /* protect cloak */
    if( ship->smart_alloc && ship->cloak_status==CLOAK_ON
    && shield_allocation!=0 && shield_allocation < ship->cloak_cost
    && power_ratio < 1.0 && warp >= ship->cloak_cost - shield_allocation )
    {
        fore += ship->cloak_cost - shield_allocation;
        warp -= ship->cloak_cost - shield_allocation;
    }
    /* assign the new values */
    ship->nalloc_warp = warp;
    ship->nalloc_fore = fore;
    ship->nalloc_aft = aft;
    ship->nalloc_port = port;
    ship->nalloc_starboard = starboard;

    /* check for cloak power */
    if( ship->cloak_status == CLOAK_ON )
    {
        if( fore + aft + port + starboard < ship->cloak_cost )
        {
            /* not enough juice.  Bum-mer. */
            fnotify( enactor, "%s%sInsufficient energy to maintain cloak.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            sprintf( writebuf, "%s%sCloak requires %s%s%d%s%s total allocation to shields.%s",
                ANSI_HILITE, ANSI_RED, ANSI_NORMAL, ANSI_YELLOW, ship->cloak_cost,
                ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            notify( enactor, writebuf );
            disengage_cloak( ship, enactor );
        }
    }
    /* notify the enactor */
    sprintf( writebuf, "%sTotal available power: %s%d\n%sAllocations:%s", ANSI_GREEN,
        ANSI_YELLOW, ship->alloc_nav, ANSI_GREEN, ANSI_NORMAL );
    notify( enactor, writebuf );
    sprintf( writebuf, "%sWarp:%s%4d%s   Shields:  fore:%s%4d%s  aft:%s%4d%s  port:%s%4d%s  starboard:%s%4d%s", 
        ANSI_GREEN, ANSI_YELLOW, warp,
        ANSI_GREEN, ANSI_YELLOW, fore,
        ANSI_GREEN, ANSI_YELLOW, aft,
        ANSI_GREEN, ANSI_YELLOW, port,
        ANSI_GREEN, ANSI_YELLOW, starboard, ANSI_NORMAL );
    notify( enactor, writebuf );
    /* make sure we can still sustain current warp setting */
    if( ship->warp_speed >= 1.0 )
    {
        warp_cost2 = (int)((WARP_CONST + 10 * ship->warp_speed * ship->warp_speed)
                    * ship->current_warp_factor );
        if( warp_cost2 > warp )
        {
            /* oops. Must now cut warp_speed */
            speed_squared = (float)warp / 10.0 / ship->current_warp_factor - WARP_CONST/10.0;
            if( speed_squared < 1.0 )
            {
                allowed_speed = 0.0;
            }
            else
            {
                allowed_speed = sqrt( speed_squared );
            }
            set_warp( ship, enactor, allowed_speed );
        }
    }
    return;
}


/* nav_quick_alloc() -- Pass a ship pointer, enactor dbref, warp allocation, *
 * and shield allocation.  Fctn simply calls nav_allocate with the shield *
 * energy divided four ways.  No return value.                            */

void nav_quick_alloc( SHIP *ship, dbref enactor,
                      int warp, int shields )
{
    int each,fudge=0;

    /* make sure the ship is active */
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip inactive.  Navigation controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    each = (int)( shields / 4 );
    if( ship->smart_alloc && shields==ship->cloak_cost && each*4 < ship->cloak_cost )
    {
        fudge = ship->cloak_cost - (each * 4);
    }
    nav_allocate( ship, enactor, warp, each + fudge, each, each, each );
}


void warp_speed( SHIP *ship, dbref enactor, int energy )
{
  float setting;

  /* make sure the ship is active */
  if( ship == NULL )
  {
    fnotify( enactor, "%sShip inactive.  Navigation controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
    return;
  }

  if ( (energy < ((WARP_CONST+10) * ship->current_warp_factor)) ||
       (energy > (WARP_CONST + 10*15*15)*ship->current_warp_factor) )
  {
    /* This prevents overflows and underflows. */
    fnotify( enactor, "%s%sInvalid energy level.%s", ANSI_RED, ANSI_HILITE, ANSI_NORMAL ); 
    return;
  }

  energy += 1.0; /* take advantage of every point of energy */

  setting = sqrt(((energy / ship->current_warp_factor) - WARP_CONST) / 10.0);
  fnotify( enactor, "%sWarp %s%.6f%s costs %s%d%s.%s", 
         ANSI_GREEN, ANSI_YELLOW, setting-0.000001, ANSI_GREEN, ANSI_YELLOW, 
         energy-1, ANSI_GREEN, ANSI_NORMAL );
  /* setting and energy are corrected due to round-off errors */
  return;
}

void warp_cost( SHIP *ship, dbref enactor, float setting )
{
    int energy_req;

    /* make sure the ship is active */
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip inactive.  Navigation controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
            return;
    }
    if( setting<=0.0 || setting >ship->warp_max || ( setting>ship->impulse_max && setting<1.0 ) )
    {
        fnotify( enactor, "%sThat speed is unavailable.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    if( setting > ship->impulse_max )
    {
        energy_req = (int)(( WARP_CONST+10.0*setting*setting ) * ship->current_warp_factor );
    }
    else
    {
        energy_req = 0;
    }
    sprintf( writebuf, "%sWarp %s%.6f%s costs %s%d%s.%s", 
        ANSI_GREEN, ANSI_YELLOW, setting, ANSI_GREEN, ANSI_YELLOW, energy_req, 
        ANSI_GREEN, ANSI_NORMAL );
    notify( enactor, writebuf );
    return;
}


void warp_table( SHIP *ship, dbref enactor )
{
  float setting;

  /* make sure the ship is active */
  if( ship == NULL ) {
    fnotify( enactor, "%sShip inactive.  Navigation controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
    return;
  }

  fnotify( enactor, "%sWarp costs table:%s", ANSI_GREEN, ANSI_NORMAL );

  setting = 0.0;
  do {
    setting += 1.0;
    warp_cost( ship, enactor, setting );
  } while ( (setting < ship->warp_max) && (setting < 9) );
    notify( enactor, "" );

    if (9.999999 < ship->warp_max) {
    warp_cost( ship, enactor, 9.999999 );
    notify( enactor, "" );
    }
}

void set_warp( SHIP *ship, dbref enactor, float setting )
{    
    float speed_squared;
    int energy_req=0;

    /* active check */
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip not active.  Warp unavailable.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    if( !strcmp(fetch_attribute(ship->ship_object,"UNDOCKED"),"0") )
    {
       fnotify( enactor, "%sYou cannot do that while the ship is docked%s", ANSI_CYAN, ANSI_NORMAL );
       return;
    }
    if( ship->transwarp_engaging && setting > 0.0 )
    {
        fnotify( enactor, "%s%sTranswarp is currently engaging, warp drive inoperative.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( setting > MAX_WARP )
    {
        fnotify( enactor, "%s%sExcessive warp speeds can be bad for your health.%s", ANSI_HILITE,
            ANSI_BLACK, ANSI_NORMAL);
        return;
    }
#if defined(WARP_IMPULSE)
    if( setting >= 1.0 )
#else
    if( setting > 0.05 )
#endif
    {
        if( ship->damage[SYSTEM_WARP].status=='9'
        || ship->damage[SYSTEM_WARP].status=='8'
        || ship->damage[SYSTEM_WARP].status=='7' )
        {
            fnotify( enactor, "%s%sThe warp drive is inoperative.%s",
                ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            if( ship->warp_speed < 1.0 )
            {
                return;
            }
            else
            {
                setting = 0.0;
            }
        }
        else if( ship->damage[SYSTEM_WARP].status=='x' )
        {
            fnotify( enactor, "%s%sThis ship does not have warp engines.%s",
                ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
            return;
        }
    }
#if defined(WARP_IMPULSE)
    else
    {
        if( ship->damage[SYSTEM_IMPULSE].status=='9'
        || ship->damage[SYSTEM_IMPULSE].status=='8'
        || ship->damage[SYSTEM_IMPULSE].status=='7' )
        {
            fnotify( enactor, "%s%sThe impulse engines are inoperative.%s",
                ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            return;
        }
        else if( ship->damage[SYSTEM_IMPULSE].status=='x' )
        {
            fnotify( enactor, "%s%sThis ship does not have impulse engines.%s",
                ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
            return;
        }
    }
#endif
#if defined(WARP_IMPULSE)
    if( ship->flags[DISABLED] && ship->warp_speed < 1.0 )
    {
        fnotify( enactor, "%s%sShip disabled, engines inoperative, unable to change speed.%s",
            ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
        return;
    }
#endif
    if( setting <= 0.05 )
    {
        if( enactor!=-42 )
        {
            fnotify( enactor, "%s%sAll engines disengaged.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
	    ship->wnot = ship->warp_speed;
	    ship->wnotify=1;
            ship->warpset = 0;
        }
        if( ship->warp_speed >= 1.0 )
        {
            watch_message( ship, (char *)"has disengaged warp drives" );
        }
        else if( ship->warp_speed > 0.0 )
        {
            watch_message( ship, (char *)"has disengaged impulse drives" );
        }
          ship->wnot = ship->warp_speed;
	  ship->wnotify=1;
          ship->warpset = 0;
 /*       ship->inc_set = 0;
        ship->warp_speed = 0.0;
        ship->motion.range = 0.0; */
        if( enactor!=-42 )
        {
            if( ship->smart_alloc==2 && !TURNING(ship) )
            {
                 free_power( ship, POWER_NAV_WARP, ship->nalloc_warp );
            }
            ship->course.range = 0.0;
        }
        ship->inc = sph_to_xyz( ship->motion );
        return;
    }
    if( ship->interdict_status==IDICT_ON && setting > ship->interdict_speed )
    {
        fnotify( enactor, "%s%sWarp dissipator is engaged. Max speed is %.3f.%s",
            ANSI_HILITE, ANSI_RED, ship->interdict_speed, ANSI_NORMAL );
        setting = ship->interdict_speed;
    }
#if defined(WARP_IMPULSE)
    if( setting < 1.0 && setting > ship->impulse_max )
    {
        fnotify( enactor, "%s%sImpulse engines are incapable of speeds exceeding %.3fc.%s",
            ANSI_HILITE, ANSI_RED, ship->impulse_max, ANSI_NORMAL );
        setting = ship->impulse_max;
    }
#else
    if( setting < 1.0 && setting > 0)
    {
        fnotify( enactor, "Warp cannot be used to achieve speeds under warp 1.0.%s", ANSI_HILITE, 
            ANSI_RED, ANSI_NORMAL );
        return;
    }
#endif
    if( ship->flags[PINNED] )
    {
        fnotify( enactor, "%s%sShip is unable to move.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( setting > ship->impulse_max )
    {
        energy_req = (int)(( WARP_CONST+10.0*setting*setting ) * ship->current_warp_factor );
    }
    if( ship->flags[SPEEDY] || setting <= ship->impulse_max )
    {
        energy_req = 0;
    }
    if( ship->flags[POKEY] )
    {
        energy_req *= 2;
    }
    if( ship->smart_alloc==2 )
    {
        if( ship->nalloc_warp > energy_req && !TURNING(ship) )
        {
            free_power(ship, POWER_NAV_WARP, ship->nalloc_warp - energy_req );
        }
        else if( ship->nalloc_warp < energy_req )
        {
            requisition_power( ship, POWER_NAV_WARP, energy_req - ship->nalloc_warp );
        }
    }
    if( ship->nalloc_warp < energy_req )
    {
        sprintf( writebuf, "%s%sNot enough energy allocated to drives for warp %s%s%3.1f%s%s.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL, ANSI_YELLOW, setting, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify( enactor, writebuf );
        speed_squared = ((float) ship->nalloc_warp / 10.0 /
                          ship->current_warp_factor - WARP_CONST/10.0 ); 
#if defined(WARP_IMPULSE)
        if( speed_squared <= 0.0 )
#else
        if( speed_squared < 1.0 )
#endif
        {
            fnotify( enactor, "%s%sWarp engines disengaged.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            if( ship->warp_speed >= 1.0 )
            {
                watch_message( ship, (char *)"has disengaged warp drives" );
            }
            else
            {
                watch_message( ship, (char *)"has disengaged impulse drives" );
            }
	    ship->wnot = ship->warp_speed;
	    ship->wnotify = 1;
	    ship->warpset = 0;
/*  	    Warp deacceleration :-)  Howie
            ship->inc_set = 0;
            ship->warp_speed = 0.0;
            ship->motion.range = 0.0;       */
            if( enactor!=-42 )
            {
                ship->course.range = 0.0;
            }
            ship->inc = sph_to_xyz( ship->motion );
            return;
        }
        else
        {
            setting = sqrt( speed_squared );
        }
    }
    if( setting > ship->warp_max )
    {
        sprintf( writebuf, "%s%sWarp engines on this ship are not capable of speeds in excess of %s%s%3.1f%s%s.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL, ANSI_YELLOW, ship->warp_max, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify( enactor, writebuf );
        setting = ship->warp_max;
    }
    /* set ship->inc registers */
    /* moved to smain.c for warp acceleration */
    ship->inc_set = setting;
    ship->ienactor = enactor;    
    /* notify any watchers */
    if( setting!=ship->warp_speed )
    {
        if( setting > ship->warp_speed )
            sprintf( writebuf, "is accelerating to warp %3.3f", setting );
        else if( setting < ship->warp_speed )
            sprintf( writebuf, "is decelerating to warp %3.3f", setting );

        watch_message( ship, writebuf );
    }
    ship->wnot = ship->warp_speed;
    ship->wnotify=1;
    ship->warpset = setting;
  
    if( setting >= 1.0 )
    {
        sprintf( writebuf, "%sWarp engines set at %s%3.3f%s.%s", 
            ANSI_GREEN, ANSI_YELLOW, setting, ANSI_GREEN, ANSI_NORMAL );
    }
    else
    {
        sprintf( writebuf, "%sImpulse engines set at %s%.0f%c%s.%s",
            ANSI_GREEN, ANSI_YELLOW, setting*100.0/ship->impulse_max,
            '%', ANSI_GREEN, ANSI_NORMAL );
    }
    notify( enactor, writebuf );
    return;
}


void nav_alloc_check( SHIP *ship )
{
  int allocation;
  int available_power;
  dbref navigator;

  available_power = ship->alloc_nav;

  allocation = ship->nalloc_warp + ship->nalloc_fore + ship->nalloc_aft
             + ship->nalloc_port + ship->nalloc_starboard;

  /* get the dbref of the navigator */
  navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

  if( allocation > available_power )
  {
    fnotify( navigator, "%sEnergy allocation cut:%s", ANSI_GREEN, ANSI_NORMAL );
    nav_allocate( ship, navigator, ship->nalloc_warp, ship->nalloc_fore,
                  ship->nalloc_aft, ship->nalloc_port,
                  ship->nalloc_starboard );
  }
  else
  {
    sprintf( writebuf, "%sEnergy allocation cut.  New allocation is %s%d%s.  No shortfall.%s",
           ANSI_GREEN, ANSI_YELLOW, available_power, ANSI_GREEN, ANSI_NORMAL );
    notify( navigator, writebuf );
  }

  return;
}


void raise_shields( SHIP *ship, dbref enactor, char *action )
{
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip inactive.  Navigation controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    /* Make sure we're not docked */
    if( !strcmp(fetch_attribute(ship->ship_object, "UNDOCKED"),"0") ) 
   {
       fnotify( enactor, "%sShip is docked.  Unable to raise shields%s", ANSI_CYAN, ANSI_NORMAL );
       return;
   }
    /* make sure we're not set naked or transwarping */
    if( ship->flags[NAKED] || ship->transwarp_engaging )
    {
        fnotify( enactor, "%s%sShields inoperable.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* make sure it's not in a think nebula. */
    if( ship->nebula_visibility < .2 )
    {
        fnotify( enactor, "%s%sShields inoperative inside very thick nebulas.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* decloak if cloaked */
    if( ship->cloak_status == CLOAK_ON )
    {
        disengage_cloak( ship, enactor );
    }
    if( !strcmp( action, "all" ))
    {
        raise_shields( ship, enactor, (char *)"fore" );
        raise_shields( ship, enactor, (char *)"aft" );
        raise_shields( ship, enactor, (char *)"port" );
        raise_shields( ship, enactor, (char *)"starboard" );
        return;
    }
    else if( !strcmp( action, (char *)"fore" ) )
    {
        switch( ship->shield_status[0] )
        {
            case SHLD_READY:
                ship->shield_status[0] = SHLD_UP;
                fnotify( enactor, "%sForward shield raised.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_UP:
                fnotify( enactor, "%sForward shield is already up.%s", 
                    ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sForward shield is damaged and may not be raised or lowered.%s", 
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                return;
        }
    }
    else if( !strcmp( action, "aft" ) )
    {
        switch( ship->shield_status[1] )
        {
            case SHLD_READY:
                ship->shield_status[1] = SHLD_UP;
                fnotify( enactor, "%sAft shield raised.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_UP:
                fnotify( enactor, "%sAft shield is already up.%s", 
                ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sAft shield is damaged and may not be raised or lowered.%s",
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
               return;
        }
    }
    else if( !strcmp( action, "port" ))
    {
        switch( ship->shield_status[2] )
        {
            case SHLD_READY:
                ship->shield_status[2] = SHLD_UP;
                fnotify( enactor, "%sPort shield raised.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_UP:
                fnotify( enactor, "%sPort shield is already up.%s", 
                     ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sPort shield is damaged and may not be raised or lowered.%s", 
                     ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                return;
        }
    }
    else if( !strcmp( action, "starboard" ) || !strcmp( action, "star" ) )
    {
        switch( ship->shield_status[3] )
        {
            case SHLD_READY:
                ship->shield_status[3] = SHLD_UP;
                fnotify( enactor, "%sStarboard shield raised.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_UP:
                fnotify( enactor, "%sStarboard shield is already up.%s", 
                    ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sStarboard shield is damaged and may not be raised or lowered.%s", 
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                return;
        }
    }
    return;
}


void lower_shields( SHIP *ship, dbref enactor, char *action )
{
    /* active check */
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip inactive.  Navigation controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    if( !strcmp( action, "all" ) )
    {
        lower_shields( ship, enactor, (char *)"fore" );
        lower_shields( ship, enactor, (char *)"aft" );
        lower_shields( ship, enactor, (char *)"port" );
        lower_shields( ship, enactor, (char *)"starboard" );
        return;
    }
    else if( !strcmp( action, (char *)"fore" ))
    {
        switch( ship->shield_status[0] )
        {
            case SHLD_UP:
                ship->shield_status[0] = SHLD_READY;
                fnotify( enactor, "%sForward shield lowered.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_READY:
                if( ship->cloak_status != CLOAK_ON )
                    fnotify( enactor, "%sForward shield is already down.%s", 
                        ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sForward shield is damaged and may not be raised or lowered.%s", 
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                return;
        }
    }
    else if( !strcmp( action, "aft" ) )
    {
        switch( ship->shield_status[1] )
        {
            case SHLD_UP:
                ship->shield_status[1] = SHLD_READY;
                fnotify( enactor, "%sAft shield lowered.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_READY:
                if( ship->cloak_status != CLOAK_ON )
                    fnotify( enactor, "%sAft shield is already down.%s", 
                        ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sAft shield is damaged and may not be raised or lowered.%s", 
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                return;
        }
    }
    else if( !strcmp( action, "port" ) )
    {
        switch( ship->shield_status[2] )
        {
            case SHLD_UP:
                ship->shield_status[2] = SHLD_READY;
                fnotify( enactor, "%sPort shield lowered.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_READY:
                if (ship->cloak_status != CLOAK_ON )
                    fnotify( enactor, "%sPort shield is already down.%s", 
                        ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sPort shield is damaged and may not be raised or lowered.%s", 
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                return;
        }
    }
    else if( !strcmp( action, "starboard" ) || !strcmp( action, "star" ) )
    {
        switch( ship->shield_status[3] )
        {
            case SHLD_UP:
                ship->shield_status[3] = SHLD_READY;
                fnotify( enactor, "%sStarboard shield lowered.%s", ANSI_GREEN, ANSI_NORMAL );
                return;
            case SHLD_READY:
                if( ship->cloak_status != CLOAK_ON )
                    fnotify( enactor, "%sStarboard shield is already down.%s", 
                        ANSI_MAGENTA, ANSI_NORMAL );
                return;
            case SHLD_DAMAGED:
                fnotify( enactor, "%s%sStarboard shield is damaged and may not be raised or lowered.%s", 
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                return;
        }
    }
    return;
}


void engage_cloak( SHIP *ship, dbref enactor )
{
SHIP *watcher;
CONTACT *contact;
dbref helmsman;
int i;
char message[160];

  /* make sure we're active */
  if( ship == NULL ) {
    fnotify( enactor, "%sThis ship is not active.%s", ANSI_CYAN, ANSI_NORMAL );
    return;
  }
  /* Make sure we're undocked */
  if ( !strcmp(fetch_attribute(ship->ship_object, "UNDOCKED"),"0") ) 
   {
       fnotify( enactor, "%sShip is docked.  Unable to cloak.%s", ANSI_CYAN, ANSI_NORMAL );
       return;
   }

  /* make sure we're not set naked */
  if( ship->flags[NAKED] || ship->transwarp_engaging
  || ship->interdict_status==IDICT_ON )
  {
    fnotify( enactor, "%s%sCloak inoperable.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }

  /* make sure we're even allowed to cloak */
  switch( ship->damage[SYSTEM_CLOAK].status ) {
    case 'x':
    case 'X':
      fnotify( enactor, "%s%sThis ship has no cloaking device.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    case '7':
    case '9':
      fnotify( enactor, "%s%sThe cloaking device is damaged and may not be used until repaired.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    default:
      /* cool.  Move on and check shields. */
      break;
  }

  /* make sure it isn't already on */
  if( ship->cloak_status == CLOAK_ON ) {
    fnotify( enactor, "%sCloak is already engaged.%s", ANSI_MAGENTA, ANSI_NORMAL );
    return;
  }

  /* make sure it's not in a think nebula. */
  if( ship->nebula_visibility < .5 ) {
    fnotify( enactor, "%s%sCloak inoperative inside thick nebulas.%s", ANSI_HILITE, ANSI_RED,
           ANSI_NORMAL );
    return;
  }

  /* check for shields */
  for( i = 0; i < 4; i++ )
  {
    if( ship->shield_status[i] == SHLD_DAMAGED )
    {
      fnotify( enactor, "%s%sAll shields must be undamaged to use cloak.%s", 
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    }
  }
  if( ship->smart_alloc==2 )  
  {
      free_power( ship, POWER_NAV_SHIELD_FORE, ship->nalloc_fore );
      free_power( ship, POWER_NAV_SHIELD_AFT, ship->nalloc_aft );
      free_power( ship, POWER_NAV_SHIELD_PORT, ship->nalloc_port );
      free_power( ship, POWER_NAV_SHIELD_STAR, ship->nalloc_starboard );
      requisition_power( ship, POWER_NAV_SHIELD_FORE, (ship->cloak_cost/4) + (ship->cloak_cost%4) );
      requisition_power( ship, POWER_NAV_SHIELD_AFT, ship->cloak_cost/4 );
      requisition_power( ship, POWER_NAV_SHIELD_PORT, ship->cloak_cost/4 );
      requisition_power( ship, POWER_NAV_SHIELD_STAR, ship->cloak_cost/4 );
  }
  /* alright.   Make sure the shield allocation is enough to run the cloak */
  if( ship->nalloc_fore + ship->nalloc_aft + ship->nalloc_port +
    ship->nalloc_starboard < ship->cloak_cost )
  {
    /* not enough juice.  Bum-mer. */
    fnotify( enactor, "%s%sInsufficient energy to engage cloak.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    sprintf( writebuf, "%s%sCloak requires %s%s%d%s%s total allocation to shields.%s",
           ANSI_HILITE, ANSI_RED, ANSI_NORMAL, ANSI_YELLOW, ship->cloak_cost,
           ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    notify( enactor, writebuf );
    return;
  }

  /* Time to cloak.  Set the cloak status first so that the shield  *
   * functions will know to suppress the messages.                  */

  ship->cloak_status = CLOAK_ON;

  lower_shields( ship, enactor, (char *)"all" );
/* Don't hose shields anymore.
  for( i = 0; i < 4; i++ )
    ship->shield_level[i] = 0;
*/
  /* calculate the aspect ratio */
  ship->aspect_ratio = ship->size * ship->cloak_ratio * (float)( ship->reactor_setting ) / 3000.0;

  /* poof!  You're cloaked.  Notify the enactor */
  fnotify( enactor, "%sCloaking device engaged.%s", ANSI_GREEN, ANSI_NORMAL );

  /* now tell anyone who has sensor contact with us that we've cloaked */
  watcher = space_list[current_space];
  while( watcher != NULL ) {
    contact = watcher->contact_list;
    while( contact != NULL ) {
      if( contact->listref == ship ) {
        /* they see us.  Notify their helmsman */
        helmsman = attrib_dbref( watcher->helm, "XB" );
        contact_string( message, contact, INFO_VERBOSE );
        fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s has cloaked.%s",
                 ANSI_YELLOW, ANSI_HILITE, ANSI_MAGENTA, contact->contact_number,
             ANSI_NORMAL, ANSI_YELLOW, ANSI_CYAN, message, ANSI_YELLOW, ANSI_NORMAL );
        /* set contact to the end of the list to break out */
        contact = watcher->contact_tail;
      }
      contact = contact->next;
    }
    watcher = watcher->next;
  }
  return;
}


void disengage_cloak( SHIP *ship, dbref enactor )
{
SHIP *watcher;
CONTACT *contact;
dbref helmsman;
char message[160];

  /* make sure we're active */
  if( ship == NULL ) {
    fnotify( enactor, "%sThis ship is not active.%s", ANSI_CYAN, ANSI_NORMAL );
    return;
  }

  /* switch on the status */
  switch( ship->damage[SYSTEM_CLOAK].status ) {
    case 'x':
    case 'X':
      fnotify( enactor, "%s%sThis ship has no cloaking device.%s", 
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            return;
    case '7':
    case '9':
      fnotify( enactor, "%s%sThe cloaking device is damaged and need not be disengaged.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            return;
    default:
          break;
  }

  /* make sure it isn't not on */
  if( ship->cloak_status == CLOAK_OFF ) {
    fnotify( enactor, "%sCloak is already disengaged.%s", ANSI_MAGENTA, ANSI_NORMAL );
    return;
  }

  /* terrific.  We're cloaked.  Change the status register */
  ship->cloak_status = CLOAK_OFF;

  /* reset the aspect ratio */
  ship->aspect_ratio = ship->size;

  /* notify anyone who can see us - JMS 25 Sep 93 */
  watcher = space_list[current_space];
  while( watcher != NULL ) {
    contact = watcher->contact_list;
    while( contact != NULL ) {
      if( contact->listref == ship ) {
        /* they see us.  Notify their helmsman */
        helmsman = attrib_dbref( watcher->helm, "XB" );
        contact_string( message, contact, INFO_VERBOSE );
        fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s has decloaked.%s",
                 ANSI_YELLOW, ANSI_HILITE, ANSI_MAGENTA, contact->contact_number,
             ANSI_NORMAL, ANSI_YELLOW, ANSI_CYAN, message, ANSI_YELLOW, ANSI_NORMAL );
        /* set contact to the end of the list to break out */
        contact = watcher->contact_tail;
      }
      contact = contact->next;
    }
    watcher = watcher->next;
  }

  /* whee.  That's it.  Notify the enactor */
  fnotify( enactor, "%sCloaking device disengaged.%s", ANSI_GREEN, ANSI_NORMAL );
  return;
}


void reset_coordinates( SHIP *ship, dbref enactor )
{

  sprintf( ship->origin_name, "HRC" );
  ship->origin.x = 0;
  ship->origin.y = 0;
  ship->origin.z = 0;

  atr_add(ship->ship_object, "COORDS", "HRC 0 0 0", (HOWIE), NOTHING );

  notify( enactor, "Coordinates reset to Hub-relative." );
  return;
}


void list_planets( SHIP *ship, dbref enactor )
{
  struct planet_contact *contact;
  XYZ xyz_rel;
  SPH sph_rel;
  char rel_range[5];
  char Empire[15]; 
  char tempb[80];
  STAR *star;
  PLANET *oplanet;

  /* active check */
  if( ship == NULL ) {
    fnotify( enactor, "%sThis ship is inactive.%s", ANSI_CYAN, ANSI_NORMAL );
    return;
  }

  contact = ship->planet_list;

  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ %sPlanet List%s ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
         ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL );
  if( contact == NULL ) {
    notify( enactor, "No planets on sensors." );
    fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ %sEnd Planet List%s ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
           ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL );
    return;
  }

  fnotify( enactor, "%s%s%-20s %-15s %-4s   %-13s   %-9s%s", ANSI_HILITE, ANSI_RED, "Planet Name", 
           "Empire", "Size", "Bearing Range", "Orbitting", ANSI_NORMAL );

  while( contact != NULL ) {
    xyz_rel.x = contact->listref->pos.x - ship->pos.x;
    xyz_rel.y = contact->listref->pos.y - ship->pos.y;
    xyz_rel.z = contact->listref->pos.z - ship->pos.z;
    sph_rel = xyz_to_sph( xyz_rel );

    if( sph_rel.range >= 10000000.0 )
       sprintf( rel_range, "%4.0fM", sph_rel.range / 1000000.0 );
    else if( sph_rel.range >= 100000.0 )
       sprintf( rel_range, "%4.0fK", sph_rel.range / 1000.0 );
    else
       sprintf( rel_range, "%5.0f", sph_rel.range );

    

    sprintf( Empire, "%-15.15s", 
             my_atr_get_raw( contact->listref->planet_object, "EMPIRE" ) );
    if ( !strncmp( Empire, (char *)"#-1", 3 ) )
       sprintf( Empire, "None" );
       
    if((star=find_star(attrib_dbref(contact->listref->planet_object,"ORBITTING"))))
    {
     strcpy(tempb,star->name);
     }
    else if ((oplanet=find_planet(attrib_dbref(contact->listref->planet_object,"ORBITTING"))))
     {
     	strcpy(tempb,oplanet->name);
     }
    else
     {
         strcpy(tempb,"Nothing");
     }
 /*   if ( (star!=NULL) || (oplanet != NULL) ) */
    
    fnotify( enactor, "%s%-20.20s %s%-15.15s %s%s%-4.1f   %s%-3.0f %-+3.0f %-5s   %s%s%-10s%s", 
             ANSI_CYAN, contact->name,
             ANSI_MAGENTA, Empire,
             ANSI_HILITE, ANSI_RED, contact->listref->size, 
             ANSI_CYAN, sph_rel.bearing, sph_rel.elevation, rel_range,
             ANSI_NORMAL, ANSI_HILITE, tempb,
             ANSI_NORMAL );
     
    
/*     else
     {
     	fnotify( enactor, "%s%-20.20s %s%-15.15s %s%s%-4.1f   %s%-3.0f %-+3.0f %-5s   %s%sNothing%s", 
             ANSI_CYAN, contact->name,
             ANSI_MAGENTA, Empire,
             ANSI_HILITE, ANSI_RED, contact->listref->size, 
             ANSI_CYAN, sph_rel.bearing, sph_rel.elevation, rel_range,
             ANSI_NORMAL, ANSI_HILITE,
             ANSI_NORMAL );	
	} */
    contact = contact->next;
  }
  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ %sEnd Planet List%s ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
         ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL );

  return;
}


void set_coordinates( SHIP *ship, dbref enactor, char *frame, char *label )
{
  struct planet_contact *contact;

  contact = ship->planet_list;

  while( contact != NULL )
  {
    if( strstr( contact->name, frame )) {
      /* okay, we found it.  set the new frame and return */
      ship->origin.x = contact->listref->pos.x;
      ship->origin.y = contact->listref->pos.y;
      ship->origin.z = contact->listref->pos.z;
      label[3] = '\0';
      strncpy( ship->origin_name, label, 3 );

      /* update the ship object */

      sprintf( writebuf, "%s %f %f %f", label, ship->origin.x,
               ship->origin.y, ship->origin.z );
      atr_add(ship->ship_object, "COORDS", writebuf, (HOWIE), NOTHING );

      sprintf( writebuf, "Coordinates now reported relative to planet %s.",
               contact->name );
      notify( enactor, writebuf );
      return;
    }
    contact = contact->next;
  }
  notify( enactor, "There is no planet on sensors that matches that name." );
  return;
}


/**************************************
 *
 * engage_autopilot()
 *
 *  input:
 *    SHIP *ship       ship
 *    dbref enactor                    navigator
 *    char *xc, *yc, *zc            char strings of desired coords
 *    char *alarm                   alarm string
 *
 *  purpose:
 *    sets the ship on autopilot heading for the specified point.  Upon
 *    reaching said point, the alarm message is flashed to the navigator.
 *
 *  return value:
 *    none
 *
 * jms 24 May 93
 *
 *************************************/

void engage_autopilot( SHIP *ship, dbref enactor, char *xc, char *yc, char *zc, char *alarm )
{
  XYZ destination;
  SPH sph;

  if( ship->transwarp_engaging )
  {
    fnotify( enactor, "%s%sUnable to alter coordinates, transwarp is locked.%s",
        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
  /* get the sph coords */
  sph.bearing = (float) atoi( xc );
  sph.elevation = (float) atoi( yc );
  sph.range = (float) atoi( zc );

  /* check for legal values */
  if(( sph.bearing > 359 ) || ( sph.bearing < 0 )) {
   fnotify( enactor, "%s%sValid headings are from 0 to 359.%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);
    return;
  }

  if(( sph.elevation > 90 ) || ( sph.elevation < -90 )) {
    fnotify( enactor, "%s%sValid elevation/depressions are from -90 to 90 inclusive.%s", 
            ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL); 
    return;
  }

  
  /* convert to xyz coords */
  destination = sph_to_xyz( sph );

  sph = xyz_to_sph( destination );

  /* set the autopilot flag */
  ship->on_autopilot = TRUE;

  /* note:  no need to set a course.  the first autopilot_dest_check
   * will take care of that.
   */
  ship->autopilot_destination = destination;

  /* save the alarm string */
  strncpy( ship->autopilot_alarm, alarm, 79 );

  /* save the enactor */
  ship->autopilot_doer = enactor;

  /* notify the enactor */
    fnotify( enactor, "%s%sAutopilot engaged.%s", ANSI_HILITE, ANSI_CYAN,
ANSI_NORMAL );

    fnotify( enactor, "%sDestination(%s): %sbearing: %s%s%3.0f%s%s  elevation: %s%s%+3.0f%s%s  range: %s%s%8.0f%s", 
           ANSI_CYAN, ship->origin_name, ANSI_WHITE, ANSI_HILITE,
ANSI_RED, sph.bearing, ANSI_NORMAL, 
           ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.elevation, ANSI_NORMAL, 
           ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.range, ANSI_NORMAL );
    return;
}

/* Like engage_autopilot, but takes XYZ coords. */

void engage_xyzautopilot( SHIP *ship, dbref enactor, char *xc,
                        	  char *yc, char *zc, char *alarm )
{
     XYZ destination;
     SPH sph;

     /* get the float coords */
     destination.x = (float)atoi( xc );
     destination.y = (float)atoi( yc );
     destination.z = (float)atoi( zc );

     sph = xyz_to_sph( destination );

     /* set the autopilot flag */
     ship->on_autopilot = TRUE;

    /* note:  no need to set a course.  the first autopilot_dest_check
     * will take care of that.
     */
    ship->autopilot_destination = destination;
    ship->previous_distance = distance(ship->pos,destination) + 100.0;

    /* save the alarm string */
    strncpy( ship->autopilot_alarm, alarm, 79 );

    ship->autopilot_doer = enactor;

    fnotify( enactor, "%s%sAutopilot engaged.%s", ANSI_HILITE, ANSI_CYAN,
ANSI_NORMAL );

    fnotify( enactor, "%sDestination(%s): %sbearing: %s%s%3.0f%s%s  elevation: %s%s%+3.0f%s%s  range: %s%s%8.0f%s", 
        ANSI_CYAN, ship->origin_name, ANSI_WHITE, ANSI_HILITE, ANSI_RED,
sph.bearing, ANSI_NORMAL, 
        ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.elevation, ANSI_NORMAL, 
        ANSI_WHITE, ANSI_HILITE, ANSI_RED, sph.range, ANSI_NORMAL );
    autopilot_dest_check( ship );
    return;
}

/*
 * disengage_autopilot()
 *  input:
 *    SHIP *ship         ship to check
 *    dbref enactor         a check for $3000
 *  purpose:
 *    turns off the autopilot, flashes an abort warning to the auto enactor,
 *    LEAVES THE WARP DRIVES RUNNING.
 *  return value:
 *    none
 * JMS 24 May 93
 */

void disengage_autopilot( SHIP *ship, dbref enactor )
{
  if( !ship->on_autopilot ) {
    notify( enactor, "Autopilot is not currently engaged." );
    return;
  }

  ship->on_autopilot = FALSE;
  /*
  sprintf( writebuf, "AUTIPILOT ABORT: %s", ship->autopilot_alarm );
  notify( ship->autopilot_doer, writebuf );
  */
  notify( enactor, "Autopilot disengaged." );
  ship->autopilot_alarm[0] = '\0';
}

/**************************************
 *
 * autopilot_dest_check()
 *
 *  input:
 *    SHIP *ship         ship to check
 *
 *  purpose:
 *    checks to see if the ship is at it's destination
 *
 *  return value:
 *    none
 *
 * JMS 24 May 93
 *
 *************************************/

void autopilot_dest_check( SHIP *ship )
{
    float current_distance;
    XYZ ccourse;
    SPH scourse;

    if( ship->flags[DISABLED] )
    {
        return;
    }
    current_distance = distance( ship->pos, ship->autopilot_destination );
    if( current_distance >= ship->previous_distance-ship->motion.range+10.0
    || current_distance > ship->previous_distance )
    {
        if( current_distance > ship->motion.range )
        {
            ccourse.x = ship->autopilot_destination.x - ship->pos.x;
            ccourse.y = ship->autopilot_destination.y - ship->pos.y;
            ccourse.z = ship->autopilot_destination.z - ship->pos.z;

            scourse = xyz_to_sph( ccourse );

            /* set the new course */
            nav_new_course( (int)scourse.bearing, (int)scourse.elevation,
                      ship, ship->autopilot_doer );
            ship->previous_distance = current_distance;
        }
        else
        {
            ship->pos = ship->autopilot_destination;

            ship->on_autopilot = FALSE;

            set_warp( ship, ship->autopilot_doer, 0.0 );

            sprintf( writebuf, ship->autopilot_alarm );
            notify_room( BRIDGE(ship), writebuf );
        }
    }
    else
    {
        /* not there yet */
        ship->previous_distance = current_distance;
    }
    return;
}

void sensor_sweep( SHIP *ship, dbref enactor )
{

  /* active check */
  if( ship == NULL ) {
    fnotify( enactor, "%sThis ship is inactive.%s", ANSI_CYAN, ANSI_NORMAL );
    return;
  }

  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ %sSensor Sweep%s ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
         ANSI_HILITE, ANSI_MAGENTA, ANSI_YELLOW, ANSI_MAGENTA, ANSI_NORMAL );

  fnotify( enactor, "%s%sInside Name                 Bearing Range   Density   Size   Facing Shield%s",
         ANSI_HILITE, ANSI_RED, ANSI_NORMAL );

  list_nebulas(ship, enactor);
  list_asteroids(ship,enactor);
  list_wormholes(ship,enactor);
  list_shockwaves(ship,enactor);
  list_plasma(ship, enactor);

  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ %sEnd Sensor Sweep%s ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
         ANSI_HILITE, ANSI_MAGENTA, ANSI_YELLOW, ANSI_MAGENTA, ANSI_NORMAL );
  return;
}

void kamikaze_attack( SHIP *ship, dbref enactor, char *target_name )
{
    int damage,damage0,damage1,shield_hit,target_number;
    char rammer_string[120],target_string[120];
    CONTACT *contact,*rammer,*target=NULL;
    SHIP *victim,*observer;
    SHIP fake_ship;
    dbref helmsman;
    WDATA weapon0 = {WPN_RAM,1.0,1.0,1.0,1};
    WDATA weapon1 = {WPN_KAMIKAZE,1.0,1.0,1.0,1};
    if( ship->flags[STARBASE] )
    {
        fnotify( enactor, "Bases cannot ram other targets." );
        return;
    }
    if( ship->flags[DISABLED] )
    {
        fnotify( enactor, "Ship disabled: cannot ram." );
        return;
    }
    target_number = atoi( target_name );
    if( target_number )
    {
        for(contact=ship->contact_list;contact!=NULL;contact=contact->next)
        {
            if( contact->contact_number == target_number )
            {
                target = contact;
                contact = NULL;
                break;
            }
        }
        if( target==NULL )
        {
            fnotify( enactor, "%s%sInvalid contact number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            return;
        }
    }
    else
    {
        if( !strcmp( target_name, "" ) )
        {
            fnotify( enactor, "%s%sYou must specify a target name or contact number.%s",
                ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            return;
        }

        contact = ship->contact_list;
        for(contact=ship->contact_list;contact!=NULL;contact=contact->next)
        {
            if( contact->info_level==5 )
            {
                if( !strstr(contact->listref->name,target_name) )
                {
                    target = contact;
                    contact = NULL;
                    break;
                }
            }
        }
        if( target==NULL )
        {
            fnotify( enactor, "%s%sNo contact with any ship called '%s%s%s%s%s'.%s", ANSI_HILITE,
                ANSI_RED, ANSI_NORMAL, ANSI_CYAN, target_name, ANSI_HILITE, ANSI_RED,
                ANSI_NORMAL );
            return;
        }
    }
    victim = target->listref;
    if( distance( ship->pos, victim->pos ) > 10 )
    {
        fnotify( enactor, "You must be within 10 ranges to ram a target." );
        return;
    }
    if( victim->warp_speed > 0.0 && ( ship->tractor_target==NULL
    || ship->tractor_target->listref==victim ) )
    {
        fnotify( enactor, "Target is in motion, unable to ram." );
        return;
    }
    rammer = NULL;
    for(contact=victim->contact_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref==ship )
        {
            rammer = contact;
            break;
        }
    }
    if( rammer==NULL )
    {
        contact_string( rammer_string, rammer, INFO_TERSE );
        sprintf( writebuf, "%s%sCOLLISION: Unknown Contact has collided with this ship!%s",
            ANSI_RED, ANSI_HILITE, ANSI_NORMAL );
    }
    else
    {
        contact_string( rammer_string, rammer, INFO_TERSE );
        sprintf(writebuf, "%s%sCOLLISION: Contact [%s%d%s%s]: %s%s%s has collided with this ship!%s",
            ANSI_RED, ANSI_HILITE, ANSI_MAGENTA, rammer->contact_number, ANSI_NORMAL,
            ANSI_CYAN, ANSI_NORMAL, rammer_string, ANSI_CYAN, ANSI_NORMAL );        
    }
    notify_room( BRIDGE(victim), writebuf );
    victim->battle_timer = TIMER_RESET;
    ship->battle_timer = TIMER_RESET;
    /* Hey, I got an idea, let's tell everyone else too! */
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship || observer==victim )
        {
            continue;
        }
        target = NULL;
        rammer = NULL;
        for(contact=observer->contact_list;contact!=NULL;contact=contact->next)
        {
            if( contact->listref==ship )
            {
                rammer = contact;
                if( target!=NULL )
                    break;
            }
            else if( contact->listref==victim )
            {
                target = contact;
                if( rammer!=NULL )
                    break;
            }
        }
        /* find observer helmsman's dbref */
        helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);

        /* OK we got 4 cases here */
        if( rammer==NULL && target==NULL )
        {
        }
        else if( rammer==NULL )
        {
            contact_string( target_string, target, INFO_TERSE );

            fnotify( helmsman, "%sUnknown source collided with contact [%s%s%d%s%s]: %s%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, target->contact_number, ANSI_NORMAL,
                ANSI_CYAN, ANSI_NORMAL, target_string );
        }
        else if( target == NULL )
        {
            contact_string( rammer_string, rammer, INFO_TERSE );

            fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s collided with unknown target.%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, rammer->contact_number, ANSI_NORMAL,
                ANSI_CYAN, ANSI_NORMAL, rammer_string, ANSI_CYAN, ANSI_NORMAL );
        }
        else
        {
            contact_string( rammer_string, rammer, INFO_TERSE );
            contact_string( target_string, target, INFO_TERSE );

            fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s collided with contact [%s%s%d%s%s]: %s%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, rammer->contact_number, ANSI_NORMAL,
                ANSI_CYAN, ANSI_NORMAL, rammer_string, ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA,
                target->contact_number, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, target_string );
        }
    }
    fake_ship = (*victim);
    fake_ship.target_system = SYSTEM_HULL;
    shield_hit=facing_shield(ship,victim);
    damage0 = ship->hull_integrity + ship->hull_integrity/3 + 1;
    if( ship->shield_status[0]==SHLD_UP )
    {
        damage0 += ship->shield_level[0];
    }
    damage1 = victim->hull_integrity + victim->hull_integrity/3 + 1;
    if( victim->shield_status[shield_hit]==SHLD_UP )
    {
        damage1 += victim->shield_level[shield_hit];
    }
    battle_damage(ship,victim,damage0,weapon0);
    battle_damage(&fake_ship,ship,damage1,weapon1);
    return;
}


void fire_shields( SHIP *ship, dbref enactor )
{
    char shooter_string[120],target_string[120];
    dbref navigator,dmg_officer;
    CONTACT *shooter,*shootee;
    int damage,i,mrange=0,dist;
    SHIP *target,*observer;
    WDATA weapon = {WPN_GUN,0.9,1.0,0.9,1};
    static char *shield_strings[]=
    {
        (char *)"Fore",
        (char *)"Aft",
        (char *)"Port",
        (char *)"Starboard"
    };

    if( ship->locked_target==NULL || ( target=ship->locked_target->listref )==NULL )
    {
        notify( enactor, "Weapons are not locked onto a target." );
        return;
    }
    if( ship->cloak_status==CLOAK_ON )
    {
        notify( enactor, "May not fire while cloaked." );
        return;
    }
    if( ship_is_safe(ship->locked_target->listref) )
    {
        fnotify( enactor, "%s%sThat ship is safe. Unable to fire.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    for(i=0;i<4;i++)
    {
        if( ship->shield_status[i]!=SHLD_READY )
        {
            notify( enactor, "Shields must be down and not damaged." );
            return;
        }
    }
    for(i=0,damage=0;i<4;i++)
    {
        if( ship->shield_status[i]!=SHLD_DAMAGED )
        {
            damage += ship->shield_level[i] * 3/4;
            mrange += ship->shield_level[i];
        } 
    }
    if( ( dist=distance(ship->pos,target->pos) ) > mrange )
    {
        notify( enactor, "Target is out of range." );
        return;
    }
    if( mrange )
    {
        damage -= damage * dist / mrange;
        fnotify (enactor, "Firing deflector blast");
    }
    navigator = attrib_dbref( ship->nav, "XB" );
    dmg_officer = attrib_dbref( ship->damcon, "XB" );
    for(i=0;i<4;i++)
    {
        ship->shield_level[i] = 0;
        if( FRAND < 0.6 )
        {
            ship->damage[SYSTEM_SHIELD_FORE+i].status='7';
            ship->damage[SYSTEM_SHIELD_FORE+i].time_to_fix = 600;
            ship->shield_status[i] = SHLD_DAMAGED;
            sprintf( writebuf, "%s%s%s shield damaged.%s", ANSI_HILITE, ANSI_RED,
                shield_strings[i], ANSI_NORMAL );
            notify( navigator, writebuf );
            if( navigator!=dmg_officer )
            {
                notify( dmg_officer, writebuf );
            }
        }
    }
    ship->battle_timer = TIMER_RESET;
    target->battle_timer = TIMER_RESET;
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship || observer==target )
        {
            continue;
        }
        shooter=find_contact(observer,ship);
        shootee=find_contact(observer,target);
        if( shooter==NULL && shootee==NULL )
        {
            continue;
        }
        if( shooter==NULL )
        {
            contact_string( target_string, shootee, INFO_TERSE );
            sprintf( writebuf, "Unknown source has fired upon contact [%d]: %s",
                shootee->contact_number, target_string );
        }
        else if( shootee==NULL )
        {
            contact_string( shooter_string, shooter, INFO_TERSE );
            sprintf( writebuf, "Contact [%d]: %s has fired upon unknown contact.",
                shooter->contact_number, shooter_string );
        }
        else
        {
            contact_string( shooter_string, shooter, INFO_TERSE );
            contact_string( target_string, shootee, INFO_TERSE );
            sprintf( writebuf, "Contact [%d]: %s has fired upon contact [%d]: %s",
                shooter->contact_number, shooter_string, shootee->contact_number, target_string );
        }
        notify_room( BRIDGE(observer), writebuf );
    }
    shooter=find_contact(target,ship);
    if( shooter!=NULL )
    {
        contact_string( shooter_string, shooter, INFO_TERSE );
        sprintf( writebuf, "Enemy deflector dish blast fired by [%d]: %s",
            shooter->contact_number, shooter_string );
    }
    else
    {
        sprintf( writebuf,"Enemy deflector dish blast fired by unknown source!" );
    }
    notify_room( BRIDGE(target), writebuf );
    battle_damage( ship, target, damage, weapon );
    return;
}

void ship_interdict_check( SHIP *ship )
{
    SHIP *idict;

    for(idict=space_list[current_space];idict!=NULL;idict=idict->next)
    {
        if( idict->interdict_status!=IDICT_ON
        || distance(idict->pos,ship->pos) > idict->interdict_range )
        {
            continue;
        }
        if( ship->warp_speed > idict->interdict_speed )
        {
            sprintf(writebuf,"%s%sWARNING: Warp field has collapsed!%s",
                ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
            notify_room( BRIDGE(ship), writebuf );
            if( FRAND < (ship->warp_speed-idict->interdict_speed) / idict->interdict_speed )
            {
                break_system( ship, SYSTEM_WARP );
            }
            set_warp( ship, -1, 0.0 );
        }
        if( ship->transwarp_engaging )
        {
            ship->transwarp_charge = 0;
        }
    }
    return;
}

void toggle_interdict( SHIP *ship, dbref enactor )
{
    switch( ship->interdict_status )
    {
        default:
        case IDICT_NONE:
            fnotify( enactor, "%s%sThis ship is not equipped with a warp dissipator.%s",
                ANSI_GREEN, ANSI_HILITE, ANSI_NORMAL );
            break;
        case IDICT_OFF:
            ship->interdict_status = IDICT_ON;
            fnotify( enactor, "%s%sWarp dissipator activated.%s",
                ANSI_RED, ANSI_HILITE, ANSI_NORMAL );
            if( ship->warp_speed > ship->interdict_speed )
            {
                set_warp( ship, enactor, ship->interdict_speed );
            }
            if( ship->cloak_status==CLOAK_ON )
            {
                disengage_cloak( ship, enactor );
            }
            break;
        case IDICT_ON:
            ship->interdict_status = IDICT_OFF;
            fnotify( enactor, "%s%sWarp dissipator deactivated.%s",
                ANSI_RED, ANSI_HILITE, ANSI_NORMAL );
            break;
        case IDICT_BROKEN:
            fnotify( enactor, "%s%sWarp dissipator is inoperative.%s",
                ANSI_MAGENTA, ANSI_HILITE, ANSI_NORMAL );
            break;
    }
    return;
}


float translate_warp( float warp )
{
    if( warp <= 0.0 )
    {
        return 0.0;
    }
#if defined(WARP_IMPULSE)
    else if( warp < 1.0 )
    {
        return warp*LIGHTSPEED;
    }
    else
    {
        return (warp*warp*warp)+LIGHTSPEED;
    }
#else
    return warp*warp*warp;
#endif
}
void land_ok( SHIP *ship, dbref enactor, struct planet_contact *planet, char *buff, char **bp )
{

  if( planet == NULL )
  {
    fnotify( enactor, "Planet not on sensors." );
    sprintf( writebuf, "NO" );
    safe_str( writebuf, buff, bp);
  }
  else
  {
  if( distance( ship->pos, planet->listref->pos ) > 5 && ship->warp_speed < 1 && planet != NULL )
  {
    fnotify( enactor, "Planet too far away, must be under 5 units away." );
    sprintf( writebuf, "NO" );
    safe_str( writebuf, buff, bp);
  }
  if( ship->flags[DISABLED] && planet != NULL )
  { 
    fnotify( enactor, "Ship is disabled and cannot land." );
    sprintf( writebuf, "NO" );
    safe_str( writebuf, buff, bp);
  }
  if( ship->warp_speed >=1 && planet != NULL )
  { 
    fnotify( enactor, "Ship cannot land while at warp." );
    sprintf( writebuf, "NO" );
    safe_str( writebuf, buff, bp);
  }
  if( current_space != REAL && planet != NULL )
   {
    fnotify( enactor, "Not in the sims" );
    sprintf( writebuf, "NO" );
    safe_str( writebuf, buff, bp);
   }
  if( planet != NULL && current_space == REAL && ship->warp_speed < 1 && distance( ship->pos, planet->listref->pos ) < 5 && planet != NULL )
   {
    fnotify( enactor, "Ship now in approach pattern.");
    sprintf( writebuf, "YES" );
    safe_str( writebuf, buff, bp );
   }
  }
 }

 void dock_ok( SHIP *ship, dbref enactor, char *target, char *buff, char **bp )
{
  CONTACT *spacedock;
  int shields=0, i;
  spacedock = match_contact( ship, target );
    if( spacedock == NULL || spacedock->listref->flags[ISPLANET] )
    {
        fnotify( enactor, "%sInvalid target.%s", ANSI_MAGENTA, ANSI_NORMAL );
    }
    else
     {
      if( target == NULL )
     {
      fnotify( enactor, "Ship not on sensors." );
      sprintf( writebuf, "NO" );
      safe_str( writebuf, buff, bp);
      return;
      }
      if( !strcmp(fetch_attribute(ship->ship_object,"UNDOCKED"),"0") )
      {
       fnotify( enactor, "You are already docked." );
       return;
      }
      if( distance( ship->pos, spacedock->listref->pos ) > 5 && ship->warp_speed < 1 && target != NULL )
      {
       fnotify( enactor, "Planet too far away, must be under 5 units away." );
       sprintf( writebuf, "NO" );
       safe_str( writebuf, buff, bp);
      }
     if( ship->flags[DISABLED] && target != NULL )
      { 
       fnotify( enactor, "Ship is disabled and cannot land." );
       sprintf( writebuf, "NO" );
       safe_str( writebuf, buff, bp);
      }
     if( ship->warp_speed >=1 && target != NULL )
      { 
       fnotify( enactor, "Ship cannot land while at warp." );
       sprintf( writebuf, "NO" );
       safe_str( writebuf, buff, bp);
      }
    if( current_space == REAL && ship->flags[SHUTTLECRAFT] && target != NULL)
      {
       sprintf( writebuf, "SHUTTLE" );
       safe_str( writebuf, buff, bp);
      }
    if( current_space != REAL && target != NULL )
     {
      fnotify( enactor, "Not in the sims" );
      sprintf( writebuf, "NO" );
      safe_str( writebuf, buff, bp);
     }
   for( i = 0; i < 4; i++ )
    {
        if( ship->shield_status[i] == SHLD_UP )
        {
            fnotify( enactor, "%s%sShields must be lowered prior to docking.%s", ANSI_HILITE,
                ANSI_RED, ANSI_NORMAL );
            shields = 1;
        }
    }

   if( target != NULL && current_space == REAL && ship->warp_speed < 1 && distance( ship->pos, spacedock->listref->pos ) < 5 && target != NULL && shields !=1)
     {
      fnotify( enactor, "Ship now in approach pattern.");
      sprintf( writebuf, "YES" );
      safe_str( writebuf, buff, bp );
     }
   }
 }
/*More Howie Code.  Auto Intercept course..just a loop */
void intercept(SHIP *ship, dbref enactor, char *target)
{
  CONTACT *contact;
  SPH sph_rel;
  XYZ xyz_rel;
  contact = match_contact( ship, target );

  if( contact == NULL )
  {
   fnotify(enactor, "That is not a valid contact" );
  }
   if( ship->flags[DISABLED] )
  {
       fnotify( enactor, "%s%sShip disabled, unable to change course.%s",
           ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
       return;
  }
  
  if( ship->warp_speed == 0 )
  {
    fnotify(enactor, "%s%sCannot intercept while standing still%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
    return;
  }
  if( contact != NULL && (distance(ship->pos,contact->listref->pos) > 500) )
  {
    ship->intercepting = 1;
    ship->interceptor = contact->listref;
    fnotify( enactor, "%s%sNow intercepting.%s", ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL ); 
  }
  else
  {
    fnotify(enactor,"%s%sShip too close to intercept, fly manually.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
  }
}  

void remote_down( SHIP *ship, dbref enactor, char *target, char *code )
{
   CONTACT *contact;
   contact = match_contact( ship, target ); 

   if( contact == NULL )
   {
     fnotify( enactor, "%s%sContact not on sensors%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
     return;
   }

   if ( !strcmp(code,fetch_attribute(contact->listref->ship_object,"SHIP_PREFIX")) )
      {
        fnotify( enactor, "%s%sFrom Target:%s", ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL);
        lower_shields( cfind_ship(contact->listref->ship_object), enactor,(char *) "all");
        door_control( cfind_ship(contact->listref->ship_object), enactor, 0);
        fnotify( enactor, "%s%sTaget ready to be docked in.%s",ANSI_HILITE, ANSI_CYAN,ANSI_NORMAL);
      }
    else
      {
        fnotify( enactor, "Invalid code: Permission Denied." );
      }
}

void remote_undock( dbref enactor, dbref ship_object, char *code )
{
    dbref sdock;
  
    sdock = attrib_dbref(ship_object,"DOCKED_AT");
  
     if ( !strcmp(code,fetch_attribute(sdock,"SHIP_PREFIX")) )
      {
        fnotify(enactor,"%s%sFrom dock:%s", ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL);
        lower_shields( cfind_ship(sdock), enactor, (char *) "all");
        door_control( cfind_ship(sdock), enactor, 0);
        fnotify( enactor, "%s%sReady to undock.%s",ANSI_HILITE, ANSI_CYAN,ANSI_NORMAL);
      }
    else
      {
        fnotify( enactor, "Invalid code: Permission Denied." );
      }
}

void remote_up( dbref enactor, dbref executor )
{
   dbref target;
   target = attrib_dbref(executor,"DOCKED_TO");

   raise_shields( cfind_ship(target), enactor, (char *) "all");
   door_control( cfind_ship(target), enactor, 1);
}

void remote_raise_shields( dbref enactor, SHIP *ship, char *target, char *code )
{
   CONTACT *contact;
   contact = match_contact( ship, target );
   
   if( contact == NULL )
   {
     fnotify( enactor, "%s%sContact not on sensors%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
     return;
   }

   if ( !strcmp(code,fetch_attribute(contact->listref->ship_object,"SHIP_PREFIX")) )
      {
        fnotify( enactor, "%s%sFrom Target:%s",ANSI_HILITE, ANSI_CYAN,ANSI_NORMAL);
        raise_shields( cfind_ship(contact->listref->ship_object), enactor, (char *) "all");
      }
    else
      {
        fnotify( enactor, "Invalid code: Permission Denied." );
      }
}   

void remote_lower_shields( dbref enactor, SHIP *ship, char *target, char *code )
{
   CONTACT *contact;
   contact  = match_contact( ship, target );
   
   if( contact == NULL )
   {
     fnotify( enactor, "%s%sContact not on sensors%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
     return;
   }

   if ( !strcmp(code,fetch_attribute(contact->listref->ship_object,"SHIP_PREFIX")) )
      {
        fnotify( enactor, "%s%sFrom Target:%s",ANSI_HILITE, ANSI_CYAN,ANSI_NORMAL);
        lower_shields( cfind_ship(contact->listref->ship_object), enactor, (char *) "all");
      }
    else
      {
        fnotify( enactor, "Invalid code: Permission Denied." );
      }
}     

void remote_decloak( SHIP *ship, dbref enactor, char *target, char *code )
{
   CONTACT *contact;
   contact  = match_contact( ship, target );

   /*self explanatory, as a matter of fact, all these remote functions are */

   if( contact == NULL )
   {
     fnotify( enactor, "%s%sContact not on sensors%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
     return;
   }

   if ( !strcmp(code,fetch_attribute(contact->listref->ship_object,"SHIP_PREFIX")) )
      {
        fnotify( enactor, "%s%sFrom Target:%s",ANSI_HILITE, ANSI_CYAN,ANSI_NORMAL);
        disengage_cloak( cfind_ship(contact->listref->ship_object), enactor);
      }
    else
      {
        fnotify( enactor, "Invalid code: Permission Denied." );
      }
}

void remote_cloak( SHIP *ship, dbref enactor, char *target, char *code)
{
   CONTACT *contact;
   contact  = match_contact( ship, target );
   
   if( contact == NULL )
   {
     fnotify( enactor, "%s%sContact not on sensors%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
     return;
   }

   if ( !strcmp(code,fetch_attribute(contact->listref->ship_object,"SHIP_PREFIX")) )
      {
        fnotify( enactor, "%s%sFrom Target:%s",ANSI_HILITE, ANSI_CYAN,ANSI_NORMAL);
        engage_cloak( cfind_ship(contact->listref->ship_object), enactor);
      }
    else
      {
        fnotify( enactor, "Invalid code: Permission Denied." );
      }
}

void eta( SHIP *ship, dbref enactor )
{
   float dist;
   int seconds, minutes, hours;
   
   /* Ok, here's the deal: Gotta make sure ship is moving and has the autopilot on. */
   if( !ship->on_autopilot )
   {
      fnotify(enactor, "%s%sNo autopilot destination selected.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
      return;
   }
   if( ship->transwarp_engaging )
   {
     fnotify( enactor, "%s%sShip is charging transwarp, your guess is as good as mine.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
     return;
   }
   if( ship->warp_speed == 0 )
  {
     fnotify(enactor, "%s%sYour ship is not moving...ETA is infinity.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
     return;
  }
   
   /*Ok, everything is valid, let's do some figuring */

   dist = distance( ship->pos, ship->autopilot_destination );
   seconds = 2 * (dist / (pow(ship->warp_speed,3) + 500) );
   minutes = seconds / 60;
   hours = minutes / 60;

  /* Be sure to return right units */   
   if ( minutes < 1 )
   {
    fnotify( enactor, "%s%sETA: %s%d seconds. %s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, seconds, ANSI_NORMAL);
    }
   else if( minutes < 60)
   { 
     fnotify( enactor, "%s%sETA: %s%d minutes, %d seconds. %s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, minutes, seconds - (minutes * 60), ANSI_NORMAL);
   }
   else
   {
      fnotify( enactor, "%s%sETA: %s%d hours, %d minutes, %d seconds.%s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, hours, (minutes - (hours*60)), (seconds - (minutes*60)), ANSI_NORMAL);
   }

}
  
