/* function.c */
/* Philip 12/98, functions to return status values */

FUNCTION(space)
{
  SHIP *ship;
  dbref ship_object;

   if( !Wizard(executor) || args[0]==NULL )
   {
     safe_str("#-1 PERMISSION DENIED", buff, bp );
     return;
   }

  /* get the dbref of the ship object */
  ship_object = attrib_dbref( executor, "SHIP_OBJECT" );
  if( !GoodObject( ship_object )) {
    safe_str("#-1 BAD SHIP OBJECT", buff, bp );
    return;
  }

  if( ship == NULL )
  {
    safe_str("#-1 SHIP INACTIVE", buff, bp);
    return;
  }
  else if (!strcmp(args[0], "pos")) {
    /* return ship position */
    sprintf(writebuf, "%d %d %d", ship->pos.x, ship->pos.y, ship->pos.z);
    safe_str(writebuf, buff, bp);
  }
  else if (!strcmp(args[0], "motion")) {
    /* return ship motion */
    sprintf(writebuf, "%d %d %f", ship->motion.bearing, ship->motion.elevation,
		ship->warp_speed);
    safe_str(writebuf, buff, bp);
  }
  else if (!strcmp(args[0], "course")) {
    /* return ship course */
    sprintf(Writebuf, "%d %d %f", ship->course.bearing, ship->course.elevation,
		ship->warp_speed);
    safe_str(writebuf, buff, bp);
  }
  else {
    safe_str("#-1 INVALID ARGUMENT", buff, bp);
  }
  return;
}
