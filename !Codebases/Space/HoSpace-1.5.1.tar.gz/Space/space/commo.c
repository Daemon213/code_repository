/*
 * $Id: commo.c,v 1.4 1993/09/28 05:20:03 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: commo.c,v $
 * Revision 1.4  1993/09/28  05:20:03  chuckles
 * transmitter range to float.  sensornet stuff.
 *
 * Revision 1.3  1993/09/25  20:39:40  chuckles
 * cleaned up logging code
 *
 * Revision 1.2  1993/09/21  03:24:01  chuckles
 * minor bulletproofing
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 */

/*
 * JMS 26 Aug 93 - use SHIP_OBJECT instead of XA
 */
FUNCTION(fun_comm_cmd)
{
   SHIP *ship;
//   PLANET *planet;
   dbref ship_object;

  if (!Wizard(executor)) {
    safe_str("#-1 PERMISSION DENIED", buff, bp );
    return;
  }
  
    if( !strcmp(args[0],"compin_activate"))
   {
   	compin_activate( enactor, executor);
   	return;
   }
   
    if( !strcmp(args[0],"compin_send"))
   {
   	compin_send( enactor, executor, atoi(args[1]), args[2], cfind_ship(executor));
   	return;
   }
   
   if(!strcmp( args[0], "compin_deactivate"))
   {
   	compin_deactivate( enactor, executor );
   	return;
   }
   if( !strcmp( args[0], "set_com_freq" ))
   {
   	set_com_freq( executor, atoi(args[1]) );
   	return;
   }
   /* get the dbref of the ship object */
   ship_object = attrib_dbref( executor, "SHIP_OBJECT" );
   if( ship_object == NOTHING ) {
      safe_str("#-1 BAD SHIP OBJECT", buff, bp );
      return;
   }

   /* now set the ship pointer to the proper ship and also set the
    * space list to the list that contains it (handled by cfind_ship).
    */
   ship = cfind_ship( ship_object );
      
   /* no comm commands will work for an inactive ship or planet */
   if( ship == NULL )
   {
      /* Don't generate this message for unintentional sends */
      if( !strstr( args[0], "_send" ))
      fnotify( enactor, "%sShip must be active to use that command.%s", ANSI_CYAN, ANSI_NORMAL );
      return;
   }
   

   /* Everything is fine so far.  Switch on the command argument */
   /* Apparently a ship */
   if( !strcmp( args[0], "commrange" ) )
   {
      sprintf(writebuf,"%.0f", ship->transmitter_range );
      safe_str(writebuf, buff, bp);
   }
   else if( !strcmp( args[0], "status" ))
   {
      comm_status( ship, enactor );
   }
   else if( !strcmp( args[0], "set_channel" ))
   {
      set_channel( ship, enactor, atoi( args[1] ), atoi( args[2] ));
   }
   else if( !strcmp( args[0], "label_channel" ))
   {
      label_channel( ship, enactor, atoi( args[1] ), args[2] );
   }
   else if( !strcmp( args[0], "comm_send" ))
   {
      comm_send( ship, enactor, atoi( args[1] ), args[2] );
   }
   else if( !strcmp( args[0], "audio_send" ))
   {
      audio_send( ship, args[1] );
   }
   else if( !strcmp( args[0], "visual_send" ))
   {
      visual_send( ship, args[1] );
   }
   else if( !strcmp( args[0], "set" ))
   {
      set_channel_setting( ship, enactor, args[1], atoi( args[2] ), args[3] );
   }
   else if( !strcmp( args[0], "netstat" ))
   {
      net_stat( ship, enactor );
   }
   else if( !strcmp( args[0], "extend_link" ))
   {
      extend_link( ship, enactor, args[1] );
   }
   else if( !strcmp( args[0], "accept_link" ))
   {
      accept_link( ship, enactor, args[1] );
   }
   else if( !strcmp( args[0], "cut_link" ))
   {
      cut_link( ship, enactor, args[1] );
   }
   else if( !strcmp( args[0], "toggle_jamming" ) )
   {
      toggle_jamming( ship, enactor );
   }
   else if( !strcmp( args[0], "manual_snet_client" ) )
   {
      manual_snet_client( ship, enactor, args[1] );
   }
   else if( !strcmp( args[0], "manual_snet_server" ) )
   {
      manual_snet_server( ship, enactor, args[1] );
   }
   else if( !strcmp( args[0], "set_transpond" ) && args[1]!=NULL )
   {
      set_transpond( ship, enactor, args[1] );
   }
   else if( !strcmp( args[0], "quadrant" ))
   { 
      quadrant( ship, enactor, buff, bp );
   }
   else if( !strcmp( args[0], "subspace_add" ))
   {
     subspace_add( ship, enactor, args[1] );
   }
   else if( !strcmp( args[0], "subspace_remove"))
   {
   	subspace_remove(ship, enactor, args[1] );
   }	
   else if( !strcmp( args[0], "subspace_hail" ))
   {
     subspace_hail( ship, enactor, args[1], args[2] );
   }
   else if( !strcmp( args[0], "subspace_change"))
   {
     subspace_change( ship, enactor, args[1], args[2] );
   }
   else if( !strcmp( args[0], "sub_status" ) )
   {
     sub_status( ship, enactor );
   }
   else if( !strcmp( args[0], "subspace_label" ))
   {
     subspace_label( ship, enactor, args[1], args[2] );
   }
   else if( !strcmp( args[0], "netchan_off") )
   {
     netchan_off( enactor, args[1], buff, bp);
   }
   else if( !strcmp(args[0], "subspace_send"))
   {
   	subspace_send(enactor, ship, args[1], args[2]);
   }	
   else
      /* unrecognized command */
      notify( enactor, "Unrecognized comm_cmd call." );
  
  /* Ok, we find it a planet?  New For HoSpace :) */
  /*if( planet != NULL )
  {
  } */
}

void comm_status( SHIP *ship, dbref enactor )
{
   int i;
   static char *send_string[] = { (char *)"local ", (char *)"audio ",(char *) "visual" };
   static char *receive_string[] = {(char *) "local ",(char *) "audio ",(char *) "visual" };

   /* active check already done */

   fnotify( enactor, "%s%sComm channel configuration:%s\n", ANSI_HILITE, ANSI_BLUE,
            ANSI_NORMAL );
   fnotify( enactor, "%s%s Channel                 Freqency   Transmitting   Receiveing%s",
            ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );

   for( i = 0; i < MAX_CHANNEL; i++ ) {
      if( ship->channel[i].frequency == 0 ) {
	 fnotify( enactor, "%s%s   [%s%d%s] Closed%s", ANSI_HILITE, ANSI_BLUE, ANSI_RED, i,
                  ANSI_BLUE, ANSI_NORMAL );
      }                             
      else 
      {
      	if( !strcmp( ship->channel[i].label,"none"))
      	{
      		fnotify( enactor, "%s%s   [%s%d%s]:                %s  %5u      %s         %s%s", ANSI_HILITE,
		  ANSI_BLUE, ANSI_RED, i, ANSI_BLUE, ANSI_RED,
                  ship->channel[i].frequency, send_string[ship->channel[i].send_status],
		  receive_string[ship->channel[i].receive_status], ANSI_NORMAL );
		  }
		  else
		  {
	           fnotify( enactor, "%s%s   [%s%d%s]:%-16s%s  %5u      %s         %s%s", ANSI_HILITE,
		      ANSI_BLUE, ANSI_RED, i, ANSI_BLUE, ship->channel[i].label, ANSI_RED,
                ship->channel[i].frequency, send_string[ship->channel[i].send_status],
		      receive_string[ship->channel[i].receive_status], ANSI_NORMAL );
		   }
      }
   }
   if( ship->jammer_status )
   {
      notify( enactor, "Currently jamming subspace communications." );
   }
   /* and the customary CRLF */
   notify( enactor, "" );
}

void set_channel( SHIP *ship, dbref enactor, int chan, unsigned freq )
{
   /* active check already done */

   /* check for valid channel */
   if(( chan < 0 ) || ( chan >= MAX_CHANNEL )) {
      fnotify( enactor, "%s%sValid channels are between 0 and 5 inclusive.%s", ANSI_HILITE,
               ANSI_RED, ANSI_NORMAL );
      return;
   }

   /* frequency HAS to be valid since we'll accept anything that can fit
    * in a short integer.
    */

   if( freq == 0 ) {
      /* close the channel */
      ship->channel[chan].frequency = 0;
      ship->channel[chan].send_status = CS_COMM_ONLY;
      ship->channel[chan].receive_status = CR_COMM_ONLY;
      strcpy( ship->channel[chan].label, "none" );

      /* tell enactor about it */
      fnotify( enactor, "%s%sChannel %d closed.%s", ANSI_HILITE, ANSI_RED, chan, ANSI_NORMAL );
   }
   else {
      /* set the channel up */
      ship->channel[chan].frequency = freq;
      ship->channel[chan].send_status = CS_COMM_ONLY;
      ship->channel[chan].receive_status = CR_COMM_ONLY;
      strcpy( ship->channel[chan].label, "none" );
      
      /* tell the enactor */
      fnotify( enactor, "%s%sChannel %d set to frequency %u.%s", ANSI_HILITE, ANSI_GREEN,
               chan, freq, ANSI_NORMAL );
   }
}

void label_channel( SHIP *ship, dbref enactor, int chan, char *label )
{
   /* active check already done */

   /* check for in range channel */
   if(( chan < 0 ) || ( chan >= MAX_CHANNEL )) {
      fnotify( enactor, "%s%sValid channels are between 0 and 5 inclusive.%s", ANSI_HILITE,
               ANSI_RED, ANSI_NORMAL );
      return;
   }

   /* check for open channel */
   if( ship->channel[chan].frequency == 0 ) {
      fnotify( enactor, "%s%sChannel %d is closed.%s", ANSI_HILITE, ANSI_RED, chan,
               ANSI_NORMAL );
      return;
   }

   /* valid channel.  Label it */
   strncpy( ship->channel[chan].label, label, 16 );

   /* notify the enactor */
   fnotify( enactor, "%s%sChannel %d labeled as: %s%s", ANSI_HILITE, ANSI_GREEN, chan,
            ship->channel[chan].label, ANSI_NORMAL );

   return;
}

void comm_send( SHIP *ship, dbref enactor, int chan, char *message )
{
   /* active check already done */

   /* check for in-range channel */
   if(( chan < 0 ) || ( chan >= MAX_CHANNEL )) {
      fnotify( enactor, "%s%sValid channels are between 0 and 5 inclusive.%s", ANSI_HILITE,
               ANSI_RED, ANSI_NORMAL );
      return;
   }

   /* check for open channel */
   if( ship->channel[chan].frequency == 0 ) {
      fnotify( enactor, "%s%sChannel %d is closed.%s", ANSI_HILITE, ANSI_RED, chan,
               ANSI_NORMAL );
      return;
   }

   /* Hokay.  Channel is open and valid.  Check for a null message */
   if( !strcmp( message, "" )) {
      return;
   }

   /* send the message */
   send_comm_message( ship, ship->channel[chan].frequency, message, MSG_AUDIO );
   compin_send(enactor, (int)NULL, ship->channel[chan].frequency, message, ship);

   /*
   fnotify( enactor, "%s%sSent.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
   COMMENTED OUT - Jeremy(N'tok) 5/20/97 */

   return;
}

void send_comm_message( SHIP *ship, unsigned freq, char *message, int format )
{
   SHIP *listener;
   int i;
   dbref bridge, comm_op;

   /* active checks were done a long time ago.  We know that we have a valid
    * ship, frequency, and message.  All we have to do is send it.
    */
   if( check_jammed(ship,ship) )
   {
       return;
   }

   listener = space_list[current_space];

   while( listener != NULL )
   {
      /* don't send to sender */
      /*
      if( listener == ship ) {
	 listener = listener->next;
	 continue;
      }
      COMMENTED OUT - Jeremy(N'tok) 5/20/97 */
      /* see if they're out of range */
      if( distance( ship->pos, listener->pos ) > ((float)ship->transmitter_range * listener->receiver_sensitivity ))
      {
	 listener = listener->next;
	 continue;
      }

      /* see if they're monitoring this frequency */
      for( i = 0; i < MAX_CHANNEL; i++ )
      {
	 if( listener->channel[i].frequency == freq 
         && !check_jammed(listener,ship) )
         {
	    /* o-tay.  They're listening.  Lay it on 'em */
	    switch( listener->channel[i].receive_status )
            {
	       case CR_COMM_ONLY:
		  /* screen out visuals */
		  if( format == MSG_VISUAL )
		     break;

		  comm_op = match_result(HOWIE, my_atr_get_raw(listener->comm, "XB"), NOTYPE, MAT_ABSOLUTE);
            if( strcmp(listener->channel[i].label,"none"))
            {
        		  fnotify( comm_op, "%s%s<<%s%d%s>>%s %s", ANSI_HILITE, ANSI_RED, ANSI_BLUE, i,
                            ANSI_RED, ANSI_NORMAL, message );
             }
             else
             {
             	fnotify( comm_op, "%s%s<<%s%d:%s%s>>%s %s", ANSI_HILITE, ANSI_RED, ANSI_BLUE, i,
                           listener->channel[i].label, ANSI_RED, ANSI_NORMAL, message );
             }
		  break;

	       case CR_BRIDGE_AUDIO:
		  /* screen out visuals */
		  if( format == MSG_VISUAL )
		     break;
	       case CR_ON_SCREEN:  /* NOTE: Deliberate fall-through */
		  bridge = db[listener->comm].location;
		  sprintf( writebuf, "%s%s<<%s%d:%s%s>>%s %s", ANSI_HILITE, ANSI_RED, ANSI_BLUE, i,
                           listener->channel[i].label, ANSI_RED, ANSI_NORMAL, message );
		  notify_except(db[bridge].contents, listener->comm, writebuf);
		  break;
	       default:
		  break;
	    }
	 }
      }

      listener = listener->next;
   }
}   



void audio_send( SHIP *ship, char *message )
{
   int i;

   /* active check already done */

   /* loop through our channels and send it out on anything that's set
    * CR_BRIDGE_AUDIO.
    */

   for( i = 0; i < MAX_CHANNEL; i++ )
   {
      if( ship->channel[i].send_status == CR_BRIDGE_AUDIO )
	 send_comm_message( ship, ship->channel[i].frequency,
			    message, MSG_AUDIO );
   }

   return;
}

void visual_send( SHIP *ship, char *message )
{
   int i;

   /* active check already done */

   /* loop through our channels and send it out on anything that's set
    * CS_VISUALS.
    */

   for( i = 0; i < MAX_CHANNEL; i++ ) {
      if( ship->channel[i].send_status == CS_VISUALS )
	 send_comm_message( ship, ship->channel[i].frequency,
			    message, MSG_VISUAL );
   }

   return;
}

void set_channel_setting( SHIP *ship, dbref enactor, char *action, int chan, char *setting )
{
   /* active check already done */

   /* check for in range channel */
   if(( chan < 0 ) || ( chan >= MAX_CHANNEL )) {
      fnotify( enactor, "%s%sValid channels are between 0 and 5 inclusive.%s", ANSI_HILITE,
               ANSI_RED, ANSI_NORMAL );
      return;
   }

   /* check for open channel */
   if( ship->channel[chan].frequency == 0 ) {
      fnotify( enactor, "%s%sChannel %d is closed.%s", ANSI_HILITE, ANSI_RED, chan,
               ANSI_NORMAL );
      return;
   }

   /* compare on the action register */
   if( !strcmp( action, "send" )) {
      switch( setting[0] ) {
	 case 'L':
	 case 'l':
	    /* local.  Set it to CS_COMM_ONLY */
	    ship->channel[chan].send_status = CS_COMM_ONLY;
	    break;
	 case 'A':
	 case 'a':
	    /* audio */
	    ship->channel[chan].send_status = CS_BRIDGE_AUDIO;
	    break;
	 case 'V':
	 case 'v':
	    /* visual */
	    ship->channel[chan].send_status = CS_VISUALS;
	    break;
	 default:
	    fnotify( enactor, "%s%sInvalid setting.  Valid settings are: local, audio, and visual.%s",
                     ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
	    return;
      }
   }
   else if( !strcmp( action, "rec" )) {
      switch( setting[0] ) {
	 case 'L':
	 case 'l':
	    /* local.  Set it to CR_COMM_ONLY */
	    ship->channel[chan].receive_status = CR_COMM_ONLY;
	    break;
	 case 'A':
	 case 'a':
	    /* audio */
	    ship->channel[chan].receive_status = CR_BRIDGE_AUDIO;
	    break;
	 case 'V':
	 case 'v':
	    /* visual */
	    ship->channel[chan].receive_status = CR_ON_SCREEN;
	    break;
	 default:
	    fnotify( enactor, "%s%sInvalid setting.  Valid settings are: local, audio, and visual.%s",
                     ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
	    return;
      }
   }
   else { /* bad argument.  Go home. */
      log_space( "Bad argument in set_channel_setting for ship %d comm %d.",
		 ship->ship_object, ship->comm );
      notify( enactor, "Internal error.  Notify a director." );
      return;
   }

   fnotify( enactor, "%s%sSet.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
   return;
}

/*
 *  net_range
 *  returns a nonzero value if ship a and ship b are in two-way comm range,
 *  zero if not.
 *
 * JMS 25 Sep 93
 */
int net_range( SHIP *a, SHIP *b )
{
float atob, btoa, range;

  atob = a->transmitter_range * b->receiver_sensitivity;
  btoa = b->transmitter_range * a->receiver_sensitivity;
  range = distance( a->pos, b->pos );

  return(( range <= atob ) || ( range <= btoa ));
}


/*
 * net_stat
 * sensorlink info
 *
 * JMS 25 Sep 93
 */
void net_stat( SHIP *ship, dbref enactor )
{
CONTACT *contact;
char target_string[80];
unsigned int i;

  fnotify( enactor, "%s%sSensornet Status:%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
  /* server info first */
  switch( ship->server.status ) {
    case SNS_OFF:
      fnotify( enactor, "%s%sServer  : %s%sNone%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL,
               ANSI_CYAN, ANSI_NORMAL );
      break;
    case SNS_ON:
      /* find the contact */
      contact = find_contact( ship, ship->server.ship );

      if( contact == NULL ) {
	/* error.  you shouldn't ever have a link to a ship you can't
	 * see.  throw a fit. */
	log_space( "ERROR: %s:%d", __FILE__, __LINE__ );
	ship->server.status = SNS_OFF;
	net_stat( ship, enactor );
	return;
      }
      contact_string( target_string, contact, INFO_TERSE );
      fnotify( enactor, "%s%sServer  : %s%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL,
               target_string );
      break;
    default:
      log_space( "ERROR: %s:%d", __FILE__, __LINE__ );
  }

  /* now the client connections */
  if( ship->max_clients ) {
    for( i = 0; i < ship->max_clients; i++ ) {
      switch( ship->clients[i].status ) {
	case SNS_OFF:
	  fnotify( enactor, "%s%sClient %d: %s%sNone%s", ANSI_HILITE, ANSI_BLUE, i, ANSI_NORMAL,
                   ANSI_CYAN, ANSI_NORMAL );
	  break;
	case SNS_PENDING:
	  contact = find_contact( ship, ship->clients[i].ship );
	  contact_string( target_string, contact, INFO_TERSE );
	  fnotify( enactor, "%s%sClient %d: %s%sPending to %s%s", ANSI_HILITE, ANSI_BLUE, i, 
                   ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, target_string );
	  break;
	case SNS_ON:
	  contact = find_contact( ship, ship->clients[i].ship );
	  contact_string( target_string, contact, INFO_TERSE );
	  fnotify( enactor, "%s%sClient %d: %s%s", ANSI_HILITE, ANSI_BLUE, i, ANSI_NORMAL,
                   target_string );
	  break;
      }
    }
  }

  fnotify( enactor, "" );
  return;
}


void extend_link( SHIP *ship, dbref enactor, char *target )
{
CONTACT *contact, *source_contact;
char message[80];
dbref target_comm;

  /* make sure we're a server */
  if( ship->max_clients == 0 )
  {
    fnotify( enactor, "%s%sThis ship is unable to act as a sensornet server.%s", ANSI_HILITE,
             ANSI_RED, ANSI_NORMAL );
    return;
  }
  /* make sure it's a valid contact */
  contact = match_contact( ship, target );
  if( contact == NULL )
  {
    fnotify( enactor, "%s%sInvalid contact.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
  /* make sure we've got a spare link to offer */
  if( ship->max_clients == ship->active_clients )
  {
    fnotify( enactor, "%s%sNo available links.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
  if( check_jammed(ship,ship) || check_jammed(contact->listref,ship) )
  {
    fnotify( enactor, "Subspace communications jammed, unable to extend link." );
    return;
  }
  /* target in range? */
  if( !net_range( ship, contact->listref ))
  {
    fnotify( enactor, "%s%sClient is out of communications range.%s", ANSI_HILITE, ANSI_RED,
             ANSI_NORMAL );
    return;
  }

  /* would this create a circular tree? */
  if( is_client( ship, contact->listref ) )
  {
    fnotify( enactor, "%s%sTarget is a server in our current tree.  Circular trees are not permitted.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }

  /* are they already a client? */
  /* note: don't use is_client, because that hunts up the tree.  we just
   * want to know if it's an immediatel client. */
  if( contact->listref->server.ship == ship ) {
    fnotify( enactor, "%s%sTarget is already a client.  New link not extended.%s", ANSI_HILITE,
             ANSI_RED, ANSI_NORMAL );
    return;
  }
  
  /* Okay, extend the link */
  ship->clients[ship->active_clients].ship = contact->listref;
  ship->clients[ship->active_clients].status = SNS_PENDING;

  /* tell the target */
  target_comm = attrib_dbref( contact->listref->comm, "XB" );
  source_contact = find_contact( contact->listref, ship );
  contact_string( message, source_contact, INFO_TERSE );
  fnotify( target_comm, "%sSensornet connection extended from %s%s%s.%s", ANSI_CYAN, ANSI_NORMAL,
           message, ANSI_CYAN, ANSI_NORMAL );

  contact_string( message, contact, INFO_TERSE );
  fnotify( enactor, "%sSensornet connection extended to %s%s%s.%s", ANSI_CYAN, ANSI_NORMAL,
           message, ANSI_CYAN, ANSI_NORMAL );

  ship->active_clients++;

  return;
}


void accept_link( SHIP *ship, dbref enactor, char *target )
{
CONTACT *us_to_them, *them_to_us;
char message[80];
dbref target_comm;
unsigned int i;

  /* valid target? */
  us_to_them = match_contact( ship, target );
  if( us_to_them == (CONTACT *)NULL ) {
    fnotify( enactor, "Invalid contact." );
    return;
  }

  /* have they extended a link our way? */
  for( i = 0; i < us_to_them->listref->active_clients; i++ ) {
    if( us_to_them->listref->clients[i].ship == ship )
      break;
  }

  if( i == us_to_them->listref->active_clients )
  {
    fnotify( enactor, "%s%sNo extended link from that server.%s", ANSI_HILITE, ANSI_RED,
             ANSI_NORMAL );
    return;
  }
  if( check_jammed(ship,us_to_them->listref)
  || check_jammed(us_to_them->listref,us_to_them->listref) )
  {
    fnotify( enactor, "Subspace communications jammed, unable to accept link." );
    return;
  }
  /* are they in range? */
  if( !net_range( ship, us_to_them->listref ))
  {
    fnotify( enactor, "%s%sServer is out of communications range.%s", ANSI_HILITE, ANSI_RED,
             ANSI_NORMAL );
    return;
  }

  /* circular tree check */
  if( is_client( us_to_them->listref, ship )) {
    fnotify( enactor, "%s%sServer is already a client or subclient.%s", ANSI_HILITE, ANSI_RED,
             ANSI_NORMAL );
    return;
  }

  /* cut existing serverlink, if present */
  if( ship->server.status == SNS_ON )
    sever_link( ship, ship->server.ship, TS_CUT_BY_CLIENT, TN_BOTH );

  /* valid target, open link.  connect */
  ship->server.status = SNS_ON;
  ship->server.ship = us_to_them->listref;
  us_to_them->listref->clients[i].status = SNS_ON;
  them_to_us = find_contact( us_to_them->listref, ship );
  us_to_them->info_level = 5;
  them_to_us->info_level = 5;

  /* tell us */
  contact_string( message, us_to_them, INFO_TERSE );
  fnotify( enactor, "%sSensornet link established with server %s%s%s.%s", ANSI_CYAN, ANSI_NORMAL,
           message, ANSI_CYAN, ANSI_NORMAL );

  /* tell them */
  target_comm = attrib_dbref( us_to_them->listref->comm, "XB" );
  contact_string( message, them_to_us, INFO_TERSE );
  fnotify( target_comm, "%sSensornet link established with client %s%s%s.%s", ANSI_CYAN,
           ANSI_NORMAL, message, ANSI_CYAN, ANSI_NORMAL );

  return;
}


/*
 * returns TRUE if client is a client of server, FALSE if not.
 */
int is_client( SHIP *client, SHIP *server )
{
    if( client->server.ship == NULL )
        return FALSE;
    else if( client->server.ship == server )
        return TRUE;
    else
        return is_client( client->server.ship, server );
}


void cut_link( SHIP *ship, dbref enactor, char *target )
{
CONTACT *contact;

  /* valid contact? */
  contact = match_contact( ship, target );
  if( contact == NULL ) {
    fnotify( enactor, "%s%sInvalid contact.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }

  if( ship->server.ship == contact->listref ) {
    sever_link( ship, contact->listref, TS_CUT_BY_CLIENT, TN_BOTH );
  }
  else if( contact->listref->server.ship == ship ) {
    sever_link( ship, contact->listref, TS_CUT_BY_SERVER, TN_BOTH );
  }
  else {
    fnotify( enactor, "Not linked to that ship.", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
}


/*
 * call then whenever you kill a client link for ship.  This shuffles the
 * remaining links down to fill the hole.  Note: This will only plug ONE
 * hole.  If there are more, it'll miss them.
 */
void rearrange_clients( SHIP *ship )
{
unsigned int i, j;

  for( i = 0; i < ( ship->max_clients - 1 ); i++ ) {
    if( ship->clients[i].status == SNS_OFF ) {
      for( j = i+1; j < ship->max_clients; j++ ) {
	ship->clients[j-1] = ship->clients[j];
      }
      return;
    }
  }
}


void sever_link( SHIP *a, SHIP *b, int reason, int who )
{
unsigned int i;
CONTACT *atob, *btoa;
dbref a_comm, b_comm;
static char *cserver[] = { (char *)"client", (char *)"server" };
static char *reasons[] = { (char *)"timed out",(char *) "terminated by client",
			   (char *)"terminated by server", (char *)"interrupted" };
static char *types[] = { (char *)"Sensornet link", (char *)"Pending link" };
static char *to_from[] = {(char *) "to",(char *) "from" };
char *arelb = NULL, *brela = NULL;
char message_a[80], message_b[80];
int inform_a = 0, inform_b = 0;
int pending_link = FALSE;
char *a_prep = to_from[0], *b_prep = to_from[0], *linktype = types[0];

  atob = find_contact( a, b );
  btoa = find_contact( b, a );
  a_comm = attrib_dbref( a->comm, "XB" );
  b_comm = attrib_dbref( b->comm, "XB" );
  if( atob != NULL )
    contact_string( message_a, atob, INFO_TERSE );
  if( btoa != NULL )
    contact_string( message_b, btoa, INFO_TERSE );

  /* is there a link? */
  if( a->server.ship == b ) {
    arelb = cserver[0];
    brela = cserver[1];
    inform_a = who & TN_CLIENT;
    inform_b = who & TN_SERVER;
    a->server.ship = NULL;
    a->server.status = SNS_OFF;
    for( i = 0; i < b->active_clients; i++ ) {
      if( b->clients[i].ship == a ) {
	b->clients[i].ship = NULL;
	b->clients[i].status = SNS_OFF;
	b->active_clients--;
	i--;
	rearrange_clients( b );
      }
    }
  }
  else if ( b->server.ship == a ) {
    brela = cserver[0];
    arelb = cserver[1];
    inform_a = who & TN_SERVER;
    inform_b = who & TN_CLIENT;
    b->server.ship = NULL;
    b->server.status = SNS_OFF;
    for( i = 0; i < a->active_clients; i++ ) {
      if( a->clients[i].ship == b ) {
	a->clients[i].ship = NULL;
	a->clients[i].status = SNS_OFF;
	a->active_clients--;
	i--;
	rearrange_clients( a );
      }
    }
  }
  else {
    /* no link.  kill of anything that's pending too */
    for( i = 0; i < a->active_clients; i++ ) {
      if(( a->clients[i].status == SNS_PENDING ) &&
	 ( a->clients[i].ship == b )) {
	a->clients[i].ship = NULL;
	a->clients[i].status = SNS_OFF;
	a->active_clients--;
	i--;
	b_prep = to_from[1];
	brela = cserver[0];
	arelb = cserver[1];
	rearrange_clients( a );
	pending_link = TRUE;
      }
    }
    for( i = 0; i < b->active_clients; i++ ) {
      if(( b->clients[i].status == SNS_PENDING ) &&
	 ( b->clients[i].ship == a )) {
	b->clients[i].ship = NULL;
	b->clients[i].status = SNS_OFF;
	b->active_clients--;
	i--;
	a_prep = to_from[1];
	brela = cserver[1];
	arelb = cserver[0];
	rearrange_clients( b );
	pending_link = TRUE;
      }
    }
    if( !pending_link )
      return;
    else {
      linktype = types[1];
    }
  }

  if( inform_a )
    fnotify( a_comm, "%s%s %s %s %s%s%s %s.%s", ANSI_CYAN, linktype, a_prep, brela, ANSI_NORMAL,
	     message_a, ANSI_CYAN, reasons[reason], ANSI_NORMAL );

  if( inform_b )
    fnotify( b_comm, "%s%s %s %s %s %s.",  ANSI_CYAN, linktype, b_prep, arelb, ANSI_NORMAL,
	     message_b, ANSI_CYAN, reasons[reason], ANSI_NORMAL );
}

int check_jammed( SHIP *ship, SHIP *sender )
{
    int jamrange;
    SHIP *jammer;
    for(jammer=space_list[current_space];jammer!=NULL;jammer=jammer->next)
    {
        if( !jammer->jammer_status
        || !strcmp(sender->transponder,jammer->transponder) )
        {
            continue;
        }
        jamrange = jammer->transmitter_range / 5;
        if( distance(ship->pos,jammer->pos) < jamrange )
        {
            return 1;
        }
    }
    return 0;
}

void toggle_jamming( SHIP *ship, dbref enactor )
{
    if( ship->transmitter_range < 5.0 )
    {
        fnotify( enactor, "%s%sThis ship does not have jamming capability.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ship->jammer_status )
    {
        fnotify( enactor, "Jamming deactivated." );
        ship->jammer_status=0;
    }
    else
    {
        fnotify( enactor, "Jamming activated." );
        ship->jammer_status=1;
    }
    return;
}

void manual_snet_client( SHIP *ship, dbref enactor, char *argument )
{
    CONTACT *s2c,*c2s;
    dbref client;
    SHIP *target;

    if( argument==NULL || argument[0]=='\0' )
    {
        return;
    }
    else
    {
        client=(dbref)atoi(argument);
    }
    if( ship->max_clients <= ship->active_clients )
    {
        notify( enactor, "No more links available." );
        return;
    }
    if( ship->ship_object==client )
    {
        notify( enactor, "Ha, ha, ha." );
        return;
    }
    for(target=space_list[current_space];target!=NULL;target=target->next)
    {
        if( target->ship_object==client )
        {
            break;
        }
    }
    if( target==NULL )
    {
        notify( enactor, "That ship does not exist or is not active." );
        return;
    }
    if( is_client( ship, target ) )
    {
        fnotify( enactor, "%s%sTarget is a server in our current tree. Circular trees are not permitted.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( target->server.status == SNS_ON )
    {
        sever_link( target, target->server.ship, TS_CUT_BY_CLIENT, TN_BOTH );
    }
    if( find_contact(ship,target)==NULL )
    {
        add_contact( ship, target );
    }
    if( find_contact(target,ship)==NULL )
    {
        add_contact( target, ship );
    }
    ship->clients[ship->active_clients].ship = target;
    ship->clients[ship->active_clients].status = SNS_ON;
    target->server.status = SNS_ON;
    target->server.ship = ship;
    ship->active_clients++;
    if( ( s2c=find_contact(ship,target) )!=NULL )
    {
        s2c->info_level = 5;
    }
    if( ( c2s=find_contact(ship,target) )!=NULL )
    {
        c2s->info_level = 5;
    }
    notify( enactor, "Established." );
    return;
}

void manual_snet_server( SHIP *ship, dbref enactor, char *argument )
{
    CONTACT *s2c,*c2s;
    dbref server;
    SHIP *target;

    if( argument==NULL || argument[0]=='\0' )
    {
        return;
    }
    else
    {
        server=(dbref)atoi(argument);
    }
    if( ship->ship_object==server )
    {
        notify( enactor, "Ha, ha, ha." );
        return;
    }
    for(target=space_list[current_space];target!=NULL;target=target->next)
    {
        if( target->ship_object==server )
        {
            break;
        }
    }
    if( target==NULL )
    {
        notify( enactor, "That ship does not exist or is not active." );
        return;
    }
    if( target->max_clients <= target->active_clients )
    {
        notify( enactor, "No more links available." );
        return;
    }
    if( ship->server.ship==target && ship->server.status==SNS_ON )
    {
        notify( enactor, "Target is already our server." );
        return;
    }
    if( is_client( target, ship ) )
    {
        fnotify( enactor, "%s%sTarget is a server in our current tree. Circular trees are not permitted.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ship->server.status == SNS_ON )
    {
        sever_link( ship, ship->server.ship, TS_CUT_BY_CLIENT, TN_BOTH );
    }
    if( find_contact(ship,target)==NULL )
    {
        add_contact( ship, target );
    }
    if( find_contact(target,ship)==NULL )
    {
        add_contact( target, ship );
    }
    target->clients[target->active_clients].ship = ship;
    target->clients[target->active_clients].status = SNS_ON;
    ship->server.status = SNS_ON;
    ship->server.ship = target;
    target->active_clients++;
    if( ( s2c=find_contact(ship,target) )!=NULL )
    {
        s2c->info_level = 5;
    }
    if( ( c2s=find_contact(ship,target) )!=NULL )
    {
        c2s->info_level = 5;
    }
    notify( enactor, "Established." );
    return;
}

void set_transpond( SHIP *ship, dbref enactor, char *arg )
{
    int i;

    if( ship==NULL )
    {
        fnotify( enactor, "%sShip must be active to use that command.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    strncpy( ship->transponder, arg, 4 );
    for(i=0;i<4;i++)
    {
        ship->transponder[i] = toupper( ship->transponder[i] );
    }
    ship->transponder[4] = '\0';
    fnotify( enactor, "%s%sShip transponder set to '%s'.%s", ANSI_HILITE,
        ANSI_GREEN, ship->transponder, ANSI_NORMAL );
    atr_add( ship->ship_object, "TRANSPOND", ship->transponder, HOWIE, NOTHING );
    return;
}

void quadrant( SHIP *ship, dbref enactor, char *buff, char **bp )
{
   if( ship->pos.x >= 0 && ship->pos.y >= 0 )
   { 
     sprintf( writebuf, "ALPHA" );
     safe_str( writebuf, buff, bp );
   }
   if( ship->pos.x < 0 && ship->pos.y >= 0 )
   {
     sprintf( writebuf, "BETA" );
     safe_str( writebuf, buff, bp );
   }
   if( ship->pos.x < 0 && ship->pos.y < 0 )
   {
     sprintf( writebuf, "GAMMA" );
     safe_str( writebuf, buff, bp );
   }
   if( ship->pos.x >= 0 && ship->pos.y < 0 )
   {
     sprintf( writebuf, "DELTA" );
     safe_str( writebuf, buff, bp );
   }
}


char on_snet( SHIP *ship )
{
    unsigned int i;

    if( ship->server.status==SNS_ON && ship->server.ship!=NULL )
    {
        return TRUE;
    }
    for(i=0;i<ship->max_clients;i++)
    {
        if( ship->clients[i].status==SNS_ON && ship->clients[i].ship!=NULL )
        {
            return TRUE;
        }
    }
    return FALSE;
}


void subspace_add( SHIP *ship, dbref enactor, char *channel )
{
  int i;
  
   /* No Negative Channels */
   if ( atoi(channel) <= 0 )
   {
   	fnotify(enactor,"%s%sSubspace channels must be greater than 0.%s",ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
        return;
   }

  for( i = 0 ; i < MAX_SUB_CHANS; i++ )
  {
    if( ship->subspace[i].channel == (unsigned)atoi( channel ) )
    {
      fnotify(enactor, "%s%sYou are already on that subspace channel%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
      return;
    }
  }

  if( ship->numsubchan < MAX_SUB_CHANS )
  {
    ship->subspace[ship->numsubchan].channel = (unsigned) atoi(channel);
    fnotify( enactor, "%s%sSubspace channel %d set to %s.%s",ANSI_HILITE, ANSI_CYAN, ship->numsubchan + 1, channel, ANSI_NORMAL) ;
    ship->numsubchan++;
  }
  
  else
  {
    fnotify( enactor, "%s%sYou are already listening on your max amount of channels.%s", ANSI_HILITE, ANSI_RED,
ANSI_NORMAL);
  }
}

void subspace_remove(SHIP *ship, dbref enactor, char *channel )
{
  int i, onchan, j;
    
   /* No Negative Channels */
   if ( atoi(channel) <= 0 )
   {
   	fnotify(enactor,"%s%sSubspace channels must be greater than 0.%s",ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
        return;
   }
	
   onchan = 0;
  for( i = 0 ; i < MAX_SUB_CHANS; i++ )
  {
    if( ship->subspace[i].channel == (unsigned)atoi( channel ) )
    {
      onchan = 1;
    }
  }
  if( onchan == 0 )
  {
  	fnotify(enactor, "%s%sYou are not on that subspace channel.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
      return;
  }

  /* Removal algorithm now to shorten the list. */  
  for( i = 0 ; i < MAX_SUB_CHANS; i++ )
  {
  	if( ship->subspace[i].channel == (unsigned)atoi(channel) )
  	{
  		for( j=0; j < ship->numsubchan; j++ )
  		{
  			ship->subspace[j].channel= ship->subspace[j+1].channel;
  		}
  		ship->numsubchan = ship->numsubchan - 1;
  	}
  	fnotify( enactor, "%s%sChannel %s removed from subspace monitoring.%s", ANSI_HILITE, ANSI_RED, channel, ANSI_NORMAL );
  	
  }
  
  
}

void subspace_hail( SHIP *ship, dbref enactor, char *channel, char *subject )
{
 
  SHIP *reciever;
  int i;
  dbref communicator;

  reciever = space_list[current_space]; 

   /* No Negative Channels */
   if ( atoi(channel) <= 0 )
   {
   	fnotify(enactor,"%s%sSubspace channels must be greater than 0.%s",ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
        return;
   }

  while( reciever != NULL )
  {
   for( i = 0; i < MAX_SUB_CHANS; i++ )
   {
     if( (reciever->subspace[i].channel == (unsigned)atoi(channel)) && (reciever != ship) )
    {
      /*find the person on each ship's console */
      communicator = attrib_dbref( (attrib_dbref(reciever->ship_object, "COMM")), "XB");
      fnotify( communicator, "%s%sIncoming subspace request on channel %s with subject: %s%s", ANSI_HILITE, ANSI_CYAN,
channel, subject, ANSI_NORMAL );
    }
   }
   reciever = reciever->next;
  }
  
     fnotify(enactor, "%sHail sent on channel %s with subject: %s.%s", ANSI_CYAN, channel, subject, ANSI_NORMAL);

}

void subspace_change( SHIP *ship, dbref enactor, char *channel, char *newchan)
{
    int i;
    int onchan=0;
   
    /* Is ship on any channels? */    
    if( ship->numsubchan == 0 )
    {
       fnotify( enactor, "%s%sYou are not on any subspace channels.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
       return;
    }
   
      /* No Negative Channels */
   if ( atoi(channel) <= 0 )
   {
   	fnotify(enactor,"%s%sSubspace channels must be greater than 0.%s",ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
        return;
   }
   
   /* Check the channels to see if they are already on the channel they are leaving */
   for( i = 0; i < ship->numsubchan; i++)
   {
      if( ship->subspace[i].channel == (unsigned)atoi(channel) )
      {
         onchan = 1;
      }
   }
   
    if( onchan != 1)
    {
       fnotify(enactor, "%s%sYou are not currently listening to channel %s%s.", ANSI_HILITE, ANSI_RED, channel, ANSI_NORMAL);
         return;
     }

    /* Now, change the channel */
    for( i = 0; i < ship->numsubchan; i++ )
    {
      if( ship->subspace[i].channel == (unsigned)atoi(channel) )
      {
        fnotify(enactor, "%sSubspace channel %d changed to %s.%s", ANSI_CYAN, ship->subspace[i].channel, newchan, ANSI_NORMAL);
        ship->subspace[i].channel = (unsigned)atoi(newchan);
        
      }
    }

}


void sub_status( SHIP *ship, dbref enactor )
{
   int c;


     fnotify( enactor, "%s%s--------------------------------------[ %sSubspace Status%s ]-------------%s",ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL);
   if( ship->numsubchan == 0 )
   {
     fnotify( enactor, "%s%sNot listening on any subspace channels%s", ANSI_HILITE, ANSI_WHITE, ANSI_NORMAL );
   }
   else
   {
     for( c = 0; c < ship->numsubchan; c++ )
     {
       fnotify(enactor, "%s%s %d. Channel %d \t\t\t\t\t'%s'%s", ANSI_HILITE, ANSI_WHITE, c+1, ship->subspace[c].channel, ship->subspace[c].label, ANSI_NORMAL);
     }
   }  
     fnotify( enactor, "%s%s----------------------------------------------------------------------%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);
      
}

void subspace_label( SHIP *ship, dbref enactor, char *channel, char *label )
{
   int i;
   int onchan=0;
   

   /* standard on-channel check. */
   for( i = 0; i < ship->numsubchan; i++ )
   {
     if( ship->subspace[i].channel == (unsigned)atoi(channel) )
     {
       onchan = 1;
     }
   }

   if( onchan != 1)
   {
      fnotify( enactor, "%s%sYou are not on that channel.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
   }
   else
   {
     for( i = 0; i < ship->numsubchan; i++ )
     {
       if( ship->subspace[i].channel == (unsigned)atoi(channel) )
        {  
         strcpy(ship->subspace[i].label, label);
         fnotify( enactor, "%sLabel on channel %d set to '%s'.%s", ANSI_CYAN, ship->subspace[i].channel, ship->subspace[i].label, ANSI_NORMAL);
        }
     }
   }
}

void subspace_send(dbref enactor, SHIP *ship, char *channel, char *message)
{
	SHIP *target;
	dbref comm_op;
	int i;
	
	for(target = space_list[current_space]; target != NULL; target=target->next)
	{
		for( i=0; i < target->numsubchan; i++)
		{
			if( target->subspace[i].channel==(unsigned)atoi(channel) )
			{
				comm_op = match_result(HOWIE, my_atr_get_raw(target->comm, "XB"), NOTYPE, MAT_ABSOLUTE);
				fnotify(  comm_op, "%s%sSubspace: %s[%s%d%s - %s%s%s] - %s|%s| %s %s", ANSI_HILITE, ANSI_BLUE, ANSI_CYAN, ANSI_RED,  target->subspace[i].channel, ANSI_WHITE, ANSI_BLUE, target->subspace[i].label, ANSI_CYAN, ANSI_YELLOW, ship->name, ANSI_NORMAL, message);
			}
		} 
	}
		
}




  void netchan_off(dbref enactor, char *target, char *buff, char **bp)
{
  sprintf( writebuf, "@chan/off HoSpace_Net=%s\n", target );
  safe_str( writebuf, buff, bp );
}




/* Whee!  Compin code (greatly needed) */
void compin_send(dbref enactor, dbref executor, int frequency, char *message, SHIP *sender)
{
	
  SHIP *ship;
  PLANET *planet;
  COMPIN *compin, *ctarget;
  int i;
  
  
  ship = cfind_ship(match_result(HOWIE, my_atr_get_raw(Zone(Location(enactor)), "SHIP_OBJECT"), NOTYPE, MAT_ABSOLUTE));
  planet = find_planet( match_result(HOWIE, my_atr_get_raw(Zone(Location(enactor)), "SHIP_OBJECT"), NOTYPE, MAT_ABSOLUTE));
  ctarget = find_compin(executor);  
  
  
  if(ship == NULL && planet == NULL)
    return; 
  if(ctarget == NULL && sender == NULL)
    return;
   
  for(compin = compin_list[COMPINS]; compin != NULL; compin=compin->next)
  {	
  	if( ship != NULL )
  	{
  		
             if( ((compin->frequency == frequency) && (frequency > 0))  && sinrange(ship, NULL, compin->owner) )
             {
   	       /* Also get the room if possible */
  	       sprintf( writebuf, "%s%s<<%s%s's Compin | %d%s>>%s %s", ANSI_HILITE, ANSI_BLUE, ANSI_WHITE, Name(compin->owner), frequency, ANSI_BLUE, ANSI_WHITE, message);
  	       /* Don't emit sends to the room */
  	       if(ctarget != NULL ) { /* Done to take care of crashes froma calling ctarget->owner */
  	       
  	       if(compin->owner != ctarget->owner)  {
  	       notify_except( Contents(Location(compin->owner)), compin->owner, writebuf );
  	       fnotify( compin->owner, "%s%s<<%sCompin | %d%s>>%s %s", ANSI_HILITE, ANSI_BLUE, ANSI_WHITE, frequency, ANSI_BLUE, ANSI_WHITE, message); }
  	       } 
  	       else /* Do it anyway */
  	       {
  	       	notify_except( Contents(Location(compin->owner)), compin->owner, writebuf );
  	           fnotify( compin->owner, "%s%s<<%sCompin | %d%s>>%s %s", ANSI_HILITE, ANSI_BLUE, ANSI_WHITE, frequency, ANSI_BLUE, ANSI_WHITE, message); }
              }
              
             /* Yup, need to send the comm stuff anyway */
              if(ctarget != NULL )
                send_comm_message( ship, compin->frequency, message, MSG_AUDIO );       
        }
        

    else if(planet != NULL)
    {    	
           if( ((compin->frequency == frequency) && (frequency > 0 ))  && sinrange(NULL, planet,compin->owner) )
           {
  	       
  	       /* Also get the room if possible */
  	       sprintf( writebuf, "%s%s<<%s%s's Compin | %d%s>>%s %s", ANSI_HILITE, ANSI_BLUE, ANSI_WHITE, Name(compin->owner), frequency, ANSI_BLUE, ANSI_WHITE, message);
			if( ctarget != NULL) 
			{ 		 
			 
			 if((compin->owner != ctarget->owner)) {
  	       notify_except( Contents(Location(compin->owner)), compin->owner, writebuf );
  	       fnotify( compin->owner, "%s%s<<%sCompin | %d%s>>%s %s", ANSI_HILITE, ANSI_BLUE, ANSI_WHITE, frequency, ANSI_BLUE, ANSI_WHITE, message); }
  	       }
  	       else {
  	       	 notify_except( Contents(Location(compin->owner)), compin->owner, writebuf );
  	       fnotify( compin->owner, "%s%s<<%sCompin | %d%s>>%s %s", ANSI_HILITE, ANSI_BLUE, ANSI_WHITE, frequency, ANSI_BLUE, ANSI_WHITE, message); }
  	       }
  	      
  	      /* Send planet comm regaurdless of range */
  	      if( ctarget != NULL )
  	      	planet_send_message( planet, compin->frequency, message, MSG_AUDIO );
  	        
      }
      else
       return;	
    
  } /* FOR */
}


int sinrange( SHIP *ship, PLANET *planet, dbref player )
{
	SHIP *pship;
	PLANET *tplanet;
	dbref ship_object;
	
	ship_object = match_result(HOWIE, my_atr_get_raw(Zone(Location(player)), "SHIP_OBJECT"), NOTYPE, MAT_ABSOLUTE);
	
	if( !GoodObject(ship_object) )
	{
		log_space( "Bad Compin Ship Object call by %s in %s [%d](Check Zoning if an IC place).", Name(player), Name(Location(player)), Location(player) );
		return 0;
	}
	
	pship=cfind_ship(ship_object);
	tplanet=find_planet(ship_object);
	
	if( pship !=NULL )
	{	if( (ship != NULL) && (distance(ship->pos,pship->pos) <= COMPIN_RANGE) )
	  	return 1;
		else if( (planet != NULL) && (distance(planet->pos,pship->pos) <= COMPIN_RANGE) )
	 	 return 1;
		else
		  return 0;
	}
	else if (tplanet !=NULL) 
	{
		if( (ship != NULL) && (distance(ship->pos,tplanet->pos) <= COMPIN_RANGE) )
	  	return 1;
		else if( (planet != NULL) && (distance(planet->pos,tplanet->pos) <= COMPIN_RANGE) )
	 	 return 1;
		else
		  return 0;
	}
	else
		return 0;
	
}

/*Need to initialize the list */
void compin_activate(dbref enactor, dbref executor)
{
	COMPIN *new_compin;
	COMPIN *compin;

	for( compin = compin_list[COMPINS]; compin !=NULL; compin=compin->next )
	{
		if(compin->compin_object == executor)
		{
			fnotify(enactor, "%s%sCompin already active.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
			return;
		}
		    
	}
	
	if(!(new_compin=(COMPIN *)JMALLOC( sizeof( COMPIN ))))
       return;
       
    new_compin->compin_object=executor;
    fnotify(enactor, "%s%sThe compin activates with a chirp.%s", ANSI_YELLOW, ANSI_HILITE, ANSI_NORMAL);
       
    if( compin_list[COMPINS] == NULL ) 
    {   /* empty list */

       compin_list[COMPINS] = new_compin;
       compin_tail[COMPINS] = new_compin;
       new_compin->prev = NULL;
       new_compin->next = NULL;
   }
  else
  {
    compin_tail[COMPINS]->next=new_compin;
 
    new_compin->prev = compin_tail[COMPINS];
    new_compin->next = NULL;
    compin_tail[COMPINS] = new_compin;
     
   }	
   
   
   new_compin->frequency=atoi(fetch_attribute(executor,"COM_FREQ"));
   new_compin->owner=enactor;
   put_attribute( new_compin->compin_object, (char *) "ACTIVE", (char *) "1" );
}

void compin_deactivate(dbref enactor, dbref executor)
{
	COMPIN *compin;
	
	
	compin = find_compin(executor);
	if( compin == NULL)
	{
		fnotify( enactor, "%s%sThis compin is not currently active.  %s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
		return;
	}
	else  /*Set the active attribute */
		put_attribute( compin->compin_object, (char *) "ACTIVE", (char *) "1" );
	/* Some nifty code I've decided to steal form eng.c */
	 if( compin_list[COMPINS] == compin_tail[COMPINS] )
    {
        /* only one entry */
        compin_list[COMPINS] = NULL;
        compin_tail[COMPINS] = NULL;
    }
    else if( compin == compin_list[COMPINS] )
    {   /* compin is first */
        compin_list[COMPINS] = compin->next;
        compin_list[COMPINS]->prev = NULL;
    }
    else if( compin == compin_tail[COMPINS] )
    {   /* compin is last */
        compin_tail[COMPINS] = compin->prev;
        compin_tail[COMPINS]->next = NULL;
    }
    else
    { /* compin in the middle - Don't ya just love arrays? */
        compin->prev->next = compin->next;
        compin->next->prev = compin->prev;
    }
    /* Now tell them it's off */
    fnotify( enactor, "%s%sThe compin chirps as you tap it to turn it off.%s", ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL);
    JFREE(compin);
}




 
COMPIN *find_compin( dbref target )
{
  COMPIN *compin;

    compin = compin_list[COMPINS];

    while( compin != NULL )
     {
	    if( compin->compin_object == target )
	      return compin;

	    compin = compin->next;
     }
  

  return NULL;
}

/* Get this, an exact copy of send_comm_message, just substitute PLANET in to make it work :) */

void planet_send_message( PLANET *planet, unsigned freq, char *message, int format )
{
   SHIP *listener;
   int i;
   dbref bridge, comm_op;

   /* active checks were done a long time ago.  We know that we have a valid
    * ship, frequency, and message.  All we have to do is send it.
    */
 

   listener = space_list[current_space];

   while( listener != NULL )
   {
     
      if( distance( planet->pos, listener->pos ) > COMPIN_RANGE )
      {
	 listener = listener->next;
	 continue;
      }

      /* see if they're monitoring this frequency */
      for( i = 0; i < MAX_CHANNEL; i++ )
      {
	 if( listener->channel[i].frequency == freq  )
         {
	    /* o-tay.  They're listening.  Lay it on 'em */
	    switch( listener->channel[i].receive_status )
            {
	       case CR_COMM_ONLY:
		  /* screen out visuals */
		  if( format == MSG_VISUAL )
		     break;

		  comm_op = match_result(HOWIE, my_atr_get_raw(listener->comm, "XB"), NOTYPE, MAT_ABSOLUTE);
            if( strcmp(listener->channel[i].label,"none"))
            {
        		  fnotify( comm_op, "%s%s<<%s%d%s>>%s %s", ANSI_HILITE, ANSI_RED, ANSI_BLUE, i,
                            ANSI_RED, ANSI_NORMAL, message );
             }
             else
             {
             	fnotify( comm_op, "%s%s<<%s%d:%s%s>>%s %s", ANSI_HILITE, ANSI_RED, ANSI_BLUE, i,
                           listener->channel[i].label, ANSI_RED, ANSI_NORMAL, message );
             }
		  break;

	       case CR_BRIDGE_AUDIO:
		  /* screen out visuals */
		  if( format == MSG_VISUAL )
		     break;
	       case CR_ON_SCREEN:  /* NOTE: Deliberate fall-through */
		  bridge = db[listener->comm].location;
		  sprintf( writebuf, "%s%s<<%s%d:%s%s>>%s %s", ANSI_HILITE, ANSI_RED, ANSI_BLUE, i,
                           listener->channel[i].label, ANSI_RED, ANSI_NORMAL, message );
		  notify_except(db[bridge].contents, listener->comm, writebuf);
		  break;
	       default:
		  break;
	    }
	 }
      }

      listener = listener->next;
   }
}  
/* Just a simple function to update the compin frequency wihtout restarting the compin */
void set_com_freq( dbref executor, int freq )
{
	COMPIN *compin;
	
	compin = find_compin( executor );
	
	if(compin == NULL)
	 return;
	else
	compin->frequency = freq;
	return;
}
