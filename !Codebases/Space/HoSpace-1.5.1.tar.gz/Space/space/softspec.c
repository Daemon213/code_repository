/* Softspec.c
 *
 * Purpose: Stuff moved from stc.c to have specs in softcode
 * instead of in the shell.  Very necessary for Win32 HoSpace since
 * there is no shell :) or the owner of the game would have to be 
 * space wiz.
 *
 * --Howie
 */
 
 
 /* Maybe none of this is needed...hmmm.... */
 /*
void soft_label_wpns( char *str, int type, SHIP *ship )
{
    char arg[30],*x;
    int i;

    str=one_argument(str,arg);
    i = atoi(arg);
    switch( type )
    {
        case WPN_GUN:
            x = ship->phaser[i].label;
            break;
        case WPN_TORP:
            x = ship->photon[i].label;
            break;
        default:
            x = arg;
            break;
    }
    strncpy( x, str, 29 );
    return;
}
*/

ARC soft_read_arc( char *str )
{
    char arg0[30],arg1[30],arg2[30];
    ARC new_arc;

    str=one_argument(str,arg0);
    str=one_argument(str,arg1);
    str=one_argument(str,arg2);

    new_arc.center.bearing = atoi(arg0);
    new_arc.center.elevation = atoi(arg1);
    new_arc.htraverse = atoi(arg2);
    new_arc.vtraverse = atoi(str);
    new_arc.center.range = 1.0;

    return new_arc;
}

/* Oh, and this is the stuff I added since eng.c is so damn long! 
 *
 * --Howie
 */
 int load_soft_specs( dbref ship_object, SHIP *ship)
{
  int i;
  
  strncpy( ship->class, atr_get(ship_object,"CLASS"), CLASS_LEN-1 );
  strncpy( ship->type, atr_get(ship_object,"TYPE"), TYPE_LEN-1 );
  strncpy( ship->short_type, atr_get(ship_object,"SHORT_TYPE"), SHORT_TYPE_LEN-1 );
  strncpy( ship->owner_name, atr_get(ship_object,"OWNER"), OWNER_LEN-1 );

  ship->class[CLASS_LEN-1] = '\0';
  ship->type[TYPE_LEN-1] = '\0';
  ship->owner_name[OWNER_LEN-1] = '\0';

	/* Why the hell is this even in here?  It's not used *
	 * Only the name is.  Oh well. */
  ship->owner = 1;
  
  /* Hull Stuff */
  ship->hull_integrity = (unsigned) (atof((char *) atr_get(ship_object,"HULL_POINTS"))); 
  ship->max_armor_strength = (unsigned) (atoi((char *) atr_get(ship_object,"ARMOR_POINTS")));
  ship->armor_type = atoi( (char *) atr_get(ship_object,"ARMOR_TYPE"));
  ship->durability = atof( (char *) atr_get(ship_object,"DURABILITY"));
  ship->size = atof( (char *) atr_get(ship_object,"HULL_SIZE"));
  
  /* Engine Stuff */
  ship->reactor_output_max = (unsigned) (atoi((char *) atr_get(ship_object,"REACTOR_POWER")));
  ship->max_overload_points = (unsigned) (atoi((char *) atr_get(ship_object,"OVERLOAD_POINTS")));
  ship->reactor_setting_limit = (unsigned) (atoi((char *) atr_get(ship_object,"MAXIMUM_SETTING")));
  ship->reactor_stress_level = (unsigned) (atoi((char *) atr_get(ship_object,"NORMAL_SETTING")));
  ship->reactor_overload_penalty = atof((char *) atr_get(ship_object,"OVERLOAD_PENALTY"));

  /* battery stuff */
  ship->battery_capacity = (unsigned) (atoi((char *) atr_get(ship_object,"BATTERY_POWER")));
  ship->battery_discharge_max = (unsigned) (atoi((char *) atr_get(ship_object,"BATTERY_DISCHARGE_RATE")));
  
  /* general ship characteristics */
  ship->warp_factor = atof((char *) atr_get(ship_object,"WARP_FACTOR"));
  ship->warp_accel = atof((char *) atr_get(ship_object,"WARP_ACCEL")) ;
  ship->warp_decel = atof((char *) atr_get(ship_object,"WARP_DECEL"));
  ship->current_warp_factor = ship->warp_factor;
  ship->warp_max = UMAX( atof((char *) atr_get(ship_object,"MAX_SPEED")), 0.0 );
  ship->impulse_max = UMIN( atof((char *) atr_get(ship_object,"MAX_IMPULSE")), ship->warp_max );
  ship->etemp_speed = atof((char *) atr_get(ship_object,"ETEMP_SPEED"));
  ship->max_etemp_points = (unsigned) (atoi((char *) atr_get(ship_object,"ETEMP_POINTS")));
  ship->transwarp_capable = atoi((char *) atr_get(ship_object,"TRANSWARP_CAPABLE"));
  ship->transwarp_tolerance = atoi((char *) atr_get(ship_object,"TRANSWARP_TOLERANCE"));
  ship->yaw_dps = atof((char *) atr_get(ship_object,"YAW_DPS"));
  ship->pitch_dps = atof((char *) atr_get(ship_object,"PITCH_DPS"));
  
 
  /* cloak */
  ship->cloak_status = (unsigned)(atoi((char *) atr_get(ship_object,"CLOAK_PRESENT")) ? CLOAK_OFF : CLOAK_NONE );
  ship->cloak_cost = (unsigned) (atoi((char *) atr_get(ship_object,"CLOAK_COST")));
  ship->cloak_ratio = atof((char *) atr_get(ship_object,"CLOAK_RATIO"));

  /* interdict */
  ship->interdict_status = ((unsigned)atoi((char *) atr_get(ship_object,"INTERDICT_RANGE"))) ? IDICT_OFF : IDICT_NONE;
  ship->interdict_range = (unsigned) atoi((char *) atr_get(ship_object,"INTERDICT_RANGE"));
  ship->interdict_speed = atof((char *) atr_get(ship_object,"INTERDICT_SPEED"));

  /* sensors */
  ship->sensor_power = atof((char *) atr_get(ship_object,"SENSOR_RANGE"));
  ship->aux_sensor_power = atof((char *) atr_get(ship_object,"AUX_SENSOR_RANGE"));
  ship->sensor_arc = soft_read_arc( (char *) atr_get(ship_object, "SENSOR_ARC"));
  ship->aux_sensor_arc = soft_read_arc( (char *) atr_get(ship_object, "AUX_SENSOR_ARC"));
  ship->scanner_range = atof( (char *) atr_get(ship_object, "SCANNER_RANGE"));
  
  /* comm/transporter */
  ship->transmitter_range = atof( (char *) atr_get(ship_object,"TRANSMITTER_RANGE"));
  ship->receiver_sensitivity = atof( (char *) atr_get(ship_object, "RECIEVER_SENSITIVITY"));
  ship->transporter_range = (unsigned) atoi( (char *) atr_get( ship_object, "TRANSPORTER_RANGE"));
  ship->tractor_range = (unsigned) atoi( (char *) atr_get( ship_object, "TRACTOR_RANGE"));
  ship->max_clients = (unsigned) atoi( (char *) atr_get( ship_object, "MAX_CLIENTS"));
  ship->tractor_mode = MODE_TRACTOR;

  /* misc stuff */
  ship->dock_capacity = (unsigned) atoi( (char *) atr_get( ship_object, "DOCK_CAPACITY")) ;
  ship->dock_max_size = (unsigned) atoi( (char *) atr_get( ship_object, "DOCK_MAX_SIZE"));
  ship->shuttlebay_capacity = (unsigned) atoi( (char*) atr_get( ship_object, "SHUTTLEBAY_MAX_SIZE" ));
  ship->landing_capable = (unsigned) atoi( (char *) atr_get( ship_object, "LANDING_CAPABLE"));
//  atr_add(ship_object, "CARGO_CAPACITY", tprintf("%d", inship.cargo_capacity), HOWIE, NOTHING);

  /* shield stuff */
  ship->shield_factor = atoi( (char *) atr_get( ship_object, "SHIELD_FACTOR"));
//  atr_add(ship_object, "WF", tprintf("%d", inship.shield_power), HOWIE, NOTHING);
//  atr_add(ship_object, "VN", tprintf("%d", inship.shield_charge_rate), HOWIE, NOTHING);

  for( i = 0; i < 4; i++ ) {
    ship->shield_max[i] = (unsigned) atoi((char *) atr_get( ship_object, "SHIELD_POWER"));
    ship->shield_max_charge[i] = (unsigned) atoi( (char *) atr_get(ship_object,"SHIELD_CHARGE_RATE"));
  }

  /* phaser stuff */
  strcpy( ship->phaser_string, (char *) atr_get(ship_object, "GUN_NAME" ));
  ship->number_of_phasers = (unsigned) atoi( (char *) atr_get( ship_object, "NUM_GUNS"));
 // atr_add(ship_object, "WU", tprintf("%d", inship.gun_power), HOWIE, NOTHING);
 // atr_add(ship_object, "WV", tprintf("%ld", inship.gun_range), HOWIE, NOTHING);  
 // atr_add(ship_object, "VO", tprintf("%d", inship.gun_charge_rate), HOWIE, NOTHING);
  if( ship->number_of_phasers > MAX_PHASERS )
    ship->number_of_phasers = MAX_PHASERS;
    
    for( i=0; i < ship->number_of_phasers; i++)
    {
    	char attrib[10];    /* Shouldn't ever be any bigger than this */
    	char gunarc[20];  /* Careful in the softcode..easy buffer overflow!
    	                      ALWAYS parent specs to the supplied default spec
    	                      parent! */
    	sprintf( attrib, "GUN_ARC_%d", i );
    	
    	strcpy(ship->phaser[i].label, (char *) atr_get( ship_object, "GUN_NAME" ));
    	ship->phaser[i].status = PHASER_OFFLINE;
    	ship->phaser[i].power = atoi((char *) atr_get( ship_object, "GUN_POWER" ));
    	ship->phaser[i].range = atol((char *) atr_get( ship_object, "GUN_RANGE" ));
    	ship->phaser[i].range_percent = atof((char *) atr_get( ship_object, "GUN_DELIVERY" ));
    	ship->phaser[i].charge_per_turn = atoi( (char *) atr_get( ship_object, "GUN_CHARGE_RATE"));
    	ship->phaser[i].reliability = atof( (char *) atr_get( ship_object, "GUN_RELIABILITY"));
    	ship->phaser[i].wpn_data.type = WPN_GUN;
    	ship->phaser[i].wpn_data.sfactor = atof( (char *) atr_get( ship_object, "GUN_SFACTOR" ));
    	ship->phaser[i].wpn_data.hfactor = atof( (char *) atr_get( ship_object, "GUN_HFACTOR" ));
    	ship->phaser[i].wpn_data.carryover = atof( (char *) atr_get ( ship_object, "GUN_CARRYOVER" ));
    	ship->phaser[i].wpn_data.taps = atoi( (char *) atr_get( ship_object, "GUN_TAPS" ));
    	
    	/* Here's where it gets harry!  But fun I think :) */
    	sprintf( attrib, "GUN_ARC_%d", i );
    	/* Ok, it's ugly as hell..but I'm brain fried at this point..will recode later */
    	if( strlen( (char *) atr_get( ship_object, attrib )) < 20 )
    	  strcpy( gunarc, (char *) atr_get( ship_object, attrib ));
    	else
    	  log_space( "Bad ARC attribute, %s, on #%d. Fix or that gun will not work!", attr, ship_object);
    	
    	ship->phaser[i].wpn_arc = soft_read_arc( gunarc );
    	
    }	/*FOR*/
  
 /* for( i = 0; i < MAX_PHASERS; i++ )
  {
    ship->phaser[i].label = atr_get();  //FIX ME!!
    ship->phaser[i].status = PHASER_OFFLINE;
    ship->phaser[i].power = inship.gun_power + atoi(atr_get(ship_object, "ADD_PHASER_POWER"));
    ship->phaser[i].range = inship.gun_range;
    ship->phaser[i].range_percent = inship.gun_delivery;
    ship->phaser[i].charge_per_turn = inship.gun_charge_rate;
    ship->phaser[i].reliability = inship.gun_reliability;
    ship->phaser[i].wpn_data.type = inship.gun_signature;
    ship->phaser[i].wpn_data.sfactor = inship.gun_shield_factor;
    ship->phaser[i].wpn_data.hfactor = inship.gun_hull_factor;
    ship->phaser[i].wpn_data.carryover = inship.gun_carryover;
    ship->phaser[i].wpn_data.taps = inship.gun_taps;
    ship->phaser[i].wpn_arc = inship.gun_arc[i];
  } */

  /* photon stuff */


/*  strcpy( ship->photon_string, inship.torp_name );
  ship->number_of_photons = inship.num_torps;
  atr_add(ship_object, "WZ", tprintf("%f", inship.torp_accuracy), HOWIE, NOTHING);
  if( ship->number_of_photons > MAX_PHOTONS )
    ship->number_of_photons = 0;
  ship->torp_reload_time = inship.torp_reload_time;
  ship->torp_max_num_turns_online = inship.torp_max_num_turns_online;
  ship->torp_capacity = inship.num_torps ? inship.torp_capacity : 0;
  ship->torps_remaining = inship.num_torps ? inship.torp_capacity : 0;
  for( i = 0; i < MAX_PHOTONS; i++ )
  {
    strcpy( ship->photon[i].label, inship.torp_label[i] );
    ship->photon[i].power = inship.torp_power + atoi(fetch_attribute(ship_object, "ADD_TORP_POWER"));
    ship->photon[i].range = inship.torp_range;
    ship->photon[i].charge_per_turn = inship.torp_charge_rate;
    ship->photon[i].base_accuracy = inship.torp_accuracy;
    ship->photon[i].reliability = inship.torp_reliability;
    ship->photon[i].wpn_data.type = inship.torp_signature;
    ship->photon[i].wpn_data.sfactor = inship.torp_shield_factor;
    ship->photon[i].wpn_data.hfactor = inship.torp_hull_factor;
    ship->photon[i].wpn_data.carryover = inship.torp_carryover;
    ship->photon[i].wpn_data.taps = inship.torp_taps;
    ship->photon[i].wpn_arc = inship.torp_arc[i];
  }*/

  /* initialize damage control team status */
  ship->damcon_teams = atoi( (char *) atr_get(ship_object, "DAMCON_TEAMS") );
  ship->fullrepair = atoi( (char *) atr_get( ship_object, "FULLREPAIR"));
  if( ship->damcon_teams > MAX_TEAMS )
  {
      ship->damcon_teams = MAX_TEAMS;
  }


 return 1;
}


