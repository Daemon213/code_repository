/*
 * $Id: damage.c,v 1.3 1993/09/24 23:46:03 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


/*
 * $Log: damage.c,v $
 * Revision 1.3  1993/09/24  23:46:03  chuckles
 * use the new log_space function.  General logging cleanup.
 *
 * Revision 1.2  1993/09/07  02:24:03  chuckles
 * notify viewers of disabled ships
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS 24 May 93 - separated into damage.c
 * JMS ?? Sep 92 - original code
 * MRR  4 Apr 97 - Fixed ships being destroyed.  No longer crashes us.
 */

/* This is the New BubbyFacing */
int Bubby_facing_shield(SHIP *shooter, SHIP *target)
{
   float dx = target->pos.x - shooter->pos.x,  /* from shooter to target */ 
          dy = target->pos.y - shooter->pos.y,
         dz = target->pos.z - shooter->pos.z;
   SPH heading = target->motion;
   XYZ unitvec, unitnorm, imagevector;
   float angle=0.0;

   heading.range = 1.0;
   unitvec = sph_to_xyz(heading);

   if ((heading.bearing > 90.0) && (heading.bearing <= 270.0))
           heading.elevation += 90.0;
   else
        heading.elevation -= 90.0;

   unitnorm = sph_to_xyz(heading);

   imagevector.x = (dy * unitnorm.z) - (dz * unitnorm.y);
   imagevector.y = (dz * unitnorm.x) - (dx * unitnorm.z);
   imagevector.z = (dx * unitnorm.y) - (dy * unitnorm.x);

   angle = acos((imagevector.x * unitvec.x + imagevector.y * unitvec.y +
        	imagevector.z * unitvec.z) /
            (sqrt(imagevector.x*imagevector.x+imagevector.y*imagevector.y+
        	imagevector.z*imagevector.z))) * 180/PI; 

   log_space("unitvec.x %3.2f unitvec.y %3.2f unitvec.z %3.2f", unitvec.x,
        unitvec.y, unitvec.z);
   log_space("unitnorm.x %3.2f unitnorm.y %3.2f unitnorm.z %3.2f",
        unitnorm.x, unitnorm.y, unitnorm.z);
   log_space("imagevector.x %3.2f imagevector.y %3.2f imagevector.z %3.2f", 
        imagevector.x, imagevector.y, imagevector.z);
   log_space("Angle: %3.2f", angle);

   if ((angle >= -150.0) && (angle <= -30.0))
        return(FORE_SHIELD);
   else if ((angle >= -30.0) && (angle <= 30.0))
        return(PORT_SHIELD);
   else if ((angle >= 30.0) && (angle <= 150.0))
        return(AFT_SHIELD);
   else return(STARBOARD_SHIELD);
}

double HappyAcos(double x)
{
  /* Like acos(), but has domain checks. */

  if (x < -1.0)
    return acos(-1.0);
  else if (x > 1.0)
    return acos(1.0);
  else
    return acos(x);
}

#define DotProduct( a, b )  ( (((a).x)*((b).x)) + (((a).y)*((b).y)) + (((a).z)*((b).z)) ) 
#define Norm( a )  ( sqrt(DotProduct((a),(a))) )

#define PORT_ANGLE        -90
#define STARBOARD_ANGLE 90

#define DEGREES_IN_RADIAN        (180/PI)

/* This function, of course, could use cross products. */
/* Personally, I absolutely hate cross products.  Using Dot products */
/* is much nicer--perhaps you might want to have n-space ships someday */

int facing_shield(SHIP *shooter, SHIP *target_ship)
{
        XYZ target;	/* from target to shooter */
        SPH heading;
        XYZ fore_shield, port_shield;
        float angle=0.0;

        heading = target_ship->motion; 

        /* A vector from the target to the shooter */
        target.x = shooter->pos.x - target_ship->pos.x;
        target.y = shooter->pos.y - target_ship->pos.y;
        target.z = shooter->pos.z - target_ship->pos.z;

        /* Unit vector in the center of target's fore shield */
        heading.range = 1.0;
        fore_shield = sph_to_xyz( heading );

        /* The angle between the center of the fore shield and the shooter */
        if ( Norm( target ) == 0 )
          return (STARBOARD_SHIELD);
        else
        angle = HappyAcos( DotProduct( fore_shield, target ) / Norm( target ) )
        	* DEGREES_IN_RADIAN;

        /* Categorize shield as fore or aft is possible */
        if (angle <= 60.0)
        	return (FORE_SHIELD);
        if (angle >= 120.0)
        	return (AFT_SHIELD);

        /* Categorization failed, thus the shield must be port or starboard */
        /* We can ignore the cases of fore or aft as a possibility */

        /* Get a unit vector in the center of target's port shield */
        heading.range = 1.0;
        heading.bearing += PORT_ANGLE;
        port_shield = sph_to_xyz( heading );

        /* Find the angle between the port shield side and the shooter */
        angle = HappyAcos( DotProduct( port_shield, target ) / Norm( target ) )
        	* DEGREES_IN_RADIAN;

        /* Is the angle on the port-side half? */
        if (angle <= 90.0)
        	return (PORT_SHIELD);

        /* No, so it must be on the starboard side */
        return (STARBOARD_SHIELD);
}

int old_facing_shield( SHIP *shooter, SHIP *target )
{
   float dx1, dy1, dz1, dx2, dy2, dz2, dx3, dy3, dz3;
   float theta, psi;
   float angle_from_front;

   dx1 = shooter->pos.x - target->pos.x;
   dy1 = shooter->pos.y - target->pos.y;
   dz1 = shooter->pos.z - target->pos.z;

   theta =  ( target->motion.bearing * PI / 180.0 );
   psi = ( target->motion.elevation * PI / 180.0 );

   dx2 = dx1*cos( psi ) + dy1*sin( psi );
   dy2 = dy1*cos( psi ) - dx1*sin( psi );
   dz2 = dz1;

   dx3 = dx2*cos( theta ) + dz2*sin( theta );
   dy3 = dy2;
   dz3 = dz2*cos( theta ) - dx2*sin( theta );

   if( dx3 == 0.0 )
      angle_from_front = 90.0;
   else {
      if (dx3 > sqrt(dx3*dx3 + dy3*dy3 + dz3*dz3))
        angle_from_front = 0.0;
      else if ( dx3 < -(sqrt(dx3*dx3 + dy3*dy3 + dz3*dz3)))
        angle_from_front = 180.0;
      else
        angle_from_front = acos( dx3 / sqrt( dx3*dx3 + dy3*dy3 + dz3*dz3 )) 
        		   * 180.0 / PI;
   }
   if( angle_from_front <= 60.0 ) return( FORE_SHIELD );
   if( angle_from_front >= 120.0 ) return( AFT_SHIELD );
   if( dz3 < 0.0 ) return( PORT_SHIELD );
   return( STARBOARD_SHIELD );
}

int battle_damage( SHIP *shooter,SHIP *target, int damage, WDATA weapon )
{
    int shield_hit,destroyed=0,absorb=0,i;
    dbref navigator;
    SHIP *victim;
    CONTACT *contact;
    char description[80],*vbuff[2];
    dbref helm, nav, comm, eng;

    static char *cap_strings[4]=
    {
        (char *)"Fore", 
        (char *)"Aft", 
        (char *)"Port", 
        (char *)"Starboard"
    };
    static char *shield_string[4]=
    {
        (char *)"fore", 
        (char *)"aft", 
        (char *)"port", 
        (char *)"starboard"
    };
    if( weapon.type==WPN_KAMIKAZE )
    {
        shield_hit=0;
    }
    else
    {
        shield_hit = facing_shield( shooter, target );
    }
    navigator = match_result(HOWIE, my_atr_get_raw(target->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
    /* if the target is set invincible, set the damage to zero */
    if( target->flags[INVINCIBLE] )
    {
        damage = 0;
    }
    if( target->shield_status[shield_hit]==SHLD_UP
    && target->shield_level[shield_hit] > 0 )
    {
        damage *= weapon.sfactor;
        if( damage > target->shield_level[shield_hit] )
        {
            damage -= (damage-target->shield_level[shield_hit]) * (1.0-weapon.carryover);
        }
        if( damage < target->shield_level[shield_hit] )
        {
            target->shield_level[shield_hit] -= damage;
            fnotify( navigator, "%s%s%s shield reduced %d - down to %i%%!%s", ANSI_HILITE,
                ANSI_RED, cap_strings[shield_hit], damage,
                (int)((float)target->shield_level[shield_hit] /
                (float)target->shield_max[shield_hit] * 100.0), ANSI_NORMAL );
            if( target->shield_level[shield_hit] > target->shield_max[shield_hit] )
            {
                damage /= 50;
            }
            else
            {
                damage /= 100;
            }
        }
        else
        {
            sprintf( writebuf, "%s%s%s shield failed!%s", ANSI_HILITE, ANSI_RED,
                cap_strings[shield_hit], ANSI_NORMAL );
            notify( navigator, writebuf );
            damage -= target->shield_level[shield_hit];
            target->shield_level[shield_hit] = 0;
        }
    }
    else
    {
        sprintf( writebuf, "%s%sDirect hit to %s!%s", ANSI_HILITE, ANSI_RED,
            shield_string[shield_hit], ANSI_NORMAL);
        notify( navigator, writebuf );
    }
    if( target->shield_level[shield_hit]<=0 || target->shield_status[shield_hit]!=SHLD_UP )
    {
        damage *= weapon.hfactor;
    }
    if( target->armor_strength[shield_hit] > 0 )
    {
        switch( target->armor_type )
        {
            case ARMR_ABLT:
                switch( weapon.type )
                {
                    case WPN_GUN:
                        absorb = damage * 99 / 100;
                        break;
                    case WPN_TORP:
                        absorb = damage * 10 / 100;
                        break;
                    case WPN_DISABLER:
                        absorb = 0;
                        break;
                    default:
                        absorb = damage * 5 / 100;
                        break;
                }
                if( target->armor_strength[shield_hit] >= absorb && absorb!=0 )
                {
                    target->armor_strength[shield_hit] -= absorb;
                    sprintf( writebuf, "%s%s%s ablative armor reduced %d - down to %i%%!%s", ANSI_HILITE,
                        ANSI_RED, cap_strings[shield_hit], absorb,
                        (int) ((float)target->armor_strength[shield_hit] /
                        (float)target->max_armor_strength * 100.0), ANSI_NORMAL );
                    notify_room( BRIDGE(target), writebuf );
                }
                else if( absorb!=0 )
                {
                    absorb -= target->armor_strength[shield_hit];
                    target->armor_strength[shield_hit] = 0;
                    sprintf(writebuf,"%s ablative armor has failed!",cap_strings[shield_hit]);
                    notify_room( BRIDGE(target), writebuf );
                }
                damage -= UMIN(absorb,damage);
                break;
            case ARMR_PLATE:
                switch( weapon.type )
                {
                    default:
                        absorb = UMIN(target->armor_strength[shield_hit],damage);
                        break;
                    case WPN_TORP:
                        absorb = UMIN(target->armor_strength[shield_hit]*3/4,damage);
                        break;
                    case WPN_DISABLER:
                        absorb = 0;
                        break;
                }
                damage -= absorb;
                if( damage > target->armor_strength[shield_hit] )
                {
                    absorb = UMIN( target->armor_strength[shield_hit], damage/100 );
                    if( absorb < target->armor_strength[shield_hit] )
                    {
                        sprintf(writebuf,"%s armor damaged %d! Down to %d%%.",
                            cap_strings[shield_hit], absorb,
                            target->armor_strength[shield_hit]-absorb );
                    }
                    else
                    {
                        sprintf(writebuf,"%s armor has failed!", cap_strings[shield_hit] );
                    }
                    notify_room( BRIDGE(target), writebuf );
                    target->armor_strength[shield_hit] -= absorb;
                }
                break;
            default:
                break;
        }
    }
    if( damage==0 )
    {
        return 0;
    }
    if( weapon.type!=WPN_DISABLER )
    {
        target->current_integrity -= damage;
    }
    /* update the permanent damage register */
    if( !target->fullrepair && weapon.type!=WPN_DISABLER )
    {
        target->permanent_hull_damage += ( damage / 10 );
    }
    if( target->current_integrity <= ( -target->hull_integrity * 0.333333 ) )
    {
        /* abandon ship? Abandon ship! All hands, abandon ship! */
/*        sprintf( writebuf, "FN_BLOWUP" );
        vbuff[0] = writebuf;
        vbuff[1] = NULL;
        fun_ufun( writebuf, vbuff, 1, vbuff, target->eng, HOWIE, HOWIE, "U", NULL );*/
        sprintf( writebuf, "%s%sHull has failed.  Ship destroyed.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        notify_room(BRIDGE(target), writebuf);
        if( BRIDGE(target)!=ENGINE(target) )
        {
            notify_room(ENGINE(target), writebuf); 
        }
        /* If in real space, log it */
        if( current_space == REAL )
        {
            atr_add( target->ship_object, "UNDOCKED", "0", (HOWIE), NOTHING );
        }
        /* notify anyone who has sensor contact */
        victim = space_list[current_space];
        while( victim != NULL )
        {
            for(contact=victim->contact_list;contact!=NULL;contact=contact->next)
            {
                if( contact->listref==target )
                {
                    contact_string( description, contact, INFO_TERSE );
                    sprintf( writebuf, "\n%s%s***** Contact [%s%d%s]: %s%s%s%s DESTROYED. *****%s\n",
                        ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, contact->contact_number,
                        ANSI_RED, ANSI_NORMAL, description, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify_room(BRIDGE(victim), writebuf);
                    break;
                }
            }
            victim = victim->next;
        }
        deallocate_ship( target );
        return 1;
    }
    if( weapon.type!=WPN_DISABLER && ( target->shield_level[shield_hit] <= 0
    || target->shield_status[shield_hit]!=SHLD_UP ) )
    {
        sprintf( writebuf, "%s%sHull damaged %d -- integrity now at %d%%%s", ANSI_HILITE,
            ANSI_RED, damage, ( 100 * target->current_integrity / target->hull_integrity ),
            ANSI_NORMAL );
        notify_room(BRIDGE(target), writebuf);
        if( BRIDGE(target)!=ENGINE(target) )
        {
            notify_room(ENGINE(target), writebuf);
        }
    }
    /* now check and see if the target is disabled */
    if( target->current_integrity <= 0 )
    {
        sprintf( writebuf, "%s%sShip disabled.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room(BRIDGE(target), writebuf);
        if( BRIDGE(target) != ENGINE(target) )
        {
            notify_room(ENGINE(target), writebuf);
        }
        eng_allocate( target, -1, 0, 0, 0 );      
        if( !target->flags[DISABLED] )
        {
            target->flags[DISABLED] = 1;
            victim = space_list[current_space];
            while( victim != NULL )
            {
                for(contact=victim->contact_list;contact!=NULL;contact=contact->next)
                {
                    if( contact->listref == target )
                    {
                        contact_string( description, contact, INFO_TERSE );
                        sprintf( writebuf, "\n%s%s+++++ Contact [%s%d%s]: %s%s%s%s DISABLED. +++++%s\n",
                            ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, contact->contact_number,
                            ANSI_RED, ANSI_NORMAL, description, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                        notify_room(BRIDGE(victim), writebuf);
                        break;
                    }
                }
                victim = victim->next;
            }
        } 
    }
    /* now break some ship systems */
    if( shooter->target_system==SYSTEM_HULL || shooter->target_system < 0
    || shooter->target_system >= NUM_SYSTEMS
    || weapon.type==WPN_RAM || weapon.type==WPN_KAMIKAZE
    || ( weapon.type!=WPN_GUN && FRAND > 0.5 ) )
    {
        for(i=0;i<weapon.taps;i++)
        {
            if( system_damage( target, damage/weapon.taps, weapon.type ) )
            {
                return 1;
            }
        }
        return 0;
    }
    else
    {
        for(i=0;i<weapon.taps;i++)
        {
            if( specific_system_damage(target,damage/weapon.taps,shooter->target_system,weapon.type) )
            {
                return 1;
            }
            else if( system_damage( target, damage/weapon.taps/4, weapon.type ) )
            {
                return 1;
            }
        }
        return 0;
    }
    return 0;
}

int damage_hull( SHIP *ship, int damage, int control )
{
    SHIP *target;
    CONTACT *contact;
    char description[80];
    dbref helm, nav, comm, eng;

    if( damage == 0 )
    {
        return 0;
    }
    ship->current_integrity -= damage;

    /* update the permanent damage register */
    if( !ship->flags[STARBASE] )
    {
        ship->permanent_hull_damage += ( damage / 10 );
    }
    if( ship->current_integrity <= ( -ship->hull_integrity ) )
    {
        sprintf( writebuf, "%s%sHull has failed.  Ship destroyed.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        notify_room(BRIDGE(ship), writebuf);
        if( BRIDGE(ship)!=ENGINE(ship) )
        {
            notify_room(ENGINE(ship), writebuf); 
        }
        /* If in real space, log it */
        if( current_space == REAL )
        {
            atr_add( ship->ship_object, "UNDOCKED", "0", (HOWIE), NOTHING );
        }
        /* notify anyone who has sensor contact */
        target = space_list[current_space];
        while( target != NULL )
        {
            for(contact=target->contact_list;contact!=NULL;contact=contact->next)
            {
                if( contact->listref == ship )
                {
                    contact_string( description, contact, INFO_TERSE );
                    sprintf( writebuf, "\n%s%s***** Contact [%s%d%s]: %s%s%s%s DESTROYED. *****%s\n",
                        ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, contact->contact_number,
                        ANSI_RED, ANSI_NORMAL, description, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify_room(BRIDGE(target), writebuf);
                    break;
                }
            }
            target = target->next;
        }
        deallocate_ship( ship );
        return 1;
    }
    if( control == INFO_VERBOSE )
    {
        sprintf( writebuf, "%s%sHull damaged %d -- integrity now at %d%%%s", ANSI_HILITE,
            ANSI_RED, damage, ( 100 * ship->current_integrity / ship->hull_integrity ),
            ANSI_NORMAL );
        notify_room(BRIDGE(ship), writebuf);
        if( BRIDGE(ship)!=ENGINE(ship) )
        {
            notify_room(ENGINE(ship), writebuf);
        }
    }
    /* now break some ship systems */
    if( system_damage( ship, damage, WPN_DISABLER ) )
    {
        return 1;
    }
    /* now check and see if the target is disabled */
    if( ship->current_integrity <= 0 )
    {
        sprintf( writebuf, "%s%sShip disabled.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room(BRIDGE(ship), writebuf);
        if( BRIDGE(ship) != ENGINE(ship) )
        {
            notify_room(ENGINE(ship), writebuf);
        }
        eng_allocate( ship, -1, 0, 0, 0 );      
        if( !ship->flags[DISABLED] )
        {
            ship->flags[DISABLED] = 1;
            target = space_list[current_space];
            while( target != NULL )
            {
                for(contact=target->contact_list;contact!=NULL;contact=contact->next)
                {
                    if( contact->listref == ship )
                    {
                        contact_string( description, contact, INFO_TERSE );
                        sprintf( writebuf, "\n%s%s+++++ Contact [%s%d%s]: %s%s%s%s DISABLED. +++++%s\n",
                            ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, contact->contact_number,
                            ANSI_RED, ANSI_NORMAL, description, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                        notify_room(BRIDGE(target), writebuf);
                        break;
                    }
                }
                target = target->next;
            }
        } 
    }
    return 0;
}

int specific_system_damage( SHIP *ship, int damage, int target, int weapon )
{
    int before, after;   /* used in damage calculation */
    float ratio;         /* fraction lost in the attack */
    float chance;        /* chance of losing a given system */
    int i;

    after = ship->current_integrity;
    before = after + damage;
    ratio = (float)damage / (float)before;
    chance = fabs( ratio * 0.9 ) / ship->durability;
    switch( target )
    {
        case SYSTEM_GUN_0:
        case SYSTEM_GUN_1:
        case SYSTEM_GUN_2:
        case SYSTEM_GUN_3:
        case SYSTEM_GUN_4:
        case SYSTEM_GUN_5:
        case SYSTEM_GUN_6:
        case SYSTEM_GUN_7:
        case SYSTEM_GUN_8:
        case SYSTEM_GUN_9:
        case SYSTEM_GUN_10:
        case SYSTEM_GUN_11:
        case SYSTEM_GUN_12:
        case SYSTEM_GUN_13:
        case SYSTEM_GUN_14:
        case SYSTEM_GUN_15:
        case SYSTEM_GUN_16:
        case SYSTEM_GUN_17:
        case SYSTEM_GUN_18:
        case SYSTEM_GUN_19:
            chance *= 1.15;
            break;
        case SYSTEM_TORP_0:
        case SYSTEM_TORP_1:
        case SYSTEM_TORP_2:
        case SYSTEM_TORP_3:
        case SYSTEM_TORP_4:
        case SYSTEM_TORP_5:
        case SYSTEM_TORP_6:
        case SYSTEM_TORP_7:
        case SYSTEM_TORP_8:
        case SYSTEM_TORP_9:
        case SYSTEM_TORP_10:
        case SYSTEM_TORP_11:
        case SYSTEM_TORP_12:
        case SYSTEM_TORP_13:
        case SYSTEM_TORP_14:
        case SYSTEM_TORP_15:
        case SYSTEM_TORP_16:
        case SYSTEM_TORP_17:
        case SYSTEM_TORP_18:
        case SYSTEM_TORP_19:
            chance *= 0.85;
            break;
        case SYSTEM_SCANNERS:
            chance /= 2.0;
            break;
        case SYSTEM_ENGINE:
            chance *= 0.9;
        case SYSTEM_SENSORS:
        case SYSTEM_AUX_SENSORS:
            chance /= 3.0;
            break;
        case SYSTEM_LANDING_GEAR:
            if( weapon==WPN_DISABLER )
            {
                chance = 0.0;
            }
            else
            {
                chance /= 4.0;
            }
            break;
        case SYSTEM_TARGETTING:
        case SYSTEM_IMPULSE:
            chance *= 0.8;
            break;
        case SYSTEM_WARP:
            chance *= 3.0;
            break;
        case SYSTEM_PAINT_JOB:
            if( weapon==WPN_DISABLER )
            {
                chance = 0.0;
            }
            else
            {
                chance *= 100.0;
            }
            break;
        case SYSTEM_HULL:
        case SYSTEM_CRYSTAL:
            chance = 0.0;
            break;
        case SYSTEM_TRANSPORTERS:
            if( ship->current_integrity < 0 )
            {
                chance *= 10.0;
            }
            else
            {
                chance /= 5.0;
            }
            break;
    }
    if( FRAND <= chance )
    {
        return break_system( ship, target );
    }
    else
    {
        return 0;
    }
}

int system_damage( SHIP *ship, int damage, int weapon )
{
    int before, after;   /* used in damage calculation */
    float ratio;         /* fraction lost in the attack */
    float chance;        /* chance of losing a given system */
    int i;

    after = ship->current_integrity;
    before = after + damage;
    ratio = (float)damage / (float)before;
    chance = fabs( ratio * 0.3 ) / ship->durability;

    /* reactor */
    if( FRAND < ( chance / 3.0 ) )
    {
        if( break_system( ship, SYSTEM_ENGINE ) )
        {
            return 1;
        }
    }
    /* shields */
    for( i = 0; i < 4; i++ )
    {
        if( FRAND < chance )
        {
            break_system( ship, SYSTEM_SHIELD_FORE + i );
        }
    }
    if( FRAND < chance )
    {
        break_system( ship, SYSTEM_TRACTOR );
    }
    /* cloaking device */
    if( FRAND < chance )
    {
        break_system( ship, SYSTEM_CLOAK );
    }
    /* batteries */
    if( FRAND < chance )
    {
        break_system( ship, SYSTEM_BATTERIES );
    }
    /* warp drive */
    if( FRAND < (1.5*chance) )
    {
        break_system( ship, SYSTEM_WARP );
    }
#if defined(WARP_IMPULSE)
    if( FRAND < (chance*0.75) )
    {
        break_system( ship, SYSTEM_IMPULSE );
    }
#endif
    /* phasers */
    for( i = 0; i < ship->number_of_phasers; i++ )
    {
        if( FRAND < chance*1.15 )
        {
            break_system( ship, SYSTEM_GUN_0 + i );
        }
    }
    /* photons */
    for( i = 0; i < ship->number_of_photons; i++ )
    {
        if( FRAND < (chance*0.85) )
        {
            break_system( ship, SYSTEM_TORP_0 + i );
        }
    }
    /* active scanners */
    if( FRAND < chance / 2)
    {
        break_system( ship, SYSTEM_SCANNERS );
    }
    /* passive sensors */
    if( FRAND < ( chance / 3 ) )
    {
        break_system( ship, SYSTEM_SENSORS );
    }
    if( FRAND < ( chance / 3 ) )
    {
        break_system( ship, SYSTEM_AUX_SENSORS );
    }
    /* paint job */
    if( weapon!=WPN_DISABLER && FRAND < ( chance * 20.0 ) )
    {
        break_system( ship, SYSTEM_PAINT_JOB );
    }
    if( FRAND < (chance*0.8) )
    {
        break_system( ship, SYSTEM_TARGETTING );
    }
    if( weapon!=WPN_DISABLER && FRAND < (chance/4.0) )
    {
        break_system( ship, SYSTEM_LANDING_GEAR );
    }
    if( FRAND < chance )
    {
        break_system( ship, SYSTEM_TRANSWARP );
    }
    if( FRAND < chance*0.75 )
    {
        break_system( ship, SYSTEM_DISSIPATOR );
    }
    if( FRAND < chance/5.0 )
    {
        break_system( ship, SYSTEM_TRANSPORTERS );
    }
    /* now update the damage register */
    write_damage( ship );   
    return 0;
}

int break_system( SHIP *ship, int bustee )
{
    dbref helmsman,navigator,engineer,dmg_officer;
    int i,x,y,z;
    static char *shield_strings[]=
    {
        (char *)"Fore", 
        (char *)"Aft", 
        (char *)"Port", 
        (char *)"Starboard"
    };
    helmsman = attrib_dbref( ship->helm, "XB" );
    navigator = attrib_dbref( ship->nav, "XB" );
    engineer = attrib_dbref( ship->eng, "XB" );
    dmg_officer = attrib_dbref( ship->damcon, "XB" );
    switch( bustee )
    {
        case SYSTEM_ENGINE:
            ship->damage[SYSTEM_ENGINE].status += (int)(( FRAND * 3 ) + 2 );
            if( ship->damage[SYSTEM_ENGINE].status > '8' )
            {
                log_space("%s destroyed by warp core breach.", ship->name );
                sprintf( writebuf, "%s%sAntimatter chamber breach.  Ship destroyed.%s", ANSI_HILITE,
                    ANSI_RED, ANSI_NORMAL );
                notify_room(BRIDGE(ship), writebuf);
                if( BRIDGE(ship) != ENGINE(ship) )
                notify_room(ENGINE(ship), writebuf); 
                explode_ship( ship );
                return 1;
            }
            /* The ship survived. */
            ship->damage[SYSTEM_ENGINE].time_to_fix = 150 * (ship->damage[SYSTEM_ENGINE].status-'0');
            ship->current_reactor_output_max = ship->reactor_output_max *
                ( 1 - ((float)( ship->damage[SYSTEM_ENGINE].status - '0' ) * 0.1 )) *
                ( 1 - ((float)( ship->damage[SYSTEM_CRYSTAL].status - '0' ) * 0.1 ));
            sprintf( writebuf, "%s%sReactor damage.  New max power is %d.%s", ANSI_HILITE, 
                ANSI_RED, ship->current_reactor_output_max, ANSI_NORMAL );
            notify( engineer, writebuf );
            if( engineer != dmg_officer )
                notify( dmg_officer, writebuf );
            eng_alloc_check( ship, engineer );
            break;
        case SYSTEM_SHIELD_FORE:
        case SYSTEM_SHIELD_AFT:
        case SYSTEM_SHIELD_PORT:
        case SYSTEM_SHIELD_STARBOARD:
            i=bustee-SYSTEM_SHIELD_FORE;
            switch( ship->damage[SYSTEM_SHIELD_FORE + i].status )
            {
                case 'x':
                case 'X':
                case '9': /* already gone.  Leave it alone */
                    break;
                case '7': /* already damaged.  Waste it. */
                    sprintf( writebuf, "%s%s%s shield destroyed.%s", ANSI_HILITE, ANSI_RED,
                        shield_strings[i], ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer ) 
                        notify( dmg_officer, writebuf );
                    ship->shield_level[i] = 0;
                    if( ship->cloak_status == CLOAK_ON )
                    {
                        fnotify( navigator, "%s%sCloaking device failing due to shield loss.%s",
                            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                        disengage_cloak( ship, navigator );
                    }
                    ship->damage[bustee].status = '9';
                    ship->shield_status[i] = SHLD_DAMAGED;
                    break;
                 case '6':   /* damaged once already.  send inoperable */
                 case '1':
                    sprintf( writebuf, "%s%s%s shield damaged.%s", ANSI_HILITE, ANSI_RED,
                        shield_strings[i], ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator != dmg_officer ) 
                        notify( dmg_officer, writebuf );
                    ship->shield_level[i] = 0;
                    if( ship->cloak_status == CLOAK_ON )
                    {
                        fnotify( navigator, "%s%sCloaking device failing due to shield loss.%s",
                            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                        disengage_cloak( ship, navigator );
                    }
                    ship->damage[bustee].status = '7';
                    ship->damage[bustee].time_to_fix = 600;
                    ship->shield_status[i] = SHLD_DAMAGED;
                    break;
                case '0':   /* in normal working condition.  Damage it. */
                    sprintf( writebuf, "%s%s%s shield damaged.%s", ANSI_HILITE, ANSI_RED,
                        shield_strings[i], ANSI_NORMAL );
                   notify( navigator, writebuf );
                   if( navigator != dmg_officer )
                       notify( dmg_officer, writebuf );
                   ship->damage[bustee].status = '6';
                   ship->damage[bustee].time_to_fix = 300;
                   ship->shield_max[i] *= 0.5;
                   ship->shield_max_charge[i] *= 0.5;
                   if( ship->shield_level[i] > (int)( (float)ship->shield_max[i] * 0.9 ) )
                       ship->shield_level[i] = (int)( (float)ship->shield_max[i] * 0.9 );
                   break;
            }
            break;
        case SYSTEM_TRACTOR:
            switch( ship->damage[SYSTEM_TRACTOR].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '7':
                    sprintf( writebuf, "%s%sTractor beam destroyed.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TRACTOR].status = '9';
                    break;
                default:
                    sprintf( writebuf, "%s%sTractor beam damaged.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    if( ship->damage[SYSTEM_TRACTOR].status=='0' )
                    {
                        ship->damage[SYSTEM_TRACTOR].status = '7';
                        ship->damage[SYSTEM_TRACTOR].time_to_fix = 600;
                    }
                    else
                    {
                        ship->damage[SYSTEM_TRACTOR].status = '8';
                        ship->damage[SYSTEM_TRACTOR].time_to_fix = 800;
                    }
                    break_tractor( ship );
                    break;
            }
            break;
        case SYSTEM_CLOAK:
            switch( ship->damage[SYSTEM_CLOAK].status )
            {
                default:
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                    sprintf( writebuf, "%s%sCloak is destroyed.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_CLOAK].status = '9';
                    break;
                case '1':
                    sprintf( writebuf, "%s%sCloak is damaged.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator != dmg_officer ) 
                        notify( dmg_officer, writebuf );
                    if( ship->cloak_status == CLOAK_ON )
                        disengage_cloak( ship, navigator );
                    ship->damage[SYSTEM_CLOAK].status = '8';
                    ship->damage[SYSTEM_CLOAK].time_to_fix = 650;
                    break;
                case '0':
                    sprintf( writebuf, "%s%sCloak is damaged.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator != dmg_officer ) 
                        notify( dmg_officer, writebuf );
                    if( ship->cloak_status == CLOAK_ON )
                        disengage_cloak( ship, navigator );
                    ship->damage[SYSTEM_CLOAK].status = '7';
                    ship->damage[SYSTEM_CLOAK].time_to_fix = 600;
                    break;
            }
            break;
        case SYSTEM_BATTERIES:
            switch( ship->damage[SYSTEM_BATTERIES].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '7':
                    ship->battery_level = 0;
                    ship->damage[SYSTEM_BATTERIES].status = '9';
                    ship->battery_status = BTTY_DAMAGED;
                    sprintf( writebuf, "%s%sBatteries destroyed.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( engineer, writebuf );
                    if( engineer != dmg_officer )
                        notify( dmg_officer, writebuf );
                    eng_alloc_check( ship, engineer );
                    break;
                case '6':
                case '1':
                    ship->damage[SYSTEM_BATTERIES].status = '7';
                    ship->damage[SYSTEM_BATTERIES].time_to_fix = 600;
                    ship->battery_status = BTTY_DAMAGED;
                    sprintf( writebuf, "%s%sBatteries damaged. Inpoerable.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( engineer, writebuf );
                    if( engineer != dmg_officer ) 
                        notify( dmg_officer, writebuf ); 
                    eng_alloc_check( ship, engineer );
                    break;
                case '0':
                    ship->damage[SYSTEM_BATTERIES].status = '6';
                    ship->damage[SYSTEM_BATTERIES].time_to_fix = 300;
                    ship->battery_discharge_max /= 2;
                    sprintf( writebuf, "%s%sBatteries damaged.  Output reduced 50%%.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( engineer, writebuf );
                    if( engineer != dmg_officer )
                        notify( dmg_officer, writebuf );
                    eng_alloc_check( ship, engineer );
                    break;
            }
            break;
        case SYSTEM_GUN_0:
        case SYSTEM_GUN_1:
        case SYSTEM_GUN_2:
        case SYSTEM_GUN_3:
        case SYSTEM_GUN_4:
        case SYSTEM_GUN_5:
        case SYSTEM_GUN_6:
        case SYSTEM_GUN_7:
        case SYSTEM_GUN_8:
        case SYSTEM_GUN_9:
        case SYSTEM_GUN_10:
        case SYSTEM_GUN_11:
        case SYSTEM_GUN_12:
        case SYSTEM_GUN_13:
        case SYSTEM_GUN_14:
        case SYSTEM_GUN_15:
        case SYSTEM_GUN_16:
        case SYSTEM_GUN_17:
        case SYSTEM_GUN_18:
        case SYSTEM_GUN_19:
            i = bustee-SYSTEM_GUN_0;
            x=atof( my_atr_get_raw( ship->ship_object, "WU" ) );
            y=atof( my_atr_get_raw( ship->ship_object, "WV" ) );
            z=atof( my_atr_get_raw( ship->ship_object, "VO" ) );
            switch( ship->damage[SYSTEM_GUN_0 + i].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                    ship->damage[SYSTEM_GUN_0 + i].status = '9';
                    sprintf( writebuf, "%s%s%s %d destroyed.%s", ANSI_HILITE, ANSI_RED,
                        ship->phaser_string, i, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    if( ship->phaser[i].status == PHASER_ONLINE )
                        ship->num_phasers_online--;
                    ship->phaser[i].status = PHASER_DAMAGED;
                    ship->phaser[i].charge = 0;
                    break;
                case '6':
                case '5':
                    ship->damage[SYSTEM_GUN_0 + i].status = '7';
                    ship->damage[SYSTEM_GUN_0 + i].time_to_fix = 600;
                    sprintf( writebuf, "%s%s%s %d damaged. Inoperable.%s", ANSI_HILITE, ANSI_RED,
                        ship->phaser_string, i, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    if( ship->phaser[i].status == PHASER_ONLINE )
                        ship->num_phasers_online--;
                    ship->phaser[i].status = PHASER_DAMAGED;
                    ship->phaser[i].charge = 0;
                    break;
                case '4':
                case '3':
                    ship->damage[SYSTEM_GUN_0 + i].status = '6';
                    ship->damage[SYSTEM_GUN_0 + i].time_to_fix = 450;
                    ship->phaser[i].range = y * 0.5;
                    ship->phaser[i].power = x * 0.5;
                    ship->phaser[i].charge_per_turn = z * 0.5;
                    sprintf( writebuf, "%s%s%s %d heavily damaged.%s", ANSI_HILITE, ANSI_RED,
                        ship->phaser_string, i, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    break;
                case '2':
                case '1':
                    ship->damage[SYSTEM_GUN_0 + i].status = '4';
                    ship->damage[SYSTEM_GUN_0 + i].time_to_fix = 300;
                    ship->phaser[i].range = y * 0.65;
                    ship->phaser[i].power = x * 0.65;
                    ship->phaser[i].charge_per_turn = z * 0.65;
                    sprintf( writebuf, "%s%s%s %d moderately damaged.%s", ANSI_HILITE, ANSI_RED,
                        ship->phaser_string, i, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    break;
                case '0':
                    ship->damage[SYSTEM_GUN_0 + i].status = '2';
                    ship->damage[SYSTEM_GUN_0 + i].time_to_fix = 150;
                    ship->phaser[i].range = y * 0.75;
                    ship->phaser[i].power = x * 0.75;
                    ship->phaser[i].charge_per_turn = z * 0.75;
                    sprintf( writebuf, "%s%s%s %d lightly damaged.%s", ANSI_HILITE, ANSI_RED,
                        ship->phaser_string, i, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    break;
            }
            break;
        case SYSTEM_TORP_0:
        case SYSTEM_TORP_1:
        case SYSTEM_TORP_2:
        case SYSTEM_TORP_3:
        case SYSTEM_TORP_4:
        case SYSTEM_TORP_5:
        case SYSTEM_TORP_6:
        case SYSTEM_TORP_7:
        case SYSTEM_TORP_8:
        case SYSTEM_TORP_9:
        case SYSTEM_TORP_10:
        case SYSTEM_TORP_11:
        case SYSTEM_TORP_12:
        case SYSTEM_TORP_13:
        case SYSTEM_TORP_14:
        case SYSTEM_TORP_15:
        case SYSTEM_TORP_16:
        case SYSTEM_TORP_17:
        case SYSTEM_TORP_18:
        case SYSTEM_TORP_19:
            i = bustee-SYSTEM_TORP_0;
            switch( ship->damage[SYSTEM_TORP_0 + i].status )
            {
                case 'X':
                case 'x':
                case '9':
                    break;
                case '7':
                    ship->photon[i].status = PHOTON_DAMAGED;
                    sprintf( writebuf, "%s%s%s %d destroyed.%s", ANSI_HILITE, ANSI_RED,
                        ship->photon_string, i, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->photon[i].charge = 0;
                    ship->damage[SYSTEM_TORP_0 + i].status = '9';
                    break;
                case '1':
                case '0':
                    if( ship->photon[i].status==PHOTON_ONLINE )
                    {
                        ship->num_photons_online--;
                    }
                    else if( ship->photon[i].status==PHOTON_ARMED
                    && ship->torps_remaining > 0 && ship->torp_capacity > 0 )
                    {
                        ship->torps_remaining--;
                    }
                    ship->photon[i].status = PHOTON_DAMAGED;
                    sprintf( writebuf, "%s%s%s %d damaged.  Inoperable.%s", ANSI_HILITE, ANSI_RED,
                        ship->photon_string, i, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->photon[i].charge = 0;
                    ship->damage[SYSTEM_TORP_0 + i].status = '7';
                    ship->damage[SYSTEM_TORP_0 + i].time_to_fix = 240;
                    break;
            }
            break;
        case SYSTEM_SCANNERS:
            i=atof( my_atr_get_raw( ship->ship_object, "WL" ) );
            switch( ship->damage[SYSTEM_SCANNERS].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                    ship->damage[SYSTEM_SCANNERS].status = '9';
                    sprintf( writebuf, "%s%sActive scanners destroyed.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer ) 
                        notify( dmg_officer, writebuf );
                    break;
                case '6':
                case '5':
                    ship->damage[SYSTEM_SCANNERS].status = '7';
                    ship->damage[SYSTEM_SCANNERS].time_to_fix = 600;
                    sprintf( writebuf, "%s%sActive scanners damaged.  Inoperable.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer ) 
                        notify( dmg_officer, writebuf );
                    break;
                case '4':
                case '3':
                    ship->damage[SYSTEM_SCANNERS].status = '6';
                    ship->damage[SYSTEM_SCANNERS].time_to_fix = 300;
                    sprintf( writebuf, "%s%sActive scanners heavily damaged.  Range reduced.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->scanner_range = i * 0.5;
                    break;
                case '2':
                case '1':
                    ship->damage[SYSTEM_SCANNERS].status = '4';
                    ship->damage[SYSTEM_SCANNERS].time_to_fix = 150;
                    sprintf( writebuf, "%s%sActive scanners moderately damaged.  Range reduced.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->scanner_range = i * 0.65;
                    break;
                case '0':
                    ship->damage[SYSTEM_SCANNERS].status = '2';
                    ship->damage[SYSTEM_SCANNERS].time_to_fix = 150;
                    sprintf( writebuf, "%s%sActive scanners lightly damaged.  Range reduced.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->scanner_range = i * 0.75;
                    break;
            }
            break;
        case SYSTEM_SENSORS:
            i=atof( my_atr_get_raw( ship->ship_object, "WK" ) );
            switch( ship->damage[SYSTEM_SENSORS].status )
            {
                case '9':
                    break;
                case '7':
                    ship->damage[SYSTEM_SENSORS].status = '9';
                    ship->sensor_power = 0;
                    sprintf( writebuf, "%s%sPrimary sensors destroyed.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    break;
                case '6':
                case '5':
                    ship->damage[SYSTEM_SENSORS].status = '7';
                    ship->damage[SYSTEM_SENSORS].time_to_fix = 600;
                    ship->sensor_power = 0;
                    sprintf( writebuf, "%s%sPrimary sensors damaged.  Inoperable.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf ); 
                    break;
                case '4':
                case '3':
                    ship->damage[SYSTEM_SENSORS].status = '6';
                    ship->damage[SYSTEM_SENSORS].time_to_fix = 450;
                    sprintf( writebuf, "%s%sPrimary sensors damaged. Range reduced.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf ); 
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->sensor_power = i * 0.5;
                    break;
                case '2':
                case '1':
                    ship->damage[SYSTEM_SENSORS].status = '4';
                    ship->damage[SYSTEM_SENSORS].time_to_fix = 300;
                    sprintf( writebuf, "%s%sPrimary sensors damaged.  Range reduced.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf ); 
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->sensor_power = i * 0.65;
                    break;
                case '0':
                    ship->damage[SYSTEM_SENSORS].status = '2';
                    ship->damage[SYSTEM_SENSORS].time_to_fix = 150;
                    sprintf( writebuf, "%s%sPrimary sensors damaged.  Range reduced.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf ); 
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->sensor_power = i * 0.75;
                    break;
            }
            break;
        case SYSTEM_WARP:
            switch( ship->damage[SYSTEM_WARP].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                    sprintf( writebuf, "%s%sWarp drive destroyed.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_WARP].status = '9';
                    break;
                case '6':
                case '5':
                    sprintf( writebuf, "%s%sWarp drive inoperative.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_WARP].status = '7';
                    ship->damage[SYSTEM_WARP].time_to_fix = 1500;
                    break;
                case '4':
                case '3':
                    sprintf( writebuf, "%s%sWarp drive heavily damaged.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf ); 
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_WARP].status = '6';
                    ship->damage[SYSTEM_WARP].time_to_fix = 1200;
                    ship->current_warp_factor = ship->warp_factor * 1.75;
                    break;
                case '2':
                case '1':
                    sprintf( writebuf, "%s%sWarp drive moderately damaged.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf ); 
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_WARP].status = '4';
                    ship->damage[SYSTEM_WARP].time_to_fix = 900;
                    ship->current_warp_factor = ship->warp_factor * 1.5;
                    break;
                case '0':
                    sprintf( writebuf, "%s%sWarp drive lightly damaged.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf ); 
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_WARP].status = '2';
                    ship->damage[SYSTEM_WARP].time_to_fix = 600;
                    ship->current_warp_factor = ship->warp_factor * 1.25;
                    break;
            }
            if( ship->warp_speed >= 1.0 )
            {
                set_warp( ship, navigator, ship->warp_speed );
            }
            break;
        case SYSTEM_PAINT_JOB:
            switch( ship->damage[SYSTEM_PAINT_JOB].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                    sprintf( writebuf, "%s%sPaint job destroyed.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_PAINT_JOB].status = '9';
                    break;
                case '4':
                case '3':
                    sprintf( writebuf, "%s%sPaint job heavily damaged.%s", ANSI_HILITE,
                        ANSI_YELLOW, ANSI_NORMAL );
                    notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_PAINT_JOB].status = '6';
                    ship->damage[SYSTEM_PAINT_JOB].time_to_fix = 900;
                    break;
                case '2':
                    sprintf( writebuf, "%s%sPaint job moderately damaged.%s", ANSI_HILITE,
                        ANSI_YELLOW, ANSI_NORMAL );
                    notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_PAINT_JOB].status = '4';
                    ship->damage[SYSTEM_PAINT_JOB].time_to_fix = 600;
                    break;
                case '1':
                case '0':
                    sprintf( writebuf, "%s%sPaint job lightly damaged.%s", ANSI_HILITE,
                        ANSI_GREEN, ANSI_NORMAL );
                    notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_PAINT_JOB].status = '2';
                    ship->damage[SYSTEM_PAINT_JOB].time_to_fix = 300;
                    break;
            }
            break;
        case SYSTEM_TARGETTING:
            switch( ship->damage[SYSTEM_TARGETTING].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                    sprintf( writebuf, "%s%sTargetting system destroyed.%s",
                        ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TARGETTING].status = '9';
                    ship->target_system = SYSTEM_HULL;
                    if( ship->locked_target || ship->pending_lock )
                    {
                        break_lock( ship );
                    }
                    break;
                case '6':
                case '5':
                    sprintf( writebuf, "%s%sTargetting system damaged. Now inoperative.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TARGETTING].status = '7';
                    ship->damage[SYSTEM_TARGETTING].time_to_fix = 600;
                    ship->target_system = SYSTEM_HULL;
                    if( ship->locked_target || ship->pending_lock )
                    {
                        break_lock( ship );
                    }
                    break;
                case '4':
                case '3':
                    sprintf( writebuf, "%s%sTargetting system heavily damaged.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TARGETTING].status = '6';
                    ship->damage[SYSTEM_TARGETTING].time_to_fix = 450;
                    ship->target_system = SYSTEM_HULL;
                    if( ship->locked_target || ship->pending_lock )
                    {
                        break_lock( ship );
                    }
                    break;
                case '2':
                case '1':
                    sprintf( writebuf, "%s%sTargetting system moderately damaged.%s",
                        ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TARGETTING].status = '4';
                    ship->damage[SYSTEM_TARGETTING].time_to_fix = 300;
                    if( ship->locked_target || ship->pending_lock )
                    {
                        break_lock( ship );
                    }
                    break;
                case '0':
                    sprintf( writebuf, "%s%sTargetting system lightly damaged.%s",
                        ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TARGETTING].status = '2';
                    ship->damage[SYSTEM_TARGETTING].time_to_fix = 150;
                    ship->target_system = SYSTEM_HULL;
                    if( ship->pending_lock )
                    {
                        break_lock( ship );
                    }
                    else
                    {
                        ship->pending_lock = ship->locked_target;
                        ship->locked_target = NULL;
                    }
                    break;
            }
            break;
        case SYSTEM_LANDING_GEAR:
            switch( ship->damage[SYSTEM_LANDING_GEAR].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                case '6':
                case '5':
                    sprintf( writebuf, "%s%sLanding gear destroyed.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_LANDING_GEAR].status = '9';
                    ship->landing_capable = 0;
                    break;
                case '4':
                case '3':
                case '2':
                case '1':
                case '0':
                    sprintf( writebuf, "%s%sLanding gear damaged. Now inoperative.%s",
                        ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_LANDING_GEAR].status = '7';
                    ship->damage[SYSTEM_LANDING_GEAR].time_to_fix = 600;
                    ship->landing_capable = 0;
                    break;
            }
            break;
        case SYSTEM_TRANSWARP:
            switch( ship->damage[SYSTEM_TRANSWARP].status )
            {
                case 'x':
                case 'X':
                    break;
                case '9':
                    if( FRAND < 0.05 )
                    {
                        sprintf( writebuf, "Transwarp drive FUBAR!" );
                        notify( navigator, writebuf );
                        if( dmg_officer!=navigator )
                            notify( dmg_officer, writebuf );
                        ship->damage[SYSTEM_TRANSWARP].status = 'X';
                        ship->transwarp_capable = FALSE;
                    }
                    break;
                case '8':
                case '7':
                    sprintf( writebuf, "%s%sTranswarp drive destroyed.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TRANSWARP].status = '9';
                    break;
                case '1':
                    if( ship->transwarp_engaging )
                    {
                        abort_transwarp( ship, navigator );
                    }
                    ship->damage[SYSTEM_TRANSWARP].status = '8';
                    ship->damage[SYSTEM_TRANSWARP].time_to_fix = 1500;
                    sprintf( writebuf, "%s%sTranswarp drive inoperative.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    break;
                case '0':
                    if( ship->transwarp_engaging )
                    {
                        abort_transwarp( ship, navigator );
                    }
                    ship->damage[SYSTEM_TRANSWARP].status = '7';
                    ship->damage[SYSTEM_TRANSWARP].time_to_fix = 1200;
                    sprintf( writebuf, "%s%sTranswarp drive inoperative.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    break;
            }
            break;
        case SYSTEM_DISSIPATOR:
            switch( ship->damage[SYSTEM_DISSIPATOR].status )
            {
                case 'x':
                case 'X':
                    break;
                case '9':
                    if( FRAND < 0.05 )
                    {
                        sprintf( writebuf, "Warp dissipator FUBAR!" );
                        notify( navigator, writebuf );
                        if( dmg_officer!=navigator )
                            notify( dmg_officer, writebuf );
                        ship->damage[SYSTEM_DISSIPATOR].status = 'X';
                        ship->interdict_status = IDICT_BROKEN;
                    }
                    break;
                case '8':
                case '7':
                    sprintf( writebuf, "%s%sWarp dissipator destroyed.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    ship->interdict_status = IDICT_BROKEN;
                    ship->damage[SYSTEM_DISSIPATOR].status = '9';
                    break;
                case '1':
                    if( ship->interdict_status==IDICT_ON )
                    {
                        toggle_interdict( ship, navigator );
                    }
                    ship->interdict_status = IDICT_BROKEN;
                    ship->damage[SYSTEM_DISSIPATOR].status = '8';
                    ship->damage[SYSTEM_DISSIPATOR].time_to_fix = 1500;
                    sprintf( writebuf, "%s%sWarp dissipator inoperative.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    break;
                case '0':
                    if( ship->interdict_status==IDICT_ON )
                    {
                        toggle_interdict( ship, navigator );
                    }
                    ship->interdict_status = IDICT_BROKEN;
                    ship->damage[SYSTEM_DISSIPATOR].status = '7';
                    ship->damage[SYSTEM_DISSIPATOR].time_to_fix = 1200;
                    sprintf( writebuf, "%s%sWarp dissipator inoperative.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( dmg_officer!=navigator )
                        notify( dmg_officer, writebuf );
                    break;
            }
            break;
        case SYSTEM_AUX_SENSORS:
            i=atof( my_atr_get_raw( ship->ship_object, "WM" ) );
            switch( ship->damage[SYSTEM_AUX_SENSORS].status )
            {
                case '9':
                    break;
                case '7':
                    ship->damage[SYSTEM_AUX_SENSORS].status = '9';
                    ship->aux_sensor_power = 0;
                    sprintf( writebuf, "%s%sAuxiliary sensors destroyed.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    break;
                case '6':
                case '5':
                    ship->damage[SYSTEM_AUX_SENSORS].status = '7';
                    ship->damage[SYSTEM_AUX_SENSORS].time_to_fix = 600;
                    ship->aux_sensor_power = 0;
                    sprintf( writebuf, "%s%sAuxiliary sensors damaged.  Inoperable.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf );
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf ); 
                    break;
                case '4':
                case '3':
                    ship->damage[SYSTEM_AUX_SENSORS].status = '6';
                    ship->damage[SYSTEM_AUX_SENSORS].time_to_fix = 450;
                    sprintf( writebuf, "%s%sAuxiliary sensors damaged. Range reduced.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf ); 
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->aux_sensor_power = i * 0.5;
                    break;
                case '2':
                case '1':
                    ship->damage[SYSTEM_AUX_SENSORS].status = '4';
                    ship->damage[SYSTEM_AUX_SENSORS].time_to_fix = 300;
                    sprintf( writebuf, "%s%sAuxiliary sensors damaged.  Range reduced.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf ); 
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->aux_sensor_power = i * 0.65;
                    break;
                case '0':
                    ship->damage[SYSTEM_AUX_SENSORS].status = '2';
                    ship->damage[SYSTEM_AUX_SENSORS].time_to_fix = 150;
                    sprintf( writebuf, "%s%sAuxiliary sensors damaged.  Range reduced.%s", ANSI_HILITE,
                        ANSI_RED, ANSI_NORMAL );
                    notify( helmsman, writebuf ); 
                    if( helmsman != dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->aux_sensor_power = i * 0.75;
                    break;
            }
            break;
        case SYSTEM_TRANSPORTERS:
            switch( ship->damage[SYSTEM_TRANSPORTERS].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                case '6':
                case '5':
                case '4':
                case '3':
                case '2':
                    sprintf( writebuf, "%s%sTransporters destroyed.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_TRANSPORTERS].status = '9';
                    ship->transporter_range = -1.0;
                    break;
                case '1':
                case '0':
                    sprintf( writebuf, "%s%sTransporters damaged. Now offline.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( dmg_officer, writebuf );                    
                    ship->transporter_range = -fabs(ship->transporter_range);
                    ship->damage[SYSTEM_TRANSPORTERS].time_to_fix = 1200;
                    if( ship->damage[SYSTEM_TRANSPORTERS].status=='0' )
                    {
                        ship->damage[SYSTEM_TRANSPORTERS].status = '7';
                    }
                    else
                    {
                        ship->damage[SYSTEM_TRANSPORTERS].status = '8';
                        ship->damage[SYSTEM_TRANSPORTERS].time_to_fix += 400;
                    }
                    break;
            }
            break;
        case SYSTEM_IMPULSE:
            switch( ship->damage[SYSTEM_IMPULSE].status )
            {
                case 'x':
                case 'X':
                case '9':
                    break;
                case '8':
                case '7':
                    sprintf( writebuf, "%s%sImpulse engines destroyed.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_IMPULSE].status = '9';
                    set_warp( ship, navigator, ship->warp_speed );
                    break;
                case '6':
                case '5':
                    sprintf( writebuf, "%s%sImpulse engines damaged. Now inoperative.%s",
                        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_IMPULSE].status = '7';
                    ship->damage[SYSTEM_IMPULSE].time_to_fix = 1200;
                    break;
                case '4':
                case '3':
                    sprintf( writebuf, "%s%sImpulse engines heavily damaged. Efficiency reduced.%s",
                        ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_IMPULSE].status = '6';
                    ship->damage[SYSTEM_IMPULSE].time_to_fix = 900;
                    set_warp( ship, navigator, ship->warp_speed );
                    break;
                case '2':
                case '1':
                    sprintf( writebuf, "%s%sImpulse engines moderately damaged. Efficiency reduced.%s",
                        ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_IMPULSE].status = '4';
                    ship->damage[SYSTEM_IMPULSE].time_to_fix = 600;
                    break;
                case '0':
                    sprintf( writebuf, "%s%sImpulse engines lightly damaged. Efficiency reduced.%s",
                        ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                    notify( navigator, writebuf );
                    if( navigator!=dmg_officer )
                        notify( dmg_officer, writebuf );
                    ship->damage[SYSTEM_IMPULSE].status = '2';
                    ship->damage[SYSTEM_IMPULSE].time_to_fix = 300;
                    break;
            }
            break;
    }
    return 0;
}
