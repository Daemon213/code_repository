FUNCTION(fun_wormhole_cmd)
{
    WORMH *wormhole;
    int i;

    if( !Wizard(executor) || args[0]==NULL )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    /* switch on the argument */
    if( !strcmp( args[0], "activate" ))
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            wormhole = wormhole_list[i];
            while( wormhole != NULL )
            {
                if( executor == wormhole->wormhole_object )
                {
                    notify( enactor, "This wormhole is already activated." );
                    return;
                }
                wormhole = wormhole->next;
            }
        }
        /* okay, we've made it to this point so the wormhole in question
         * must be inactive so far.  Cool.  Activate it
         */
        if ( activate_wormhole( executor, enactor ))
            notify( enactor, "Error initializing wormhole." );

        return;
    }
    else if( !strcmp( args[0], "deactivate" ) )
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            wormhole = wormhole_list[i];
            while( wormhole != NULL )
            {
                if( executor == wormhole->wormhole_object )
                {
                    current_space = i;
                    deactivate_wormhole( wormhole, enactor );
                    return;
                }
                wormhole = wormhole->next;
            }
        }

        /* okay, we've made it to this point so the wormhole in question
         * must not be active.  Warn and return.
         */
        notify( enactor, "Wormhole isn't active." );
        return;
    }
    else
    {
        notify( enactor, "Unrecognized wormhole_command() call." );
    }
    return;
}


int activate_wormhole( dbref executor, dbref enactor )
{
    WORMH *new_wormhole;
    char *curspace;

    if(!(new_wormhole=(WORMH *)JMALLOC(sizeof(WORMH))))
        return SERR_MALLOC;

    /* wormhole space -- either real space, or a sim space */
    curspace = fetch_attribute( executor, "SPACE" );
    if( !strcmp( curspace, "real" ))
        current_space = REAL;
    else if( !strcmp( curspace, "1" ))
        current_space = 1;
    else if( !strcmp( curspace, "2" ))
        current_space = 2;
    else if( !strcmp( curspace, "3" ))
        current_space = 3;
    else if( !strcmp( curspace, "4" ))
        current_space = 4;
    else if( !strcmp( curspace, "5" ))
        current_space = 5;
    else if( !strcmp( curspace, "6" ))
        current_space = 6;
    else if( !strcmp( curspace, "7" ))
        current_space = 7;
    else if( !strcmp( curspace, "8" ))
        current_space = 8;
    else if( !strcmp( curspace, "9" ))
        current_space = 9;
    else if( !strncmp( curspace, "10", 2 ))
        current_space = 10;
    else if( !strncmp( curspace, "11", 2 ))
        current_space = 11;
    else
        current_space = SIM;

    sscanf( fetch_attribute( executor, "LOCATION1" ), "%f %f %f", &new_wormhole->pos[0].x,
        &new_wormhole->pos[0].y, &new_wormhole->pos[0].z );
    sscanf( fetch_attribute( executor, "LOCATION2" ), "%f %f %f", &new_wormhole->pos[1].x,
        &new_wormhole->pos[1].y, &new_wormhole->pos[1].z );

    new_wormhole->name = (char *)Name( executor );
    new_wormhole->size = atof( fetch_attribute( executor, "SIZE" ));
    new_wormhole->wormhole_object = executor;

    if( wormhole_list[current_space]==NULL )
    {
        wormhole_list[current_space] = new_wormhole;
        wormhole_tail[current_space] = new_wormhole;
        new_wormhole->prev = NULL;
    }
    else
    {
        wormhole_tail[current_space]->next = new_wormhole;
        new_wormhole->prev = wormhole_tail[current_space];
        wormhole_tail[current_space] = new_wormhole;
    }
    new_wormhole->next = NULL;
    fnotify( enactor, "Wormhole %s activated in %s space.",
        Name( executor), space_names[current_space] );
    return 0;
}
   
void deactivate_wormhole( WORMH *wormhole, dbref enactor )
{
    SHIP *ship;

    /* this is an easy one.  Simply zorch it from the linked list */
    if( ( wormhole_list[current_space]==wormhole )
    && ( wormhole_tail[current_space]==wormhole ) )
    {
        wormhole_list[current_space] = NULL;
        wormhole_tail[current_space] = NULL;
    }
    else if( wormhole_list[current_space] == wormhole )
    {
        wormhole_list[current_space] = wormhole_list[current_space]->next;
        wormhole_list[current_space]->prev = NULL;
    }
    else if( wormhole_tail[current_space] == wormhole )
    {
        wormhole_tail[current_space] = wormhole_tail[current_space]->prev;
        wormhole_tail[current_space]->next = NULL;
    }
    else
    {
        wormhole->prev->next = wormhole->next;
        wormhole->next->prev = wormhole->prev;
    }
    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        remove_wormhole( ship, wormhole );
    }
    JFREE( wormhole );
    notify( enactor, "Wormhole is zorched." );
    return;
}

void wormhole_checks( void )
{
    float range,range0,range1;
    WORMH *wormhole;
    SHIP *ship;

    ship = space_list[current_space];

    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        /* clear the closest_wormhole counter */
        ship->near_planet_range = -1;
        ship->near_planet_size = 0.00001;

        for(wormhole=wormhole_list[current_space];wormhole!=NULL;wormhole=wormhole->next)
        {
            range0 = distance( ship->pos, wormhole->pos[0] );
            range1 = distance( ship->pos, wormhole->pos[1] );
            range = UMIN( range0, range1 );

            if( ( range < ( ship->nebula_visibility * ship->sensor_power * wormhole->size ) )
            || ( ship->flags[OMNISCIENT] ))
            {
                add_wormhole( ship, wormhole );
            }
            else
            {
                remove_wormhole( ship, wormhole );
            }
            if( ( ship->near_planet_range == -1 )
            || ( range < ship->near_planet_range ) )
            {
                ship->near_planet_range = range;
                ship->near_planet_size = wormhole->size;
            }
        }
    }
    return;
}

void add_wormhole( SHIP *ship, WORMH *wormhole )
{
    struct wormhole_contact *contact;
    float range0,range1;
    XYZ xyz_rel;
    SPH sph_rel;
    dbref navigator;
    int npos=0;

    for(contact=ship->wormhole_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref == wormhole )
        {
            return;
        }
    }
    /* allocate memory for the contact and the wormhole name. */
    if( ( contact=(struct wormhole_contact *)JMALLOC( sizeof( struct wormhole_contact ))) == NULL )
    {
        return;
    }
    if( ( contact->name=(char *)JMALLOC( 48 ) )==NULL )
    {
        return;
    }
    range0 = distance( ship->pos, wormhole->pos[0] );
    range1 = distance( ship->pos, wormhole->pos[1] );
    if( range0 < range1 )
    {
        npos=0;
    }
    else
    {
        npos=1;
    }
    xyz_rel.x = wormhole->pos[npos].x - ship->pos.x;
    xyz_rel.y = wormhole->pos[npos].y - ship->pos.y;
    xyz_rel.z = wormhole->pos[npos].z - ship->pos.z;
    sph_rel = xyz_to_sph( xyz_rel );
    navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
    switch( ship->owner )
    {
        default:
            strncpy( contact->name, wormhole->name, 48 );
        break;
    }
    fnotify( navigator, "%sWormhole %s now in sensor range bearing %s%s%d%+d%s%s at range %s%s%ld%s%s.%s",
        ANSI_CYAN, contact->name, ANSI_HILITE, ANSI_MAGENTA, (int)sph_rel.bearing,
        (int)sph_rel.elevation, ANSI_NORMAL, ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, 
        (long int)sph_rel.range, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL );

    contact->listref = wormhole;

    if( ship->wormhole_list==NULL )
    {
        ship->wormhole_list = contact;
        ship->wormhole_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->wormhole_tail->next = contact;
        contact->prev = ship->wormhole_tail;
        contact->next = NULL;
        ship->wormhole_tail = contact;
    }
    return;
}

void remove_wormhole( SHIP *ship, WORMH *wormhole )
{
    struct wormhole_contact *contact;
    dbref navigator;

    for(contact=ship->wormhole_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref == wormhole )
        {
            sprintf( writebuf, "Wormhole %s is no longer in sensor range.",
                contact->name );

            navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
            notify( navigator, writebuf );

            if( ship->wormhole_list == ship->wormhole_tail )
            {
                ship->wormhole_list = NULL;
                ship->wormhole_tail = NULL;
                JFREE( contact );
                return;
            }
            if( contact==ship->wormhole_list )
            {
                ship->wormhole_list = contact->next;
                ship->wormhole_list->prev=NULL;
                JFREE( contact );
                return;
            }
            if( contact==ship->wormhole_tail )
            {
                ship->wormhole_tail = contact->prev;
                ship->wormhole_tail->next = NULL;
                JFREE( contact );
                return;
            }
            if( ( contact!=ship->wormhole_list )
            && ( contact!=ship->wormhole_tail ) )
            {
                (contact->prev)->next = contact->next;
                (contact->next)->prev = contact->prev;
                JFREE( contact );
                return;
            }
        }
    }
    return;
}

WORMH *find_wormhole( dbref target )
{
    WORMH *wormhole;

    for(current_space=0;current_space<SPACE_LIMIT;current_space++)
    {
        for(wormhole=wormhole_list[current_space];wormhole!=NULL;wormhole=wormhole->next)
        {
            if( wormhole->wormhole_object == target )
            {
                return wormhole;
            }
        }
    }
    return NULL;
}

void wormhole_jump( SHIP *ship, dbref enactor )
{
    struct wormhole_contact *wcontact,*jumpee;
    char jumper_string[160];
    CONTACT *jumper,*contact;
    float range,range0,range1;
    WORMH *wormhole;
    SHIP *observer;
    dbref helmsman;
    int npos;

    for(wcontact=ship->wormhole_list;wcontact!=NULL;wcontact=wcontact->next)
    {
        range0 = distance( ship->pos, wcontact->listref->pos[0] );
        range1 = distance( ship->pos, wcontact->listref->pos[1] );
        npos = range0 < range1 ? 1 : 0;
        range = UMIN( range0, range1 );
        if( range <= 5 )
        {
            break;
        }
    }
    if( wcontact==NULL || ( wormhole=wcontact->listref )==NULL )
    {
        fnotify( enactor, "No wormhole within 5 ranges." );
        return;
    }
    if( ship->size > wormhole->size )
    {
        fnotify( enactor, "Your ship is too large to fit through the wormhole." );
        return;
    }
    fnotify( enactor, "Entering wormhole..." );
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship )
        {
            continue;
        }
        jumper = NULL;
        jumpee = NULL;       
        for(contact=observer->contact_list;contact!=NULL;contact=contact->next)
        {
            if( contact->listref==ship )
            {
                jumper = contact;
                break;
            }
        }
        for(wcontact=observer->wormhole_list;wcontact!=NULL;wcontact=wcontact->next)
        {
            if( wcontact->listref==wormhole )
            {
                jumpee = wcontact;
                break;
            }
        }
        /* get observer helmsman's dbref */
        helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
        /* ok we got 4 cases here */
        if(( jumper==NULL ) || ( jumpee==NULL ))
        {}
        else
        {
            contact_string( jumper_string, jumper, INFO_TERSE );
            fnotify( helmsman, "Contact [%d]: %s jumped through wormhole: %s",
               jumper->contact_number, jumper_string, wormhole->name );
        }
    }
    ship->pos.x = wormhole->pos[npos].x;
    ship->pos.y = wormhole->pos[npos].y;
    ship->pos.z = wormhole->pos[npos].z;
    fnotify( enactor, "Exiting wormhole." );
    if( ship->tractor_target!=NULL && ship->tractor_mode==MODE_TRACTOR
    && distance(ship->pos,ship->tractor_target->listref->pos) < 1.0 )
    {
        helmsman = match_result(HOWIE,my_atr_get_raw(ship->tractor_target->listref->nav,"XB"),NOTYPE,MAT_ABSOLUTE);
        wormhole_jump( ship->tractor_target->listref, helmsman );
    }
    return;
}

void list_wormholes( SHIP *ship, dbref enactor )
{
    struct wormhole_contact *contact;
    char inside_ast[2],rel_range[5];
    char wormhole_size[5];
    char wormhole_density[3];
    float range0,range1;
    int npos;
    SHIP fake_ship;
    XYZ xyz_rel;
    SPH sph_rel;
    static char *shield_strings[] = { (char *)"Fore", (char *)"Aft", (char *)"Port", (char *)"Starboard" };

    contact = ship->wormhole_list;

    if( contact == NULL )
    {
/*
        fnotify( enactor, "%s%sNo wormholes detected.%s", ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
*/
        return;
    }
    for(contact=ship->wormhole_list;contact!=NULL;contact=contact->next)
    {
        range0 = distance( ship->pos, contact->listref->pos[0] );
        range1 = distance( ship->pos, contact->listref->pos[1] );

        if( range0 < range1 )
        {
            xyz_rel.x = contact->listref->pos[0].x - ship->pos.x;
            xyz_rel.y = contact->listref->pos[0].y - ship->pos.y;
            xyz_rel.z = contact->listref->pos[0].z - ship->pos.z;
            npos = 0;
        }
        else
        {
            xyz_rel.x = contact->listref->pos[1].x - ship->pos.x;
            xyz_rel.y = contact->listref->pos[1].y - ship->pos.y;
            xyz_rel.z = contact->listref->pos[1].z - ship->pos.z;
            npos = 1;
        }
        sph_rel = xyz_to_sph( xyz_rel );

        if( sph_rel.range >= 10000000.0 )
            sprintf( rel_range, "%4.0fM", sph_rel.range / 1000000.0 );
        else if( sph_rel.range >= 100000.0 )
            sprintf( rel_range, "%4.0fK", sph_rel.range / 1000.0 );
        else
            sprintf( rel_range, "%5.0f", sph_rel.range );

        sprintf( wormhole_size, "%-1.2f", contact->listref->size );

        sprintf( wormhole_density, "%3.0f", 0.0 );

        fake_ship.pos = contact->listref->pos[npos];

        if( range0<=5 || range1<=5 )
            sprintf( inside_ast, "*" );
        else
            sprintf( inside_ast, " " );

        fnotify( enactor, "%s%s   %s   %s%s%-20.20s %s%s%-3.0f %-+3.0f %-5s      %s%s%-3s%%   %s%s%-4s   %s%-10s%s", 
             ANSI_HILITE, ANSI_RED, inside_ast, ANSI_NORMAL, ANSI_CYAN,
	     contact->listref->name, ANSI_HILITE, ANSI_CYAN,
	     sph_rel.bearing, sph_rel.elevation, rel_range, ANSI_NORMAL,
             ANSI_MAGENTA, wormhole_density, ANSI_HILITE, ANSI_WHITE, wormhole_size,
	     ANSI_BLACK, shield_strings[ facing_shield( &fake_ship, ship ) ], ANSI_NORMAL );
    }
    return;
}
