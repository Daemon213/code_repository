/*
 * $Id: dock.c,v 1.3 1993/09/25 20:39:40 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: dock.c,v $
 * Revision 1.3  1993/09/25  20:39:40  chuckles
 * cleaned up logging code.
 *
 * Revision 1.2  1993/09/21  03:24:20  chuckles
 * Notify the dock when someone docks with it.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 26 Aug 93 - DOCK_RANGE instead of hard values
 * JMS 19 Aug 93 - begin MUSH2.0 port
 * JMS  2 Jun 93 - cleanup
 * JMS 24 May 93 - separated into dock.c
 * JMS ?? Oct 92 - original code
 */


dbref dock( SHIP *ship, dbref enactor, char *target )
{
    char docker_string[160],dock_string[160],*vbuff[3];
    CONTACT *spacedock,*contact,*docker,*dockee;
    dbref docking_bay,ship_marker,shuttle_bay;
    SHIP *observer;
    int i, clamps_on;


    /* active check */
    if( ship == NULL )
    {
        notify( enactor, "%sShip is already docked.%s" );
        return -1;
    }
    spacedock = match_contact( ship, target );
    if( spacedock == NULL || spacedock->listref->flags[ISPLANET] )
    {
        fnotify( enactor, "%sInvalid target.%s", ANSI_MAGENTA, ANSI_NORMAL );
        return -1;
    }
    /* Does the target have clamps? */
    clamps_on = atoi(fetch_attribute(spacedock->listref->ship_object, "CLAMPS_ON"));
    /* target is capable of receiving dockers */
    if( !ship->flags[SHUTTLECRAFT] && spacedock->listref->dock_max_size < ship->size )
    {
        fnotify( enactor, "%s%sThis ship is too large to dock with that one.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    for( i = 0; i < 4; i++ )
    {
        if( ship->shield_status[i] == SHLD_UP )
        {
            fnotify( enactor, "%s%sShields must be lowered prior to docking.%s", ANSI_HILITE,
                ANSI_RED, ANSI_NORMAL );
            return -1;
        }
    }
    /* dock facing shield is down */
    if( spacedock->listref->shield_status[facing_shield(ship,spacedock->listref)]==SHLD_UP )
    {
        fnotify( enactor, "%s%sThe shield facing your ship must be lowered.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* distance less than five units */
    if( distance( ship->pos, spacedock->listref->pos ) > DOCK_RANGE )
    {
        fnotify( enactor, "%s%sA ship must be within %d units of the target to dock.%s",
            ANSI_HILITE, ANSI_RED, (int)DOCK_RANGE, ANSI_NORMAL );
        return -1;
    }
    if( !spacedock->listref->flags[DISABLED] )
    {
        /* target doors opened */
        if( spacedock->listref->door_status != DOORS_OPEN)
        {
            fnotify( enactor, "%s%sTarget docking bay doors are closed.%s", ANSI_HILITE,
                ANSI_RED, ANSI_NORMAL );
            return -1;
        }
    }
    /* target dock has room */
    if(ship->flags[SHUTTLECRAFT])
    {
    if( ( spacedock->listref->shuttlebay_capacity -
atof(fetch_attribute(spacedock->listref->ship_object, "SHUTTLE_CAPACITY"))) < ship->size)
    {
        fnotify( enactor, "%s%sTarget shuttle bay is too small to fit ship.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    }
    else
    {
    if ( (( spacedock->listref->dock_capacity - atof(fetch_attribute(spacedock->listref->ship_object, "CAPACITY"))) <
ship->size) && clamps_on == 0)
    {
        fnotify( enactor, "%s%sTarget docking bay is too small to fit ship.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
     }
     }
    /* extract the dbref of the docking bay, shuttle bay, and ship marker, so we can move it to the appropriate one */
    shuttle_bay = match_result(HOWIE, fetch_attribute(spacedock->listref->ship_object, "SHUTTLE_BAY"), NOTYPE, MAT_ABSOLUTE);
    docking_bay = match_result(HOWIE, fetch_attribute(spacedock->listref->ship_object, "DOCK"), NOTYPE, MAT_ABSOLUTE);
    ship_marker = match_result(HOWIE, fetch_attribute(ship->ship_object, "MARKER"), NOTYPE, MAT_ABSOLUTE);
   
    if( !GoodObject(docking_bay) && clamps_on == 0 )
    {
        notify( enactor, "Target does not have a docking bay nor docking clamps." );
        return -1;
    }
    if( (ship->flags[SHUTTLECRAFT] && !GoodObject(shuttle_bay) && GoodObject(docking_bay)) )
    {
        notify(enactor , "Target has no shuttle bay, docking in docking bay.");
    }
    if( !GoodObject(ship_marker) )
    {
        notify( enactor, "This ship is unable to dock." );
        return -1;
    }
    if( (!GoodObject(docking_bay) && clamps_on == 0) || (!GoodObject(ship_marker)) )
    {
        notify( enactor, "Internal docking error.  Notify a director." );
        log_space( "Docking error.  Ship: %d  Dock: %d  Marker: %d\n"
            "  Bay: %d", ship->ship_object, spacedock->listref->ship_object,
            ship_marker, docking_bay );
        return -1;
    }
    /* log it */
    log_space( "%s(#%d) docked %s at %s.", Name(enactor), enactor,
        ship->name, spacedock->listref->name );

    /* inform anyone who can see the docker about the maneuver */
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship || observer==spacedock->listref)
        {
            continue; /* continue looping */
        }
        docker = find_contact( observer, ship );
        dockee = find_contact( observer, spacedock->listref );
        observer->helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);

        /* OK we got 4 cases here */
        if( docker==NULL || dockee==NULL )
        {
        }
        else
        {
            contact_string( docker_string, docker, INFO_TERSE );
            contact_string( dock_string, dockee, INFO_TERSE );

            fnotify( observer->helmsman, "%sContact [%s%s%d%s%s]: %s%s%s docked with contact [%s%s%d%s%s]: %s%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, docker->contact_number, ANSI_NORMAL,
                ANSI_CYAN, ANSI_NORMAL, docker_string, ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA,
                dockee->contact_number, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, dock_string );
        }
    }
    /* observers are notified.  Now perform the actual docking. */
    /* first, set the dock status register in the ship object */
    sprintf( writebuf, "#%d", spacedock->listref->ship_object );
    put_attribute( ship->ship_object, (char *)"DOCKED_AT", writebuf );

    /* notify the bridge */
    sprintf( writebuf, "Now docked at %s.",
        fetch_attribute( spacedock->listref->ship_object, "NAME" ));
    notify_room(db[ship->nav].location, writebuf);

    /* adjust the room in the docking bay or shuttle bay*/
    if (ship->flags[SHUTTLECRAFT])
    {
    sprintf( writebuf, "%.2f", 
        atof(fetch_attribute(spacedock->listref->ship_object, "SHUTTLE_CAPACITY"))+
	    ship->size);
    put_attribute(spacedock->listref->ship_object, (char *)"SHUTTLE_CAPACITY", writebuf);
    }
    if (clamps_on == 0 && !ship->flags[SHUTTLECRAFT] )
    {
    sprintf( writebuf, "%.2f", 
        atof(fetch_attribute(spacedock->listref->ship_object, "CAPACITY"))+
	    ship->size);
    put_attribute(spacedock->listref->ship_object, (char *)"CAPACITY", writebuf);
    }

    /* notify the dock - JMS 20 Sep 93 */
    contact = find_contact( spacedock->listref, ship );
    if( contact!=NULL && !ship->flags[SHUTTLECRAFT] )
    {
        contact_string( docker_string, contact, INFO_TERSE );
        sprintf( writebuf, "%sContact [%s%s%d%s%s]: %s%s%s has docked.%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, contact->contact_number, ANSI_NORMAL,
            ANSI_CYAN, ANSI_NORMAL, docker_string, ANSI_CYAN, ANSI_NORMAL );

        notify_room(db[spacedock->listref->nav].location, writebuf);
    }
    if( contact!=NULL && ship->flags[SHUTTLECRAFT] )
    {
        contact_string( docker_string, contact, INFO_TERSE );
        sprintf( writebuf, "%sContact [%s%s%d%s%s]: %s%s%s has entered the shuttle bay.%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, contact->contact_number, ANSI_NORMAL,
            ANSI_CYAN, ANSI_NORMAL, docker_string, ANSI_CYAN, ANSI_NORMAL );

        notify_room(db[spacedock->listref->nav].location, writebuf);
    }
/*    sprintf( writebuf, "FN_PARK" );
    sprintf( dock_string, "#%d", docking_bay );
    vbuff[0] = writebuf;
    vbuff[1] = dock_string;
    vbuff[2] = NULL;
    fun_ufun( writebuf, vbuff, 2, vbuff, ship->nav, HOWIE, HOWIE, "U", NULL );*/
    if( ship->flags[SHUTTLECRAFT] )
    {
     safe_tel(ship_marker,shuttle_bay, 0);
    }
     sprintf( writebuf, "0"); 
     put_attribute(ship->ship_object, (char *)"UNDOCKED", writebuf);
    deallocate_ship( ship );
    return docking_bay;
}

dbref land( SHIP *ship, dbref enactor, char *target )
{
    dbref landing_pad,ship_marker,helmsman;
    char lander_string[160],*vbuff[3];
    struct planet_contact *p_contact;
    CONTACT *lander,*contact;
    SHIP *observer;
    int i;

    /* active check */
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip is already landed.%s", ANSI_MAGENTA, ANSI_NORMAL );
        return -1;
    }
    if( current_space!=REAL )
    {
        fnotify( enactor, "%s%sNot in the sims.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    p_contact = match_planet( ship, target );

    if( p_contact == NULL )
    {
        fnotify( enactor, "%s%sPlanet cannot be found on sensors.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* landing capable */
    ship_marker = match_result(HOWIE, fetch_attribute(ship->ship_object, "MARKER"), NOTYPE, MAT_ABSOLUTE);
    if( !ship->landing_capable || !GoodObject(ship_marker) )
    {
        fnotify( enactor, "%s%sThis ship is not capable of landing.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return -1;
    }
    if( ship->flags[DISABLED] )
    {
        fnotify( enactor, "%s%sThis ship is too shot up to land.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* unmoving */
    if( ship->warp_speed >= 1.0 )
    {
        fnotify( enactor, "%s%sA ship can not land while at warp speed.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return -1;
    }
    if( p_contact->listref->shield_status==SHLD_UP && p_contact->listref->shield_level > 0 )
    {
        fnotify( enactor, "%s%sPlanetary shield must be lowered before landing.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* distance less than five units */
    if( distance( ship->pos, p_contact->listref->pos ) > DOCK_RANGE )
    {
        fnotify( enactor, "%s%sA ship must be within %d units of the planet to land.%s",
            ANSI_HILITE, ANSI_RED, (int)DOCK_RANGE, ANSI_NORMAL );
        return -1;
    }
    landing_pad = match_result(HOWIE,fetch_attribute(p_contact->listref->planet_object,"LANDING_PAD"), NOTYPE, MAT_ABSOLUTE);
    if( !GoodObject(landing_pad) )
    {
        fnotify( enactor, "%s%sThat planet may not be landed on.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    if( !GoodObject(landing_pad) || !GoodObject(ship_marker) )
    {
        notify( enactor, "Internal landing error.  Notify a director." );
        log_space( "Landing error.  Ship: %d  Planet: %d  Marker: %d\n"
            "  Pad: %d", ship->ship_object,p_contact->listref->planet_object,
            ship_marker, landing_pad );
        return -1;
    }
    /* log it */
    log_space( "%s(#%d) landed %s on %s.", Name(enactor), enactor,
        ship->name, p_contact->name);

    /* inform anyone who can see the lander about the maneuver */
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship )
        {
            continue;
        }
        lander = find_contact( observer, ship );
        /* find observer helmsman's dbref */
        observer->helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);

        /* OK we got 4 cases here */
        if( lander==NULL )
        {
            /* do nothing unless you can see the ship */
        }
        else
        {
            /* saw both */
            contact_string( lander_string, lander, INFO_TERSE );
            fnotify( observer->helmsman, "%sContact [%s%s%d%s%s]: %s%s%s landed on planet: %s%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, lander->contact_number, ANSI_NORMAL,
                ANSI_CYAN, ANSI_NORMAL, lander_string, ANSI_CYAN, p_contact->name, ANSI_NORMAL );

        }
    }
    /* observers are notified.  Now perform the actual docking. */
    /* first, set the dock status register in the ship object */
    sprintf( writebuf, "#%d", p_contact->listref->planet_object );
    put_attribute( ship->ship_object, (char *)"DOCKED_AT", writebuf );

    /* notify the bridge */
    sprintf( writebuf, "%s%sNow landed on %s.%s", ANSI_HILITE, ANSI_BLUE, p_contact->name,
        ANSI_NORMAL );
    notify_room(db[ship->nav].location, writebuf);
 /*   sprintf( writebuf, "FN_PARK" );
    sprintf( lander_string, "#%d", landing_pad );
    vbuff[0] = writebuf;
    vbuff[1] = lander_string;
    vbuff[2] = NULL;
    fun_ufun( writebuf, vbuff, 2, vbuff, ship->nav, HOWIE, HOWIE, "U", NULL );*/
    deallocate_ship( ship );
    return landing_pad;
}

/*
 * JMS 26 Aug 93 - removed the bit where the position registers are updated
 *                 when you undock.  They never really mattered.  You always
 *                 undock at the starbase position anyway.
 */
dbref undock( SHIP *ship, dbref executor, dbref enactor )
{ 
  dbref ship_object, spacedock;
  PLANET *planet_ref = NULL;
  SHIP *dock_ref = NULL;
  int i, clamps_on, isshuttle;
  


  /* make sure we're active */
  if( ship == NULL )
  {
    fnotify( enactor, "%sThis ship doesn't have it's reactor running yet.  Can't undock without power.%s", ANSI_MAGENTA, 
           ANSI_NORMAL );
    return( -1 );
  }
    /* Get the ship object dbref. Check for docking clamps. */
  ship_object = attrib_dbref( executor, "SHIP_OBJECT");
  if( !GoodObject( ship_object )) {
    notify( enactor, "Problem with your ship object.  Contact a director." );
    return( -1 );
  }

  /* okay, we're active. */  

  /* Make sure we aren't already undocked */
  if( !strcmp( fetch_attribute( ship_object, "UNDOCKED" ), "1") )
  {
    fnotify( enactor, "%s%sShip is already undocked%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
    return( -1 );
  }
  

  /* now get the dbref of the dock we're at and check for docking clamps */
  spacedock = attrib_dbref( ship_object, "DOCKED_AT" );
  if( !strcmp( fetch_attribute( spacedock, "CLAMPS_ON" ), "1" )  )
     {
        clamps_on = 1;
     }
  else {
        clamps_on = 0;
       }  
   if( !strcmp( fetch_attribute( ship_object, "ISSHUTTLE" ), "1" )  )
     {
        isshuttle= 1;
     }
  else {
        isshuttle = 0;
       }  

  /* make sure we're in a legal dock */
  if( spacedock == -1 )
  {
    fnotify( enactor, "%s%sShip is not in a legal spacedock.  Unable to leave.%s", ANSI_HILITE,
           ANSI_RED, ANSI_NORMAL );
    return( -1 );
  }

  /* now make sure that the dock is active */
  if( ( dock_ref=cfind_ship(spacedock) )== NULL )
  {
    if( ( planet_ref=find_planet(spacedock) )==NULL )
    {
      fnotify( enactor, "%s%sThe dock/planet is not active.  Unable to leave.%s", ANSI_HILITE, 
           ANSI_RED, ANSI_NORMAL );
      return -1;
    }
  }

  if (dock_ref != NULL) {  /* Then do all the SB checks */

  /* check for a lock on space */
  if( space_lock[current_space] == SPACE_LOCKED ) {
    fnotify( enactor, "%sSpace is temporarily locked.  Try again later.%s", ANSI_HILITE,
           ANSI_NORMAL );
    return( -1 );
  }
  
   /* Check for shields */
  
    for( i = 0; i < 4; i++ )
    {
        if( dock_ref->shield_status[i] == SHLD_UP )
        {
            fnotify( enactor, "%s%sBase must lower shields before undocking%s", ANSI_HILITE,
                ANSI_RED, ANSI_NORMAL );
            return -1;
        }
    }
  /* and make sure that the doors are open */
  if( (dock_ref->door_status != DOORS_OPEN && !dock_ref->flags[DISABLED] && clamps_on !=  1) || (dock_ref->door_status != DOORS_OPEN && !dock_ref->flags[DISABLED] && isshuttle == 1) ) 
    {
    fnotify( enactor, "%s%sSpacedock doors are closed.  Unable to leave.%s", ANSI_HILITE,
           ANSI_RED, ANSI_NORMAL );
    return( -1 );
   }
  }

  if( planet_ref != NULL )
  {
      /* check for a lock on space */
      if( space_lock[current_space] == SPACE_LOCKED )
      {
          fnotify( enactor, "%sSpace is temporarily locked.  Try again later.%s", ANSI_HILITE,
              ANSI_NORMAL );
          return( -1 );
      }
      if( planet_ref->shield_status==SHLD_UP && planet_ref->shield_level > 0 )
      {
          fnotify( enactor, "%s%sPlanetary shields must be lowered before takeoff.%s",
              ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
          return -1;
      }
  }
  
  if( ship != NULL )
  {
    ship = cfind_ship( ship_object );

    if (dock_ref != NULL) {  /* Do SBish Stuffs */
    fnotify( enactor, "%s%sShip has completed undocking.%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );

    /* log it */
    log_space( "%s(#%d) undocked %s from %s.", Name(enactor),
               enactor, ship->name, dock_ref->name );

    /* now set the location of the ship to that of the dock */
    ship->pos.x = dock_ref->pos.x;
    ship->pos.y = dock_ref->pos.y;
    ship->pos.z = dock_ref->pos.z;

    /* adjust the dock's capacity */
    if (ship->flags[SHUTTLECRAFT])
    {
     sprintf(writebuf, "%.2f", atof(fetch_attribute(dock_ref->ship_object, "SHUTTLE_CAPACITY")) - ship->size);
     put_attribute(dock_ref->ship_object, (char *)"SHUTTLE_CAPACITY", writebuf);
    }
    if ( clamps_on == 0 && !ship->flags[SHUTTLECRAFT])
    {
     sprintf(writebuf, "%.2f", atof(fetch_attribute(dock_ref->ship_object, "CAPACITY")) - ship->size);
     put_attribute(dock_ref->ship_object, (char *)"CAPACITY", writebuf);
    }
    /* tell the dock that it's had a baby */
    sprintf( writebuf, "%s%s has undocked.%s", ANSI_CYAN, ship->name, ANSI_NORMAL );
    notify_room(db[dock_ref->nav].location, writebuf);
    
     add_contact( ship, dock_ref );
     find_contact(ship,dock_ref)->info_level = 5;
 
     add_contact( dock_ref, ship );
     find_contact(dock_ref,ship)->info_level = 5;
  
    }

    if(planet_ref != NULL)
    { /* Do Planetish Stuffs */
    fnotify( enactor, "%s%sShip has cleared planet atmosphere.%s", ANSI_HILITE, ANSI_BLUE,
           ANSI_NORMAL );
    add_planet( ship, planet_ref );

    /* log it */
    log_space( "%s(#%d) launched %s from %s.", Name(enactor),
               enactor, ship->name, Name(planet_ref->planet_object) );

    /* now set the location of the ship to that of the dock */
    ship->pos.x = planet_ref->pos.x;
    ship->pos.y = planet_ref->pos.y;
    ship->pos.z = planet_ref->pos.z;
    }

    return( ship->ship_object );
  }
  else
    return( -1 );
}


void door_control( SHIP *ship, dbref enactor, int control )
{
  /* active check */
  if( ship == NULL ) {
    fnotify( enactor, "%sShip is inactive.%s", ANSI_GREEN, ANSI_NORMAL );
    return;
  }

  switch( ship->door_status ) {
    case DOORS_NONE:
      fnotify( enactor, "%s%sThis ship has no docking bay doors.%s", ANSI_HILITE,
             ANSI_RED, ANSI_NORMAL );
      return;
    case DOORS_CLOSED:
      if( control == 0 ) {
        /* This is a perfectly ordinary bit of code.  Keep reading.  You *
         * didn't see this.  You are getting sleepy.  Sleeeeppppppyyyyy. */
/*
        if( FRAND < 0.02 ) {
          notify( enactor, "A calm voice from a speaker says \"I'm sorry, Dave."
                  "  I can't do that.\"" );
          return;
        }
*/

        fnotify( enactor, "%s%sDocking bay doors opened.%s", ANSI_HILITE, ANSI_GREEN,
               ANSI_NORMAL );
        ship->door_status = DOORS_OPEN;
        return;
      }
      else {
        fnotify( enactor, "%sDocking bay doors are already closed.%s", ANSI_MAGENTA,
               ANSI_NORMAL);
        return;
      }

    case DOORS_OPEN:
      if( control == 0 ) {
        fnotify( enactor, "%sDocking bay doors are already open.%s", ANSI_MAGENTA, ANSI_NORMAL );
        return;
      }
      else {
        fnotify( enactor, "%s%sDocking bay doors closed.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        ship->door_status = DOORS_CLOSED;
        return;
      }
    default:
      /* bizarre.  this shouldn't happen.  throw a fit */
      log_space( "ERROR! - door_control@%s:%d", __FILE__, __LINE__ );
      break;
  }
}

void orbit( SHIP *ship, dbref enactor, char *argument )
{
    struct planet_contact *planet;
    char orbitter_string[120];
    CONTACT *contact;
    SHIP *observer;

    if( ship->flags[STARBASE] )
    {
        fnotify( enactor, "%s%sThat is unnecessary.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ( planet=ship->orbitting )!=NULL && ( argument==NULL || argument[0]=='\0' ) )
    {
        ship->bombarding = 0;
        sprintf( writebuf, "%s%sBreaking out of orbit from %s.%s", ANSI_HILITE,
            ANSI_GREEN, ship->orbitting->name, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if( ( contact=find_contact(observer,ship) )!=NULL )
            {
                contact_string( orbitter_string, contact, INFO_TERSE );
                sprintf( writebuf, "%s%sContact [%d]: %s left orbit around %s.%s",
                    ANSI_HILITE, ANSI_MAGENTA, contact->contact_number,
                    orbitter_string, planet->name, ANSI_NORMAL );
                notify_room( BRIDGE(observer), writebuf );
            }
        }
        ship->orbitting = NULL;
        return;
    }
    else if( ship->orbitting!=NULL )
    {
        fnotify( enactor, "%s%sShip is already in orbit.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( argument==NULL )
    {
        fnotify( enactor, "%s%sNot currently in orbit.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    planet = match_planet( ship, argument );
    if( planet==NULL )
    {
        fnotify( enactor, "%s%sPlanet cannot be found on sensors.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( distance(ship->pos,planet->listref->pos) > planet->listref->size )
    {
        fnotify( enactor, "%s%sYou must be within %d units of %s to orbit.%s",
            ANSI_HILITE, ANSI_RED, (int)planet->listref->size,
            planet->name, ANSI_NORMAL );
        return;
    }
    ship->orbitting = planet;
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        contact = find_contact( observer, ship );
        if( contact!=NULL )
        {
            contact_string( orbitter_string,  contact, INFO_TERSE );
            sprintf( writebuf, "%s%sContact [%d]: %s entered orbit around %s.%s",
                ANSI_HILITE, ANSI_MAGENTA, contact->contact_number,
                orbitter_string, planet->name, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
        }
    }
    sprintf( writebuf, "%s%sNow in orbit around %s.%s", ANSI_HILITE,
        ANSI_GREEN, planet->name, ANSI_NORMAL );
    notify_room( BRIDGE(ship), writebuf );

    sprintf( writebuf, "#%d", planet->listref->planet_object );
    put_attribute( ship->ship_object, (char *) "ORBITTING", writebuf );
    
    log_space( "%s (#%d) put %s in orbit around %s.", Name(enactor), enactor, ship->name, planet->name ); 
    return;
}

dbref tractor_dock( SHIP *ship, dbref enactor )
{
    char docker_string[160],dock_string[160],*vbuff[3];
    CONTACT *victim,*docker,*dockee;
    dbref docking_bay,shuttle_bay,ship_marker;
    SHIP *observer;
    int i;

    if( ( victim=ship->tractor_target )==NULL || victim->listref==NULL )
    {
        fnotify( enactor, "%sThe tractor beam is not locked onto a ship.%s",
            ANSI_MAGENTA, ANSI_NORMAL );
        return -1;
    }
   /* AHEM! That's a crash waiting to happen!
   
    if( ship->dock_capacity <= 0.0 )
    {
        fnotify( enactor, "%sThis ship has no docking bay.%s",
            ANSI_MAGENTA, ANSI_NORMAL );
        return -1;
    }
    * -- Howie
   */
       /* extract the dbref of the docking bay */
    docking_bay = match_result(HOWIE, fetch_attribute(ship->ship_object, "DOCK"), NOTYPE, MAT_ABSOLUTE);
    shuttle_bay = match_result(HOWIE, fetch_attribute(ship->ship_object, "SHUTTLE_BAY"), NOTYPE, MAT_ABSOLUTE);
    ship_marker = match_result(HOWIE, fetch_attribute(victim->listref->ship_object, "MARKER"), NOTYPE, MAT_ABSOLUTE);
    /* Howie mods.  Makes room for more IC play.  Use Shuttle_bay for shuttles. */
    if( !GoodObject(shuttle_bay) && !GoodObject(docking_bay))
    {
        notify( enactor, "The ship does not have a docking bay nor a shuttle bay." );
        return -1;
    }
    if( !GoodObject(docking_bay) && !victim->listref->flags[SHUTTLECRAFT] )
    {
        notify( enactor, "The ship does not have a docking bay." );
        return -1;
    }
    if( !GoodObject(ship_marker) )
    {
        notify( enactor, "That ship is unable to dock." );
        return -1;
    }
    if( (atoi(fetch_attribute(victim->listref->ship_object,"CLAMPS_ON")) == 1) && !victim->listref->flags[SHUTTLECRAFT] )
    {
    	fnotify( enactor, "%s%sCannot clamp any ship...can only dock to a ship with a docking bay (This one probably has clamps instead).%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
		return -1;
	}
    /* target is capable of receiving dockers */
    if( ((ship->dock_max_size < victim->listref->size ) && !victim->listref->flags[SHUTTLECRAFT]) )
    {
        fnotify( enactor, "%s%sThat ship is too large to dock with this one.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* dock facing shield is down */
    if( ship->shield_status[facing_shield(ship,victim->listref)]==SHLD_UP )
    {
        fnotify( enactor, "%s%sThe shield facing their ship must be lowered.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* distance less than five units */
    if( distance( ship->pos, victim->listref->pos ) > DOCK_RANGE )
    {
        fnotify( enactor, "%s%sTarget must be within %d units of the ship to be docked.%s",
            ANSI_HILITE, ANSI_RED, (int)DOCK_RANGE, ANSI_NORMAL );
        return -1;
    }
    if( victim->listref->motion.range > 0.0 )
    {
        fnotify( enactor, "%s%sTarget is still moving! Make him hold still!%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    if( ship->door_status!=DOORS_OPEN )
    {
        fnotify( enactor, "%s%sDocking bay doors are closed.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    if( victim->listref->flags[SHUTTLECRAFT] && (( ship->shuttlebay_capacity - atof(fetch_attribute(ship->ship_object,"SHUTTLE_CAPACITY"))) < victim->listref->size ))
    {
        fnotify( enactor, "%s%sShuttle bay is too small to fit target.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }       
    if( !victim->listref->flags[SHUTTLECRAFT] && (( ship->dock_capacity - atof(fetch_attribute(ship->ship_object,"CAPACITY"))) < victim->listref->size ))
    {
        fnotify( enactor, "%s%sDocking bay is too small to fit target.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return -1;
    }

    log_space( "%s(#%d) tractored %s into %s.", Name(enactor), enactor,
        victim->listref->name, ship->name );
    

    /* inform anyone who can see the docker about the maneuver */
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship || observer==victim->listref)
        {
            continue; /* continue looping */
        }
        docker = find_contact( observer, victim->listref );
        dockee = find_contact( observer, ship );
        observer->helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);

        /* OK we got 4 cases here */
        if( docker==NULL || dockee==NULL )
        {
        }
        else
        {
            contact_string( docker_string, docker, INFO_TERSE );
            contact_string( dock_string, dockee, INFO_TERSE );

            fnotify( observer->helmsman, "%sContact [%s%s%d%s%s]: %s%s%s tractored into contact [%s%s%d%s%s]: %s%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, docker->contact_number, ANSI_NORMAL,
                ANSI_CYAN, ANSI_NORMAL, docker_string, ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA,
                dockee->contact_number, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, dock_string );
        }
    }
    sprintf( writebuf, "#%d", ship->ship_object );
    put_attribute( victim->listref->ship_object, (char *)"DOCKED_AT", writebuf );
    /* notify the bridge */
    if( ( dockee=find_contact(victim->listref,ship) )!=NULL )
    {
        contact_string( dock_string, dockee, INFO_TERSE );
        sprintf( writebuf, "%s%sContact [%d]: %s has tractored you into its docking bay.%s",
            ANSI_HILITE, ANSI_RED, dockee->contact_number, dock_string,
            ANSI_NORMAL );
    }
    else
    {
        sprintf( writebuf, "%s%sUnknown source has tractored you into its docking bay.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    notify_room( BRIDGE(victim->listref), writebuf);
    if( victim->listref->flags[SHUTTLECRAFT] )
    {
    sprintf( writebuf, "%.2f",
        atof(fetch_attribute(ship->ship_object, "SHUTTLE_CAPACITY")) +
	    victim->listref->size);
    put_attribute(ship->ship_object, (char *)"SHUTTLE_CAPACITY", writebuf);
    sprintf( writebuf, "0");
    put_attribute( victim->listref->ship_object, (char*)"UNDOCKED", writebuf);
    }
    else
    {
    sprintf( writebuf, "%.2f",
        atof(fetch_attribute(ship->ship_object, "CAPACITY")) +
	    victim->listref->size);
    put_attribute(ship->ship_object, (char *)"CAPACITY", writebuf);
    sprintf( writebuf, "0");
    put_attribute( victim->listref->ship_object, (char*)"UNDOCKED",writebuf);
    }
    if( victim!=NULL )
    {
        contact_string( docker_string, victim, INFO_TERSE );
        sprintf( writebuf, "%sContact [%s%s%d%s%s]: %s%s%s has been tractored into the docking bay.%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, victim->contact_number, ANSI_NORMAL,
            ANSI_CYAN, ANSI_NORMAL, docker_string, ANSI_CYAN, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
    }
    
    /* Howie mods.  Moved this to hardcode from softcode for a reason.  People kept messing up the console softcode.  This fixes that */
    if( victim->listref->flags[SHUTTLECRAFT] && GoodObject( shuttle_bay ) )
    {
    safe_tel( ship_marker, shuttle_bay ,0);
    deallocate_ship( victim->listref );
    return shuttle_bay;
    }
    else
    {
    safe_tel( ship_marker, docking_bay ,0);
    deallocate_ship( victim->listref );
    return docking_bay;
    }
    

}
