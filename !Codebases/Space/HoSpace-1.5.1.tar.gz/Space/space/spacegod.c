/*
 * $Id: spacegod.c,v 1.2 1993/09/25 20:39:40 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


/*
 * $Log: spacegod.c,v $
 * Revision 1.2  1993/09/25  20:39:40  chuckles
 * cleaned up logging code.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 23 Aug 93 - get names from struct instead of object
 *               - space roster function
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS 24 May 93 - separated into nav.c
 * JMS/DJB ?? Jul 92 - original code
 */


/*
 * all_eng_status() -- Pass the dbref of the enactor.  Fctn gives doer engineering
 * status reports for all active ships.  This command will only be available
 * from special consoles.  Standard equipment will not call it.
 */

void all_eng_status( dbref enactor )
{
SHIP *ship;

  ship = space_list[current_space];

  while( ship !=NULL ) {
    sprintf( writebuf, "%s - %s %s-class %s", ship->name, ship->owner_name,
             ship->class, ship->type );
    notify( enactor, writebuf );
    eng_status( ship, enactor );
    ship = ship->next;
  }
}

void all_nav_status( dbref enactor )
{
SHIP *ship;

  ship = space_list[current_space];

  while( ship !=NULL ) {
    sprintf( writebuf, "%s - %s %s-class %s", ship->name, ship->owner_name,
             ship->class, ship->type );
    notify( enactor, writebuf );
    nav_status( ship, enactor );
    ship = ship->next;
  }
}

void space_roster( dbref enactor )
{
SHIP *ship;
int i;

  for( i = 0; i < SPACE_LIMIT; i++ ) {
    ship = space_list[i];
    if( ship == NULL ) {
      sprintf( writebuf, "--- %s space is empty ---\n", space_names[i] );
      notify( enactor, writebuf );
    }
    else {
      sprintf( writebuf, "--- ships in %s space ---", space_names[i] );
      notify( enactor, writebuf );
      sprintf( writebuf, "%-20.20s %-15.15s %-18.18s %-18.18s\n--------------------"
               " --------------- ------------------ ------------------",
               "name", "power", "class", "type" );
      notify( enactor, writebuf );
      do {
        sprintf( writebuf, "%-20.20s %-15.15s %-18.18s %-18.18s", ship->name,
                 ship->owner_name, ship->class, ship->type );
        notify( enactor, writebuf );
        ship = ship->next;
      } while( ship != NULL );
    }
  }
}

void shutdown_space( dbref enactor )
{
static char *shutdown_message = { (char *)"Space shutting down.  Ship deactivated." };
   
  if (!Wizard(enactor)) {
    notify( enactor, "You attempt to warp the fabric of space with your powers, but fail." );
    return;
  }
  while( space_list[current_space] !=NULL ) {
    notify_room(BRIDGE(space_list[current_space]), shutdown_message);
    notify_room(ENGINE(space_list[current_space]), shutdown_message );
    deallocate_ship( space_list[current_space] );
  }
  fnotify( enactor, "Space %d shut down.", current_space );
   
  /* log it */
  log_space( "Space shut down by %s(#%d)", fetch_attribute( enactor, "NAME" ),
             enactor );
  return;
}

void set_ship_flag( SHIP *ship, dbref enactor, char *arg1, int control )
{
int i;
int found;

  if( !Wizard(enactor) )
  {
    notify( enactor, "You attempt to warp the fabric of space with your powers, but fail." );
    return;
  }
  /* match the name to one of our flag names */
  found = 0;
  i = 0;
  while(( i < NUM_FLAGS ) && ( !found )) {
    if( strstr( flag_names[i], arg1 ) )
      found++;
    else
      i++;
  }

  /* might be status check. */
  if( !strcmp( arg1, "status" ))
  {
    notify( enactor, "Ship flags:" );
    for( i = 0; i < NUM_FLAGS; i++ ) {
      if( ship->flags[i] ) {
        notify( enactor, flag_names[i] );
      }
    }
    notify( enactor, "" );
    return;
  }
  else if( !found ) {
    /* not status and not a flag.  Return */
    notify( enactor, "Invalid flag." );
    return;
  }

  /* okay, it's a valid flag. */
  if( control ) {
    if( ship->flags[i] )
      notify( enactor, "Flag is already set." );
    else {
      ship->flags[i] = TRUE;
      sprintf( writebuf, "Ship now %s.", flag_names[i] );
      notify( enactor, writebuf );
    }
  }
  else {
    if( ship->flags[i] ) {
      ship->flags[i] = FALSE;
      sprintf( writebuf, "Ship is no longer %s.", flag_names[i] );
      notify( enactor, writebuf );
    }
    else
      notify( enactor, "Flag isn't currently set." );
  }

  return;
}

void force_contact( SHIP *ship, dbref enactor, char *argument )
{
    CONTACT *contact;
    SHIP *target;
    dbref victim;

    /* punish wise guy */
    if( !Wizard(enactor) )
    {
        if( FRAND < 0.5 )
        {
            notify( enactor, "You attempt to warp the fabric of space with your powers, but fail." );
        }
        else
        {
            break_system( ship, SYSTEM_SENSORS );
        }
        return;
    }
    if( argument==NULL || argument[0]=='\0' || !is_number(argument) )
    {
        fnotify( enactor, "%s%sI don't think so, Chief.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    else
    {
        victim=(dbref)atoi(argument);
    }
    if( ship->ship_object==victim )
    {
        fnotify( enactor, "%s%sThat's you!%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    for(target=space_list[current_space];target!=NULL;target=target->next)
    {
        if( target->ship_object==victim )
        {
            break;
        }
    }
    if( target==NULL )
    {
        fnotify( enactor, "%s%sTarget not found or not active.%s",
            ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
        return;
    }
    if( ( contact=find_contact(ship,target) )!=NULL )
    {
        contact->info_level = UMIN( contact->info_level + 1, 5 );
        contact->stale      = FALSE;
    }
    else
    {
        if( add_contact( ship, target )!=SERR_MALLOC )
        {
            contact = ship->contact_tail;
            contact->info_level = UMAX( contact->info_level, 1 );
            display_sensor_info( ship, contact, -1, DSD_NEW );
        }
    }
    return;
}

void armageddon( dbref enactor, int space )
{
    SHIP *ship;

    if( enactor!=HOWIE )
    {
        fnotify( enactor, "%s%sI don't think so, Chief.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( space < 0 || space >= SPACE_LIMIT )
    {
        fnotify( enactor, "%s%sSorry, Dave. I can't do that.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    current_space = space;
    for(ship=space_list[space];ship!=NULL;ship=space_list[space])
    {
        sprintf( writebuf, "%s%s*** OOOOH, NOOOOOOO! IT'S ARMAGEDDON!!! ***%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
        if( BRIDGE(ship)!=ENGINE(ship) )
        {
            notify_room( ENGINE(ship), writebuf );
        }
        explode_ship( ship );
    }
    return;
}
