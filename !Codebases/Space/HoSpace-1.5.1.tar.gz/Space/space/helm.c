/*
 * $Id: helm.c,v 1.6 1993/09/28 05:20:30 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: helm.c,v $
 * Revision 1.6  1993/09/28  05:20:30  chuckles
 * scanner range to float.  kill sensorlinks on loss of contact.
 *
 * Revision 1.5  1993/09/25  20:39:40  chuckles
 * arm all guns/torps
 *
 * Revision 1.4  1993/09/24  23:46:20  chuckles
 * use the new log_space function.  General logging cleanup.
 *
 * Revision 1.3  1993/09/24  23:09:41  chuckles
 * use jmalloc library.
 *
 * Revision 1.2  1993/09/01  04:38:22  chuckles
 * some tab/space cleanup
 * sprintf/notify combos changed to fnotifys
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 23 Aug 93 - get ship strings from struct instead of ship object
 * JMS 21 Aug 93 - compress/neaten helm status report
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS  2 Jun 93 - cleanup
 * JMS 27 May 93 - added course and speed to identify_ship
 * JMS 25 May 93 - lenghtened string fields in contact_string
 * JMS 24 May 93 - separated into helm.c
 * JMS/DJB ?? Jul 92 - original code
 */


/*
 * fun_helm_cmd()
 *
 *  input:
 *    standard fun_xxx stuff
 *
 *  purpose:
 *    parses and processes the function call
 *
 * JMS/DJB 21 Jul 92
 * JMS 24 May 93 - cleanup
 * JMS 26 Aug 93 - use SHIP_OBJECT instead of XA
 */

/* kludegy globals */
char *writebuf2;


FUNCTION(fun_helm_cmd)
{
    SHIP *ship;
    dbref ship_object;

    if( !Wizard(executor) || args[0]==NULL )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    /* get the dbref of the ship object */
    ship_object = attrib_dbref( executor, "SHIP_OBJECT" );
    if( !GoodObject( ship_object ) )
    {
        safe_str("#-1 BAD SHIP OBJECT", buff, bp );
        return;
    }
    /* now set the ship pointer to the proper ship and also set the
     * space list to the list that contains it (handled by cfind_ship).
     */
    ship = cfind_ship( ship_object );
    /* no helm commands will work for an inactive ship */
    if( ship == NULL )
    {
        fnotify( enactor, "%sShip must be active to use that command.%s", ANSI_CYAN,ANSI_NORMAL );
        return;
    }
    /* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
    else if( ship->flags[DEADMAN] )
    {
        fnotify( enactor, "%s%sShip is deadmanned. That command is unavailable.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    else if( current_space==REAL && !Wizard(executor) )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    /* Everything is fine so far.  Switch on the command argument */
    else if( !strcmp( args[0], "contacts" ) )
    {
        CONTACT *contact;
        char minibuf[10];

        minibuf[0]='\0';
        for(contact=ship->contact_list;contact!=NULL;contact=contact->next)
        {
            sprintf( minibuf, "%d ", contact->contact_number );
            strcat( writebuf, minibuf );
        }
        safe_str( writebuf, buff, bp );
    }
    else if( !strcmp( args[0], "locked_contact" ) )
    {
        sprintf( writebuf, "%d", ship->locked_target ? ship->locked_target->contact_number : 0 );
        safe_str( writebuf, buff, bp );
    }
    else if( !strcmp( args[0], "tractor_dock" ) )
    {
        sprintf( writebuf, "#%d", tractor_dock(ship, enactor) );
        safe_str( writebuf, buff, bp );
    }
    else if( !strcmp( args[0], "tractor_target" ) )
    {
        sprintf( writebuf, "#%d", ship->tractor_target ? ship->tractor_target->listref->ship_object : -1 );
        safe_str( writebuf, buff, bp );
    }
    else if( !strcmp( args[0], "sensor_report" ) )
    {
        helm_sensor_report( ship, enactor );
    }
    else if( !strcmp( args[0], "short_sensor_report" ) )
    {
        short_sensor_report( ship, enactor );
    }
    else if( !strcmp( args[0], "status" ) )
    {
        helm_status( ship, enactor );
    }
    else if( !strcmp( args[0], "lock" ) && args[1]!=NULL )
    {
        lock_weapons( ship, enactor, args[1] );
    }
    else if( !strcmp( args[0], "unlock" ))
    {
        drop_lock( ship, enactor );
    }
    else if( !strcmp( args[0], "engage_tractor" ) )
    {
        lock_tractor( ship, enactor, args[1] );
    }
    else if( !strcmp( args[0], "disengage_tractor" ) )
    {
        drop_tractor( ship, enactor );
    }
    else if( !strcmp( args[0], "target_system" ) )
    {
        target_system( ship, enactor, args[1] ? args[1] : "" );
    }
    else if( !strcmp( args[0], "set_tractor_mode" ) )
    {
        set_tractor_mode( ship, enactor, args[1] );
    }
    else if( !strcmp( args[0], "scan_ship" ))
    {
        scan_ship( ship, enactor, args[1], SS_SCAN );
    }
    else if( !strcmp( args[0], "dscan_ship" ) )
    {
        dscan_ship( ship, enactor, args[1] );
    }
    else if( !strcmp( args[0], "scan_planet" ) && args[1]!=NULL )
    {
        scan_planet( ship, enactor, match_planet(ship,args[1]) );
    }
    else if( !strcmp( args[0], "report_ship" ) )
    {
        scan_ship( ship, enactor, args[1], SS_REPORT );
    }
    else if( !strcmp( args[0], "photon_online" ) )
    {
         photon_online( ship, enactor, atoi( args[1] ));
    }
    else if( !strcmp( args[0], "photon_offline" ) )
    {
        photon_offline( ship, enactor, atoi( args[1] ));
    }
    else if( !strcmp( args[0], "phaser_online" ) )
    {
        phaser_online( ship, enactor, atoi( args[1] ));
    }
    else if( !strcmp( args[0], "phaser_offline" ) && args[1]!=NULL )
    {
        phaser_offline( ship, enactor, atoi( args[1] ));
    }
    else if( !strcmp( args[0], "fire_photon" ) && args[1]!=NULL )
    {
        fire_photon( ship, enactor, atoi( args[1] ), INFO_VERBOSE );
    }
    else if( !strcmp( args[0], "fire_phaser" ) && args[1]!=NULL )
    {
        fire_phaser( ship, enactor, atoi( args[1] ), INFO_VERBOSE, ship->locked_target );
    }
    else if( !strcmp( args[0], "manual_fire_phaser" ) )
    {
        xyz_fire_phaser( ship, enactor, atoi(args[1]), atoi(args[2]), atoi(args[3]), atoi(args[4]) );
    }
    else if( !strcmp( args[0], "manual_fire_photon" ) )
    {
        manual_fire_photon( ship, enactor, atoi(args[1]), args[2], args[3], args[4] );
    }
    else if( !strcmp( args[0], "reload_photon" ) )
    {
        reload_photon( ship, enactor, atoi(args[1]) );
    }
    else if( !strcmp( args[0], "allocate" ) )
    {
        helm_allocate( ship, enactor, atoi(args[1]), atoi(args[2]), atoi(args[3]) );
    }
    else if( !strcmp( args[0], "toggle_auto_reload" ) )
    {
        toggle_auto_reload( ship, enactor );
    }
    else if( !strcmp( args[0], "toggle_auto_online" ) )
    {
        toggle_auto_online( ship, enactor );
    }
    else if( !strcmp( args[0], "ship_specs" ))
    {
        ship_specs( ship, enactor );
    }
    else if( !strcmp( args[0], "watch" ) )
    {
        add_watch( ship, enactor, args[1], W_HELM );
    }
    else if( !strcmp( args[0], "unwatch" ) )
    {
        remove_watch( ship, enactor, args[1], W_HELM );
    }
    else if( !strcmp( args[0], "listwatch" ) )
    {
        list_watches( ship, enactor, W_HELM );
    }
    else if( !strcmp( args[0], "identify" ) )
    {
        identify_ship( ship, enactor, args[1] );
    }
    else if( !strcmp( args[0], "idlist" ) )
    {
        id_list( ship, enactor );
    }
    else if( !strcmp( args[0], "toggle_ignore" ) )
    {
        toggle_ignore_contact( ship, enactor, args[1] );
    }
    else if( !strcmp( args[0], "bombard" ) )
    {
        bombard_planet( ship, enactor );
    }
    else if( !strcmp( args[0], "external_reload" ) && args[1]!=NULL )
    {
        sprintf( writebuf, "%d", external_reload( ship, atoi(args[1]) ) );
        safe_str( writebuf, buff, bp );
    }
    else if( !strcmp( args[0], "battle_timer" ) )
    {
        sprintf( writebuf, "%d", ship->battle_timer );
        safe_str( writebuf, buff, bp );
    }
    else if( !strcmp( args[0], "force_contact" ) )
    {
        force_contact( ship, enactor, args[1] );
    }
    else if( !strcmp( args[0], "reset_safety" ) )
    {
        ship->battle_timer = TIMER_RESET;
    }
    else
    {
        notify( enactor, "Unrecognized helm_cmd call." );
    }
    return;
}


/**************************************
 *
 * identify_ship()
 *
 *  input:
 *    SHIP *ship          active ship
 *    dbref enactor                       person giving the command
 *    char *target                     the string given by enactor
 *
 *  purpose:
 *    generates the ID report.  Generally used only for automated vessels
 *    like starbases and merchants.
 *
 *  return value:
 *    none
 *
 * JMS ?? Nov 92
 * JMS 24 May 93 - cleanup
 * JMS 27 May 93 - finally added target course and speed
 * JMS 23 Aug 93 - get strings from struct instead of ship object
 *
 *************************************/

void identify_ship( SHIP *ship, dbref enactor, char *target )
{
  CONTACT *contact;
  XYZ cpos;
  SPH spos;
  static char *shield_strings[] = { 
	(char *)"fore", 
	(char *)"aft", 
	(char *)"port", 
	(char *)"starboard" };

  contact = match_contact( ship, target );

  if( contact == NULL ) {
    fnotify( enactor, "%s%sInvalid contact number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }

  cpos.x = contact->listref->pos.x - ship->pos.x;
  cpos.y = contact->listref->pos.y - ship->pos.y;
  cpos.z = contact->listref->pos.z - ship->pos.z;

  spos = xyz_to_sph( cpos );

  fnotify( enactor, "%sContact [%s%s%d%s%s]:\n%s%sName> %s%s\n%sClass> %s%s\n%sType> %s%s\n%sOwner> %s%s"
    "\n%sBearing> %s%3.0f\n%sElevation> %s%+3.0f\n%sRange> %s%3.0f\n%sHeading> %s%d%+d\n%sSpeed> %s%2.1f%s",
    ANSI_YELLOW, ANSI_MAGENTA, ANSI_HILITE, contact->contact_number, ANSI_NORMAL, ANSI_YELLOW, ANSI_HILITE,
    ANSI_BLUE, ANSI_RED, (contact->info_level < 5 ? "Unknown" : contact->listref->name),
    ANSI_BLUE, ANSI_RED, (contact->info_level < 4 ? "Unknown" : contact->listref->class),
    ANSI_BLUE, ANSI_RED, contact->listref->type,
    ANSI_BLUE, ANSI_RED, (contact->info_level < 3 ? "Unknown" : contact->listref->owner_name),
    ANSI_BLUE, ANSI_RED, spos.bearing,
    ANSI_BLUE, ANSI_RED, spos.elevation,
    ANSI_BLUE, ANSI_RED, spos.range,
    /* shield_strings[facing_shield( contact->listref, ship )], */
    ANSI_BLUE, ANSI_RED, (int)contact->listref->motion.bearing, (int)contact->listref->motion.elevation,
    ANSI_BLUE, ANSI_RED, contact->listref->warp_speed, ANSI_NORMAL );

  return;
}


void helm_sensor_report( SHIP *ship, dbref enactor )
{
    CONTACT *contact;

    fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s[Detailed Contact List]%s~~~%s",
        ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL );
    if( ship->contact_list==NULL )
    {
        notify( enactor, "No contacts on sensors." );
        fnotify ( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
            ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
        return;
    }
    for(contact=ship->contact_list;contact!=NULL;contact=contact->next)
    {
        display_sensor_info( ship, contact, enactor, DSD_ROUTINE );
    }
    fnotify ( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
            ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );

    return;
}


void short_sensor_report( SHIP *ship, dbref enactor )
{
    CONTACT *contact;
    contact = ship->contact_list;

    fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s[Contact List]%s~~~%s",
        ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL );
    if( contact == NULL )
    {
        notify( enactor, "No contacts on sensors." );
        fnotify ( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
            ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
        return;
    }
    fnotify( enactor, "%s%sLk   #   Name           Owner Cls   Bearing Range  Heading Warp  Shld  Status%s", 
        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    for(contact=ship->contact_list;contact!=NULL;contact=contact->next)
    {
        if( contact->ignored )
        {
            continue;
        }
        display_short_sensor_report( ship, contact, enactor );
    }
    fnotify ( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
            ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
    return;
}

int add_contact( SHIP *senser, SHIP *sensee )
{
    CONTACT *new_contact;
    
    /* Only if the contact is undocked! Or in the sims. */
    if( (find_contact(senser,sensee)!=NULL && !strcmp(fetch_attribute(senser->ship_object,"UNDOCKED"),"1") && !strcmp(fetch_attribute(sensee->ship_object,"UNDOCKED"),"1")) || (current_space != REAL && find_contact(senser,sensee)!=NULL) )
    {
        return 0;
    }
    if(!(new_contact=(CONTACT *)JMALLOC(sizeof(CONTACT))))
    {
        return SERR_MALLOC;
    }
    bzero( new_contact, sizeof(CONTACT) );
    if( senser->contact_list == NULL )
    {   /* empty list */
        senser->contact_list = new_contact;
        senser->contact_tail = new_contact;
        new_contact->prev = NULL;
        new_contact->next = NULL;
    }
    else
    {
        senser->contact_tail->next=new_contact;
        new_contact->prev = senser->contact_tail;
        new_contact->next = NULL;
        senser->contact_tail = new_contact;
    }
    /* great.  It's allocated and tacked on.  Now initialize it. */
    new_contact->listref = sensee;
    new_contact->turns_of_contact = 0;
    new_contact->info_level = 0;
    new_contact->contact_number = senser->next_contact_number;
    new_contact->watcher = W_NOBODY;
    new_contact->stale = FALSE;
    new_contact->ignored = FALSE;
    senser->next_contact_number = (senser->next_contact_number % 999) + 1;
    return 0;
   
}


void remove_contact( SHIP *senser, CONTACT *contact )
{
  dbref helmsman;
  XYZ last_position;
  SPH last_relative;
  PLANET *planet;

  /* kill any sensor link to the lost contact - JMS 26 Sep 93 */
  sever_link( senser, contact->listref, TS_INTERRUPTED, TN_BOTH );

  /* if there's a corresponding watch, kill it */
  remove_watch_ref( contact->listref, senser );

  /* notify the helmsman that we've lost our bad guy */
  /* first, figure out who he is */
  helmsman = attrib_dbref( senser->helm, "XB" );

  /* don't give this message if the target or senser is destroyed */
  if( contact->listref->hull_integrity > 0 && senser->hull_integrity > 0
  && !contact->ignored )
  {
    fnotify( helmsman, "%s%s<%s%sCONTACT LOST:%s%s --[%s%sContact %d%s%s]-- %s%s %s%s%s>%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL, ANSI_RED, ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL, ANSI_RED, contact->contact_number, ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL, ANSI_RED, contact->listref->name, ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
    /* get the target string */
    contact_string( writebuf, contact, INFO_VERBOSE );
    notify( helmsman, writebuf );

    /* give last known bearing and range */
    /* no, give the real bearing and range */
    last_position.x = contact->listref->pos.x - senser->pos.x;
    last_position.y = contact->listref->pos.y - senser->pos.y;
    last_position.z = contact->listref->pos.z - senser->pos.z;

    last_relative = xyz_to_sph( last_position );
    fnotify( helmsman, "Contact last spotted bearing: %s%s%3.0f%+2.0f%s, range %s%s%1.0f%s",
           ANSI_HILITE, ANSI_CYAN, last_relative.bearing, last_relative.elevation, ANSI_NORMAL,
           ANSI_HILITE, ANSI_CYAN, last_relative.range, ANSI_NORMAL );

    /* construct the target's movement string */
    if( contact->info_level > 1 || contact->listref->warp_speed > 0.0 )
    {
      fnotify( helmsman, "                     heading: %s%s%3.0f%+2.0f%s at warp %s%s%3.3f%s",
               ANSI_HILITE, ANSI_CYAN, contact->listref->motion.bearing, contact->listref->motion.elevation,
               ANSI_NORMAL, ANSI_HILITE, ANSI_CYAN, contact->listref->warp_speed, ANSI_NORMAL );
    }
  }
  /* shake tractor if one */
  if( senser->tractor_target == contact )
  {
    break_tractor( senser );
  }

  /* shake the lock if there was one */
  if( senser->locked_target == contact )
  {
    break_lock( senser );
  }

  /* If the lock is shaken before it's achieved, we need to tell the
   * lockee about it.  We do this by giving the locker the lock, then
   * calling break_lock().  This will generate the message for the
   * target, but not for the locking ship, which is exactly what we want.
   */
  if( senser->pending_lock == contact )
  {
    senser->locked_target = contact;
    break_lock( senser );
    senser->pending_lock = NULL;
  }
  for(planet=planet_list[current_space];planet!=NULL;planet=planet->next)
  {
    if( planet->locked_target == contact )
    {
      planet->locked_target = NULL;
    }
  }
  if( senser->contact_list == senser->contact_tail ) {   /* only one entry */
    senser->contact_list = NULL;
    senser->contact_tail = NULL;
    JFREE( contact );
    return;
  }

  if( contact == senser->contact_list )
  {
    senser->contact_list=contact->next;
    senser->contact_list->prev=NULL;
    JFREE(contact);
    return;
  }

  if( contact == senser->contact_tail )
  {
    senser->contact_tail = contact->prev;
    senser->contact_tail->next = NULL;
    JFREE( contact );
    return;
  }

  if(( contact != senser->contact_list) && ( contact != senser->contact_tail )) { /* contact centered */
    (contact->prev)->next = contact->next;
    (contact->next)->prev = contact->prev;
    JFREE( contact );
    return;
  }

}


void display_short_sensor_report( SHIP *senser, CONTACT *contact, dbref enactor )
{
    XYZ xyz;
    SPH sph;
    char Range[8];
    char Lk[3] = { ' ', ' ', '\0' };
    char Name[14], Owner[3], Cls[3], Bearing[15], Heading[15];
    char Shld[3], Status[7]; 
    static char *shield_strings[]={ (char *)"^", (char *)"v", (char *)"<", (char *)">" }; 
    char facing0,facing1;

    Shld[0] = '\0'; 
    Status[0] = '\0';
    Range[0] = '\0';
    /* calculate relative positions */
    xyz.x = contact->listref->pos.x - senser->pos.x;
    xyz.y = contact->listref->pos.y - senser->pos.y;
    xyz.z = contact->listref->pos.z - senser->pos.z;
    sph = xyz_to_sph( xyz );

    /* if enactor = -1, find the dbref of the helmsman */
    if( enactor == -1 )
    {
        enactor = match_result(HOWIE, my_atr_get_raw(senser->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
    }
    if( contact->listref->pending_lock!=NULL
    && contact->listref->pending_lock->listref==senser )
    {
        Lk[0] = '+';
    }
    if( contact->listref->locked_target!=NULL
    && contact->listref->locked_target->listref==senser )
    {
        Lk[0] = '*';
    }
    if( contact->listref->tractor_target!=NULL
    && contact->listref->tractor_target->listref==senser )
    {
        switch( contact->listref->tractor_mode )
        {
            default:
                Lk[1] = '?';
                break;
            case MODE_HOLD:
                Lk[1] = 'h';
                break;
            case MODE_TRACTOR:
                Lk[1] = 't';
                break;
            case MODE_PRESSOR:
                Lk[1] = 'p';
                break;
            case MODE_DET:
                Lk[1] = 'd';
                break;
        }
    }
    if( sph.range >= 10000000.0 )
    {
        sprintf( Range, "%-4.0fM", sph.range/1000000.0 );
    }
    else if( sph.range >= 100000.0 )
    {
        sprintf( Range, "%-4.0fK", sph.range/1000.0 );
    }
    else
    {
        sprintf( Range, "%-5.0f", sph.range );
    }
    sprintf( Cls, "%-3.3s", contact->listref->short_type );
    facing0 = facing_shield(contact->listref,senser);
    facing1 = facing_shield(senser,contact->listref);
    strcat( Shld, shield_strings[facing0] ); 
    if( contact->listref->shield_status[facing1]==SHLD_UP
    && contact->listref->shield_level[facing1] > 0 )
    {
        strcat( Shld, (char *)"|" );
    }
    else
    {
        strcat( Shld, (char *)":" );
    }
    if( contact->info_level > 1 || contact->listref->warp_speed > 0.0 )
    {
        sprintf( Heading, "%-3.0f %-+3.0f %-3.1f",
             contact->listref->motion.bearing,
             contact->listref->motion.elevation,
             contact->listref->warp_speed );
        strcat( Shld,
             shield_strings[facing1] );
    }
    else
    { 
        strcat( Shld, (char *)"?" );
        sprintf( Heading, "??????? ????" );
    }
    if( contact->info_level > 2 )
    {
        sprintf( Owner, "%-3.3s", contact->listref->owner_name );
    }
    else
    {
        sprintf( Owner, "???" );
    }
    if( contact->info_level > 4 ) 
        sprintf( Name, "%-14.14s", contact->listref->name );
    else
        sprintf( Name, "??????????????" );

    if( contact->listref->orbitting!=NULL )
    {
        sprintf(Status, "*%s*", contact->listref->bombarding ? "PBomb" : "Orbit" );
    }
    else if( contact->listref->flags[DEADMAN] )
    {
        sprintf(Status, "*Deadm*" );
    }
    else if( contact->listref->flags[DISABLED] )
    {
        sprintf(Status, "*Disab*" );
    }
    else if( contact->listref->cloak_status==CLOAK_ON )
    {
        sprintf(Status, "*Cloak*" );
    }
    sprintf( Bearing, "%-3.0f %-+3.0f %-5s", sph.bearing, sph.elevation, Range );
    fnotify( enactor, "%s%s%s %s%3d%s   %s%-14.14s %s%-3.3s   %s%s%-3.3s   %s%-14.14s %-14.14s%s%s%-3.3s   %s%-.7s%s",
        ANSI_HILITE, ANSI_RED, Lk, ANSI_MAGENTA, contact->contact_number, ANSI_NORMAL,
        ANSI_CYAN, Name, ANSI_MAGENTA, Owner, ANSI_HILITE, ANSI_RED, Cls, ANSI_CYAN, 

        Bearing, Heading, ANSI_NORMAL, ANSI_HILITE, Shld, ANSI_RED, Status, ANSI_NORMAL );
    notify( enactor, "" );
}


void display_sensor_info( SHIP *senser, CONTACT *contact, dbref enactor, int control )
{
    char target_string[120];
    char facing0,facing1;
    dbref navigator;
    XYZ xyz;
    SPH sph;
    static char *shield_strings[] =
    {
	(char *)"fore", 
	(char *)"aft", 
	(char *)"port", 
	(char *)"starboard"
    };

    /* calculate relative positions */
    xyz.x = contact->listref->pos.x - senser->pos.x;
    xyz.y = contact->listref->pos.y - senser->pos.y;
    xyz.z = contact->listref->pos.z - senser->pos.z;
    sph = xyz_to_sph( xyz );

    /* if enactor = -1, find the dbref of the helmsman */
    if( enactor == -1 )
    {
        enactor = match_result(HOWIE, my_atr_get_raw(senser->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
        navigator = match_result(HOWIE,my_atr_get_raw(senser->nav,"XB"),NOTYPE,MAT_ABSOLUTE);
        senser->navigator = navigator;
    }
    else
    {
        navigator = enactor;
    }
    /* flash the header message, if any */
    switch( control )
    {
        case DSD_NEW:
            sprintf( writebuf, "%s%sNEW CONTACT%s%s - designated number %s%s%d%s",
                ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL, ANSI_YELLOW, ANSI_HILITE,
                ANSI_MAGENTA, contact->contact_number, ANSI_NORMAL );
            notify( navigator, writebuf );
            break;
        case DSD_UPDATE:
          if (contact->info_level < 4) 
           {
            sprintf( writebuf, "%sUpdate:  Contact [%s%s%d%s%s] further identified as:%s",
                ANSI_YELLOW, ANSI_HILITE, ANSI_MAGENTA, contact->contact_number, ANSI_NORMAL,
                ANSI_YELLOW, ANSI_NORMAL );
            notify( navigator, writebuf );
            sprintf( writebuf, "%s%s %s class %s - <%.2f>%s", ANSI_CYAN, contact->listref->owner_name, contact->listref->class, contact->listref->type, contact->listref->size, ANSI_NORMAL);
            notify( navigator, writebuf );
            sprintf( writebuf,"%s%sContact is at range %s%s%.0f%s", ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL, ANSI_RED, sph.range, ANSI_NORMAL);
            notify( navigator, writebuf );
            }
          else 
           {
            sprintf( writebuf, "%sUpdate:  Contact [%s%s%d%s%s] further identified as:%s",
                ANSI_YELLOW, ANSI_HILITE, ANSI_MAGENTA, contact->contact_number, ANSI_NORMAL,
                ANSI_YELLOW, ANSI_NORMAL );
            notify( navigator, writebuf );
            sprintf( writebuf, "%s%s %sat range%s%s %.0f%s%s bearing %.0f %+.0f%s", ANSI_CYAN, contact->listref->name, ANSI_HILITE, ANSI_NORMAL, ANSI_RED, sph.range, ANSI_HILITE, ANSI_CYAN, sph.bearing, sph.elevation, ANSI_NORMAL);
            notify(navigator, writebuf);
           }
           break;
        case DSD_ROUTINE:
            /* set up the default */
            sprintf( writebuf, "%sContact [%s%s%d%s%s]:  %s%s%s <%.2f>%s", ANSI_YELLOW, ANSI_HILITE, ANSI_YELLOW,
                contact->contact_number, ANSI_NORMAL, ANSI_YELLOW, ANSI_GREEN, contact->listref->name, ANSI_WHITE, contact->listref->size, ANSI_NORMAL );

            /* now replace it if we need to */
            if( contact->listref->pending_lock != NULL )
            {
                if( contact->listref->pending_lock->listref == senser )
                {
                    sprintf( writebuf, "%s[%s%s+%s%s] Contact [%s%s%d%s%s]:%s", ANSI_YELLOW, ANSI_HILITE, 
                        ANSI_RED, ANSI_NORMAL, ANSI_YELLOW, ANSI_HILITE, ANSI_YELLOW,
                        contact->contact_number, ANSI_NORMAL,ANSI_YELLOW, ANSI_NORMAL );
                }
            }
            if( contact->listref->locked_target != NULL )
            {
                if( contact->listref->locked_target->listref == senser )
                {
                    sprintf( writebuf, "%s[%s%s*%s%s] Contact [%s%s%d%s%s]:%s", ANSI_YELLOW, ANSI_HILITE, 
                        ANSI_RED, ANSI_NORMAL, ANSI_YELLOW, ANSI_HILITE, ANSI_MAGENTA,
                        contact->contact_number, ANSI_NORMAL,ANSI_YELLOW, ANSI_NORMAL );
                }
            }
    
    notify( enactor, writebuf );
    if( navigator!=enactor )
    {
        notify( navigator, writebuf );
    }
    /* sprintf( writebuf, "   Contact bearing %s%s%3.0f%s elevation %s%s%+2.0f%s range %s%s%1.0f%s",
        ANSI_HILITE, ANSI_CYAN, sph.bearing, ANSI_NORMAL,
        ANSI_HILITE, ANSI_CYAN, sph.elevation, ANSI_NORMAL,
        ANSI_HILITE, ANSI_CYAN, sph.range, ANSI_NORMAL );
    if( navigator!=enactor )
    {
        notify( navigator, writebuf );
    } */
    contact_string( target_string, contact, INFO_VERBOSE );
    /* sprintf( writebuf, "%s <%.2f>\n-----------------------------------------------------------------------------%s", target_string, contact->listref->size, ANSI_WHITE, ANSI_NORMAL );
       notify( enactor, writebuf ); */
    if( navigator!=enactor )
    {
        notify( navigator, writebuf );
    }
    facing0 = facing_shield(contact->listref,senser);
    facing1 = facing_shield(senser,contact->listref);
    sprintf( writebuf, "%sContact at XYZ: %.0f %.0f %.0f.   Bearing: %3.0f %+2.0f Range: %.0f%s", ANSI_CYAN,
        contact->listref->pos.x, contact->listref->pos.y,
        contact->listref->pos.z, sph.bearing, sph.elevation, sph.range, ANSI_NORMAL );
    notify( enactor, writebuf );
    if( navigator!=enactor )
    {
        notify( navigator, writebuf );
    }
    /* sprintf( writebuf, "   Contact bearing %s%s%3.0f%s elevation %s%s%+2.0f%s range %s%s%1.0f%s",
        ANSI_HILITE, ANSI_CYAN, sph.bearing, ANSI_NORMAL,
        ANSI_HILITE, ANSI_CYAN, sph.elevation, ANSI_NORMAL,
        ANSI_HILITE, ANSI_CYAN, sph.range, ANSI_NORMAL );
    notify( enactor, writebuf );
    if( navigator!=enactor )
    {
        notify( navigator, writebuf );
    } */
    
    if( contact->info_level > 1 )
    {
        /* construct the target's movement string */
        /* sprintf( writebuf, "Contact heading %s%s%1.0f%+2.0f%s at warp %s%s%3.3f%s with shields ",
            ANSI_HILITE, ANSI_CYAN, contact->listref->motion.bearing,
            contact->listref->motion.elevation, ANSI_NORMAL,
            ANSI_HILITE, ANSI_CYAN, contact->listref->warp_speed, ANSI_NORMAL );
        notify( enactor, writebuf );
        if( navigator!=enactor )
        {
            notify( navigator, writebuf );
        } */
    }
    /* if they are cloaked, let's hear about it */
    if( contact->listref->cloak_status == CLOAK_ON )
    {
        sprintf( writebuf, "%sContact heading %s%s%1.0f%+2.0f%s at warp %s%s%3.1f%s while %s%sCLOAKED%s",
           ANSI_WHITE, ANSI_HILITE, ANSI_CYAN, contact->listref->motion.bearing, contact->listref->motion.elevation, ANSI_WHITE, ANSI_HILITE, ANSI_CYAN, contact->listref->warp_speed,  ANSI_WHITE, ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );

    }
    else if( contact->listref->shield_status[facing1]==SHLD_UP
    && contact->listref->shield_level[facing1] > 0 )
    {
        sprintf( writebuf, "%sContact heading %s%s%1.0f%+2.0f%s at warp %s%s%3.1f%s with shields %s%sUP%s",
          ANSI_WHITE, ANSI_HILITE, ANSI_CYAN, contact->listref->motion.bearing, contact->listref->motion.elevation, ANSI_WHITE, ANSI_HILITE, ANSI_CYAN, contact->listref->warp_speed,  ANSI_WHITE, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    else
    {
        sprintf( writebuf, "%sContact heading %s%s%1.0f%+2.0f%s at warp %s%s%3.1f%s with shields %s%sDown%s",
             ANSI_WHITE, ANSI_HILITE, ANSI_CYAN, contact->listref->motion.bearing, contact->listref->motion.elevation, ANSI_WHITE, ANSI_HILITE, ANSI_CYAN, contact->listref->warp_speed,  ANSI_WHITE, ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    }
    notify( enactor, writebuf );
    
    if( navigator!=enactor )
    {
        notify( navigator, writebuf );
    }
    if( contact->listref->orbitting!=NULL )
    {
        sprintf( writebuf, "%s%sContact is in orbit around %s.%s", ANSI_HILITE,
            ANSI_RED, contact->listref->orbitting->name, ANSI_NORMAL );
        if( navigator!=enactor )
        {
            notify( navigator, writebuf );
        }
    }
    if( contact->ignored )
    {
        fnotify( enactor, "%sContact is currently being ignored.%s",
            ANSI_GREEN, ANSI_NORMAL );
    }
    if( contact->info_level >1 )
    {
        /* and give the shield facings */
        sprintf( writebuf, "%sOur %s%s%s%s %sside is facing their %s%s%s%s %sside.%s\n",
            ANSI_WHITE, ANSI_HILITE, ANSI_MAGENTA, shield_strings[facing0], ANSI_NORMAL,
            ANSI_WHITE, ANSI_HILITE, ANSI_MAGENTA, shield_strings[facing1], ANSI_NORMAL, ANSI_WHITE, ANSI_NORMAL );
        notify( enactor, writebuf );
        if( navigator!=enactor )
        {
            notify( navigator, writebuf );
        }
    }
    /* and the customary carriage return */
    notify( navigator, "" );
    return;
 }
}

/**************************************
 *
 * lock_weapons()
 *
 *  input:
 *    SHIP *ship         locking ship
 *    dbref enactor                      person giving the command
 *    char *target_string
 *
 *  purpose:
 *    matches target_string to a current contact if possible, and then locks
 *    weapons on that target
 *
 *  return value:
 *    none
 *
 * DJB/JMS ?? July 92
 * JMS 27 May 93 - cleanup
 *
 *************************************/

void lock_weapons( SHIP *ship, dbref enactor, char *target_string )
{
  int target_number;
  CONTACT *contact;
  CONTACT *target = NULL;
  char locker[120];
  float range;  /* used for the do_sensors */

  /* Inactive check already done for helm commands */
  /* But, need to see if we are undocked.  Do that here */
  if( !strcmp(fetch_attribute(ship->ship_object,"UNDOCKED"),"0" ))
  {
    fnotify( enactor, "%sYou cannot lock weapons while docked.%s", ANSI_CYAN, ANSI_NORMAL);
    return;
  }

  /* Okay, now convert the target string to an integer and search the
   * contact list for it.
   */
  if( ship->damage[SYSTEM_TARGETTING].status=='9'
  || ship->damage[SYSTEM_TARGETTING].status=='8'
  || ship->damage[SYSTEM_TARGETTING].status=='7' )
  {
      fnotify( enactor, "%s%sTargetting system is inoperative.%s",
          ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
  }
  target_number = atoi( target_string );

  if( target_number ) {
    /* they gave us a number */
    contact = ship->contact_list;
    while( contact != NULL ) {
      if( contact->contact_number == target_number ) {
  target = contact;
  contact = NULL;
      }
      else
  contact = contact->next;
    }

    if( target == NULL )
    {
      /* They've given us a number, and it's not in the list.  Go home. */
      fnotify( enactor, "%s%sInvalid contact number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    }
  }
  else {
    /* the wimps gave us a name, a zero, or nothing.    Oh well. */
    /* first check for a null string */
    if( !strcmp( target_string, "" )) {
      fnotify( enactor, "%s%sYou must specify a target name or contact number.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    }

    /* terrific.  We've got a valid string.  Go to town */
    contact = ship->contact_list;
    while( contact != NULL ) {

      /* only check if they can actually see the name */
      if( contact->info_level == 5 ) {
  if( strstr( contact->listref->name, target_string ) ) {
    /* whee! We found it */
    target = contact;
    contact = NULL;
  }
  else
         contact = contact->next;
      }
      else
  contact = contact->next;
    }
  }
   
  /* okay, we've looked hard.  Go home if target is still a NULL */
  if( target == NULL ) {
    fnotify( enactor, "%s%sNo contact with any ship called '%s%s%s%s%s'.%s", ANSI_HILITE,
           ANSI_RED, ANSI_NORMAL, ANSI_CYAN, target_string, ANSI_HILITE, ANSI_RED,
           ANSI_NORMAL );
    return;
  }

  /* alright.   We've got a valid ship on our scanners.  Go to town. */
  /* drop any prior lock */
  if( ship->locked_target != NULL ) {
    if( ship->locked_target == contact ) {
      fnotify( enactor, "%sWe are already locked on that ship.%s", ANSI_MAGENTA, ANSI_NORMAL );
      return;
    }
    else
      break_lock( ship );
  }
  if( ship_is_safe(target->listref) )
  {
     fnotify( enactor, "%s%sThat ship is safe. Unable to lock.%s",
          ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
     return;
  }
  if( ship->orbitting )
  {
    fnotify( enactor, "%s%sYou cannot lock while orbitting (you're prolly on the wrong side of the planet!)%s",
        ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
  /* set the new pending lock */
  ship->battle_timer = TIMER_RESET;
  ship->pending_lock = target;
  target->listref->battle_timer = TIMER_RESET;
   
  /*****************************
   *
   * THIS IS IMPORTANT
   * Mostly because it's a break in the turn sequence.  I find it likely
   * that future bugs could result in forgetting about this call.
   * Right here we immeiately call do_sensors and give the target a
   * chance to acquire the locker, out of turn, even.   It makes a lot
   * of sense and is really neccesary, but it's a deviation from the
   * turn sequence and chould therefore be carefully noted. - JMS
   *
   *****************************/
  range = distance( target->listref->pos, ship->pos );
  do_sensors( target->listref, ship, range );

  /* notify the enactor that the lock is pending */
  fnotify( enactor, "%sAttempting to lock weapons.%s", ANSI_CYAN, ANSI_NORMAL );

  /* search to see if target has sensor contact with locker */
  contact = target->listref->contact_list;
  while( contact != NULL )
  {
    if( contact->listref == ship )
    {
      contact->ignored = FALSE;
      /* okay, they've got us.  tell them who's doing it */
      contact_string( locker, contact, INFO_VERBOSE );

      sprintf( writebuf, "%s%sWarning!  Contact [%s%d%s]: %s%s%s%s has locked weapons.%s",
             ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, contact->contact_number, 
             ANSI_RED, ANSI_NORMAL, locker, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      notify_room(BRIDGE(target->listref), writebuf);

      /* we don't need contact anymore.  Go home */
     return;
    }
    else
      contact = contact->next;
  }

  /* mystery ship locking... */
  sprintf( writebuf, "%s%sWarning!  Weapons have been locked from an unknown source.%s",
           ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
  notify_room(BRIDGE(target->listref), writebuf );
  return;
}

void lock_tractor( SHIP *ship, dbref enactor, char *target_string )
{
   // int target_number;
    CONTACT *contact;
    CONTACT *target = NULL;
    char locker[120];
    float range;

    if( ship->tractor_range<=0 )
    {
        fnotify( enactor, "%s%sThis ship has no tractor beam.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ship->damage[SYSTEM_TRACTOR].status=='9' )
    {
        fnotify( enactor, "The tractor beam is destroyed." );
        return;
    }
    if( ship->damage[SYSTEM_TRACTOR].status=='7' )
    {
        fnotify( enactor, "The tractor beam is damaged." );
        return;
    }
    if( ship->halloc_tractor<=0 )
    {
        fnotify( enactor, "%s%sCannot engage tractors without allocated power.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( target_string==NULL || target_string[0]=='\0' )
    {
        fnotify( enactor, "%s%sYou must specify a target name or contact number.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ( target=match_contact(ship,target_string) )==NULL )
    {
        fnotify( enactor, "%s%sNo contact with any ship called '%s%s%s%s%s'.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL, ANSI_CYAN, target_string, ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return;
    }
    if( ship_is_safe( target->listref ) )
    {
        fnotify( enactor, "Unable to engage tractors, target is safe." );
        return;
    }
    if( distance( ship->pos, target->listref->pos ) > ship->tractor_range )
    {
        fnotify( enactor, "Target out of range." );
        return;
    }
    if( ship->tractor_target != NULL )
    {
        if( ship->tractor_target==target )
        {
            fnotify( enactor, "%sWe are already tractoring that ship.%s",
                ANSI_MAGENTA, ANSI_NORMAL );
            return;
        }
        else
        {
            break_tractor( ship );
        }
    }
    if( ship->smart_alloc==2 )
    {
        switch( ship->tractor_mode )
        {
            case MODE_DET:
                free_power( ship, POWER_HELM_TRACTOR, ship->halloc_tractor );
                requisition_power( ship, POWER_HELM_TRACTOR, 1 );
                break;
            default:
                break;
        }
    }
    /* set the new tractor target */
    ship->tractor_target = target;
   
  /*****************************
   *
   * THIS IS IMPORTANT
   * Mostly because it's a break in the turn sequence.  I find it likely
   * that future bugs could result in forgetting about this call.
   * Right here we immeiately call do_sensors and give the target a
   * chance to acquire the locker, out of turn, even.   It makes a lot
   * of sense and is really neccesary, but it's a deviation from the
   * turn sequence and chould therefore be carefully noted. - JMS
   *
   *****************************/
    range = distance( target->listref->pos, ship->pos );
    do_sensors( target->listref, ship, range );

    /* notify the enactor that the lock is pending */
    fnotify( enactor, "%sEngaging tractors.%s", ANSI_CYAN, ANSI_NORMAL );

    /* search to see if target has sensor contact with locker */
    if( ( contact=find_contact(target->listref,ship) )!=NULL )
    {
        contact->ignored = FALSE;
        /* okay, they've got us.  tell them who's doing it */
        contact_string( locker, contact, INFO_VERBOSE );

        sprintf( writebuf, "%s%sWarning!  Contact [%s%d%s]: %s%s%s%s has engaged tractor beam.%s",
            ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, contact->contact_number, 
            ANSI_RED, ANSI_NORMAL, locker, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room(BRIDGE(target->listref), writebuf);
        return;
    }
    else
    {
        sprintf( writebuf, "%s%sWarning!  Tractor beams have been engaged from an unknown source.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room(BRIDGE(target->listref), writebuf );
    }
    return;
}

/*
 * contact_string()
 *
 *  input:
 *    char *buff                      place to write finished string
 *    CONTACT *contact   contact we need a string for
 *    int control                     INFO_TERSE or INFO_VERBOSE
 *
 *  purpose:
 *    Builds a contact identifying string for contact.
 *
 *  notes:
 *    buff should be allocated to at least 120 before this function is
 *    called.
 *
 * JMS/DJB ?? Jul 92
 * JMS 24 May 93 - cleanup
 * JMS 24 May 93 - field lengths extended
 * JMS 23 Aug 93 - field lengths removed. :)  Read from struct instead.
 */

void contact_string( char *buff, CONTACT *contact, int control )
{
  SHIP *target;

  /* bulletproofing - JMS 26 Sep 93 */
  if( contact == NULL )
  {
    strcpy(buff,"-error-");
    return;
  }

  if( ( target=contact->listref )==NULL )
  {
    strcpy(buff,"-error-");
    return;
  }

  /* switch on the info level */
  switch( contact->info_level )
  {
    case 5:
      if( control != INFO_VERBOSE )
  /* spam control */
  sprintf( buff, "%s%s%s", ANSI_CYAN, target->name, ANSI_NORMAL );
      else
  sprintf( buff, "%s%s -- %s %s-class %s%s", ANSI_CYAN, target->name,
                 target->owner_name, target->class, target->type, ANSI_NORMAL );
      break;
    case 4:
      sprintf( buff, "%s%s %s-class %s%s", ANSI_CYAN, target->owner_name, target->class,
               target->type, ANSI_NORMAL );
      break;
    case 3:
      sprintf( buff, "%s%s %s%s", ANSI_CYAN, target->owner_name, target->type, ANSI_NORMAL );
      break;
    default:
      sprintf( buff, "%s%s%s", ANSI_CYAN, target->type, ANSI_NORMAL );
      break;
  }
}

/*************************************************************************
 * this is as far south as the code cleanup has progressed - JMS 5/24/93 *
 *************************************************************************/

/*
 * break_lock() -- Pass the breaker.  Fctn notifies the target
 * that the lock is gone.  Note that it does NOT notify the breaker that the
 * lock is gone.
 */


void break_lock( SHIP *ship )
{
   dbref helmsman;
   CONTACT *contact, *target = NULL;
   char description[120];

   if( ship->locked_target==NULL )
   {
       return;
   }
   /* get the helmsman */
   helmsman = match_result(HOWIE, my_atr_get_raw(ship->locked_target->listref->helm, 
			    "XB"), NOTYPE, MAT_ABSOLUTE);

   /* Check the target's contact list for the breaker. */
   contact = ship->locked_target->listref->contact_list;
   while( contact != NULL ) {
      if( contact->listref == ship ) {
   target = contact;
   contact = NULL;
      }
      else
   contact = contact->next;
   }

   /* Okay.  Notify the bad guy now, but only if he's alive. */
   if( ship->hull_integrity > 0 ) {
      if( target == NULL ) {
   fnotify( helmsman, "%s%sWeapons lock from unknown source has been broken.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
      }
      else {
        contact_string( description, target, INFO_VERBOSE );
          fnotify( helmsman, "%s%sWeapons lock from contact [%s%d%s] %s%s%s%s has been broken.%s",
                 ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, target->contact_number, ANSI_RED,
                 ANSI_NORMAL, description, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      }
   }
   
   /* break the lock */
   ship->locked_target = NULL;
   return;
}

void break_tractor( SHIP *ship )
{
    char description[120];
    CONTACT *contact;

    if( ship->tractor_target==NULL )
    {
        return;
    }
    /* get the helmsman */
    ship->helmsman = match_result(HOWIE,my_atr_get_raw(ship->tractor_target->listref->helm,"XB"),NOTYPE,MAT_ABSOLUTE);
    /* Check the target's contact list for the breaker. */
    contact = find_contact( ship->tractor_target->listref, ship );
    if( contact==NULL )
    {
        fnotify( ship->helmsman, "%s%sTractor beam from unknown source has been disengaged.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    else
    {
        contact_string( description, contact, INFO_VERBOSE );
        fnotify( ship->helmsman, "%s%sTractor beam from contact [%s%d%s] %s%s%s%s has been disengaged.%s",
            ANSI_HILITE, ANSI_RED, ANSI_MAGENTA, contact->contact_number, ANSI_RED,
            ANSI_NORMAL, description, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    if( ship->smart_alloc==2 )
    {
        free_power( ship, POWER_HELM_TRACTOR, ship->halloc_tractor );
    }   
    /* break the lock */
    ship->tractor_target = NULL;
    return;
}

void drop_lock( SHIP *ship, dbref enactor )
{
   /* Inactive check already done for helm commands */

   /* locking check */
   if( ship->pending_lock !=NULL ) {
      fnotify( enactor, "%s%sLock attempt aborted.%s", 
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      ship->pending_lock = NULL;
      return;
   }

   /* locked check */
   if( ship->locked_target == NULL ) {
      fnotify( enactor, "%sWeapons are currently not locked.%s",
            ANSI_MAGENTA, ANSI_NORMAL );
      return;
   }

   /* break the lock */
   break_lock( ship );
   fnotify( enactor, "%s%sWeapons unlocked.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
   return;
}

void drop_tractor( SHIP *ship, dbref enactor )
{
    if( enactor == -1  )
    {
        enactor = match_result(HOWIE, my_atr_get_raw(ship->helm,"XB"), NOTYPE, MAT_ABSOLUTE);
    }
    /* locked check */
    if( ship->tractor_target == NULL )
    {
        fnotify( enactor, "%sTractor beam is currently not engaged.%s",
            ANSI_MAGENTA, ANSI_NORMAL );
        return;
    }
    /* break the lock */
    fnotify( enactor, "%s%sTractor beam disengaged.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    break_tractor( ship );
    return;
}

/*************************************
 *
 * helm_status()
 *
 *  input:
 *    SHIP *ship         ship to generate report for
 *    dbref enactor                      guy wanting the report
 *
 *  purpose:
 *    flashes a helm status report to enactor
 *
 *  return value:
 *    none
 *
 * DJB/JMS ?? July 92
 * JMS 27 May 93 - cleanup
 * JMS 21 Aug 93 - compress/neaten
 *
 *************************************/

void helm_status( SHIP *ship, dbref enactor )
{
  int i;
  char astring[80], bstring[80];
  static char *onoff[] = { (char *)"off", (char *)"on " };
  static char *automan[] = { (char *) "manual", (char *) "automatic" };

  /* Inactive check already done for helm commands */
  fnotify( enactor,
"%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s[Helm Status]%s~~~~~%s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE,
ANSI_NORMAL);
  fnotify( enactor, "%s     Allocations                           Power%s",
ANSI_CYAN, ANSI_NORMAL);
  fnotify(
enactor,"%s--------------------------------------------------------------------%s",
ANSI_WHITE, ANSI_NORMAL ); 

  /* energy info */
  fnotify( enactor, "%s          Total power: %s%25d%s", ANSI_CYAN,
ANSI_WHITE, ship->alloc_helm, ANSI_NORMAL );

  fnotify( enactor, "%s%20ss: %s%25d \n%s%20ss: %s%25d%s",
           ANSI_CYAN, ship->phaser_string, ANSI_WHITE,
ship->halloc_phasers, ANSI_CYAN, ship->photon_string, ANSI_WHITE,
ship->halloc_photons, ANSI_NORMAL );

   fnotify( enactor, "%s         Tractor beam: %s%25d%s",
           ANSI_CYAN, ANSI_WHITE, ship->halloc_tractor, ANSI_NORMAL );
  fnotify(
enactor,"%s--------------------------------------------------------------------%s",
ANSI_WHITE, ANSI_NORMAL ); 
  fnotify( enactor, "%s   Weapon                             Status              Power%s", ANSI_CYAN, ANSI_NORMAL);
 fnotify(
enactor,"%s--------------------------------------------------------------------%s",
ANSI_WHITE, ANSI_NORMAL ); 
  /* display individual weapon stats */
     /* print a phaser */
     for( i = 0; (i < ship->number_of_phasers); i++ )
     {
       switch( ship->phaser[i].status )
       {
        case PHASER_ONLINE:
          if( ship->phaser[i].charge == ship->phaser[i].power )
            fnotify( enactor, "%s%15s %d%s:%s%s           On-Line        Fully Charged", ANSI_CYAN, ship->phaser_string, i+1,
ship->phaser[i].label[0] ? ship->phaser[i].label : "", ANSI_HILITE,
ANSI_RED, ship->phaser[i].charge, ship->phaser[i].power, ANSI_NORMAL );

          else
            fnotify( enactor, "%s%15s %d%s:%s%s           On-Line %12d of %d%s", ANSI_CYAN,
                ship->phaser_string, i+1,
                ship->phaser[i].label[0] ? ship->phaser[i].label : "",
                ANSI_HILITE, ANSI_RED, ship->phaser[i].charge,
                ship->phaser[i].power, ANSI_NORMAL );
          break;
        case PHASER_OFFLINE:
          fnotify( enactor, "%s%15s %d%s:%s%s           Off-Line %11d of %d%s", ANSI_CYAN,
              ship->phaser_string, i+1,
              ship->phaser[i].label[0] ? ship->phaser[i].label : "",
              ANSI_HILITE, ANSI_GREEN, ship->phaser[i].charge,
              ship->phaser[i].power, ANSI_NORMAL );
          break;
        case PHASER_DAMAGED:
          fnotify( enactor, "%s%15s %d%s:%s%s           Damaged %12d of %d)%s", ANSI_CYAN,
                  ship->phaser_string, i+1,
                  ship->phaser[i].label[0] ? ship->phaser[i].label : "",
                  ANSI_HILITE, ANSI_MAGENTA, ship->phaser[i].charge,
                  ship->phaser[i].power, ANSI_NORMAL );
          break;
        }
    }

    /* print a photon */
    for( i = 0; (i < ship->number_of_photons); i++ ) {
      switch( ship->photon[i].status ) {
        case PHOTON_EMPTY:
          if( i == ship->reloading_tube )
            fnotify( enactor, "%s              Tube %d%6s: %s%s          Reloading (%is)%s", ANSI_CYAN, i+1,
                 ship->photon[i].label[0] ? ship->photon[i].label : "",
		     ANSI_HILITE, ANSI_MAGENTA,
                 ship->turns_to_reload*6 - tcount + (tcount==0 ? 0 : 6), ANSI_NORMAL ); 
          else
            fnotify( enactor, "%s              Tube %d%6s: %s%s          Empty%s", ANSI_CYAN, i+1, 
                 ship->photon[i].label[0] ? ship->photon[i].label : "",
                     ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
          break;
        case PHOTON_LOADED:
          fnotify( enactor, "%s              Tube %d%6s: %s%s          Loaded%s", ANSI_CYAN, i+1,
              ship->photon[i].label[0] ? ship->photon[i].label : "",
              ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
          break;
        case PHOTON_ONLINE:
          fnotify( enactor, "%s              Tube %d%6s: %s%s          Charging %10d of %d (%is)%s", ANSI_CYAN, i+1,
               ship->photon[i].label[0] ? ship->photon[i].label : "",
               ANSI_HILITE, ANSI_MAGENTA,
               ship->photon[i].charge, ( ship->photon[i].power / 2 ),
		   (ship->torp_max_num_turns_online - ship->photon[i].turns_charged)*6
		    - tcount + (tcount == 0 ? 0 : 6), ANSI_NORMAL);
          break;
        case PHOTON_ARMED:
          fnotify( enactor, "%s              Tube %d%6s: %s%s          Armed (%is)%s", ANSI_CYAN, i+1,
               ship->photon[i].label[0] ? ship->photon[i].label : "",
               ANSI_HILITE, ANSI_GREEN,
		   (ship->torp_max_num_turns_online - ship->photon[i].turns_charged)*6
		    - tcount + (tcount == 0 ? 0 : 6), ANSI_NORMAL);
          break;
        case PHOTON_DAMAGED:
          fnotify( enactor, "%s                    Tube %d: %s%s          Damaged%s",ANSI_CYAN,  i+1,
                   ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
          break;
      }
    }

   fnotify( enactor, "%s--------------------------------------------------------------------%s", ANSI_WHITE, ANSI_NORMAL );

    if( ship->torps_remaining > 0 && ship->torp_capacity > 0 )
    {
        fnotify( enactor, "%s%ss remaining:%s%s %d of %d (%d%%)%s",
            ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_GREEN,
            ship->torps_remaining, ship->torp_capacity,
            100 * ship->torps_remaining / ship->torp_capacity, ANSI_NORMAL );
    }
    if( ship->number_of_photons )
    {
        if( ship->auto_online )
        {
            fnotify( enactor, "%s%s charging controls: %s%sAutomatic%s",
                ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        }
        else
        {
            fnotify( enactor, "%s%s charging controls: %s%sManual%s",
                ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        }
        if( ship->auto_reload )
        {
            fnotify( enactor, "%s%s reloading controls: %s%sAutomatic%s",
                ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        }
        else
        {
            fnotify( enactor, "%s%s reloading controls: %s%sManual%s",
                ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        }
    }
    /* weapon lock status */
    if( ship->damage[SYSTEM_TARGETTING].status == '9'
    || ship->damage[SYSTEM_TARGETTING].status == '8'
    || ship->damage[SYSTEM_TARGETTING].status == '7' )
    {
        fnotify( enactor, "%s%sWeapons targetting inoperative.%s",
            ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
    }
    else if( ship->locked_target!=NULL )
    {
        fnotify( enactor, "%sWeapons: %s%sLocked on contact [%s%d%s]:%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_MAGENTA,
            ship->locked_target->contact_number, ANSI_RED, ANSI_NORMAL);
        contact_string( writebuf, ship->locked_target, INFO_VERBOSE );
        notify( enactor, writebuf );
    }
    else if( ship->pending_lock!=NULL )
    {
        fnotify( enactor, "%sWeapons: %s%sLock pending on contact [%s%d%s]:%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_MAGENTA,
            ship->pending_lock->contact_number, ANSI_RED, ANSI_NORMAL);
        contact_string( writebuf, ship->pending_lock, INFO_VERBOSE );
        notify( enactor, writebuf );
    }
    else
    {
        fnotify( enactor, "%sWeapons: %s%sUnlocked%s", ANSI_CYAN, ANSI_HILITE,
            ANSI_GREEN, ANSI_NORMAL );
    }
    if( ship->target_system!=SYSTEM_HULL )
    {
        fnotify( enactor, "%sWeapons currently targetting: %s%s%s%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_GREEN, system_names[ship->target_system], ANSI_NORMAL );
    }
    if( ship->tractor_range )
    {
        if( ship->tractor_target!=NULL )
        {
            fnotify( enactor, "%sTractor beam: %s%sLocked on contact [%s%d%s]:%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_MAGENTA,
                ship->tractor_target->contact_number, ANSI_RED, ANSI_NORMAL);
            contact_string( writebuf, ship->tractor_target, INFO_VERBOSE );
            notify( enactor, writebuf );
        }
        else
        {
            fnotify( enactor, "%sTractor beam: %s%sDisengaged%s", ANSI_CYAN, ANSI_HILITE,
                ANSI_GREEN, ANSI_NORMAL );
        }
        fnotify( enactor, "%sTractor beam operating in %s%s%s%s%s mode.%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_GREEN, get_tractor_mode( ship ), ANSI_NORMAL,
            ANSI_CYAN, ANSI_NORMAL );
    }
    if( ship->damage[SYSTEM_SENSORS].status > '6' )
    {
        fnotify( enactor, "%s%sPassive sensors damaged.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    if( ship->damage[SYSTEM_SCANNERS].status > '6' )
    {
        fnotify( enactor, "%s%sActive scanners damaged.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
  fnotify( enactor,
"%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",
ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);
    /* and the customary CRLF */
    notify( enactor, "" );
    return;
}


void scan_ship( SHIP *ship, dbref enactor, char *target_string, int action )
{
    int target_number;
    CONTACT *contact;
    CONTACT *target = NULL;
    dbref helmsman;
    char description[120];
    int target_shield[4], warp, i;
    char *s[4];
    char *upstring=(char *)"UP  ", *downstring=(char *)"DOWN";
    XYZ difference;
    SPH sph_rel;
    float target_hull;
    static char *shield_strings[]=
    {
        (char *)"fore", 
        (char *)"aft", 
        (char *)"port", 
        (char *)"starboard"
    };

    /* now check for scanner damage */
    /* but only if it's a scan.  We can report without scanners */
    if( ship->damage[SYSTEM_SCANNERS].status > '6' && action==SS_SCAN )
    {
        fnotify( enactor, "%s%sScanners are damaged and inoperable.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ( target=match_contact(ship,target_string) )==NULL )
    {
        fnotify( enactor, "%s%sNo contact with any ship called '%s%s%s%s%s'.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL, ANSI_CYAN, target_string, ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return;
    }
    /* alright.   We've got a valid ship on our scanners. */
    /* if this is just a report, do it instead of scanning */
    if( action == SS_REPORT )
    {
        display_sensor_info( ship, target, enactor, DSD_ROUTINE );
        return;
    }
    /* make sure they're in range */
    if( distance(ship->pos,target->listref->pos) > ship->scanner_range )
    {
        fnotify( enactor, "%s%sThat ship is out of scanner range.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
    if( target->listref->flags[DEADMAN] )
    {
        fnotify( enactor, "%s%sThat ship is deadmanned. Unable to scan.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* raise our information_level on this ship */
    if( target->listref->cloak_status == CLOAK_ON )
    {
        if( target->info_level < 5 )
             target->info_level = 4;
    }
    else
    {
        target->info_level = 5;
    }
    /* OK lets go ahead and scan them */
    contact_string( description, target, INFO_VERBOSE );

    fnotify( enactor, "%sScanning [%s%s%d%s%s]: %s%s", ANSI_CYAN, ANSI_HILITE,
        ANSI_MAGENTA, target->contact_number, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, 
        description );

    /* compute the relative position of the target */
    difference.x = target->listref->pos.x - ship->pos.x;
    difference.y = target->listref->pos.y - ship->pos.y;
    difference.z = target->listref->pos.z - ship->pos.z;
    sph_rel = xyz_to_sph( difference );

    /* load the target data */
    for( i = 0; i < 4; i++ )
    {
        target_shield[i] = target->listref->shield_level[i];
    }
    warp = target->listref->nalloc_warp;
    target_hull = (float)target->listref->current_integrity / (float)target->listref->hull_integrity;

    /* mangle the target data */
    for( i = 0; i < 4; i++ )
    {
        target_shield[i] += ( 10 - (( target_shield[i] + 10 ) % 20 ));
    }
    /* print the target data */
    if( target->listref->cloak_status != CLOAK_ON )
    {
        if( strlen( fetch_attribute( target->listref->ship_object, "DESC" )))
            notify( enactor, fetch_attribute( target->listref->ship_object, "DESC" ));
    }
    fnotify( enactor, "   Target bearing %s%s%3.0f%+2.0f%s at range %s%s%1.0f%s",
        ANSI_HILITE, ANSI_CYAN, sph_rel.bearing, sph_rel.elevation, ANSI_NORMAL,
        ANSI_HILITE, ANSI_CYAN, sph_rel.range, ANSI_NORMAL );
    fnotify( enactor, "   Target heading %s%s%3.0f%+2.0f%s at warp %s%s%3.3f%s",
        ANSI_HILITE, ANSI_CYAN, target->listref->motion.bearing, target->listref->motion.elevation,
        ANSI_NORMAL, ANSI_HILITE, ANSI_CYAN, target->listref->warp_speed, ANSI_NORMAL );
    fnotify( enactor, "   Our %s%s%s%s side is facing their %s%s%s%s side.\n",
        ANSI_HILITE, ANSI_MAGENTA, shield_strings[facing_shield( target->listref, ship )], ANSI_NORMAL,
        ANSI_HILITE, ANSI_MAGENTA, shield_strings[facing_shield( ship, target->listref )], ANSI_NORMAL );

    /* weapons status */
    fnotify( enactor, "%sWeapons:%s", ANSI_CYAN, ANSI_NORMAL );
    fnotify( enactor, "    %s%s%d %ss%s on line  --  energy allocated %s%d%s",
        ANSI_HILITE, ANSI_RED, target->listref->num_phasers_online, target->listref->phaser_string,
        ANSI_NORMAL, ANSI_MAGENTA, target->listref->halloc_phasers, ANSI_NORMAL );
    fnotify( enactor, "    %s%s%d %ss%s on line  --  energy allocated %s%d%s\n",
        ANSI_HILITE, ANSI_RED, target->listref->num_photons_online, target->listref->photon_string,
        ANSI_NORMAL, ANSI_MAGENTA, target->listref->halloc_photons, ANSI_NORMAL );

    /* shield status */
    /* no shield status if cloaked */
    if( target->listref->cloak_status == CLOAK_ON )
    {
        fnotify( enactor, "%sCloak: %s%sEngaged\n%s", ANSI_CYAN, ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL); 
    }
    else
    {
        if( target->listref->cloak_status == CLOAK_OFF )
        {
            fnotify( enactor, "%sCloak: %s%sDisengaged\n%s", ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
        }
        else
        {
            fnotify( enactor, "%sCloak: %s%sNot Present\n%s", ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
        }
        switch( target->listref->cloak_status  )
        {
            case CLOAK_ON: 
                break;
            default:
            for( i = 0; i < 4; i++ )
                s[i] = ( target->listref->shield_status[i] == SHLD_UP ) ? upstring : downstring;

            fnotify( enactor, "%sShields:%s\n%sFore:  %s%d:%s%s  Aft: %s%d:%s%s Port: %s%d:%s%s  Starboard:  %s%d:%s%s",
                ANSI_CYAN, ANSI_NORMAL, ANSI_CYAN, ANSI_MAGENTA, target_shield[0], s[0],
                ANSI_CYAN, ANSI_MAGENTA, target_shield[1], s[1],
                ANSI_CYAN, ANSI_MAGENTA, target_shield[2], s[2],
                ANSI_CYAN, ANSI_MAGENTA, target_shield[3], s[3], ANSI_NORMAL );
            break;
        }
    }
    fnotify( enactor, "%sHull integrity:  %s%3.0f%%%s     power to warp: %s%d%s",
        ANSI_CYAN, ANSI_MAGENTA, target_hull * 100.0, ANSI_CYAN, ANSI_MAGENTA,
        warp, ANSI_NORMAL );
    notify( enactor, "" ); /* don't forget that traditional last line */

    /* let them know they are being scanned.  First find their helmsman */
    helmsman = match_result(HOWIE, my_atr_get_raw(target->listref->helm, "XB"), NOTYPE, MAT_ABSOLUTE);

    /* search to see if target has sensor contact with scanner */
    for(contact=target->listref->contact_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref == ship )
        {
            /* okay, they've got us.  tell them who's doing it */
            contact_string( description, contact, INFO_VERBOSE );
            fnotify( helmsman, "%sWe are being scanned by contact [%s%s%d%s%s]: %s%s%s.%s",
                ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, contact->contact_number, ANSI_NORMAL,
                ANSI_CYAN, ANSI_NORMAL, description, ANSI_CYAN, ANSI_NORMAL );
            /* we don't need contact anymore.  Go home */
            return;
        }
    }
    /* mystery ship scanning... */
    fnotify( helmsman, "%sWe are being scanned from an unknown source.%s",
        ANSI_CYAN, ANSI_NORMAL );
    return;
}


/*  auto_online allows the ship computer to automatically bring *
 *  photons on line to be armed when they are reloaded.         */

void toggle_auto_online( SHIP * ship, dbref enactor )
{
  /* inactive check already done for helm commands */

  int i;

  ship->auto_online = !ship->auto_online;

  if( ship->auto_online ) {
    fnotify( enactor, "%s%s charging controls set to: %s%sAutomatic%s",
           ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    for( i = 0; i < ship->number_of_photons; i++ ) {
      if( ship->photon[i].status == PHOTON_LOADED ) {
        fnotify( enactor, "%s%sBringing %s tube %d on line:%s", ANSI_HILITE, ANSI_GREEN,
               ship->photon_string, i, ANSI_NORMAL );
        photon_online( ship, enactor, i );
      }
    }
  }
  else
    fnotify( enactor, "%s%s charging controls set to: %s%sManual%s",
           ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );

  return;
}


void toggle_auto_reload( SHIP *ship, dbref enactor )
{
  /* inactive check already done for helm commands */

  int i;

  ship->auto_reload = !ship->auto_reload;

  if( ship->auto_reload ) {
    fnotify( enactor, "%s%s reloading controls set to: %s%sAutomatic%s",
           ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    for( i = 0; i < ship->number_of_photons; i++ ) {
      if( ship->photon[i].status == PHOTON_EMPTY ) {
  reload_photon( ship, enactor, i );
  i = ship->number_of_photons;
      }
    }
  }
  else
    fnotify( enactor, "%s%s reloading controls set to: %s%sManual%s",
            ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_RED, ANSI_NORMAL );

  return;
}


void phaser_online( SHIP *ship, dbref enactor, int bank )
{
    int i;

    if( bank == ARM_ALL )
    {
        for( i = 0; i < ship->number_of_phasers; i++ )
        {
            if( ship->phaser[i].status==PHASER_OFFLINE )
                phaser_online( ship, enactor, i );
        }
        return;
    }
    /* valid bank check */
    if( bank < 0 || bank >= ship->number_of_phasers )
    {
        fnotify( enactor, "%s%sInvalid %s number.%s", ANSI_HILITE, ANSI_RED,
            ship->phaser_string, ANSI_NORMAL );
        return;
    }
    switch( ship->phaser[bank].status )
    {
        case PHASER_OFFLINE:
            sprintf( writebuf, "%s%s %d set on line.%s", ANSI_CYAN, ship->phaser_string,
                bank+1, ANSI_NORMAL );
            ship->phaser[bank].status = PHASER_ONLINE;
            ship->num_phasers_online++;
            if( ship->smart_alloc==2 )
            {
                requisition_power( ship, POWER_HELM_GUNS, ship->phaser[bank].charge_per_turn );
            }
            break;
        case PHASER_ONLINE:
            sprintf( writebuf, "%s%s %d already on line.%s", ANSI_MAGENTA, ship->phaser_string,
                bank+1, ANSI_NORMAL );
            break;
        case PHASER_DAMAGED:
            sprintf( writebuf, "%s%s%s %d damaged.%s", ANSI_HILITE, ANSI_RED, 
                ship->phaser_string, bank+1, ANSI_NORMAL );
            break;
        default:
            writebuf[0] = '\0';
            break;
    }
    notify( enactor, writebuf );
    return;
}


void phaser_offline( SHIP *ship, dbref enactor, int bank )
{
    int max,i;

    if( bank == ARM_ALL )
    {
        for( i = 0; i < ship->number_of_phasers; i++ )
        {
            if( ship->phaser[i].status == PHASER_ONLINE )
                phaser_offline( ship, enactor, i );
        }
        return;
    }
    if( bank < 0 || bank >= ship->number_of_phasers )
    {
        fnotify( enactor, "%s%sInvalid %s number.%s", ANSI_HILITE, ANSI_RED, 
            ship->phaser_string, ANSI_NORMAL );
        return;
    }
    switch( ship->phaser[bank].status )
    {
        case PHASER_ONLINE:
            sprintf( writebuf, "%s%s %d set off line.%s", ANSI_CYAN, ship->phaser_string,
                bank+1, ANSI_NORMAL );
            ship->phaser[bank].status = PHASER_OFFLINE;
            ship->num_phasers_online--;
            if( ship->smart_alloc==2 )
            {
                max = atoi( my_atr_get_raw(ship->ship_object,"VO") );
                if( ship->halloc_phasers > ship->num_phasers_online * max )
                {
                    free_power( ship, POWER_HELM_GUNS, ship->alloc_helm - (max*ship->num_phasers_online) );
                }
            }
            break;
        case PHASER_OFFLINE:
            sprintf( writebuf, "%s%s %d already off line.%s", ANSI_MAGENTA, ship->phaser_string,
                bank+1, ANSI_NORMAL );
            break;
        case PHASER_DAMAGED:
            sprintf( writebuf, "%s%s%s %d damaged.%s", ANSI_HILITE, ANSI_RED,
                ship->phaser_string, bank+1, ANSI_NORMAL );
            break;
        default:
            writebuf[0] = '\0';
            break;
    }
    notify( enactor, writebuf );
    return;
}


void photon_online( SHIP *ship, dbref enactor, int tube )
{
    int i;

    if( tube == ARM_ALL )
    {
        for( i = 0; i < ship->number_of_photons; i++ )
        {
            if( ship->photon[i].status == PHOTON_LOADED )
                photon_online( ship, enactor, i );
        }
        return;
    }
    /* valid tube check */
    if( tube < 0 || tube >= ship->number_of_photons )
    {
        fnotify( enactor, "%s%sInvalid tube number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    switch( ship->photon[tube].status )
    {
        case PHOTON_EMPTY:
            fnotify( enactor, "%s%s%s must be loaded before it can be armed.%s", ANSI_HILITE,
                ANSI_RED, ship->photon_string, ANSI_NORMAL );
            return;
        case PHOTON_LOADED:
            fnotify( enactor, "%sCharging.%s", ANSI_CYAN, ANSI_NORMAL );
            ship->num_photons_online++;
            ship->photon[tube].status = PHOTON_ONLINE;
            if( ship->smart_alloc==2 )
            {
                requisition_power( ship, POWER_HELM_TORPS, ship->photon[tube].charge_per_turn );
            }
            return;
        case PHOTON_ONLINE:
            fnotify( enactor, "%sAlready charging.%s", ANSI_MAGENTA, ANSI_NORMAL );
            return;
        case PHOTON_ARMED:
            fnotify( enactor, "%sAlready armed.%s", ANSI_MAGENTA, ANSI_NORMAL );
            return;
        case PHOTON_DAMAGED:
            fnotify( enactor, "%s%s%s damaged and cannot be charged.%s", ANSI_HILITE, ANSI_RED,
                ship->photon_string, ANSI_NORMAL );
            return;
    }
    return;
}


/*
 * photon_offline() takes a photon that is charging and JFREEs that
 * energy for other photons
 */

void photon_offline( SHIP *ship, dbref enactor, int tube )
{
    int i;

    if( tube==ARM_ALL )
    {
        for(i=0;i<ship->number_of_photons;i++)
        {
            if( ship->photon[i].status==PHOTON_ONLINE
            || ship->photon[i].status==PHOTON_ARMED )
                photon_offline( ship, enactor, i );
        }
        return;
    }
    if( tube < 0 || tube >= ship->number_of_photons )
    {
        fnotify( enactor, "%s%sInvalid tube number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    switch( ship->photon[tube].status )
    {
        case PHOTON_ONLINE:
            ship->num_photons_online--;
            if( ship->smart_alloc==2 )
            {
                if( ship->halloc_photons > ship->num_photons_online * ship->photon[tube].charge_per_turn )
                {
                    free_power( ship, POWER_HELM_TORPS, ship->alloc_helm - (ship->photon[tube].charge_per_turn*ship->num_phasers_online) );
                }
            }
           fnotify( enactor, "%sTaken off line.%s", ANSI_CYAN, ANSI_NORMAL );
           ship->photon[tube].status = PHOTON_LOADED;
           ship->photon[tube].charge = 0;
           ship->photon[tube].turns_charged = 0;
           return;
       default:
           fnotify( enactor, "%s%s not on line.%s", ANSI_MAGENTA, ship->photon_string,
               ANSI_NORMAL );
           return;
    }
    return;
}


/* fire_photon is self-explanatory. it uses the combat_damage() *
 * function to deliver damage from hits                         */
int fire_photon( SHIP *ship, dbref enactor, int tube, int control )
{
    dbref helmsman;
    char shooter_string[120], target_string[120];
    CONTACT *contact,*shooter,*target;
    int i,hit,hits=0,count=0,detted=0;
    SHIP *observer,*detter;
    float roll,prob,range;
    WDATA weapon;
    SPH point;

    if( ship->locked_target == NULL )
    {
        fnotify( enactor, "%s%sWeapons must be locked in order to fire.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return( -1 );
    }
    /* make sure we're not set pacifist */
    if( ship->flags[PACIFIST] )
    {
        fnotify( enactor, "%s%sWeapons inoperable.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
    if( ship->locked_target->listref->flags[DEADMAN] )
    {
        fnotify( enactor, "%s%sTargeted ship is deadmanned. Unable to fire.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    if( ship_is_safe(ship->locked_target->listref) )
    {
        fnotify( enactor, "%s%sTargeted ship is safe. Unable to fire.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    /* for purposes of logging, get the names ahead of time.  If we wait
     * until after the shots, and one of the torps kills the target, the
     * ship will have no locked target and we'll get a segmentation fault.
     */
    strcpy( shooter_string, Name(ship->ship_object));
    strcpy( target_string, Name(ship->locked_target->listref->ship_object));
    range = distance( ship->pos, ship->locked_target->listref->pos );
    if( current_space == REAL )
    {
        log_position( ship );
        log_position( ship->locked_target->listref );
    }
    /* check for fire all tubes */
    if( tube == FIRE_ALL )
    {
        fnotify( enactor, "%sFiring all available %ss.%s", ANSI_CYAN, 
            ship->photon_string, ANSI_NORMAL );
        for( i = 0; i < ship->number_of_photons; i++ )
        {
            if( ship->photon[i].status == PHOTON_ARMED )
            {
                hits += fire_photon( ship, enactor, i, control++ );
                count++;
            }
        }
        /* if in real space, log it */
        if( current_space == REAL )
        {
            log_space( "%s hits %s with %d of %d photons from %2.0f.\n",
                shooter_string, target_string, hits, count, range );
        }
        return 0;
    }
    /* valid tube check */
    if( ( tube < 0 ) || ( tube >= ship->number_of_photons ) )
    {
        fnotify( enactor, "%s%sInvalid tube number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return -1;
    }
    if( !in_arc(ship->photon[tube].wpn_arc,facing_vector(ship,ship->locked_target->listref->pos)) )
    {
        point.bearing = ship->motion.bearing + ship->photon[tube].wpn_arc.center.bearing;
        point.elevation = ship->motion.elevation + ship->photon[tube].wpn_arc.center.elevation;
        point.range = 1.0;
        point = fix_sph_coord( point );
        fnotify( enactor, "%s%s%s %d can only fire at targets within %.0f%+.0f of %.0f%+.0f.%s",
            ANSI_HILITE, ANSI_RED, ship->photon_string, tube+1,
            ship->photon[tube].wpn_arc.htraverse, ship->photon[tube].wpn_arc.vtraverse,
            point.bearing, point.elevation,
            ANSI_NORMAL );    
        return -1;
    }
    if( ship->photon[tube].status != PHOTON_ARMED )
    {
        fnotify( enactor, "%s%sA %s must be armed before firing.%s", ANSI_HILITE, ANSI_RED,
            ship->photon_string, ANSI_NORMAL );
        return -1;
    }
    if( ship->torps_remaining > 0 )
    {
        ship->torps_remaining--;
        write_damage( ship );
    }
    /* bombs away! Compute the probability of a hit */
    /* the base_accuracy factor is a y-intercept adjustor. */
    ship->battle_timer = TIMER_RESET;
    ship->locked_target->listref->battle_timer = TIMER_RESET;
    prob = (1.0 - ( range /
        ( ship->photon[tube].range * ship->locked_target->listref->size ) ) )
        * ship->photon[tube].base_accuracy;
    if( ship->tractor_target==ship->locked_target )
    {
        prob *= 1.5;
    }
    if( ship->locked_target->listref->tractor_target!=NULL
    && ship->locked_target->listref->tractor_target->listref==ship
    && ship->locked_target->listref->tractor_mode==MODE_TRACTOR )
    {
        prob = 1.0;
    }
    if( ship->locked_target->listref->warp_speed==0.0 && ship->warp_speed==0.0
    && prob < 1.0 && range<=ship->photon[tube].range && ship->photon[tube].base_accuracy>=1.0 )
    {
        prob = 1.0;
    }
    if( ship->locked_target->listref->tractor_target!=NULL
    && ship->locked_target->listref->tractor_target->listref==ship
    && ship->locked_target->listref->tractor_mode==MODE_PRESSOR )
    {
        prob *= 0.75;
    }
    /* notify shooter and target of shot */
    fnotify( enactor, "%s%s %d launched.%s", ANSI_CYAN, ship->photon_string, tube+1, ANSI_NORMAL );

    /* Well gee, let's tell them about it. */
    if( ( shooter=find_contact(ship->locked_target->listref,ship) )==NULL )
    {
        /* AMAZING.  They can't see us even though we are locked on them. */
        sprintf( writebuf, "%s%sIncoming photon fired from unknown source!%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    else
    {
        /* Tell them who is shooting at them. */
        contact_string( shooter_string, shooter, INFO_TERSE );
        sprintf( writebuf, "%s%sIncoming %s from [%s%d%s]: %s%s", ANSI_HILITE, ANSI_RED,
            shooter->listref->photon_string, ANSI_MAGENTA, shooter->contact_number, 
            ANSI_RED, ANSI_NORMAL, shooter_string );
    }
    notify_room(BRIDGE(ship->locked_target->listref), writebuf);

    /* Hey, I got an idea, let's tell everyone else too! */
    observer = space_list[current_space];
    /* ***********
     * SPAM ALERT!  -- Don't tell them unless this is the first shot of a volley
     *************/
    if( control==INFO_VERBOSE )
    {
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if(( observer == ship ) || ( observer == ship->locked_target->listref ))
            {
                continue;
            }
            target = find_contact(observer,ship->locked_target->listref);
            shooter = find_contact(observer,ship);

            /* find observer helmsman's dbref */
            helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);

            /* OK we got 4 cases here */
            if(( shooter == NULL ) && ( target == NULL ))
            {
                /* do nothing */
            }
            else if( shooter == NULL )
            {
                /* only saw the target */
                contact_string( target_string, target, INFO_TERSE );

                fnotify( helmsman, "%sUnknown source fired %ss upon contact [%s%s%d%s%s]: %s%s",
                    ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_MAGENTA, target->contact_number,
                    ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, target_string );
            }
            else if( target == NULL )
            {
                /* only saw the shooter */
                contact_string( shooter_string, shooter, INFO_TERSE );
                fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s fired %ss upon unknown target.%s",
                    ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, shooter->contact_number, ANSI_NORMAL,
                    ANSI_CYAN, ANSI_NORMAL, shooter_string, ANSI_CYAN, ship->photon_string, ANSI_NORMAL );
            }
            else
            {
                /* saw both the shooter and the target */
               contact_string( shooter_string, shooter, INFO_TERSE );
               contact_string( target_string, target, INFO_TERSE );

               fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s fired %ss upon contact [%s%s%d%s%s]: %s%s",
                   ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, shooter->contact_number, ANSI_NORMAL,
                   ANSI_CYAN, ANSI_NORMAL, shooter_string, ANSI_CYAN, ship->photon_string, ANSI_HILITE, ANSI_MAGENTA,
                   target->contact_number, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, target_string );
            }
        }
    }
    /* OK everyone has seen this shot go off.  Let's see if it hit! */
    for(detter=space_list[current_space];detter!=NULL;detter=detter->next)
    {
        if( detter->tractor_target!=NULL && detter->tractor_target->listref==ship
        && detter->tractor_mode==MODE_DET )
        {
            detted=1;
            break;
        }
    }
    roll = FRAND;
    weapon = ship->photon[tube].wpn_data;
    if( FRAND > ship->photon[tube].reliability )
    {
        fnotify( enactor, "%s%s%s misfires.%s",ANSI_HILITE,ANSI_RED,ship->photon_string,ANSI_NORMAL);
        sprintf( writebuf, "%s%s%s misfires.%s", ANSI_HILITE, ANSI_GREEN, ship->photon_string,
            ANSI_NORMAL );
        notify_room(BRIDGE(ship->locked_target->listref), writebuf );
        hit = 0;
    }
    else if( detted )
    {
        target = find_contact( ship, detter );
        if( target==NULL )
        {
            fnotify( enactor, "%s%s%s detonated by unknown source!%s", ANSI_HILITE,
                ANSI_YELLOW, ship->photon_string, ANSI_NORMAL );
        }
        else
        {
            contact_string( target_string, target, INFO_TERSE );
            fnotify( enactor, "%s%s%s detonated by contact [%s%d%s]: %s%s%s!%s",
                ANSI_HILITE, ANSI_YELLOW, ship->photon_string, ANSI_MAGENTA,
                target->contact_number, ANSI_YELLOW, ANSI_CYAN,
                target_string, ANSI_YELLOW, ANSI_NORMAL );
        }
        if( ship->locked_target->listref!=detter )
        {
            target = find_contact( ship->locked_target->listref, detter );
            if( target==NULL )
            {
                sprintf( writebuf, "%s%s%s detonated by unknown source!%s", ANSI_HILITE,
                    ANSI_YELLOW, ship->photon_string, ANSI_NORMAL );
            }
            else
            {
                contact_string( target_string, target, INFO_TERSE );
                sprintf( writebuf, "%s%s%s detonated by contact [%s%d%s]: %s%s%s!%s",
                    ANSI_HILITE, ANSI_YELLOW, ship->photon_string, ANSI_MAGENTA,
                    target->contact_number, ANSI_YELLOW, ANSI_CYAN,
                    target_string, ANSI_YELLOW, ANSI_NORMAL );
            }
            notify_room( BRIDGE(ship->locked_target->listref), writebuf );
        }
        target = find_contact( detter, ship );
        if( target==NULL )
        {
            sprintf(writebuf,"%s%sDetonated %s from unknown source!%s",
                ANSI_HILITE, ANSI_RED, ship->photon_string, ANSI_NORMAL );
        }
        else
        {
            contact_string( target_string, target, INFO_TERSE );        
            sprintf(writebuf,"%s%sDetonated %s from contact [%s%d%s]: %s%s%s!%s",
                ANSI_HILITE, ANSI_RED, ship->photon_string, ANSI_MAGENTA, target->contact_number,
                ANSI_RED, ANSI_CYAN, target_string, ANSI_YELLOW, ANSI_NORMAL );
        }
        notify_room( BRIDGE(detter), writebuf );
        battle_damage( ship, detter, ship->photon[tube].power/4, weapon );
        hit = 1;
    }
    else if( roll < prob && ship->locked_target!=NULL )
    {
        /* All right, a hit.  Notify us */
        fnotify( enactor, "%s%s%s hit!%s", ANSI_HILITE, ANSI_GREEN, ship->photon_string,
            ANSI_NORMAL );
        hit = 1;
        /* Notify them too. */
        sprintf( writebuf, "%s%s%s hit!%s", ANSI_HILITE, ANSI_RED, ship->photon_string,
            ANSI_NORMAL );
        notify_room(BRIDGE(ship->locked_target->listref), writebuf );
        battle_damage( ship, ship->locked_target->listref, 
            ship->photon[tube].power, weapon );
    }
    else
    {
        /* missed.  Notify us */
        fnotify( enactor, "%s%s%s missed.%s", ANSI_HILITE, ANSI_RED, ship->photon_string,
            ANSI_NORMAL );

        hit = 0;

        /* Notify them too. */
        sprintf( writebuf, "%s%s%s missed.%s", ANSI_HILITE, ANSI_GREEN, ship->photon_string,
            ANSI_NORMAL );
        notify_room(BRIDGE(ship->locked_target->listref), writebuf );
    }
    ship->photon[tube].status = PHOTON_EMPTY;
    ship->photon[tube].charge = 0;
    ship->photon[tube].turns_charged = 0;
    /* if there's no other tube reloading and the autoload is set, reload */
    if( ship->reloading_tube==NO_RELOAD && ship->auto_reload )
    {
        reload_photon( ship, enactor, tube );
    }
    return( hit );
}

/*
 * fire_phaser is self-explanatory
 * it uses the combat_damage() function to deliver damage from hits
 */

/*
 * DJB ?? Jul 92
 * JMS 25 May 93 - Don't log shots at invincible ships
 * JMS 25 May 93 - Cleanup
 */

void fire_phaser( SHIP *ship, dbref enactor, int bank, int control, CONTACT *shootee )
{
    char shooter_string[120], target_string[120];
    int i, damage, effective_max_range;
    CONTACT *contact,*shooter,*target;
    float damage_coeff;
    SHIP *observer;
    dbref helmsman;
    WDATA weapon;
    SPH point;

    if( shootee==NULL )
    {
        fnotify( enactor, "%s%sWeapons must be locked in order to fire.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return;
    }
    if( ship->flags[PACIFIST] )
    {
        fnotify( enactor, "%s%sWeapons inoperable.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( shootee->listref->flags[DEADMAN] )
    {
        fnotify( enactor, "%s%sTargeted ship is deadmanned. Unable to fire.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ship_is_safe(shootee->listref) )
    {
        fnotify( enactor, "%s%sTargeted ship is safe. Unable to fire.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* check for fire all banks */
    if( bank == FIRE_ALL && shootee==ship->locked_target )
    {
        fnotify( enactor, "%sFiring all available %ss.%s", ANSI_CYAN, ship->phaser_string,
            ANSI_NORMAL );

        for( i = 0; i < ship->number_of_phasers; i++ )
        {
            if( ship->phaser[i].charge != 0 )
            {
                fire_phaser( ship, enactor, i, control++, ship->locked_target );
            }
        }
        return;
    }
    /* valid bank check */
    if( ( bank < 0 ) || ( bank >= ship->number_of_phasers ) )
    {
        fnotify( enactor, "%s%sInvalid %s number.%s", ANSI_HILITE, ANSI_RED,
            ship->phaser_string, ANSI_NORMAL );
        return;
    }
    if( !in_arc(ship->phaser[bank].wpn_arc,facing_vector(ship,shootee->listref->pos)) )
    {
        point.bearing = ship->motion.bearing + ship->phaser[bank].wpn_arc.center.bearing;
        point.elevation = ship->motion.elevation + ship->phaser[bank].wpn_arc.center.elevation;
        point.range = 1.0;
        point = fix_sph_coord( point );
        fnotify( enactor, "%s%s%s %d can only fire at targets within %.0f%+.0f of %.0f%+.0f.%s",
            ANSI_HILITE, ANSI_RED, ship->phaser_string, bank+1,
            ship->phaser[bank].wpn_arc.htraverse, ship->phaser[bank].wpn_arc.vtraverse,
            point.bearing, point.elevation,
            ANSI_NORMAL );
        return;
    }
    if( ship->phaser[bank].charge<=0 )
    {
        fnotify( enactor, "%s%sA %s must be charged before firing.%s", ANSI_HILITE, ANSI_RED,
            ship->phaser_string, ANSI_NORMAL );
        return;
    }
    effective_max_range = ship->phaser[bank].range * ship->phaser[bank].charge / ship->phaser[bank].power;
    if((int)( distance( ship->pos, shootee->listref->pos ) + 0.5 ) > effective_max_range )
    {
        fnotify( enactor, "%s%sThe max range for %s %i at current charge is %i.%s", ANSI_HILITE,
            ANSI_RED, ship->phaser_string, bank + 1, effective_max_range, ANSI_NORMAL );
        return;
    }
    if( FRAND > ship->phaser[bank].reliability )
    {
        sprintf( writebuf, "%s%sMalfunction and meltdown in %s %d.%s",
            ANSI_HILITE, ANSI_RED, ship->phaser_string, bank, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
        ship->damage[SYSTEM_GUN_0 + bank].status = '9';
        if( ship->phaser[bank].status==PHASER_ONLINE )
        {
            ship->num_phasers_online--;
        }
        ship->phaser[bank].status = PHASER_DAMAGED;
        ship->phaser[bank].charge = 0;
        return;
    }
    /* phasers away! Compute the damage coefficient of a hit.
     * that is, range_percent +- 25% of that
     */
    ship->battle_timer = TIMER_RESET;
    shootee->listref->battle_timer = TIMER_RESET;
    damage_coeff = ship->phaser[bank].range_percent +
        ( FRAND - 0.5 ) * 0.5 * ship->phaser[bank].range_percent;
    /* see if shooter is on the receiver's contact list */
    shooter = NULL;
    contact = shootee->listref->contact_list;
    while( contact != NULL )
    {
        if( contact->listref == ship )
        {
            shooter = contact;
            contact = NULL;
        }
        else
            contact = contact->next;
    }
    /* Well gee, let's tell them about it. */
    if( shooter == NULL )
    {
        sprintf( writebuf, "%s%sEnemy %s fired from XYZ: %.0f %.0f %.0f!%s", ANSI_HILITE,
            ANSI_RED, ship->phaser_string,
            ship->pos.x, ship->pos.y, ship->pos.z, ANSI_NORMAL );
        notify_room(BRIDGE(shootee->listref), writebuf );
    }
    else
    {
        contact_string( shooter_string, shooter, INFO_TERSE );
        sprintf( writebuf, "%s%sEnemy %s fired by [%s%d%s]: %s%s", ANSI_HILITE, ANSI_RED,
            shooter->listref->phaser_string, ANSI_MAGENTA, shooter->contact_number, ANSI_RED,
            ANSI_NORMAL, shooter_string );
        notify_room(BRIDGE(shootee->listref), writebuf);
    }
    if( control == INFO_VERBOSE )
    {
        if( current_space == REAL && !shootee->listref->flags[INVINCIBLE] )
        {
            log_space( "%s fired %ss at %s from %2.0f", ship->name, ship->phaser_string,
                shootee->listref->name,  distance( ship->pos,
                shootee->listref->pos ) );
            log_position( ship );
            log_position( shootee->listref );
        }
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if( observer==ship || observer==shootee->listref )
            {
                continue; /* continue looping */
            }
            target = find_contact( observer, shootee->listref );
            shooter = find_contact( observer, ship );
            /* find observer helmsman's dbref */
            helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
            if( shooter==NULL && target==NULL )
            {
            }
            else if( shooter == NULL )
            {
                contact_string( target_string, target, INFO_TERSE );
                fnotify( helmsman, "%sUnknown source at %.0f %.0f %.0f fired %ss upon contact [%s%s%d%s%s]: %s%s", ANSI_CYAN,
                    ship->pos.x, ship->pos.y, ship->pos.z,
                    ship->phaser_string, ANSI_HILITE, ANSI_MAGENTA, target->contact_number, ANSI_NORMAL,
                    ANSI_CYAN, ANSI_NORMAL, target_string );
            }
            else if( target == NULL )
            {
                contact_string( shooter_string, shooter, INFO_TERSE );
                fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s fired %ss upon XYZ: %.0f %.0f %.0f.%s", ANSI_CYAN,
                    ANSI_HILITE, ANSI_MAGENTA, shooter->contact_number,
                    ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, shooter_string,
                    ANSI_CYAN, ship->phaser_string, shootee->listref->pos.x,
                    shootee->listref->pos.y, 
                    shootee->listref->pos.z, ANSI_NORMAL );
            }
            else
            {
                contact_string( shooter_string, shooter, INFO_TERSE );
                contact_string( target_string, target, INFO_TERSE );
                fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s fired %ss upon contact [%s%s%d%s%s]: %s%s",
                    ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA,
                    shooter->contact_number, ANSI_NORMAL,
                    ANSI_CYAN, ANSI_NORMAL, shooter_string, ANSI_CYAN,
                    ship->phaser_string, ANSI_HILITE, ANSI_MAGENTA,
                    target->contact_number, ANSI_NORMAL, ANSI_CYAN,
                    ANSI_NORMAL, target_string );
            }
        }
    }
    /* OK everyone has seen this shot go off.  Let's see the damage! */
    /* note that the range we use is not the phaser max range.  We adjust
     * that range for a less than full charge and use effective_max_range.
     */
    damage = (int)( (float)( ship->phaser[bank].charge ) *
             ( 1.0 + ( damage_coeff - 1.0 ) *
             distance( ship->pos, shootee->listref->pos ) /
             (float)( effective_max_range )) + 0.5);
    fnotify( enactor, "%s%s%s %d fired.  Hit for %2.0f%% yield.%s", ANSI_HILITE, ANSI_GREEN,
        ship->phaser_string, bank + 1,
        (float)damage / (float)(ship->phaser[bank].charge) * 100.0, ANSI_NORMAL );
    ship->phaser[bank].charge = 0;
    weapon = ship->phaser[bank].wpn_data;
    battle_damage(ship, shootee->listref, damage, weapon );
    return;
}

/*
 * helm_alloc_check() redistributes power when a shortfall occurs.
 * It uses helm_allocate() to reallocate power.
 */

void helm_alloc_check( SHIP *ship )
{
  dbref helmsman;

  /* we don't know the helmsman so find him */
  helmsman = match_result(HOWIE, my_atr_get_raw(ship->helm, "XB"), NOTYPE, MAT_ABSOLUTE);

  if(( ship->halloc_phasers + ship->halloc_photons + ship->halloc_tractor ) > ship->alloc_helm ) {
    fnotify(helmsman, "%sEnergy allocation cut:%s",ANSI_CYAN, ANSI_NORMAL );
    helm_allocate( ship, helmsman, ship->halloc_phasers,
       ship->halloc_photons, ship->halloc_tractor );
  }
  else {
    fnotify( helmsman, "%sEnergy allocation cut.  New allocation is %s%d%s.  No shortfall.%s",
            ANSI_CYAN, ANSI_MAGENTA, ship->alloc_helm, ANSI_CYAN, ANSI_NORMAL );
  }

  return;
}


/*
 * helm_allocate() makes the helm allocations and reallocations.
 */

void helm_allocate(SHIP *ship, dbref enactor, int phasers, int photons, int tractor)
{
    int available_power;
    long total_allocation;
    float power_ratio;

    if( phasers > MAXINT/2 || photons > MAXINT/2 )
    {
        fnotify( enactor, "%s%sExcessive energy can be hazardous to your health.%s",
            ANSI_HILITE, ANSI_BLACK, ANSI_NORMAL); 
        return;
    }

    /* calculate max available power */
    available_power = ship->alloc_helm;

    /* set negative allocations to zero */
    if( phasers < 0 )
        phasers = 0;
    if( photons < 0 )
        photons = 0;
    if( tractor < 0 )
        tractor = 0;

    /* calculate total allocation */
    total_allocation = phasers + photons + tractor;

    /* if allocation > power, apply cuts */
    if( total_allocation > available_power )
    {
        power_ratio = (float)( (float)available_power / (float)total_allocation );
        phasers = (int)( (float)phasers * power_ratio );
        photons = (int)( (float)photons * power_ratio );
        tractor = (int)( (float)tractor * power_ratio );
    }

    /* store these allocations */
    ship->halloc_phasers = phasers;
    ship->halloc_photons = photons;
    ship->halloc_tractor = tractor;

    fnotify( enactor, "%sTotal available power: %s%d\n%sAllocations:%s", ANSI_CYAN,
        ANSI_MAGENTA, ship->alloc_helm, ANSI_CYAN, ANSI_NORMAL );

    fnotify( enactor, "%s    %ss: %s%d%s  %ss: %s%d%s", ANSI_CYAN, ship->phaser_string,
        ANSI_MAGENTA, phasers, ANSI_CYAN, ship->photon_string, ANSI_MAGENTA, photons, ANSI_NORMAL );

    if( tractor!=0 )
    {
        fnotify(enactor,"%s    tractor beam: %s%d%s", ANSI_CYAN, ANSI_MAGENTA,
            tractor, ANSI_NORMAL );
    }
    else if( ship->tractor_target!=NULL )
    {
        drop_tractor( ship, enactor );
    }
    return;
}


void reload_photon(SHIP *ship, dbref enactor, int tube )
{
    int i,armed;

    if( ( tube < 0 ) || ( tube >= ship->number_of_photons ) )
    {
        fnotify( enactor, "%s%sInvalid tube number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    for(i=0,armed=0;i<ship->number_of_photons;i++)
    {
        if( ship->photon[i].status==PHOTON_ARMED )
        {
            armed++;
        }
    }
    if( ship->torps_remaining<=armed && ship->torps_remaining > 0 )
    {
        fnotify( enactor, "Unable to load, no %ss remaining!", ship->photon_string );
        return;
    }
    if( ship->photon[tube].status != PHOTON_EMPTY )
    {
        fnotify( enactor, "%s%s%s tube not empty.%s", ANSI_HILITE, ANSI_RED, ship->photon_string,
            ANSI_NORMAL );
        return;
    }
    if( tube == ship->reloading_tube )
    {
        fnotify( enactor, "%sWe are already loading tube %d.%s", ANSI_MAGENTA, tube+1, ANSI_NORMAL );
        return;
    }
    if( ship->reloading_tube != NO_RELOAD )
    {
        fnotify( enactor, "%sAborting tube %d for tube %d.%s", ANSI_CYAN, ship->reloading_tube,
            tube+1, ANSI_NORMAL );
    }
    ship->reloading_tube = tube;
    ship->turns_to_reload = ship->torp_reload_time;
    fnotify( enactor, "%sReloading tube %d.%s", ANSI_CYAN, tube+1, ANSI_NORMAL );
    return;
}


void id_list( SHIP *ship, dbref enactor )
{
  CONTACT *contact;
  char minibuf[10];

  contact = ship->contact_list;

  sprintf( writebuf, "Contacts: " );

  while( contact != NULL ) {
    sprintf( minibuf, "%d ", contact->contact_number );
    strcat( writebuf, minibuf );
  }

  notify( enactor, writebuf );
}

void set_tractor_mode( SHIP *ship, dbref enactor, char *tractor_mode )
{
    if( !strcmp( "tractor", tractor_mode ) )
    {
        ship->tractor_mode = MODE_TRACTOR;
        notify( enactor, "Tractor beams set to tractor mode.\n" );
    }
    else if( !strcmp( "pressor", tractor_mode ) )
    {
        ship->tractor_mode = MODE_PRESSOR;
        notify( enactor, "Tractor beams set to pressor mode.\n" );
    }
    else if( !strcmp( "det", tractor_mode ) )
    {
        ship->tractor_mode = MODE_DET;
        notify( enactor, "Tractor beams set to detonate mode.\n" );
        if( ship->smart_alloc==2 && ship->tractor_target!=NULL )
        {
            free_power( ship, POWER_HELM_TRACTOR, ship->halloc_tractor );
            requisition_power( ship, POWER_HELM_TRACTOR, 1 );
        }
    }
    else
    {
        notify( enactor, "That is not a valid tractor mode.\n" );
    }
    return;
}

const char *get_tractor_mode( SHIP *ship )
{
    switch( ship->tractor_mode )
    {
        case MODE_HOLD:
            return "hold";
        case MODE_TRACTOR:
            return "tractor";
        case MODE_PRESSOR:
            return "pressor";
        case MODE_DET:
            return "detonate";
        default:
            return "error";
    }
    return "really serious error";
}

void manual_fire_photon( SHIP *ship, dbref enactor, int tube, char *arg1, char *arg2, char *arg3 )
{
    int i,damage,dist,mrange,temp,detted=0;
    SHIP *victim,*vict_next,*detter;
    CONTACT *contact,*shooter;
    char shooter_string[120];
    dbref helmsman,navigator;
    SPH aimpoint,rel,point;
    float roll,prob;
    XYZ detpoint,cpos;
    SHIP fake_ship;
    WDATA weapon;

    /* make sure we're not set pacifist */
    if( ship->flags[PACIFIST] )
    {
        fnotify( enactor, "%s%sWeapons inoperable.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ship->number_of_photons <= 0 )
    {
        fnotify( enactor, "%s%sSilly, this ship has no torpedoes!%s", ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
        return;
    }
    if( arg1==NULL || arg2==NULL || arg3==NULL
    || !is_number(arg1) || !is_number(arg2) || !is_number(arg3) )
    {
        fnotify( enactor, "%sInvalid target heading.%s", ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* valid tube check */
    if( tube!=FIRE_ALL && ( tube < 0 || tube >= ship->number_of_photons ) )
    {
        fnotify( enactor, "%s%sInvalid tube number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    aimpoint.bearing = atof(arg1);
    aimpoint.elevation = atof(arg2);
    aimpoint.range = atof(arg3);
    if( aimpoint.bearing < 0.0 || aimpoint.bearing > 359.0 )
    {
        fnotify( enactor, "%s%sValid headings are from 0 to 359.%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
        return;
    }
    if( aimpoint.elevation < -90.0 || aimpoint.elevation > 90.0 )
    {
        fnotify( enactor, "%s%sValid elevations are from -90 to 90 inclusive.%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
        return;
    }
    if( aimpoint.range < ship->photon[0].power * 3/4 )
    {
        fnotify( enactor,"%s%sYou may not fire that close to your own ship.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( tube==FIRE_ALL )
    {
        mrange = ship->photon[0].range;
    }
    else
    {
        mrange = ship->photon[tube].range;
    }
    if( aimpoint.range > mrange )
    {
        fnotify( enactor, "%sTarget point is out of range.%s", ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* check for fire all tubes */
    if( tube == FIRE_ALL )
    {
        fnotify( enactor, "%sFiring all available %ss.%s", ANSI_CYAN, 
            ship->photon_string, ANSI_NORMAL );
        for( i = 0; i < ship->number_of_photons; i++ )
        {
            if( ship->photon[i].status == PHOTON_ARMED )
            {
                manual_fire_photon( ship, enactor, i, arg1, arg2, arg3 );
            }
        }
        return;
    }
    cpos = sph_to_xyz( aimpoint );
    detpoint.x = cpos.x + ship->pos.x;
    detpoint.y = cpos.y + ship->pos.y;
    detpoint.z = cpos.z + ship->pos.z;
    if( !in_arc(ship->photon[tube].wpn_arc,facing_vector(ship,detpoint)) )
    {
        point.bearing = ship->motion.bearing + ship->photon[tube].wpn_arc.center.bearing;
        point.elevation = ship->motion.elevation + ship->photon[tube].wpn_arc.center.elevation;
        point.range = 1.0;
        point = fix_sph_coord( point );
        fnotify( enactor, "%s%s%s %d can only fire at targets within %.0f%+.0f of %.0f%+.0f.%s",
            ANSI_HILITE, ANSI_RED, ship->photon_string, tube+1,
            ship->photon[tube].wpn_arc.htraverse, ship->photon[tube].wpn_arc.vtraverse,
            point.bearing, point.elevation,
            ANSI_NORMAL );    
        return;
    }
    if( ship->photon[tube].status!=PHOTON_ARMED )
    {
        fnotify( enactor, "%s%sA %s must be armed before firing.%s", ANSI_HILITE, ANSI_RED,
            ship->photon_string, ANSI_NORMAL );
        return;
    }
    if( ship->torps_remaining > 0 )
    {
        ship->torps_remaining--;
        write_damage( ship );
    }
    ship->photon[tube].status = PHOTON_EMPTY;
    ship->photon[tube].charge = 0;
    ship->photon[tube].turns_charged = 0;
    weapon = ship->photon[tube].wpn_data;
    if( ship->reloading_tube==NO_RELOAD && ship->auto_reload )
    {
        reload_photon( ship, enactor, tube );
    }
    if( FRAND > ship->photon[tube].reliability )
    {
        fnotify( enactor, "%s%s%s %d misfires.%s",ANSI_HILITE,ANSI_RED,ship->photon_string,tube+1,ANSI_NORMAL);
        return;
    }
    fnotify( enactor, "%s%s %d launched.%s", ANSI_CYAN, ship->photon_string, tube, ANSI_NORMAL );
    for(detter=space_list[current_space];detter!=NULL;detter=detter->next)
    {
        if( detter->tractor_target!=NULL && detter->tractor_target->listref==ship
        && detter->tractor_mode==MODE_DET )
        {
            detted=1;
            break;
        }
    }
    if( detted )
    {
        shooter = find_contact( ship, detter );
        if( shooter==NULL )
        {
            fnotify( enactor, "%s%s%s detonated by unknown source!%s", ANSI_HILITE,
                ANSI_YELLOW, ship->photon_string, ANSI_NORMAL );
        }
        else
        {
            contact_string( shooter_string, shooter, INFO_TERSE );
            fnotify( enactor, "%s%s%s detonated by contact [%s%d%s]: %s%s%s!%s",
                ANSI_HILITE, ANSI_YELLOW, ship->photon_string, ANSI_MAGENTA,
                shooter->contact_number, ANSI_YELLOW, ANSI_CYAN,
                shooter_string, ANSI_YELLOW, ANSI_NORMAL );
        }
        shooter = find_contact( detter, ship );
        if( shooter==NULL )
        {
            sprintf(writebuf,"%s%sDetonated %s from unknown source!%s",
                ANSI_HILITE, ANSI_RED, ship->photon_string, ANSI_NORMAL );
        }
        else
        {
            contact_string( shooter_string, shooter, INFO_TERSE );        
            sprintf(writebuf,"%s%sDetonated %s from contact [%s%d%s]: %s%s%s!%s",
                ANSI_HILITE, ANSI_RED, ship->photon_string, ANSI_MAGENTA, shooter->contact_number,
                ANSI_RED, ANSI_CYAN, shooter_string, ANSI_YELLOW, ANSI_NORMAL );
        }
        notify_room( BRIDGE(detter), writebuf );
        battle_damage( ship, detter, ship->photon[tube].power/4, weapon );
        return;
    }
    fake_ship = *ship;
    fake_ship.pos = detpoint;
    fake_ship.target_system = SYSTEM_HULL;
    for(victim=space_list[current_space];victim!=NULL;victim=vict_next)
    {
        vict_next = victim->next;
        /* NO SUICIDE */
        if( victim==ship )
        {
            continue;
        }
        /* find observer helmsman's dbref */
        helmsman = match_result(HOWIE, my_atr_get_raw(victim->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
        navigator = match_result(HOWIE, my_atr_get_raw(victim->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
        cpos.x = detpoint.x - victim->pos.x;
        cpos.y = detpoint.y - victim->pos.y;
        cpos.z = detpoint.z - victim->pos.z;
        rel = xyz_to_sph( cpos );
        if( distance(victim->pos,detpoint) <= victim->sensor_power )
        {
            shooter = find_contact(victim,ship);
            if( shooter==NULL )
            {
                sprintf( writebuf, "%sUnknown source fired %s upon %.0f%+.0f, range %.0f.%s",
                    ANSI_CYAN, ship->photon_string,
                    rel.bearing, rel.elevation,
                    rel.range, ANSI_NORMAL );
            }
            else
            {
                contact_string( shooter_string, shooter, INFO_TERSE );
                sprintf( writebuf, "%sContact [%s%s%d%s%s]: %s%s%s fired %s upon %.0f%+.0f, range %.0f.%s",
                    ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA, shooter->contact_number, ANSI_NORMAL,
                    ANSI_CYAN, ANSI_NORMAL, shooter_string, ANSI_CYAN, ship->photon_string,
                    rel.bearing, rel.elevation,
                    rel.range, ANSI_NORMAL );
            }
            notify_room( BRIDGE(victim), writebuf );
        }
        /* DAMAGE! (MAYBE) */
        if( !ship->flags[DEADMAN] && !ship_is_safe(victim)
        && rel.range < ship->photon[tube].power * 3/4 )
        {
            damage = (ship->photon[tube].power * 3/4) - rel.range;
            battle_damage( &fake_ship, victim, damage, weapon );
        }
    }
    return;
}

void toggle_ignore_contact( SHIP *ship, dbref enactor, char *ignoree )
{
    CONTACT *victim;

    if( ( victim=match_contact(ship,ignoree) )==NULL )
    {
        fnotify( enactor, "%sContact '%s' doesn't exist...lay off the LSD, please!%s", ANSI_GREEN, ignoree, ANSI_NORMAL );
        return;
    }
    if( victim->ignored )
    {
        victim->ignored = FALSE;
        fnotify( enactor, "%s%sNo longer ignoring that ship.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    }
    else
    {
        victim->ignored = TRUE;
        fnotify( enactor, "%s%sNow ignoring that ship.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    return;
}

void xyz_fire_phaser( SHIP *ship, dbref enactor, int bank, int x, int y, int z )
{
    int range,effective_max_range,i,damage,hit_vict=0;
    char shooter_string[120];
    CONTACT dummy,*shooter;
    SHIP *victim,*observer;
    float damage_coeff;
    dbref helmsman;
    SPH point;
    XYZ cpos;

    cpos.x = x;
    cpos.y = y;
    cpos.z = z;

    if( bank==FIRE_ALL )
    {
        for(i=0;i<ship->number_of_phasers;i++)
        {
            if( ship->phaser[i].charge > 0 )
            {
                xyz_fire_phaser( ship, enactor, i, x, y, z );
            }
        }
        return;
    }
    if( bank < 0 || bank >= ship->number_of_phasers )
    {
        fnotify( enactor, "%s%sInvalid %s number.%s", ANSI_HILITE, ANSI_RED,
            ship->phaser_string, ANSI_NORMAL );
        return;
    }
    if( !in_arc(ship->phaser[bank].wpn_arc,facing_vector(ship,cpos)) )
    {
        point.bearing = ship->motion.bearing + ship->phaser[bank].wpn_arc.center.bearing;
        point.elevation = ship->motion.elevation + ship->phaser[bank].wpn_arc.center.elevation;
        point.range = 1.0;
        point = fix_sph_coord( point );
        fnotify( enactor, "%s%s%s %d can only fire at targets within %.0f%+.0f of %.0f%+.0f.%s",
            ANSI_HILITE, ANSI_RED, ship->phaser_string, bank+1,
            ship->phaser[bank].wpn_arc.htraverse, ship->phaser[bank].wpn_arc.vtraverse,
            point.bearing, point.elevation,
            ANSI_NORMAL );
        return;
    }
    if( ship->phaser[bank].charge == 0 )
    {
        fnotify( enactor, "%s%sA %s must be charged before firing.%s", ANSI_HILITE, ANSI_RED,
            ship->phaser_string, ANSI_NORMAL );
        return;
    }
    effective_max_range = ship->phaser[bank].range * ship->phaser[bank].charge / ship->phaser[bank].power;
    if( distance(ship->pos,cpos) > effective_max_range )
    {
        fnotify( enactor, "%s%sThe max range for %s %i at current charge is %i.%s", ANSI_HILITE,
            ANSI_RED, ship->phaser_string, bank +1, effective_max_range, ANSI_NORMAL );
        return;
    }
    for(victim=space_list[current_space];victim!=NULL;victim=victim->next)
    {
        if( victim->flags[DEADMAN] || ship_is_safe(victim) )
        {
            continue;
        }
        if( ship!=victim && distance(victim->pos,cpos) <= victim->size )
        {
            hit_vict=1;
            break;
        }
    }
    dummy.next = NULL;
    dummy.prev = NULL;
    if( hit_vict && victim!=NULL )
    {
        bzero( &dummy, sizeof(CONTACT) );
        dummy.listref = victim;
        dummy.last_pos = victim->pos;
        dummy.stale = 1;
        fire_phaser( ship, enactor, bank, 0, &dummy );
    }
    else
    {
        if( FRAND > ship->phaser[bank].reliability )
        {
            sprintf( writebuf, "%s%sMalfunction and meltdown in %s %d.%s",
                ANSI_HILITE, ANSI_RED, ship->phaser_string, bank + 1, ANSI_NORMAL );
            notify_room( BRIDGE(ship), writebuf );
            ship->damage[SYSTEM_GUN_0 + bank].status = '9';
            if( ship->phaser[bank].status==PHASER_ONLINE )
            {
                ship->num_phasers_online--;
            }
            ship->phaser[bank].status = PHASER_DAMAGED;
            ship->phaser[bank].charge = 0;
            return;
        }
        damage_coeff = ship->phaser[bank].range_percent +
            ( FRAND - 0.5 ) * 0.5 * ship->phaser[bank].range_percent;
        damage = (int)( (float)( ship->phaser[bank].charge ) *
            ( 1.0 + ( damage_coeff - 1.0 ) *
            distance( ship->pos, cpos ) /
            (float)( effective_max_range )) + 0.5);
        fnotify( enactor, "%s%s%s %d fired.  Hit for %2.0f%% yield.%s",
            ANSI_HILITE, ANSI_GREEN, ship->phaser_string, bank+1,
            (float)damage / (float)(ship->phaser[bank].charge) * 100.0, ANSI_NORMAL );
        ship->phaser[bank].charge = 0;
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if( ship!=observer && ( shooter=find_contact(observer,ship) )!=NULL )
            {
                helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
                contact_string( shooter_string, shooter, INFO_TERSE );
                fnotify( helmsman, "%sContact [%s%s%d%s%s]: %s%s%s fired %ss upon XYZ: %.0f %.0f %.0f.%s", ANSI_CYAN,
                    ANSI_HILITE, ANSI_MAGENTA, shooter->contact_number,
                    ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL, shooter_string,
                    ANSI_CYAN, ship->phaser_string, cpos.x, cpos.y, cpos.z,
                    ANSI_NORMAL );
            }
        }
    }
    return;
}

int external_reload( SHIP *ship, int torpedoes_added )
{
    int used;

    if( ship->torp_capacity <= 0 )
    {
        return torpedoes_added;
    }
    used = UMIN( ship->torp_capacity - ship->torps_remaining, torpedoes_added );
    ship->torps_remaining += used;
    return torpedoes_added - used;
}

void target_system( SHIP *ship, dbref enactor, const char *dsystem )
{
    int i=0;

    if( ship->damage[SYSTEM_TARGETTING].status != '0'
    && ship->damage[SYSTEM_TARGETTING].status != '1' )
    {
        fnotify( enactor, "%s%sTargetting system is too damaged for precision targetting.%s",
            ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
        return;
    }
    while( i < NUM_SYSTEMS && !strstr( system_names[i], dsystem ) )
    {
        i++;
    }
    if( i>=NUM_SYSTEMS || i==SYSTEM_HULL || i < 0 )
    {
        fnotify( enactor, "%s%sRandom destruction selected.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        ship->target_system = SYSTEM_HULL;
        return;
    }
    fnotify( enactor, "%s%sWeapons targetting enemy %s for destruction.%s",
        ANSI_HILITE, ANSI_RED, system_names[i], ANSI_NORMAL );
    ship->target_system = i;
    return;
}

void bombard_planet( SHIP *ship, dbref enactor )
{
    if( ship->orbitting==NULL )
    {
        fnotify( enactor, "%s%sMust be in orbit to bomb.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ship->bombarding )
    {
        fnotify( enactor, "%s%sHalting bombardment of planet %s.%s",
            ANSI_HILITE, ANSI_GREEN, ship->orbitting->name, ANSI_NORMAL );
        ship->bombarding = 0;
    }
    else
    {
        fnotify( enactor, "%s%sCommencing bombardment of planet %s.%s",
            ANSI_HILITE, ANSI_RED, ship->orbitting->name, ANSI_NORMAL );
        ship->bombarding = 1;
    }
    return;
}

char ship_is_safe( SHIP *ship )
{
    int i;

    if( ship->locked_target!=NULL || ship->pending_lock!=NULL
    || ship->jammer_status || ship->battle_timer > 0 )
    {
        return FALSE;
    }
    for(i=0;i<ship->number_of_photons;i++)
    {
        if( ship->photon[i].status==PHOTON_ARMED
        || ship->photon[i].status==PHOTON_ONLINE )
        {
            return FALSE;
        }
    }
    if( ship->orbitting!=NULL && !ship->bombarding )
     {
        return TRUE;
     }
     /*if( ship->flags[STARBASE] && ship->battle_timer<=0 )
     *{
     *  return TRUE;
     *}
     */ 
     return FALSE;
}

void dscan_ship( SHIP *ship, dbref enactor, char *target_string )
{
    char status_string[256],busted=FALSE;
    CONTACT *target;
    SHIP *victim;
    int i;

    if( ship->damage[SYSTEM_SCANNERS].status > '6' )
    {
        fnotify( enactor, "%s%sScanners are damaged and inoperable.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ( target=match_contact(ship,target_string) )==NULL )
    {
        fnotify( enactor, "%s%sNo contact with any ship called '%s%s%s%s%s'.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL, ANSI_CYAN, target_string, ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return;
    }
    if( distance(ship->pos,target->listref->pos) > ship->scanner_range
    || ( victim=target->listref )==NULL )
    {
        fnotify( enactor, "%s%sThat ship is out of scanner range.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    contact_string( writebuf, target, INFO_TERSE );
    notify( enactor, writebuf );
    for(i=0;i<NUM_SYSTEMS;i++)
    {
        if( victim->damage[i].status=='x' || victim->damage[i].status=='X'
        || victim->damage[i].status=='0' )
        {
            continue;
        }
        switch( victim->damage[i].status )
        {
            case '9':
                busted=TRUE;
                sprintf( status_string, "%s%sdestroyed%s",
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                break;
            case '8':
            case '7':
                busted=TRUE;
                sprintf( status_string, "%s%sinoperative%s",
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                break;
            case '6':
            case '5':
                busted=TRUE;
                sprintf( status_string, "%s%sheavily damaged%s",
                    ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                break;
            case '4':
            case '3':
                busted=TRUE;
                sprintf( status_string, "%s%smoderately damaged%s",
                    ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                break;
            case '2':
                busted=TRUE;
                sprintf( status_string, "%s%slightly damaged%s",
                    ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
                break;
            case '1':
                busted=TRUE;
                sprintf( status_string, "%s%spatched%s",
                    ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
                break;
            case '0':
                sprintf( status_string, "%s%sfully operational%s",
                    ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
                break;
            default:
                busted=TRUE;
                sprintf( status_string, "%s%sunknown%s",
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                break;
        }
        fnotify( enactor, "%s%s%s%s - %s", ANSI_HILITE, ANSI_GREEN,
            system_names[i], ANSI_NORMAL, status_string );
    }
    if( !busted )
    {
        fnotify( enactor, "%s%sAll systems operational.%s", ANSI_HILITE,
            ANSI_GREEN, ANSI_NORMAL );
    }
    return;
}
