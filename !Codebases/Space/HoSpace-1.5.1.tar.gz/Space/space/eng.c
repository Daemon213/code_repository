/*
 * $Id: eng.c,v 1.5 1993/09/28 05:20:52 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: eng.c,v $
 *
 * Revision HoSpace* 2001 Howie69
 * Where the hell is that mem_dump at? Been missing for 
 * years :)
 *
 * Revision 1.5  1993/09/28  05:20:52  chuckles
 * deallocate kills sensorlinks.  mem_dump command.
 *
 * Revision 1.4  1993/09/25  20:39:40  chuckles
 * cleaned up logging code.  lots of notify -> fnotify conversions.
 * start with autoload turned on.
 *
 * Revision 1.3  1993/09/22  04:56:29  chuckles
 * read remote sensor array stuff from template
 *
 * Revision 1.2  1993/09/21  19:11:38  chuckles
 * read damage control teams off of template file.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 26 Aug 93 - rewrite the status report
 * JMS 25 Aug 93 - allow 'start reactor' in sim space even if docked
 * JMS 24 Aug 93 - begin phasing out hardcoded attribute numbers in
 *                 favor of dynamic lookups.  group related numbers
 *                 in single attributes and name mnemonically.
 * JMS 23 Aug 93 - read names from struct instead of ship object
 * JMS 22 Aug 93 - (bugfix) deallocate kills watches in BOTH directions
 * JMS 21 Aug 93 - read from disk templates instead of db objects
 * JMS 19 Aug 93 - begin MUSH2.0 port
 * JMS 24 May 93 - separated into nav.c
 * JMS/DJB 21 Jul 92 - original code
 */

/*
 * fun_eng_cmd() -- This is the function that gets called whenever an object
 * uses the ENG() function.  It passes arguements to all the sub-functions
 * related to the engineering console.
 *
 * JMS 26 Aug 93 - use SHIP_OBJECT instead of XA
 */

FUNCTION(fun_eng_cmd)
{
  dbref ship_object;
  SHIP *ship;

  if( !Wizard(executor) || args[0]==NULL )
  {
    safe_str("#-1 PERMISSION DENIED", buff, bp );
    return;
  }
  /* get the dbref of the ship object */
  ship_object = attrib_dbref( executor, "SHIP_OBJECT" );
  if( !GoodObject( ship_object ))
  {
    safe_str("#-1 BAD SHIP OBJECT", buff, bp );
    return;
  }

  /* now set the ship pointer to the proper ship and also set the
   * space list to the list that contains it (handled by cfind_ship).
   */
  ship = cfind_ship( ship_object );

  /* we have a valid dbref.  Now switch on the first argument         *
   * first check for functions that will work whether or not the ship *
   * is active.  Then return on inactive.  Then check for those that  *
   * require an active ship.                                          */

  if( !strcmp( args[0], "start" ))
  {  /* start reactor */
    start_reactor( ship, enactor, ship_object );
  }
  /* General commands */
  else if( !strcmp( args[0], "lock_space" ) && args[1]!=NULL )
  {
    if (!Wizard(enactor))
    {
      fnotify( enactor, "%s%sYou attempt to warp the fabric of space, but fail.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    }
    if( ( atoi( args[1] ) < 0 ) || ( atoi( args[1] ) > SPACE_LIMIT ) )
    {
	    fnotify( enactor, "%sInvalid space index.%s", ANSI_HILITE, ANSI_NORMAL );
	    return;
    }
    fnotify( enactor, "%s%s%s space locked.%s", ANSI_HILITE, ANSI_RED, 
           space_names[atoi( args[1] )], ANSI_NORMAL );
    space_lock[atoi( args[1] )] = SPACE_LOCKED;
  }
  else if( !strcmp( args[0], "pause_space" ) && enactor==HOWIE && args[1]!=NULL )
  {
    if( atoi( args[1] ) < 0 || atoi( args[1] ) > SPACE_LIMIT )
    {
        fnotify( enactor, "%sInvalid space index.%s", ANSI_HILITE, ANSI_NORMAL );
        return;
    }
    fnotify( enactor, "%s%s%s space %s.%s", ANSI_HILITE, ANSI_RED, space_names[atoi(args[1])],
        space_pause[atoi(args[1])] ? "unpaused" : "paused", ANSI_NORMAL );
    space_pause[atoi(args[1])] = !space_pause[atoi(args[1])];
  }
  else if( !strcmp( args[0], "log_space" ))
  {
    log_space( "%s(#%d) using %s(#%d) logs: %s", db[enactor].name,
               enactor, db[executor].name, executor, args[1] );
  }
  else if( !strcmp( args[0], "unlock_space" ))
  {
    if (!Wizard(enactor)) {
      fnotify( enactor, "%s%sYou attempt to warp the fabric of space, but fail.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    } 
    if(( atoi( args[1] ) < 0 ) || ( atoi( args[1] ) > SPACE_LIMIT )) {
      fnotify( enactor, "%sInvalid space index.%s", ANSI_HILITE, ANSI_NORMAL );
    }

    fnotify( enactor, "%s%s%s space unlocked.%s", ANSI_HILITE, ANSI_GREEN, 
           space_names[atoi( args[1] )], ANSI_NORMAL );
    space_lock[atoi( args[1] )] = SPACE_UNLOCKED;
  }
  else if( !strcmp( args[0], "shutdown_space" ))
  {
    if (!Wizard(enactor)) {
      fnotify( enactor, "%s%sYou attempt to warp the fabric of space, but fail.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
      return;
    }
    fnotify( enactor, "%s%sShutting down space.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    for( current_space = 0; current_space < SPACE_LIMIT; current_space++ )
      shutdown_space( enactor );
  }
  else if( !strcmp( args[0], "master_eng_list" ))
  {
    master_eng_list( enactor );
  }
  else if( !strcmp( args[0], "master_nav_list" ))
  {
    master_nav_list( enactor );
  }
  else if( !strcmp( args[0], "space_roster" ))
  {
    space_roster( enactor );
  }
  else if( !strcmp( args[0], "active_check" ))
  {
    if( ship == NULL ) {
    sprintf( writebuf, "0" );
    safe_str(writebuf, buff, bp);
    }
    else {
    sprintf( writebuf, "1" );
    safe_str(writebuf, buff, bp);
    }
  }
  else if( !strcmp( args[0], "armageddon" ) && args[1]!=NULL && is_number(args[1]) )
  {
    armageddon( enactor, atoi(args[1]) );
  }
  /* ACTIVE CHECK */
  else if( ship == NULL )
  {
    fnotify( enactor, "%sShip must be active to use that command.%s", ANSI_CYAN, ANSI_NORMAL );
    sprintf( writebuf, "#-1");
    safe_str( writebuf, buff, bp );
  }
  else if( current_space==REAL && !Wizard(executor) )
  {
    safe_str("#-1 PERMISSION DENIED", buff, bp );
    return;
  }
  /* more god functions */
  else if( !strcmp( args[0], "set_flag" ))
  {
    set_ship_flag( ship, enactor, args[1], atoi( args[2] ));
  }
  else if( !strcmp( args[0], "output" ))
  {
    sprintf( writebuf, "%d %d", ship->reactor_setting, ship->reactor_output );
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "batteries" ) )
  {
    switch( ship->battery_status )
    {
      case BTTY_OFFLINE:
        sprintf( writebuf, "OFFLINE %d %d %d", ship->battery_level, ship->battery_capacity,
               ship->battery_discharge_max );
        break;
      case BTTY_ONLINE:
        sprintf( writebuf, "ONLINE %d %d %d", ship->battery_level, ship->battery_capacity,
               ship->battery_discharge_max );
        break;
      case BTTY_DAMAGED:
        sprintf( writebuf, "DAMAGED %d %d %d", ship->battery_level,
               ship->battery_capacity, ship->battery_discharge_max );
        break;
      case BTTY_NONE:
        sprintf( writebuf, "N/A 0 0 0" );
        break;
      default:
        /* log the error */
        log_space( "Error.  Bad battery status." );
        break;
    }
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "allocations" ))
  {
    sprintf( writebuf, "%d %d %d %d %d %d %d %d %d %d", ship->alloc_helm, ship->alloc_nav,
           ship->alloc_batt, ship->halloc_phasers, ship->halloc_photons,
           ship->nalloc_warp, ship->nalloc_fore, ship->nalloc_aft,
           ship->nalloc_port, ship->nalloc_starboard );
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "manual_shutdown" ))
  {
    manual_shutdown( ship, enactor );
  }
  else if( !strcmp( args[0], "hand_move" ))
  {
    hand_move( ship, enactor, atof( args[1] ), atof( args[2] ), atof( args[3] ));
  }
  else if( !strcmp( args[0], "get_dbref" ))
  { 
    get_dbref( ship, enactor, args[1], buff, bp );
  }
  else if( !strcmp( args[0], "ship_cost" ) )
  {
    sprintf( writebuf, "%ld", ship_cost( ship, enactor ) );
    safe_str(writebuf, buff, bp);
  }
  else if( !strcmp( args[0], "full_repair" ))
  {
    full_repair( ship, enactor );
  }
/* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
  else if( ship->flags[DEADMAN] ) {
    fnotify( enactor, "%s%sShip is deadmanned. That command is unavailable.%s",
           ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
/* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
  else if( !strcmp( args[0], "warp_table" ))
  {
    warp_table( ship, enactor );
  }
  else if( !strcmp( args[0], "shutdown" ))
  {
    shutdown_reactor( ship, enactor );
  }
  else if( !strcmp( args[0], "status" ))
  {
    eng_status( ship, enactor );
  }
  else if( !strcmp( args[0], "reactor_setting" ))
  {
    set_reactor_output( ship, enactor, atoi( args[1] ));
  }
  else if( !strcmp( args[0], "battery_on" ))
  {
    /* active.  Check battery status */
    switch( ship->battery_status )
    {
            case BTTY_ONLINE:
	      fnotify( enactor, "%sBatteries are already on line.%s", ANSI_MAGENTA, ANSI_NORMAL );
	      break;

	    case BTTY_DAMAGED:
	      fnotify( enactor, "%s%sBatteries are damaged and may not be brought on line.%s",
                     ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
	      break;

	    case BTTY_OFFLINE:
	      ship->battery_status = BTTY_ONLINE;
	      fnotify( enactor, "%s%sBatteries now on line.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
	      sprintf( writebuf, "battery level: %d  max discharge: %d",
			     ship->battery_level, ship->battery_discharge_max );
	      break;

            case BTTY_NONE:
              fnotify( enactor, "%s%sThis ship has no batteries.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
              break;

	    default:
	      fnotify( enactor, "%sBattery status unknown.%s", ANSI_HILITE, ANSI_NORMAL );
	      break;
    }
  }
  else if( !strcmp( args[0], "battery_off" ))
  {
    /* active.  Check battery status */
    switch( ship->battery_status ) {
      case BTTY_ONLINE:
	ship->battery_status = BTTY_OFFLINE;
	fnotify( enactor, "%s%sBatteries are now off line.%s", ANSI_HILITE, ANSI_RED,
               ANSI_NORMAL );

	/* check for overallocation */
	eng_alloc_check( ship, enactor );
	break;

      case BTTY_DAMAGED:
	fnotify( enactor, "%s%sBatteries are damaged and need not be taken off line.%s",
               ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
	break;

      case BTTY_OFFLINE:
	fnotify( enactor, "%sBatteries are already off line.%s", ANSI_MAGENTA, ANSI_NORMAL );
	break;

      case BTTY_NONE:
        fnotify( enactor, "%s%sThis ship has no batteries.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        break;

      default:
	fnotify( enactor, "%sBattery status unknown.%s", ANSI_HILITE, ANSI_NORMAL );
	break;
    }
  }
  else if( !strcmp( args[0], "toggle_warnings" ))
  {
    ship->eng_warnings = !ship->eng_warnings;

    if( ship->eng_warnings )
       fnotify( enactor, "%s%sWarning messages enabled.%s", ANSI_HILITE, ANSI_GREEN,
              ANSI_NORMAL );
    else
       fnotify( enactor, "%s%sWarning messages disabled.%s", ANSI_HILITE, ANSI_RED,
              ANSI_NORMAL );
  }
  else if( !strcmp( args[0], "toggle_safeties" ))
  {
    toggle_safeties( ship, enactor );
  }
  else if( !strcmp( args[0], "toggle_smartmode" ))
  {
    toggle_smartmode( ship, enactor, args[1] );
  }
  else if( !strcmp( args[0], "allocate" ))
  {
    eng_allocate( ship, enactor, atoi( args[1] ), atoi( args[2] ),
		  atoi( args[3] ));
  }
  else if( !strcmp( args[0], "ship_specs" ))
  {
    ship_specs( ship, enactor );
  }
  else if( !strcmp( args[0], "self_destruct" ))
  {
    self_destruct( ship, enactor ); 
  }
  else if( !strcmp( args[0], "eject_warp_core" ) )
  {
    eject_warp_core( ship, enactor );
  }
  else if( !strcmp( args[0], "eject_phaser_core" ) )
  {
    eject_phaser_core( ship, enactor );
  }
  else if( !strcmp( args[0], "abridged_eng_status") )
  {
  	abridged_eng_status( ship, enactor );
  }
  /* Test commands for Howie to crash test */
  else if( !strcmp( args[0], "load_space" ))
  {
    load_space();
  }
  else if( !strcmp(args[0], "orbit_stars"))
  {
  	orbit_stars();
  }
  else if( !strcmp(args[0], "orbit_planets"))
  {
  	orbit_planets();
  }
  /* End Crash Test Commands */
  else
    /* Command not recognized */
    fnotify( enactor, "Unrecognized eng_cmd call." );
}


/* self_destruct() -- This self destructs a ship.
   Should be on the Command Console and require an access code or something.
 */
void self_destruct( SHIP *ship, dbref enactor )
{
    sprintf( writebuf, "%s%sWARNING: Final auto-destruct sequence engaged. Have a nice day.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    notify_room( BRIDGE(ship), writebuf );
    if( BRIDGE(ship)!=ENGINE(ship) )
    {
        notify_room( ENGINE(ship), writebuf );
    }
    explode_ship( ship );
}

void explode_ship( SHIP *ship )
{
    char exploder_string[120],target_string[120];
    SHIP *victim,*vict_next;
    CONTACT *contact,*exploder;
    int dam,range;
    WDATA weapon;

    for(victim=space_list[current_space];victim!=NULL;victim=vict_next)
    {
        vict_next=victim->next;
        if( victim==ship
        || (int)distance(ship->pos,victim->pos) >= (ship->reactor_output_max * ship->reactor_setting_limit / 100) )
        {
            continue;
        }
        exploder = NULL;
        contact = victim->contact_list;
        while( contact != NULL )
        {
            if( contact->listref == ship )
            {
                exploder = contact;
                contact = NULL;
                break;
            }
            else
            {
                contact = contact->next;
            }
        }
        if( exploder==NULL )
        {
            sprintf(writebuf,"%s%sExplosion from XYZ: %.0f %.0f %.0f!%s",
                ANSI_HILITE, ANSI_RED, ship->pos.x,
                ship->pos.y, ship->pos.z, ANSI_NORMAL );
        }
        else
        {
            contact_string( exploder_string, exploder, INFO_TERSE ); 
            sprintf(writebuf,"%s%sExplosion from [%d]: %s%s",
                ANSI_HILITE, ANSI_RED, exploder->contact_number,
                exploder_string, ANSI_NORMAL );
        }
        notify_room(BRIDGE(victim),writebuf); 
        if( victim->flags[DEADMAN] || ship_is_safe(victim) )
        {
            continue;
        }
        dam = (ship->reactor_output_max * ship->reactor_setting_limit / 100) - (int)distance(ship->pos,victim->pos);
        weapon.type = WPN_EXPLO;
        weapon.sfactor = 1.0;
        weapon.hfactor = 1.0;
        weapon.carryover = 1.0;
        weapon.taps = 1;
        battle_damage( ship, victim, dam, weapon );
    }
    damage_hull( ship, ship->hull_integrity * 3, INFO_TERSE );
    return;
}
 
/* manual_shutdown() -- This is a god command to zorch a ship, regardless
 * of the space it's in.
 */

void manual_shutdown( SHIP *ship, dbref enactor )
{
  if( deallocate_ship( ship )) {
    /* hmm.  Didn't work.  It should have. */
    log_space( "deallocate_ship failed." );
    fnotify( enactor, "Shutdown overridden." );
  }
  else {
    fnotify( enactor, "%s%sReactor shutdown.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
  }
}


void hand_move( SHIP *ship, dbref enactor, float x, float y,
float z )
{
  if (!Wizard(enactor)) {
      fnotify( enactor, "%s%sYou attempt to warp the fabric of space, but fail.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );

    return;
  }

  ship->pos.x = x;
  ship->pos.y = y;
  ship->pos.z = z;

  fnotify( enactor, "%s%sMoved to: %s%ld %ld %ld.%s", ANSI_HILITE, ANSI_BLUE,
         ANSI_YELLOW, (long int)x, (long int)y, (long int)z, ANSI_NORMAL );
}

void get_dbref( SHIP *ship, dbref enactor, char *target, char *buff, char **bp)
{
  CONTACT *contact;
  struct planet_contact *p_contact;
   
  contact = match_contact( ship, target );
  p_contact = match_planet( ship, target );

  if( contact == NULL && p_contact == NULL )
     safe_str("#-1", buff, bp );
  else {
    if( p_contact == NULL )
    {
     sprintf( writebuf, "#%d", contact->listref->ship_object );
     safe_str(writebuf, buff, bp);
    }
    else {
     sprintf( writebuf, "#%d", p_contact->listref->planet_object);
     safe_str( writebuf, buff, bp );
     }
  }
  return;
}

void full_repair( SHIP *ship, dbref enactor )
{
  int i;

  if( !Wizard(enactor) )
  {
      fnotify( enactor, "%s%sYou attempt to warp the fabric of space, but fail.%s",
             ANSI_HILITE, ANSI_RED, ANSI_NORMAL );

    return;
  }

  for (i = 0; i < NUM_SYSTEMS; ++i)
  {
      if( ship->damage[i].status!='x' && ship->damage[i].status!='0'
      && ship->damage[i].status!='X' )
      {
          repair_system(ship, i);
      }
  }
  ship->current_integrity = ship->hull_integrity;
  ship->permanent_hull_damage = 0;

  write_damage( ship );

  fnotify( enactor, "%s%sAll systems repaired.%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
}


void shutdown_reactor( SHIP *ship, dbref enactor )
{
  if( current_space == REAL && !strcmp(fetch_attribute(ship->ship_object,"UNDOCKED"),"1") ) {
     fnotify( enactor, "%s%sUnable to shutdown while undocked%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
  }
  else if( deallocate_ship( ship )) {
    /* hmm.  Didn't work.  It should have. */
    log_space( "deallocate_ship failed." );
    fnotify( enactor, "Shutdown overridden." );
  }
  else {
    fnotify( enactor, "%s%sReactor shutdown.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
  }
}


void toggle_safeties( SHIP *ship, dbref enactor )
{
    ship->eng_safeties = !ship->eng_safeties;
    if( ship->eng_safeties )
    {
        fnotify( enactor, "%s%sSafety overrides enabled.%s", ANSI_HILITE,
            ANSI_GREEN, ANSI_NORMAL );
    }
    else
    {
        fnotify( enactor, "%s%sSafety overrides disabled.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
    }
    return;
}


void toggle_smartmode( SHIP *ship, dbref enactor, char *mode )
{
    switch( tolower(mode[0]) )
    {
        default:
            fnotify( enactor, "%sSpecify 'auto', 'smart', or 'manual'.%s", ANSI_GREEN, ANSI_NORMAL );
            return;
        case 'a':
            ship->smart_alloc = 2;
            break;
        case 's':
            ship->smart_alloc = 1;
            break;
        case 'm':
            ship->smart_alloc = 0;
            break;
    }
    if( ship->smart_alloc==2 )
    {
        fnotify( enactor, "%s%sAutomatic allocation enabled.%s", ANSI_HILITE,
            ANSI_GREEN, ANSI_NORMAL );
    }
    else if( ship->smart_alloc==1 )
    {
        fnotify( enactor, "%s%sSmart allocation enabled.%s", ANSI_HILITE,
            ANSI_YELLOW, ANSI_NORMAL );
    }
    else
    {
        fnotify( enactor, "%s%sSmart allocation disabled.%s", ANSI_HILITE,
            ANSI_RED, ANSI_NORMAL );
    }
    return;
}


void master_eng_list( dbref enactor )
{
  current_space = REAL;
  if( space_list[current_space] == NULL ) {
    fnotify( enactor, "*** Real space is empty ***\n" );
  }
  else {
    fnotify( enactor, "*** Master engineering list -- Real Space ***\n" );
    all_eng_status( enactor );
  }

  current_space = SIM;
  if( space_list[current_space] == NULL ) {
    fnotify( enactor, "*** Simulator space is empty. ***" );
  }
  else {
    fnotify( enactor, "*** Master engineering list -- Simulator Space ***\n" );
    all_eng_status( enactor );
  }
}


void master_nav_list( dbref enactor )
{
  current_space = REAL;
  if( space_list[current_space] == NULL ) {
    fnotify( enactor, "*** Real space is empty ***\n" );
  }
  else {
    fnotify( enactor, "*** Master navigation list -- Real Space ***\n" );
    all_nav_status( enactor );
  }

  current_space = SIM;
  if( space_list[current_space] == NULL ) {
    fnotify( enactor, "*** Simulator space is empty. ***" );
  }
  else {
    fnotify( enactor, "*** Master navigation list -- Simulator Space ***\n" );
    all_nav_status( enactor );
  }
}


void start_reactor( SHIP *ship, dbref enactor, dbref ship_object )
{
    

  /* make sure we aren't active yet */
  if( ship != NULL )
  {
    fnotify( enactor, "%sThe reactor is already running.%s", ANSI_MAGENTA, ANSI_NORMAL );
    return;
  }

  /* check for a lock on space */
  if( space_lock[SIM] == SPACE_LOCKED )
  {
    fnotify( enactor, "%sSpace is temporarily locked.  Try again later.%s", ANSI_HILITE,
           ANSI_NORMAL );
    return;
  }

  /* okay, we're active.  Fire 'em up. */
  switch( initialize_ship( ship_object )) {
    case 0:
      /* good.  It worked.  Move on. */
	    break;
    case SERR_MALLOC:
	    /* crud.  Error.  Log it and move on. */
	    log_space( "Malloc failure in the initialize_ship function." );
	    return;
    case SERR_BAD_SHIP_OBJ:
	    /* data extraction trouble */
	    log_space( "Initialize ship failure." );
	    fnotify( enactor, "Unable to activate ship due to a corrupted"
	      " ship object." );
	    fnotify( enactor, "Contact a director ASAP." );
	    return;
  }

  /* Initialized without incident */
  fnotify( enactor, "%sReactor started and set to %s5%%%s output.%s", ANSI_CYAN,
         ANSI_YELLOW, ANSI_CYAN, ANSI_NORMAL );
}


/* cfind_ship() -- Pass a dbref of a ship object.  Fctn returns a    *
 * pointer to the corresponding structure if found, or NULL if not. */

SHIP *cfind_ship( dbref target )
{
  SHIP *ship;

  for( current_space = 0; current_space < SPACE_LIMIT; current_space++ ) {
    ship = space_list[current_space];

    while( ship != NULL ) {
	    if( ship->ship_object == target )
	      return ship;

	    ship = ship->next;
    }
  }

  return NULL;
}


/*
 * initialize_ship() -- Pass a dbref of a ship object.  Fctn allocates
 * a structure for it and appends it to the list.  Returns a zero if
 * successful, or an SERR_xxx code if not.
 */

int initialize_ship( dbref ship_object )
{
   SHIP *new_ship;
   int i,t1,t2,t3,t4;
   char *hattr;

   if(!(new_ship=(SHIP *)JMALLOC( sizeof( SHIP ))))
       return SERR_MALLOC;

    bzero( new_ship, sizeof(SHIP) );
  /* now load the data from the ship object */
  new_ship->ship_object = ship_object;

  if( !GoodObject( (new_ship->helm = attrib_dbref( ship_object, "HELM" )) )) {
    JFREE( new_ship );
    return( SERR_BAD_SHIP_OBJ );
  }

  if( !GoodObject( (new_ship->nav = attrib_dbref( ship_object, "NAV" )) )) {
    JFREE( new_ship );
    return( SERR_BAD_SHIP_OBJ );
  }

  if( !GoodObject( (new_ship->eng = attrib_dbref( ship_object, "ENG" )) )) {
    JFREE( new_ship );
    return( SERR_BAD_SHIP_OBJ );
  }

  if( !GoodObject( (new_ship->trans = attrib_dbref( ship_object, "TRANS" )) )) {
    JFREE( new_ship );
    return( SERR_BAD_SHIP_OBJ );
  }

  if( !GoodObject( (new_ship->comm = attrib_dbref( ship_object, "COMM" )) )) {
    JFREE( new_ship );
    return( SERR_BAD_SHIP_OBJ );
  }

  if( !GoodObject( (new_ship->damcon = attrib_dbref( ship_object, "DAMCON" )) )) {
    JFREE( new_ship );
    return( SERR_BAD_SHIP_OBJ );
  }
  /* ship space -- this is either real or sim space */
  if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "real" ))
    current_space = REAL;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "1" ))
    current_space = 1;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "2" ))
    current_space = 2;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "3" ))
    current_space = 3;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "4" ))
    current_space = 4;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "5" ))
    current_space = 5;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "6" ))
    current_space = 6;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "7" ))
    current_space = 7;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "8" ))
    current_space = 8;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "9" ))
    current_space = 9;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "10" ))
    current_space = 10;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "11" ))
    current_space = 11;
  else if( !strcmp( fetch_attribute( ship_object, "SPACE" ), "sim" ))
    current_space = SIM;
  else
    current_space = SIM;
    
  /* It's allocated.  Now add it to the list */
    if( space_list[current_space] == NULL ) {   /* empty list */

       space_list[current_space] = new_ship;
       space_tail[current_space] = new_ship;
       new_ship->prev = NULL;
       new_ship->next = NULL;
   }
  else {
    space_tail[current_space]->next=new_ship;
 
    new_ship->prev = space_tail[current_space];
    new_ship->next = NULL;
    space_tail[current_space] = new_ship;
     
}

  /* initialize damage registers */
  strcpy( writebuf, fetch_attribute( ship_object, "SYSTEM_DAMAGE" ));
  for( i = 0; i < NUM_SYSTEMS; i++ )
  {
    if( writebuf[i]=='\0' )
    {
        writebuf[i] = '0';
        writebuf[i+1] = '\0';
    }

    if( writebuf[i]=='x' )
      writebuf[i] = '0';

    if( ( writebuf[i] < '0' || writebuf[i] > '9' )
    && writebuf[i]!='x' && writebuf[i]!='X' )
        new_ship->damage[i].status = '0';
    else
        new_ship->damage[i].status = writebuf[i];

    new_ship->damage[i].teams = 0;
    new_ship->damage[i].maxteams = 3;

    if( i == SYSTEM_HULL )
    {
       new_ship->damage[i].maxteams = 6;
    }
    if( i == SYSTEM_PAINT_JOB )
    {
       new_ship->damage[i].maxteams = 8;
    }
    new_ship->damage[i].time_to_fix = 0;
  }
  /* initialize contact list */
   new_ship->contact_list = NULL;
   new_ship->contact_tail = NULL;
   new_ship->next_contact_number = 1;

  /* don't start with a lock */
  new_ship->locked_target = NULL;
  new_ship->pending_lock = NULL;
  new_ship->tractor_target = NULL;
  new_ship->target_system = SYSTEM_HULL;
  new_ship->bombarding = 0;

  /* start with no planets in sight */
  new_ship->orbitting = NULL;
  new_ship->planet_list = NULL;
  new_ship->planet_tail = NULL;

  /* start with no beacons in range */
  new_ship->beacon_list = NULL;
  new_ship->beacon_tail = NULL;

  /* start with no wormholes in sight */
  new_ship->transwarp_engaging = 0;
  new_ship->wormhole_list = NULL;
  new_ship->wormhole_tail = NULL;

  /* start with no asteroids */
  new_ship->asteroids_list = NULL;
  new_ship->asteroids_tail = NULL;

  /* start with no shockwaves */
  new_ship->shockwave_list = NULL;
  new_ship->shockwave_tail = NULL;

  /* start with no nebulas in range */
  new_ship->nebula_list = NULL;
  new_ship->nebula_tail = NULL;
  new_ship->nebula_visibility = 1.0;

  /* start with nobody watching us */
  new_ship->watch_list = NULL;
  new_ship->watch_tail = NULL;
  
  /* initialize flags */
  strcpy( writebuf, fetch_attribute( ship_object, "FLAGS" ));
  for( i = 0; i < NUM_FLAGS; i++ )
  {
    if( writebuf[i]=='\0' )
    {
        for(;i<NUM_FLAGS;i++)
        {
            new_ship->flags[i] = 0;
        }
        break;
    }
    if( ( writebuf[i] < '0' ) || ( writebuf[i] > '2' ) )
       new_ship->flags[i] = 0;
    else
       new_ship->flags[i] = writebuf[i] - '0';
  }

#ifdef USE_SHELL_SPECS
  /* load the template IF we're using them */
  if ( !load_ship_template( ship_object, new_ship ) )
  {
    sprintf( writebuf, "Template load failure (bad filespec?) on ship object: %s(#%d)", Name(ship_object), ship_object );
    log_space( writebuf ); 
    deallocate_ship( new_ship ); 
    return( SERR_BAD_SHIP_OBJ );
  }
#else
  if( !load_soft_specs( ship_object, new_ship ) )
  {
    sprintf( writebuf, "Spec load failure on ship object: %s(#%d)", Name(ship_object), ship_object );
    log_space( writebuf ); 
    deallocate_ship( new_ship ); 
    return( SERR_BAD_SHIP_OBJ );
  }
#endif
  /* transponder */
  strcpy( writebuf, fetch_attribute( ship_object, "TRANSPOND" ) );
  if( writebuf[0]=='\0' )
  {
      strncpy( new_ship->transponder, new_ship->owner_name, 4 );
      new_ship->transponder[0] = toupper( new_ship->transponder[0] );
      new_ship->transponder[1] = toupper( new_ship->transponder[1] );
      new_ship->transponder[2] = toupper( new_ship->transponder[2] );
      new_ship->transponder[3] = toupper( new_ship->transponder[3] );
  }
  else
  {
      strncpy( new_ship->transponder, writebuf, 4 );
  }
  new_ship->transponder[4] = '\0';
  /* initialize other values */
  strcpy( writebuf, fetch_attribute( ship_object, "NAME" ));
  strncpy( new_ship->name, writebuf, NAME_LEN-1 );
  new_ship->name[NAME_LEN-1] = '\0';
  new_ship->jammer_status=0;

  sscanf( fetch_attribute( ship_object, "HULL_DAMAGE" ), "%d %d", &t1, &t2 );
  new_ship->current_integrity = new_ship->hull_integrity - t1;
  new_ship->permanent_hull_damage = t2;
  sscanf( fetch_attribute( ship_object, "ARMOR_DAMAGE" ), "%d %d %d %d",
      &t1, &t2, &t3, &t4 );
  new_ship->armor_strength[0] = new_ship->max_armor_strength - t1;
  new_ship->armor_strength[1] = new_ship->max_armor_strength - t2;
  new_ship->armor_strength[2] = new_ship->max_armor_strength - t3;
  new_ship->armor_strength[3] = new_ship->max_armor_strength - t4;

  /* engine stats */
  new_ship->current_reactor_output_max = new_ship->reactor_output_max *
     ( 1 - ((float)( new_ship->damage[SYSTEM_ENGINE].status - '0' ) * 0.1 )) *
     ( 1 - ((float)( new_ship->damage[SYSTEM_CRYSTAL].status - '0' ) * 0.1 ));

  new_ship->reactor_setting = 5;
  new_ship->reactor_output = (int)( 0.05 *
			     new_ship->current_reactor_output_max );
  new_ship->reactor_output = UMAX( 1, new_ship->reactor_output );
  new_ship->overload_points = 0;
  new_ship->etemp_points = 0.0;
  new_ship->eng_warnings = 1; /* set warnings on */
  new_ship->eng_safeties = 1; /* set automatic overrides on */
  new_ship->smart_alloc  = 1; /* set smart allocation */

  /* battery stuff */
  new_ship->battery_discharge = 0;
  new_ship->battery_level = new_ship->battery_capacity;
  if( new_ship->battery_discharge_max==0 || new_ship->battery_capacity==0 )
  {
    new_ship->damage[SYSTEM_BATTERIES].status = 'x';
  }
  switch( new_ship->damage[SYSTEM_BATTERIES].status )
  {
    case 'x':
    case 'X':
      new_ship->damage[SYSTEM_BATTERIES].status = 'x';
      new_ship->battery_status = BTTY_NONE;
      new_ship->battery_discharge_max = 0;
      new_ship->battery_capacity = 1;
      new_ship->battery_level = 1;
      break;
    case '9':
    case '7':
      new_ship->battery_status = BTTY_DAMAGED;
      new_ship->battery_level = 0;
      break;
    case '6':
      new_ship->battery_discharge_max *= 0.5;
      new_ship->battery_status = BTTY_OFFLINE;
      break;
    case '1':
	    new_ship->battery_discharge_max *= 0.9;
	    new_ship->battery_status = BTTY_OFFLINE;
	    break;
    case '0':
	    new_ship->battery_status = BTTY_OFFLINE;
	    break;
  }

  /* general ship characteristics */
  new_ship->aspect_ratio = new_ship->size;

  /* cloak */
  if( new_ship->cloak_status == CLOAK_NONE )
  {
    new_ship->damage[SYSTEM_CLOAK].status = 'x';
  }
  /* transwarp */
  if( !new_ship->transwarp_capable )
  {
    new_ship->damage[SYSTEM_TRANSWARP].status = 'x';
  }
  if( new_ship->interdict_status==IDICT_NONE )
  {
    new_ship->damage[SYSTEM_DISSIPATOR].status = 'x';
  }
  /* tractor */
  if( new_ship->tractor_range == 0 )
  {
    new_ship->damage[SYSTEM_TRACTOR].status = 'x';
  }
  if( new_ship->warp_max < 1.0 )
  {
    new_ship->damage[SYSTEM_WARP].status = 'x';
  }
  if( new_ship->impulse_max <= 0.0 )
  {
    new_ship->damage[SYSTEM_IMPULSE].status = 'x';
  }
  if( !new_ship->landing_capable )
  {
    new_ship->damage[SYSTEM_LANDING_GEAR].status = 'x';
  }
  if( new_ship->sensor_power <= 0 )
  {
    new_ship->damage[SYSTEM_SENSORS].status = 'x';
  }
  if( new_ship->aux_sensor_power <= 0 )
  {
    new_ship->damage[SYSTEM_AUX_SENSORS].status = 'x';
  }
  /* warp drive */
  switch( new_ship->damage[SYSTEM_WARP].status )
  {
    case '1':
        new_ship->current_warp_factor = new_ship->warp_factor * 1.05;
        break;
    case '2':
        new_ship->current_warp_factor = new_ship->warp_factor * 1.25;
        new_ship->damage[SYSTEM_WARP].time_to_fix = 450;
        break;
    case '3':
    case '4':
        new_ship->current_warp_factor = new_ship->warp_factor * 1.5;
        new_ship->damage[SYSTEM_WARP].time_to_fix = 600;
        break;
    case '5':
    case '6':
        new_ship->current_warp_factor = new_ship->warp_factor * 1.75;
        new_ship->damage[SYSTEM_WARP].time_to_fix = 750;
        break;
    case '7':
    case '8':
        new_ship->damage[SYSTEM_WARP].time_to_fix = 900;
        break;
    default:
        break;
  }
  /* sensors/scanners */
  switch( new_ship->damage[SYSTEM_SENSORS].status )
  {
    case '1':
      new_ship->sensor_power *= 0.9;
	    break;
    case '2':
	    new_ship->sensor_power *= 0.75;
            new_ship->damage[SYSTEM_SENSORS].time_to_fix = 150;
	    break;
    case '3':
    case '4':
	    new_ship->sensor_power *= 0.65;
            new_ship->damage[SYSTEM_SENSORS].time_to_fix = 300;
	    break;
    case '5':
    case '6':
	    new_ship->sensor_power *= 0.5;
            new_ship->damage[SYSTEM_SENSORS].time_to_fix = 450;
	    break;
    default:
	    break;
  }
  switch( new_ship->damage[SYSTEM_AUX_SENSORS].status )
  {
    case '1':
      new_ship->aux_sensor_power *= 0.9;
	    break;
    case '2':
	    new_ship->aux_sensor_power *= 0.75;
            new_ship->damage[SYSTEM_AUX_SENSORS].time_to_fix = 150;
	    break;
    case '3':
    case '4':
	    new_ship->aux_sensor_power *= 0.65;
            new_ship->damage[SYSTEM_AUX_SENSORS].time_to_fix = 300;
	    break;
    case '5':
    case '6':
	    new_ship->aux_sensor_power *= 0.5;
            new_ship->damage[SYSTEM_AUX_SENSORS].time_to_fix = 450;
	    break;
    default:
	    break;
  }
  switch( new_ship->damage[SYSTEM_SCANNERS].status )
  {
    case '1':
            new_ship->scanner_range *= 0.9;
	    break;
    case '2':
	    new_ship->sensor_power *= 0.75;
            new_ship->damage[SYSTEM_SCANNERS].time_to_fix = 150;
	    break;
    case '3':
    case '4':
	    new_ship->sensor_power *= 0.65;
            new_ship->damage[SYSTEM_SCANNERS].time_to_fix = 300;
	    break;
    case '5':
    case '6':
	    new_ship->scanner_range *= 0.5;
            new_ship->damage[SYSTEM_SCANNERS].time_to_fix = 450;
	    break;
    default:
	    break;
  }
  switch( new_ship->damage[SYSTEM_LANDING_GEAR].status )
  {
    case '7':
        new_ship->damage[SYSTEM_LANDING_GEAR].time_to_fix = 600;
        break;
    default:
        break;
  }
  if( new_ship->dock_capacity > 0.0 || new_ship->shuttlebay_capacity > 0.0 )
    new_ship->door_status = DOORS_CLOSED;
  else
    new_ship->door_status = DOORS_NONE;

  /* ship position */
  if( current_space != REAL )
  {
  new_ship->pos.x = 0;
  new_ship->pos.y = 0;
  new_ship->pos.z = 0;
  new_ship->rotation = 0;
  }
  
  hattr = my_atr_get_raw( ship_object, "STARTPOS" );
  if( hattr != NULL )
  {
     sscanf( hattr, "%f %f %f", &(new_ship->pos.x), &(new_ship->pos.y),
      &(new_ship->pos.z));
  }
  hattr = my_atr_get_raw( ship_object, "TORPEDOES" );
  if( hattr!=NULL )
  {
     new_ship->torps_remaining = new_ship->torp_capacity - atoi( hattr );
  }
  /* rotation, only if a base */
  if( new_ship->flags[STARBASE] )
  {
     new_ship->rotation = atoi( fetch_attribute( ship_object, "ROTATION" ));
  }
  
  /* coordinate origin */
  new_ship->origin.x = 0;
  new_ship->origin.y = 0;
  new_ship->origin.z = 0;
  sscanf( fetch_attribute( ship_object, "COORDS" ), "%s %f %f %f",
	  writebuf, &(new_ship->origin.x), &(new_ship->origin.y),
	  &(new_ship->origin.z));
  strncpy( new_ship->origin_name, strlen( writebuf ) ? writebuf : "HRC" , 3 );
  new_ship->origin_name[3] = '\0';

  /* default settings for mundane registers */
  new_ship->alloc_nav = 0;
  new_ship->alloc_batt = 0;
  new_ship->alloc_helm = 0;

  new_ship->nalloc_warp = 0;
  new_ship->nalloc_fore = 0;
  new_ship->nalloc_aft = 0;
  new_ship->nalloc_port = 0;
  new_ship->nalloc_starboard = 0;

  /* default orientation */
  new_ship->warp_speed = 0.0;
  new_ship->motion.bearing = 0.0;
  new_ship->motion.elevation = 0.0;
  new_ship->motion.range=0;            /* range in this case is vector speed */
  new_ship->inc = sph_to_xyz( new_ship->motion );

  /* shield stuff */
  for( i = 0; i < 4; i++ )
  {
    new_ship->shield_level[i] = new_ship->shield_max[i];
    new_ship->shield_status[i] = SHLD_READY;
    new_ship->shield_action[i] = SHLD_STABLE;
  }

  /* adjust the capabilities of any damaged shields */
  for( i = 0; i < 4; i++ )
  {
    switch( new_ship->damage[SYSTEM_SHIELD_FORE + i].status )
    {
            case 'x':
            case 'X':
	    case '9':
            case '8':
	    case '7':
	      new_ship->shield_status[i] = SHLD_DAMAGED;
              new_ship->shield_level[i] = 0;
	      break;
	    case '6':
	      new_ship->shield_max[i] *= 0.5;
	      new_ship->shield_max_charge[i] *=0.5;
	      break;
            case '4':
            case '3':
              new_ship->shield_max[i] *= 0.65;
              new_ship->shield_max_charge[i] *= 0.65;
              break;
            case '2':
              new_ship->shield_max[i] *= 0.75;
              new_ship->shield_max_charge[i] *= 0.75;
              break;
	    case '1':
	      new_ship->shield_max[i] *= 0.9;
	      new_ship->shield_max_charge[i] *=0.9;
	break;
	    case '0':
	      break;
	    default:
	      /* Hmm.  This shouldn't really happen.  Just set it to '0' */
	      new_ship->damage[SYSTEM_SHIELD_FORE +i].status = '0';
	      break;
    }
  }
  /* helm allocation stuff */
  new_ship->halloc_phasers = 0;
  new_ship->halloc_photons = 0;
  new_ship->halloc_tractor = 0;
  new_ship->num_phasers_online = 0;
  new_ship->num_photons_online = 0;
  

  /* phaser stuff */
  for( i = 0; i < new_ship->number_of_phasers; i++ )
  {
    new_ship->phaser[i].status = PHASER_OFFLINE;
    new_ship->phaser[i].charge = 0;
    
    /* check for damage */
    switch( new_ship->damage[SYSTEM_GUN_0 + i].status )
    {
            case 'x':
            case 'X':
	    case '9':
	    case '8':
	    case '7':
	      new_ship->phaser[i].status = PHASER_DAMAGED;
              new_ship->damage[SYSTEM_GUN_0+i].time_to_fix = 600;
	      break;
	    case '6':
	    case '5':
	      new_ship->phaser[i].power *= 0.5;
	      new_ship->phaser[i].charge_per_turn *= 0.5;
	      new_ship->phaser[i].range *= 0.5;
              new_ship->damage[SYSTEM_GUN_0+i].time_to_fix = 450;
	      break;
            case '4':
            case '3':
	      new_ship->phaser[i].power *= 0.65;
	      new_ship->phaser[i].charge_per_turn *= 0.65;
	      new_ship->phaser[i].range *= 0.65;
              new_ship->damage[SYSTEM_GUN_0+i].time_to_fix = 300;
	      break;
            case '2':
	      new_ship->phaser[i].power *= 0.75;
	      new_ship->phaser[i].charge_per_turn *= 0.75;
	      new_ship->phaser[i].range *= 0.75;
              new_ship->damage[SYSTEM_GUN_0+i].time_to_fix = 150;
	      break;
	    case '1':
	      new_ship->phaser[i].power *= 0.9;
	      new_ship->phaser[i].charge_per_turn *= 0.9;
	      new_ship->phaser[i].range *= 0.9;
              break;
    }
  }

  for( i = new_ship->number_of_phasers; i < MAX_PHASERS; i++ )
    new_ship->damage[SYSTEM_GUN_0 + i].status = 'x';

  /* photon stuff */
  new_ship->reloading_tube = NO_RELOAD;
  new_ship->turns_to_reload = 0;
  new_ship->auto_online = FALSE;
  new_ship->auto_reload = TRUE;

  for( i = 0; i < new_ship->number_of_photons; i++ ) {
    new_ship->photon[i].status = PHOTON_LOADED;
    new_ship->photon[i].charge = 0;
    new_ship->photon[i].turns_charged = 0;

    /* check for damage */
    switch( new_ship->damage[SYSTEM_TORP_0 + i].status )
    {
            case 'x':
            case 'X':
	    case '9':
	    case '7':
	      new_ship->photon[i].status = PHOTON_DAMAGED;
	      break;
	    case '1':
	      new_ship->photon[i].base_accuracy *= 0.9;
	break;
    }
  }

  for( i = new_ship->number_of_photons; i < MAX_PHOTONS; i++ )
    new_ship->damage[SYSTEM_TORP_0 + i].status = 'x';

  if (new_ship->number_of_phasers == 0)
  {
    new_ship->phaser[0].power = 0; 
    new_ship->phaser[0].range = 0; 
    new_ship->phaser[0].range_percent = 1.0; 
    new_ship->phaser[0].charge_per_turn = 0;
  }
  if (new_ship->number_of_photons == 0)
  {
    new_ship->photon[0].power = 0;
    new_ship->photon[0].range = 0;
    new_ship->photon[0].base_accuracy = 1.0;
    new_ship->photon[0].charge_per_turn = 0; 
  }

  /* initialize comm configuration */
  for( i = 0; i < MAX_CHANNEL; i++ ) {
    new_ship->channel[i].frequency = 0;
    new_ship->channel[i].send_status= CS_COMM_ONLY;
    new_ship->channel[i].receive_status = CR_COMM_ONLY;
    strcpy( new_ship->channel[i].label, "none" );
  }

  /* initialize damage control team status */
  for( i = 0; i < new_ship->damcon_teams; i++ )
    new_ship->team[i] = -1;

  /* start the autopilot in the off position */
  new_ship->on_autopilot = FALSE;


    /* initialize sensornet stuff */
    new_ship->server.ship = NULL;
    new_ship->server.status = SNS_OFF;
    new_ship->active_clients = 0;
  
    for( i = 0; i < (int) new_ship->max_clients; i++ ) {
      new_ship->clients[i].ship = NULL;
      new_ship->clients[i].status = SNS_OFF;
    }
 
  if (new_ship->current_integrity < 15)
  {
    new_ship->flags[DISABLED] = 1;
  }

  /*SubSpace stuff by Howie: howie69@hotmail.com */
   new_ship->numsubchan = 0;

    /* Need a loop here to initialize the array of subspace stuff  */
  for( i = 0; i < MAX_SUB_CHANS ; i++ )
  {
    new_ship->subspace[i].channel = 0;
    strcpy(new_ship->subspace[i].label," ");
  }

  /* Wait a minute here and make sure that nothing critical was messed *
   * up in the ship object.  We wouldn't want to crash the mush just   *
   * because someone was a little careless designing something.        */

  if( new_ship->aspect_ratio == 0.0 )
    sprintf( writebuf, "Bad aspect_ratio #%d", ship_object );
  else if( new_ship->sensor_power == 0.0 )
    sprintf( writebuf, "Bad sensor_power #%d", ship_object );
  else if( new_ship->max_overload_points == 0 )
    sprintf( writebuf, "Bad max_overload_points #%d", ship_object );
  else if( new_ship->warp_factor == 0.0 )
    sprintf( writebuf, "Bad warp_factor #%d", ship_object );
  else if( new_ship->hull_integrity == 0 )
    sprintf( writebuf, "Bad hull_integrity #%d", ship_object );
  else
    return 0;  /* everything checks out */

  /* if it gets to here there is a problem with the ship object */
  log_space( writebuf );
  deallocate_ship( new_ship );
  return( SERR_BAD_SHIP_OBJ );
}

float calc_warp_speed( float warp_factor, int power )
{
    if( warp_factor > 50.0 )
    {
        return 0.0;
    }
    else
    {
        return sqrt(((((float)power+0.5)/warp_factor) - WARP_CONST)/10.0);
    }
}

/* ship_specs() -- Pass a ship pointer and a enactor dbref.  Fctn gives
 * enactor the specs on ship.
 *
 * JMS 23 Aug 93 - read names from struct instead of ship object
 */

void ship_specs( SHIP *ship, dbref enactor )
{
  float speed_optm,speed_full,speed_max,speed_batt_max,target_size,torp_erange;
  char cloak[10], cargo[10], dock_capacity[5], shuttlebay_capacity[5];

  if( ship->locked_target!=NULL )
  {
     target_size = ship->locked_target->listref->size;
  }
  else
  {
     target_size = 1.0;
  }
  torp_erange = (ship->photon[0].range * target_size) - ( (ship->photon[0].range * target_size) / ship->photon[0].base_accuracy );
  torp_erange = UMAX( 0, torp_erange );
  sprintf( cargo, "%-7.7s", 
	   my_atr_get_raw( ship->ship_object, "CARGO_CAPACITY" ) );
  if ( !strncmp( cargo, "#-1", 3 )) {
    sprintf( cargo, "0" );
  }
  speed_optm = calc_warp_speed( ship->current_warp_factor, 
		(int) (((float) ship->reactor_stress_level)*0.01*
		((float) ship->reactor_output_max)) );
  speed_full = calc_warp_speed( ship->current_warp_factor, 
		(int) ship->reactor_output_max );
  speed_max = calc_warp_speed( ship->current_warp_factor, 
		(int) (((float) ship->reactor_setting_limit)*0.01*
		((float) ship->reactor_output_max)) );
  speed_batt_max = calc_warp_speed( ship->current_warp_factor,
		(int) ((((float) ship->reactor_setting_limit)*0.01*
		((float) ship->reactor_output_max))
		+ ship->battery_discharge_max) );
  speed_optm = UMIN( speed_optm, ship->warp_max );
  speed_full = UMIN( speed_full, ship->warp_max );
  speed_max = UMIN( speed_max, ship->warp_max );
  speed_batt_max = UMIN( speed_batt_max, ship->warp_max );
  speed_optm = UMAX( 0.0, speed_optm );
  speed_full = UMAX( 0.0, speed_full );
  speed_max = UMAX( 0.0, speed_max );
  speed_batt_max = UMAX( 0.0, speed_batt_max );
  if( ship->cloak_status == CLOAK_NONE )
  {
    sprintf( cloak, "None" );
  }
  else
  {
    sprintf( cloak, "%d", ship->cloak_cost );
  }
  if( ship->door_status == DOORS_NONE )
  {
    sprintf( dock_capacity, " None" );
  }
  else
  {
    sprintf( dock_capacity, "%6.2f", ship->dock_capacity );
  } 

  if( ship->shuttlebay_capacity > 0 )
  {
    sprintf( shuttlebay_capacity, "%4.2f", ship->shuttlebay_capacity);
  }
  else
  {
    sprintf( shuttlebay_capacity, " None" );
  }
 
  fnotify( enactor, "*******************************************************************************" );
  fnotify( enactor, "Name  : %-21.21s **  Size: %5.2f  **  Landing Capable:  %3s", 
                 ship->name, ship->size,
		 ( ship->landing_capable ? "YES" : "NO" ) );
  fnotify( enactor, "Class : %-21.21s **  Hull: %5d  **  Shuttlebay Capacity:  %s",  
      ship->class, ship->hull_integrity, shuttlebay_capacity);
  fnotify( enactor, "Type  : %-21.21s **  Armr: %5d  **  Dock Capacity: %6.6s",
		 ship->type, ship->max_armor_strength, dock_capacity );
  fnotify( enactor, "Empire: %-21.21s **               **  Cargo Capacity :  %-7s",
		 ship->owner_name, cargo );
  fnotify( enactor, "**************POWER/ENGINES****************************************************" );
  fnotify( enactor, "Optm: %3d (%5d)  Batteries : %6d (%4d)  **  Optm: %6.3f  Safe   : %6.3f",
		 ship->reactor_stress_level,
		 (int) (((float) ship->reactor_stress_level)*
		 0.01*((float) ship->reactor_output_max)), 
		 ship->battery_capacity,
		 ship->battery_discharge_max, speed_optm, 
		 UMIN(ship->etemp_speed,ship->warp_max) );
  fnotify( enactor, "Full: %3d (%5d)  Stress Pts: %6d (%4.1f)  **  Full: %6.3f  BattMax: %6.3f",
		 100, ship->reactor_output_max, (int) ship->max_overload_points,
		 (float) ship->reactor_overload_penalty, speed_full, 
		 speed_batt_max );
  fnotify( enactor, "Max : %3d (%5d)                             **  Max : %6.3f  Factor : %6.3f",
		 ship->reactor_setting_limit, 
		 (int) (((float) ship->reactor_setting_limit)
		 *0.01*((float) ship->reactor_output_max)), 
		 (float) speed_max,
		 (float) ship->current_warp_factor );  
  fnotify( enactor, "**MISCELLANEOUS****************************************************************" ); 
  fnotify( enactor, "Transporter Range:     %5d            Tractor Range: %5d", (int)ship->transporter_range, (int)ship->tractor_range ); 
  fnotify( enactor, "Damage Control Teams:  %5d", ship->damcon_teams ); 
    fnotify( enactor, "****PHASERS*********PHOTONS****************SHIELDS**************COMM/SENSORS***" );
  fnotify( enactor, "Number: %6d ** Number: %6d ** Max     :  %5d ** Sensor  Rng: %7ld",
		 ship->number_of_phasers, ship->number_of_photons,
		 ship->shield_max[0], (long int) ship->sensor_power );
  fnotify( enactor, "Power : %6d ** Power : %6d ** Charge  :  %5d ** Scanner Rng: %7ld",  
		 ship->phaser[0].power, ship->photon[0].power,
		 ship->shield_max_charge[0], (long int)ship->scanner_range );
	/* +++ Maverick +++ */
  fnotify( enactor, "ERange: %6d ** ERange: %6d ** Hold Up :  %5d ** Obfuscation: %6d%%",
		 (int) (((float) ship->phaser[0].range)*0.8), 
		 (int) torp_erange,
		 (int) (((float) ship->shield_max[0])
			*0.02/ship->shield_factor + 0.999999),
		 (int) ( 100-((float) ship->nebula_visibility)*100) );
  fnotify( enactor, "MRange: %6d ** MRange: %6d ** HoldDown:  %5d ** Comm Range : %7ld",
		 ship->phaser[0].range, ship->photon[0].range,
		 0,
		 (long int) ship->transmitter_range );
	/* --- Maverick --- */
  fnotify( enactor, "Delvry: %5d%% ** Accur : %6.3f ** Factor  :  %5.2f ** ",
		 (int) (((float) ship->phaser[0].range_percent)*100.0+0.5),
		 (float) ship->photon[0].base_accuracy,
		 (float) ship->shield_factor );
  fnotify( enactor, "Charge: %6d ** Charge: %6d ** Cloak   :  %5s ** ",
		 ship->phaser[0].charge_per_turn, 
		 ship->photon[0].charge_per_turn, cloak );
  fnotify( enactor, "*******************************************************************************" );

  return;
}


/*
 * deallocate_ship() -- Pass a dbref of a ship object.  Fctn deallocates
 * the block and reknits the linked list around it.  Returns a 0 if
 * successful, or an SERR_xxx code otherwise.
 *
 * JMS 22 Aug 93 - kill watches in BOTH directions. (was a bug)
 * JMS 26 Sep 93 - kill sensornet links
 */

int deallocate_ship( SHIP *ship )
{
    CONTACT *contact_a,*contact_b;
    SHIP *target,fake_ship;
    PLANET *planet;

    /* remove our contact from the list of other ships since we'll be gone */
    target = space_list[current_space];
    for(target=space_list[current_space];target!=NULL;target=target->next)
    {
        contact_a = target->contact_list;

        for(contact_a=target->contact_list;contact_a!=NULL;contact_a=contact_a->next)
        {
            if( contact_a->listref == ship )
            {
                remove_contact( target, contact_a );
                contact_a = NULL;
                break;
            }
        }
    }
    for(planet=planet_list[current_space];planet!=NULL;planet=planet->next)
    {
        fake_ship=planet_fake_ship( planet );
        if( ( contact_a=find_contact(&fake_ship,ship) )!=NULL )
        {
            remove_contact( &fake_ship, contact_a );
            planet->contact_list = fake_ship.contact_list;
            planet->contact_tail = fake_ship.contact_tail;
        }
    }
    /* free all sensor contacts */
    contact_a = ship->contact_list;
    while( ship->contact_list!=NULL )
    {
        remove_contact( ship, ship->contact_list );
    }
    while( ship->nebula_list!=NULL )
    {
        remove_nebula( ship, ship->nebula_list->listref );
    }
    while( ship->wormhole_list!=NULL )
    {
        remove_wormhole( ship, ship->wormhole_list->listref );
    }
    while( ship->asteroids_list!=NULL )
    {
        remove_asteroids( ship, ship->asteroids_list->listref );
    }
    if( space_list[current_space] == space_tail[current_space] )
    {
        /* only one entry */
        space_list[current_space] = NULL;
        space_tail[current_space] = NULL;
    }
    else if( ship == space_list[current_space] )
    {   /* ship is first */
        space_list[current_space] = ship->next;
        space_list[current_space]->prev = NULL;
    }
    else if( ship == space_tail[current_space] )
    {   /* ship is last */
        space_tail[current_space] = ship->prev;
        space_tail[current_space]->next = NULL;
    }
    else
    { /* ship centered */
        ship->prev->next = ship->next;
        ship->next->prev = ship->prev;
    }

    /* now update the damage register */
    write_damage( ship );

    /* kill off any watches, either by or on the dead ship */
    while( ship->watch_list != NULL )
    {
        if( ship->watch_list!=NULL )
        {
            remove_watch_ref( ship, ship->watch_list->listref );
        }
        if( ship->watch_list!=NULL )
        {
            remove_watch_ref( ship->watch_list->listref, ship );
        }
    }
    JFREE( ship );
    return 0;
}

/*
 * set_reactor_output() -- Pass a pointer to a ship, dbref of the enactor, and
 * an integer value for the reactor setting.  Fctn will deal with it and
 * notify the enactor of any action taken.  No return value.
 */

void set_reactor_output( SHIP *ship, dbref enactor, int setting )
{
  if( setting < 5 )
  {
    fnotify( enactor, "The minimum output level is 5%c.", '%' );
    set_reactor_output( ship, enactor, 5 );
    return;
  }
  else if( setting > ship->reactor_setting_limit )
  {
    sprintf( writebuf, "The maximum output level is %d%c.",
	     ship->reactor_setting_limit, '%' );
    fnotify( enactor, writebuf );
    set_reactor_output( ship, enactor, ship->reactor_setting_limit );
    return;
  }
  else
  {
    ship->reactor_setting = setting;

    /* if cloaked, update aspect ratio */
    if( ship->cloak_status == CLOAK_ON )
    {
        ship->aspect_ratio = ship->size * ship->cloak_ratio * (float)( ship->reactor_setting )
			 / 3000.0;
    }
    ship->reactor_output = (int)(ship->current_reactor_output_max
			   * setting / 100);
    ship->reactor_output = UMAX( 1, ship->reactor_output );
    fnotify( enactor, "%s%sReactor output level set to %s%d%%%s",ANSI_HILITE,
           ANSI_MAGENTA, ANSI_YELLOW, setting, ANSI_NORMAL );
    fnotify( enactor, "%s%sPower available: %s%d%s", ANSI_HILITE, ANSI_MAGENTA,
           ANSI_YELLOW, ship->reactor_output, ANSI_NORMAL );

    /* overallocation check */
    eng_alloc_check( ship, enactor );
    return;
  }
}


/*
 * eng_status() -- Pass a pointer to the ship and the dbref of the enactor.
 * Fctn gives enactor a status report for the ship.  No return value.
 *
 * JMS 26 Aug 93 - complete rewrite
 */

void eng_status( SHIP *ship, dbref enactor )
{
  ship->reactor_output = UMAX( 1, ship->reactor_output );
  /* new eng status by Howie*/
  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s[Engineering Status]%s~~%s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL);
  fnotify( enactor, "%sReactor Status           Allocations        %%        Allocated Power%s", ANSI_CYAN, ANSI_NORMAL);
  fnotify( enactor,"%s--------------------------------------------------------------------%s", ANSI_WHITE, ANSI_NORMAL ); 
  fnotify( enactor, "%sReactor Setting:%s%4d%%          %sHelm:%s%8d%%             %4d%s", ANSI_CYAN, ANSI_WHITE, ship->reactor_setting, ANSI_CYAN, ANSI_WHITE, 100 * ship->alloc_helm / ship->reactor_output, ship->alloc_helm, ANSI_NORMAL);
  fnotify( enactor, "%sReactor Output:%s%6d    %sNavigation:%s%8d%%             %4d%s", ANSI_CYAN, ANSI_WHITE, ship->reactor_output, ANSI_CYAN, ANSI_WHITE, 100 * ship->alloc_nav / ship->reactor_output, ship->alloc_nav, ANSI_NORMAL);
  fnotify( enactor, "%sReactor Stress:%s%5d%%     %sAux Power:%s%8d%%             %4d%s", ANSI_CYAN, ANSI_WHITE, 100 * ship->overload_points / ship->max_overload_points, ANSI_CYAN, ANSI_WHITE, 100 * ship->alloc_batt / ship->reactor_output, ship->alloc_batt, ANSI_NORMAL);
  if( ship->battery_status == BTTY_ONLINE )
   fnotify( enactor, "%s                       Unused Power:%s%8d%%             %4d%s", ANSI_CYAN, ANSI_WHITE, (100 * ((ship->reactor_output + ship->battery_discharge_max) - (ship->alloc_nav + ship->alloc_helm + ship->alloc_batt)) / (ship->reactor_output + ship->battery_discharge_max)), (ship->reactor_output + ship->battery_discharge_max) - (ship->alloc_nav + ship->alloc_helm + ship->alloc_batt), ANSI_NORMAL);
  else
   fnotify( enactor, "%s                       Unused Power:%s%8d%%             %4d%s", ANSI_CYAN, ANSI_WHITE, (100 * ((ship->reactor_output + ship->battery_discharge) - (ship->alloc_nav + ship->alloc_helm + ship->alloc_batt)) / (ship->reactor_output + ship->battery_discharge)), (ship->reactor_output + ship->battery_discharge) - (ship->alloc_nav + ship->alloc_helm + ship->alloc_batt), ANSI_NORMAL);
  fnotify( enactor, "%s--------------------------------------------------------------------%s", ANSI_WHITE, ANSI_NORMAL ); 
  fnotify( enactor,"%sShip Name:%s %-15s             %sClass: %s%s", ANSI_CYAN, ANSI_NORMAL, ship->name, ANSI_CYAN, ANSI_NORMAL, ship->class);
  fnotify( enactor, "%sEmpire:%s    %-15s             %sType:%s  %s", ANSI_CYAN, ANSI_NORMAL, ship->owner_name, ANSI_CYAN, ANSI_NORMAL, ship->type);
  fnotify( enactor, "%sOpt Reactor:%s% -14d             %sMax Reactor:%s %d%s", ANSI_CYAN, ANSI_WHITE, ship->reactor_stress_level, ANSI_CYAN, ANSI_WHITE, ship->reactor_setting_limit, ANSI_NORMAL);
  fnotify( enactor, "%s--------------------------------------------------------------------%s", ANSI_WHITE, ANSI_NORMAL ); 
  fnotify( enactor, "%sHull Integrity:%s  %d%% (%d/%d)%s", ANSI_CYAN, ANSI_WHITE, (100 * ship->current_integrity/ship->hull_integrity), ship->current_integrity, ship->hull_integrity, ANSI_NORMAL);
if( ship->max_armor_strength > 0 )
{  
notify( enactor, tprintf("%sArmor Strength:%s  F%d (%d%%) A%d (%d%%) P%d (%d%%) S%d (%d%%)%s", ANSI_CYAN, ANSI_WHITE, ship->armor_strength[0], (100*ship->armor_strength[0]/ship->max_armor_strength), ship->armor_strength[1], (100*ship->armor_strength[1]/ship->max_armor_strength), ship->armor_strength[2], (100*ship->armor_strength[2]/ship->max_armor_strength), ship->armor_strength[3], (100*ship->armor_strength[3]/ship->max_armor_strength), ANSI_NORMAL));
 }
  fnotify( enactor, "%sEngine Temp: %s%5d%% (%.0f/%.0f)%s", ANSI_CYAN, ANSI_WHITE, (int)(100.0 * ship->etemp_points / ship->max_etemp_points), ship->etemp_points, ship->max_etemp_points, ANSI_NORMAL);

  switch( ship->battery_status )
  {
    case BTTY_OFFLINE:
      fnotify( enactor, "%sAuxillary Power: %s%5d/%-5d (%d%%)  [%s%sOFFLINE%s%s]%s", ANSI_CYAN, ANSI_WHITE, ship->battery_level,  ship->battery_capacity, ( 100 * ship->battery_level / ship->battery_capacity ), ANSI_HILITE, ANSI_RED, ANSI_NORMAL, ANSI_WHITE, ANSI_NORMAL );
      break;
    case BTTY_ONLINE:
       fnotify( enactor, "%sAuxillary Power: %s%5d/%-5d (%d%%)  [%s%sONLINE%s%s]%s", ANSI_CYAN, ANSI_WHITE, ship->battery_level,  ship->battery_capacity, ( 100 * ship->battery_level / ship->battery_capacity ), ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL, ANSI_WHITE, ANSI_NORMAL );

      fnotify( enactor, "%s              Use:   %s%3d/%3d  (%d%%)%s", ANSI_CYAN, ANSI_WHITE, ship->battery_discharge, ship->battery_discharge_max, (100 * ship->battery_discharge / ship->battery_discharge_max), ANSI_NORMAL);
      break;
    case BTTY_DAMAGED:
      fnotify( enactor, "%sAuxilary Power: %sDamaged%s [%sUNAVAILABLE%s%s]%s", ANSI_CYAN, ANSI_WHITE, ANSI_HILITE, ANSI_RED, ANSI_NORMAL, ANSI_WHITE, ANSI_NORMAL );
      break;
    case BTTY_NONE:
      break;
    default:
      /* log the error */
      log_space( "Error.  Bad battery status." );
      break;
  }
  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);

}


/*
 * eng_allocate() -- Pass a pointer to the ship, the dbref of the enactor, and
 * allocations for helm, nav, and batteries.  Fctn sets the proper allocation
 * levels and notifies the enactor.  No return value.
 */

void eng_allocate( SHIP *ship, dbref enactor, int helm, int nav, int batt )
{
  int available_power;
  long int total_allocation;
  float power_ratio;   /* fraction the the allocation to receive *
			* in the case of over-allocation.        */
  int old_nav, old_helm;
  dbref helmsman, navigator;

  if( (helm > MAXINT/3) || (nav > MAXINT/3) || (batt > MAXINT)/3 )
  {
    fnotify( enactor, "%s%sExcessive energy can be hazardous to your health.%s",
           ANSI_HILITE, ANSI_BLACK, ANSI_NORMAL ); 
    return;
  }

  /* calculate max available power */
  available_power = ship->reactor_output;
  if( ship->battery_status == BTTY_ONLINE ) {
    if( ship->battery_discharge_max <= ship->battery_level )
       available_power += ship->battery_discharge_max;
    else
       available_power += ship->battery_level;
  }

  /* if disabled, no power is available */
  if( ship->flags[DISABLED] )
    available_power = 0;

  /* set negative allocations to zero */
  if( helm < 0 )  helm = 0;
  if( nav < 0 ) nav = 0;
  if( batt < 0 ) batt = 0;

  /* calculate total allocation */
  total_allocation = helm + nav + batt;

  /* if allocation > power, apply cuts */
  if( total_allocation > available_power ) {
    power_ratio = (float)( (float)available_power /
		  (float)total_allocation );
    helm = (int)( (float)helm * power_ratio );
    nav = (int)( (float)nav * power_ratio );
    batt = (int)( (float)batt * power_ratio );
  }

  /* save the old values */
  old_nav = ship->alloc_nav;
  old_helm = ship->alloc_helm;

  /* assign the new values */
  ship->alloc_helm = helm;
  ship->alloc_nav = nav;
  ship->alloc_batt = batt;

  /* update battery discharge */
  ship->battery_discharge = helm + nav + batt - ship->reactor_output;
  if( ship->battery_discharge < 0 )
    ship->battery_discharge = 0;

  /* notify the enactor */
  fnotify( enactor, "%s%sTotal available power: %s%d%s", ANSI_HILITE, ANSI_MAGENTA, ANSI_YELLOW,
           available_power, ANSI_NORMAL );
  fnotify( enactor, "%s%sAllocated to Helm: %s%d%s  Nav: %s%d%s  Batteries: %s%d%s\n",
	   ANSI_HILITE, ANSI_MAGENTA, ANSI_YELLOW, helm,
           ANSI_MAGENTA, ANSI_YELLOW, nav,
           ANSI_MAGENTA, ANSI_YELLOW, batt, ANSI_NORMAL );

  /* check for shortfalls at other stations */
  if( old_nav > nav )
    nav_alloc_check( ship );

  if( old_helm > helm )
    helm_alloc_check( ship );

  /* check for a power increase at other stations */
  if( old_helm < helm ) {
    helmsman = attrib_dbref( ship->helm, "XB" );
    fnotify( helmsman, "%sNew helm allocation is %s%d%s.%s", ANSI_CYAN, ANSI_MAGENTA,
           helm, ANSI_CYAN, ANSI_NORMAL );
  }

  if( old_nav < nav ) {
    navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

    fnotify( navigator, "%sNew nav allocation is %s%d%s.%s", ANSI_GREEN, ANSI_YELLOW,
           nav, ANSI_GREEN, ANSI_NORMAL );
  }

}


/*
 * eng_alloc_check() -- Checks to make sure that a change in engineering
 * status doesn't allow overallocation.  Call it whenever something happens
 * that might produce an energy shortfall.
 */

void eng_alloc_check( SHIP *ship, dbref enactor )
{
  int allocation;
  int available_power;

  /* check for unknown engineer */
  if( enactor == -1 ) {
    /* we don't know who the engineer is.  Do a match */
    enactor = match_result(HOWIE, my_atr_get_raw(ship->eng, "XB"), NOTYPE, MAT_ABSOLUTE);
  }

  /* recalculate reactor_output */
  ship->reactor_output = (int)( ship->current_reactor_output_max *
			 ship->reactor_setting / 100 );
  ship->reactor_output = UMAX( 1, ship->reactor_output );
  available_power = ship->reactor_output;
  if( ship->battery_status == BTTY_ONLINE ) {
    if( ship->battery_level < ship->battery_discharge_max )
       available_power += ship->battery_level;
    else
       available_power += ship->battery_discharge_max;
  }

  allocation = ship->alloc_helm + ship->alloc_nav + ship->alloc_batt;

  if( allocation > available_power ) {
    fnotify( enactor, "%s%sDrop in net power.  Global energy reallocation performed.%s",
           ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL );
    eng_allocate( ship, enactor, ship->alloc_helm, ship->alloc_nav,
		  ship->alloc_batt );
    nav_alloc_check( ship );
    return;
  }
  else {
    if( allocation > ship->reactor_output )
      ship->battery_discharge = allocation - ship->reactor_output;
    else
      ship->battery_discharge = 0;
    return;
  }
}

/*
 * load_ship_template
 *
 *  loads a ship template from a disk file.  Returns non-zero if successful.
 *
 * JMS 21 Sep 93 - read damage control teams too
 * JMS 21 Aug 93
 */

int load_ship_template( dbref ship_object, SHIP *ship )
{
INSHIP inship;
FILE *fp;
int i;

  sprintf( writebuf, "%s/%s%s", TEMPLATE_DIRECTORY, my_atr_get_raw( ship_object,
	   "FILESPEC" ), TEMPLATE_EXTENDER );
  
  if(( fp = fopen( writebuf, "rb" )) == NULL )
    return( 0 );

  bzero( &inship, sizeof( INSHIP ) );
  fread( &inship, sizeof( INSHIP ), 1, fp );
  fclose( fp );

  if( inship.version != VERSION_CHAR ) {
    log_space( "bad template load: %s", writebuf );
    return( 0 );
  }

  /* the template is loaded.  move the data across from INSHIP to SHIP */
  strncpy( ship->class, inship.class_name, CLASS_LEN-1 );
  strncpy( ship->type, inship.type, TYPE_LEN-1 );
  strncpy( ship->short_type, inship.short_type, SHORT_TYPE_LEN-1 );
  strncpy( ship->owner_name, inship.builder, OWNER_LEN-1 );

  ship->class[CLASS_LEN-1] = '\0';
  ship->type[TYPE_LEN-1] = '\0';
  ship->owner_name[OWNER_LEN-1] = '\0';

  ship->owner = inship.owner;
  
  ship->hull_integrity = inship.hull_points + atoi(fetch_attribute(ship_object, "ADD_HULL"));
  ship->max_armor_strength = inship.armor_points + atoi(fetch_attribute(ship_object, "ADD_ARMOR"));
  ship->armor_type = inship.armor_type;
  ship->durability = inship.durability;
  ship->reactor_output_max = inship.reactor_power;

  ship->max_overload_points = inship.overload_points;
  ship->reactor_setting_limit = inship.maximum_setting;
  ship->reactor_stress_level = inship.normal_setting;
  ship->reactor_overload_penalty = inship.overload_penalty;

  /* battery stuff */
  ship->battery_capacity = inship.battery_power;
  ship->battery_discharge_max = inship.battery_discharge_rate;
  atr_add(ship->ship_object, "WA", tprintf("%i", inship.battery_discharge_rate), HOWIE, NOTHING);

  /* general ship characteristics */
  ship->warp_factor = inship.warp_factor;
  ship->warp_accel = inship.warp_accel + atoi(fetch_attribute(ship_object, "ADD_ACCEL"));
  ship->warp_decel = inship.warp_decel;
  ship->current_warp_factor = ship->warp_factor;
  ship->warp_max = UMAX( inship.max_speed, 0.0 );
  ship->impulse_max = UMIN( inship.max_impulse, ship->warp_max );
  ship->etemp_speed = inship.etemp_speed;
  ship->max_etemp_points = inship.etemp_points;
  ship->transwarp_capable = inship.transwarp_capable;
  ship->transwarp_tolerance = inship.transwarp_tolerance;
  ship->yaw_dps = inship.yaw_dps;
  ship->pitch_dps = inship.pitch_dps;
  ship->size = inship.hull_size;
  atr_add(ship->ship_object, "SIZE", tprintf("%f", inship.hull_size), HOWIE, NOTHING);

  /* cloak */
  ship->cloak_status = ( inship.cloak_present ? CLOAK_OFF : CLOAK_NONE );
  ship->cloak_cost = inship.cloak_cost;
  ship->cloak_ratio = inship.cloak_ratio;

  /* interdict */
  ship->interdict_status = inship.interdict_range ? IDICT_OFF : IDICT_NONE;
  ship->interdict_range = inship.interdict_range;
  ship->interdict_speed = inship.interdict_speed;

  /* sensors */
  ship->sensor_power = inship.sensor_range;
  ship->aux_sensor_power = inship.aux_sensor_range;
  ship->sensor_arc = inship.sensor_arc;
  ship->aux_sensor_arc = inship.aux_sensor_arc;
  ship->scanner_range = inship.scanner_range;
  atr_add(ship->ship_object, "WK", tprintf("%f", inship.sensor_range), HOWIE, NOTHING);
  atr_add(ship->ship_object, "WL", tprintf("%f", inship.scanner_range), HOWIE, NOTHING); 
  atr_add(ship->ship_object, "WM", tprintf("%f", inship.aux_sensor_range), HOWIE, NOTHING);

  /* comm/transporter */
  ship->transmitter_range = inship.transmitter_range;
  ship->receiver_sensitivity = inship.receiver_sensitivity;
  ship->transporter_range = inship.transporter_range;
  ship->tractor_range = inship.tractor_range;
  ship->max_clients = inship.max_clients;
  ship->tractor_mode = MODE_TRACTOR;

  /* misc stuff */
  ship->dock_capacity = inship.dock_capacity;
  ship->dock_max_size = inship.dock_max_size;
  ship->shuttlebay_capacity = inship.shuttlebay_capacity;
  ship->landing_capable = inship.landing_capable;
  atr_add(ship->ship_object, "CARGO_CAPACITY", tprintf("%d", inship.cargo_capacity), HOWIE, NOTHING);

  /* shield stuff */
  ship->shield_factor = inship.shield_factor;
  atr_add(ship->ship_object, "WF", tprintf("%d", inship.shield_power), HOWIE, NOTHING);
  atr_add(ship->ship_object, "VN", tprintf("%d", inship.shield_charge_rate), HOWIE, NOTHING);

  for( i = 0; i < 4; i++ ) {
    ship->shield_max[i] = inship.shield_power;
    ship->shield_max_charge[i] = inship.shield_charge_rate;
  }

  /* phaser stuff */
  strcpy( ship->phaser_string, inship.gun_name );
  ship->number_of_phasers = inship.num_guns;
  atr_add(ship->ship_object, "WU", tprintf("%d", inship.gun_power), HOWIE, NOTHING);
  atr_add(ship->ship_object, "WV", tprintf("%ld", inship.gun_range), HOWIE, NOTHING);  
  atr_add(ship->ship_object, "VO", tprintf("%d", inship.gun_charge_rate), HOWIE, NOTHING);
  if( ship->number_of_phasers > MAX_PHASERS )
    ship->number_of_phasers = MAX_PHASERS;
  
  for( i = 0; i < MAX_PHASERS; i++ )
  {
    strcpy( ship->phaser[i].label, inship.gun_label[i] );
    ship->phaser[i].status = PHASER_OFFLINE;
    ship->phaser[i].power = inship.gun_power + atoi(fetch_attribute(ship_object, "ADD_PHASER_POWER"));
    ship->phaser[i].range = inship.gun_range;
    ship->phaser[i].range_percent = inship.gun_delivery;
    ship->phaser[i].charge_per_turn = inship.gun_charge_rate;
    ship->phaser[i].reliability = inship.gun_reliability;
    ship->phaser[i].wpn_data.type = inship.gun_signature;
    ship->phaser[i].wpn_data.sfactor = inship.gun_shield_factor;
    ship->phaser[i].wpn_data.hfactor = inship.gun_hull_factor;
    ship->phaser[i].wpn_data.carryover = inship.gun_carryover;
    ship->phaser[i].wpn_data.taps = inship.gun_taps;
    ship->phaser[i].wpn_arc = inship.gun_arc[i];
  }

  /* photon stuff */
  strcpy( ship->photon_string, inship.torp_name );
  ship->number_of_photons = inship.num_torps;
  atr_add(ship->ship_object, "WZ", tprintf("%f", inship.torp_accuracy), HOWIE, NOTHING);
  if( ship->number_of_photons > MAX_PHOTONS )
    ship->number_of_photons = 0;
  ship->torp_reload_time = inship.torp_reload_time;
  ship->torp_max_num_turns_online = inship.torp_max_num_turns_online;
  ship->torp_capacity = inship.num_torps ? inship.torp_capacity : 0;
  ship->torps_remaining = inship.num_torps ? inship.torp_capacity : 0;
  for( i = 0; i < MAX_PHOTONS; i++ )
  {
    strcpy( ship->photon[i].label, inship.torp_label[i] );
    ship->photon[i].power = inship.torp_power + atoi(fetch_attribute(ship_object, "ADD_TORP_POWER"));
    ship->photon[i].range = inship.torp_range;
    ship->photon[i].charge_per_turn = inship.torp_charge_rate;
    ship->photon[i].base_accuracy = inship.torp_accuracy;
    ship->photon[i].reliability = inship.torp_reliability;
    ship->photon[i].wpn_data.type = inship.torp_signature;
    ship->photon[i].wpn_data.sfactor = inship.torp_shield_factor;
    ship->photon[i].wpn_data.hfactor = inship.torp_hull_factor;
    ship->photon[i].wpn_data.carryover = inship.torp_carryover;
    ship->photon[i].wpn_data.taps = inship.torp_taps;
    ship->photon[i].wpn_arc = inship.torp_arc[i];
  }
  atr_add(ship->ship_object, "PODS", tprintf("%d", inship.escape_pods), HOWIE, NOTHING);
  /* initialize damage control team status */
  ship->damcon_teams = inship.damcon_teams + atoi(fetch_attribute(ship_object, "ADD_DAMCON"));
  ship->fullrepair = inship.fullrepair;
  if( ship->damcon_teams > MAX_TEAMS )
  {
      ship->damcon_teams = MAX_TEAMS;
  }
  return TRUE;
}

void eject_warp_core( SHIP *ship, dbref enactor )
{
    dbref helmsman,engineer=attrib_dbref(ship->eng,"XB");
    char ejector[120];
    CONTACT *contact;
    SHIP *observer;

    if( ship->damage[SYSTEM_ENGINE].status == '9' )
    {
        notify(enactor,"You already did that, you idiot!");
        return;
    }
    fnotify(enactor,"%s%sEjecting reactor core!%s",ANSI_HILITE,ANSI_RED,ANSI_NORMAL);
    ship->damage[SYSTEM_ENGINE].status = '9';
    ship->damage[SYSTEM_CRYSTAL].status = '9';
    ship->current_reactor_output_max = ship->reactor_output_max *
        ( 1 - ((float)( ship->damage[SYSTEM_ENGINE].status - '0' ) * 0.1 )) *
        ( 1 - ((float)( ship->damage[SYSTEM_CRYSTAL].status - '0' ) * 0.1 ));
    ship->reactor_output = (int)(ship->current_reactor_output_max
			   * ship->reactor_setting / 100);
    ship->reactor_output = UMAX( 1, ship->reactor_output );
    eng_alloc_check( ship, engineer );

    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        for(contact=observer->contact_list;contact!=NULL;contact=contact->next)
        {
            if( contact->listref==ship )
            {
                contact_string( ejector, contact, INFO_VERBOSE );
                helmsman=attrib_dbref(observer->helm,"XB");
                sprintf(writebuf,"Contact [%d]: %s has ejected reactor core.",contact->contact_number,ejector);
                notify(helmsman,writebuf);
                break;
            }
        }
    }
    return;
}

void eject_phaser_core( SHIP *ship, dbref enactor )
{
    dbref helmsman,engineer=attrib_dbref(ship->eng,"XB");
    char ejector[120];
    CONTACT *contact;
    SHIP *observer;
    int i;

    if( ship->number_of_phasers<=0 )
    {
        notify(enactor,"This ship has no phaser core.");
        return;
    }
    fnotify(enactor,"%s%sEjecting phaser core!%s",ANSI_HILITE,ANSI_RED,ANSI_NORMAL);
    for(i=0;i<ship->number_of_phasers;i++)
    {
        ship->damage[SYSTEM_GUN_0+i].status = '9';
        if( ship->phaser[i].status == PHASER_ONLINE )
        {
            ship->num_phasers_online--;
        }
        ship->phaser[i].status=PHASER_DAMAGED;
        ship->phaser[i].charge=0;
    }
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        for(contact=observer->contact_list;contact!=NULL;contact=contact->next)
        {
            if( contact->listref==ship )
            {
                contact_string( ejector, contact, INFO_VERBOSE );
                helmsman=attrib_dbref(observer->helm,"XB");
                sprintf(writebuf,"Contact [%d]: %s has ejected phaser core.",contact->contact_number,ejector);
                notify(helmsman,writebuf);
                break;
            }
        }
    }
    return;
}

int requisition_power( SHIP *ship, int location, int amount )
{
    int unused,*loc,*cons,max,nowhere=0,setting;

    unused = ship->reactor_output - ship->alloc_helm - ship->alloc_nav - ship->alloc_batt;
    if( ship->battery_status==BTTY_ONLINE )
    {
        unused += ship->battery_discharge_max;
    }
    max = ship->current_reactor_output_max * ship->reactor_setting_limit / 100;
    switch( location )
    {
        default:
            return 0;
        case POWER_HELM_GUNS:
            loc = &ship->halloc_phasers;
            cons = &ship->alloc_helm;
            break;
        case POWER_HELM_TORPS:
            loc = &ship->halloc_photons;
            cons = &ship->alloc_helm;
            break;
        case POWER_HELM_TRACTOR:
            loc = &ship->halloc_tractor;
            cons = &ship->alloc_helm;
            break;
        case POWER_NAV_WARP:
            loc = &ship->nalloc_warp;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_FORE:
            loc = &ship->nalloc_fore;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_AFT:
            loc = &ship->nalloc_aft;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_PORT:
            loc = &ship->nalloc_port;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_STAR:
            loc = &ship->nalloc_starboard;
            cons = &ship->alloc_nav;
            break;
        case POWER_ENG_BATTS:
            loc = &ship->alloc_batt;
            cons = &nowhere;
            break;
    }
    set_reactor_output( ship, -1, ship->reactor_setting_limit );
    unused = ship->reactor_output - ship->alloc_helm - ship->alloc_nav - ship->alloc_batt;
    if( unused >= amount )
    {
        (*loc) += amount;
        (*cons) += amount;
    }
    else if( ship->alloc_batt > 0 && ship->alloc_batt + unused >= amount )
    {
        (*loc) += amount;
        (*cons) += amount;
        ship->alloc_batt -= amount - unused;
    }
    else if( ship->battery_discharge < ship->battery_discharge_max && ship->battery_level > 0 )
    {
        ship->battery_status = BTTY_ONLINE;
        ship->battery_discharge += UMIN( (amount-unused), ship->battery_discharge_max );
        amount = UMIN( amount, ship->reactor_output + ship->battery_discharge_max );
        (*loc) += amount;
        (*cons) += amount;
    }
    free_power( ship, POWER_CLEANUP, 0 );
    return amount;
}

int free_power( SHIP *ship, int location, int amount )
{
    int *loc,*cons,nowhere=0,unused,setting;
    switch( location )
    {
        default:
            return 0;
        case POWER_CLEANUP:
            loc = &nowhere;
            cons = &nowhere;
            amount = 0;
            break;
        case POWER_HELM_GUNS:
            loc = &ship->halloc_phasers;
            cons = &ship->alloc_helm;
            break;
        case POWER_HELM_TORPS:
            loc = &ship->halloc_photons;
            cons = &ship->alloc_helm;
            break;
        case POWER_HELM_TRACTOR:
            loc = &ship->halloc_tractor;
            cons = &ship->alloc_helm;
            break;
        case POWER_NAV_WARP:
            loc = &ship->nalloc_warp;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_FORE:
            loc = &ship->nalloc_fore;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_AFT:
            loc = &ship->nalloc_aft;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_PORT:
            loc = &ship->nalloc_port;
            cons = &ship->alloc_nav;
            break;
        case POWER_NAV_SHIELD_STAR:
            loc = &ship->nalloc_starboard;
            cons = &ship->alloc_nav;
            break;
        case POWER_ENG_BATTS:
            loc = &ship->alloc_batt;
            cons = &nowhere;
            break;
    }
    amount = UMIN( amount, *loc );
    (*loc) -= amount;
    (*cons) -= amount;
    set_reactor_output( ship, -1, ship->reactor_setting_limit );
    unused = ship->reactor_output - ship->alloc_helm - ship->alloc_nav - ship->alloc_batt;
    if( ship->battery_status==BTTY_ONLINE )
    {
        if( unused > 0 )
        {
            ship->battery_status = BTTY_OFFLINE;
            ship->battery_discharge = 0;
        }            
        else
        {
            unused += ship->battery_discharge_max;
        }
    }
    if( unused > 0)
    {
        setting = (int)ceil( 100.0 * (ship->reactor_output - unused - ship->battery_discharge) / ship->current_reactor_output_max );
        setting = URANGE( 5, setting, ship->reactor_setting_limit );
        set_reactor_output( ship, -1, setting );
    }
    return amount;
}

int remaining_opt_power( SHIP *ship )
{
    int opt_output,remain;

    opt_output = (int)(ship->current_reactor_output_max * ship->reactor_stress_level / 100);
    remain = opt_output - (ship->alloc_helm + ship->alloc_nav + ship->alloc_batt);
    return UMAX( 0, remain );
}

long ship_cost( SHIP *ship, dbref enactor )
{
    long hullcost,guncost=0,torpcost=0,shieldcost=0,tractor,reactor,batt;
    long sensor,scanner,commo,total;
    notify( enactor, "WARNING: Will not give correct results if ship is damaged." );
    hullcost = (long)(25000.0 * ship->size * ship->size * ship->size * ship->size) + ((ship->hull_integrity + ship->max_armor_strength) * 100);
    if( ship->number_of_phasers )
    {
        guncost = (long)((ship->number_of_phasers * ship->phaser[0].power * ship->phaser[0].range_percent * ship->phaser[0].range * ship->phaser[0].charge_per_turn * 20)/(75 * ship->phaser[0].power));
    }
    if( ship->number_of_photons )
    {
        torpcost = (long)((ship->number_of_photons * ship->photon[0].power * ship->photon[0].range * ship->photon[0].base_accuracy * ship->photon[0].charge_per_turn * 15)/(175 * ship->photon[0].power));
        if( ship->photon[0].power > 3000 )
        {
            torpcost = (long)(10 * ship->number_of_photons * ship->photon[0].power * ship->photon[0].range * ship->photon[0].base_accuracy / ship->photon[0].charge_per_turn);
        }
    }
    if( ship->shield_max[0] )
    {
        shieldcost = (long)((ship->shield_max[0] * ship->shield_factor * ship->shield_max_charge[0])/sqrt(ship->size));
    }
    tractor = (long)ship->tractor_range;
    reactor = (long)(500 * ship->reactor_output_max * ship->reactor_stress_level / 100);
    batt = (long)ship->battery_capacity;
    sensor = (long)(ship->sensor_power - 56000);
    scanner = (long)(ship->scanner_range - 20000);
    commo = (long)(ship->transmitter_range - 180000);
    total = hullcost + guncost + torpcost + shieldcost + tractor + reactor + batt + sensor + scanner + commo;
    fnotify( enactor, "Hull: %ld\n\rGuns: %ld\n\rTorps: %ld\n\rShields: %ld\n\rTractor: %ld\n\rReactor: %ld\n\rBattery: %ld\n\rSensors: %ld\n\rScanners: %ld\n\rCommo: %ld\n\rTotal: %ld\n\r",
        hullcost, guncost, torpcost, shieldcost, tractor, reactor, batt, sensor, scanner, commo, total );
    fnotify( enactor, "Attack: %.2f    Defend: %.2f",
        (ship->number_of_phasers * ship->phaser[0].power * sqrt(ship->phaser[0].range_percent)) + (0.75 * ship->number_of_photons * ship->photon[0].power * ship->photon[0].base_accuracy),
        ship->shield_max[0] + (0.5 * ship->shield_factor * ship->shield_max_charge[0]) );
    return total;
}

void abridged_eng_status( SHIP *ship, dbref enactor )
{
  ship->reactor_output = UMAX( 1, ship->reactor_output );
  /* new eng status by Howie*/
  fnotify( enactor, "%s%s~~~~~~~~%s[%-32s Short Engineering Status]%s~~%s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ship->name, ANSI_BLUE, ANSI_NORMAL);
  fnotify(enactor, "%sReactor Status:  Setting: %s%3d%% %sOutput: %s%5d %sStress: %s%3d%%%s", ANSI_CYAN, ANSI_WHITE, ship->reactor_setting, ANSI_CYAN, ANSI_WHITE, ship->reactor_output, ANSI_CYAN, ANSI_WHITE,  100 * ship->overload_points / ship->max_overload_points, ANSI_NORMAL);
  fnotify( enactor, "%sEngine Temp: %s%5d%% (%.0f/%.0f)%s", ANSI_CYAN, ANSI_WHITE, (int)(100.0 * ship->etemp_points / ship->max_etemp_points), ship->etemp_points, ship->max_etemp_points, ANSI_NORMAL);
  fnotify( enactor, "%s--------------------------------------------------------------------%s", ANSI_WHITE, ANSI_NORMAL ); 
  if( ship->max_armor_strength > 0 )
{  
notify( enactor, tprintf("%sArmor Strength:%s  F%d (%d%%) A%d (%d%%) P%d (%d%%) S%d (%d%%)%s", ANSI_CYAN, ANSI_WHITE, ship->armor_strength[0], (100*ship->armor_strength[0]/ship->max_armor_strength), ship->armor_strength[1], (100*ship->armor_strength[1]/ship->max_armor_strength), ship->armor_strength[2], (100*ship->armor_strength[2]/ship->max_armor_strength), ship->armor_strength[3], (100*ship->armor_strength[3]/ship->max_armor_strength), ANSI_NORMAL));
 }
  fnotify( enactor, "%sHull Integrity:%s  %d%% (%d/%d)%s", ANSI_CYAN, ANSI_WHITE, (100 * ship->current_integrity/ship->hull_integrity), ship->current_integrity, ship->hull_integrity, ANSI_NORMAL);
  fnotify( enactor, "%s%s~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%s",ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);

	
}


void spectest( dbref enactor, SHIP *ship )
{
	int i;
	
	for( i=0; i<2; i++ )
	{
		
		fnotify( enactor, writebuf );
	}
	
}
