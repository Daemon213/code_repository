/*
 * $Id: shock.c,v 1.2 1993/09/24 23:09:41 chuckles Exp chuckles $
 *    Copyright (C) 1997 Jeremy R. Huddleston
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: shock.c,v $
 * 
 */


FUNCTION(fun_shockwave_cmd) 
{
    int i;
    SHOCKWAVE *shockwave;

    if( !Wizard(executor) || args[0]==NULL )
    {
      safe_str("#-1 PERMISSION DENIED", buff, bp );
      return;
    }

    /* switch on the argument */
    if( !strcmp( args[0], "activate" ))
    {
      for( i = 0; i < SPACE_LIMIT; i++ ) {
        shockwave = shockwave_list[i];
        while( shockwave != NULL ) {
          if( executor == shockwave->shockwave_object ) {
            notify( enactor, "This shockwave is already activated." );
            return;
          }

          shockwave = shockwave->next;
        }
      }
      /* okay, we've made it to this point so the shockwave in question  *
       * must be inactive so far.  Cool.  Activate it                 */

      if( activate_shockwave( executor, enactor ))
        notify( enactor, "Error initializing shockwave." );
      return;
    }
    else if( !strcmp( args[0], "deactivate" ))
    {
      for( i = 0; i < SPACE_LIMIT; i++ ) {
        shockwave = shockwave_list[i];
        while( shockwave != NULL ) {
          if( executor == shockwave->shockwave_object ) {
            current_space = i;
            deactivate_shockwave( shockwave, enactor );
            return;
          }

          shockwave = shockwave->next;
        }
      }

      /* okay, we've made it to this point so the shockwave in question *
       * must not be active.  Warn and return.                       
       */

      notify( enactor, "Shockwave isn't active." );

      return;
    }
    else
      notify( enactor, "Unrecognized shockwave_command() call." );

    return;
}

int activate_shockwave( dbref executor, dbref enactor )
{
    SHOCKWAVE *new_shockwave;
    char *curspace; 

    if( !(new_shockwave=(SHOCKWAVE *)JMALLOC(sizeof(SHOCKWAVE))) )
        return SERR_MALLOC;

    /* ship space -- this is either real or one of the sim spaces */
    curspace = my_atr_get_raw( executor, "SPACE" ); 
    if( !strcmp( curspace, "real" ))
        current_space = REAL;
    else if( !strcmp( curspace, "1" ))
        current_space = 1;
    else if( !strcmp( curspace, "2" ))
        current_space = 2;
    else if( !strcmp( curspace, "3" ))
        current_space = 3;
    else if( !strcmp( curspace, "4" ))
        current_space = 4;
    else if( !strcmp( curspace, "5" ))
        current_space = 5;
    else if( !strcmp( curspace, "6" ))
        current_space = 6;
    else if( !strcmp( curspace, "7" ))
        current_space = 7;
    else if( !strcmp( curspace, "8" ))
        current_space = 8;
    else if( !strcmp( curspace, "9" ))
        current_space = 9;
    else if( !strncmp( curspace, "10", 2 ))
        current_space = 10;
    else if( !strncmp( curspace, "11", 2 ))
        current_space = 11;
    else
        current_space = SIM;

    new_shockwave->shockwave_object = executor;
    new_shockwave->density = atof( my_atr_get_raw( executor, "DENSITY" ));

    sscanf( fetch_attribute( executor, "STARTPOS" ), "%f %f %f", &new_shockwave->pos.x,
            &new_shockwave->pos.y, &new_shockwave->pos.z );

    new_shockwave->size = atof( my_atr_get_raw( executor, "SIZE" ));
    new_shockwave->speed = atof( my_atr_get_raw( executor, "SPEED" ));
    new_shockwave->range1 = 0;
    new_shockwave->range2 = -(new_shockwave->size * 1000);
    new_shockwave->base_dam = atoi( my_atr_get_raw( executor, "DAMAGE" ) );
    new_shockwave->falloff = atoi( my_atr_get_raw( executor, "FALLOFF" ) );
    strcpy( writebuf, fetch_attribute( executor, "NAME" ));
    strncpy( new_shockwave->name, writebuf, NAME_LEN-1 );
    new_shockwave->name[NAME_LEN-1] = '\0';
    if( shockwave_list[current_space] == NULL )
    {
        shockwave_list[current_space] = new_shockwave;
        shockwave_tail[current_space] = new_shockwave;
        new_shockwave->prev = NULL;
    }
    else
    {
        shockwave_tail[current_space]->next = new_shockwave;
        new_shockwave->prev = shockwave_tail[current_space];
        shockwave_tail[current_space] = new_shockwave;
    }
    new_shockwave->next = NULL;
    /* and that's it for this shockwave.  Return */
    if( GoodObject(enactor) )
    fnotify( enactor, "Shockwave %s activated in %s space.",
         new_shockwave->name,
         space_names[current_space] );
    return( 0 );
}

int auto_active_shockwave( SHOCKWAVE *temp, int curspace )
{
    SHOCKWAVE *new_shockwave;

    if( !(new_shockwave=(SHOCKWAVE *)JMALLOC(sizeof(SHOCKWAVE))) )
    {
        return SERR_MALLOC;
    }
    (*new_shockwave) = (*temp);
    new_shockwave->range1 = 0;
    new_shockwave->range2 = -(new_shockwave->size * 1000);
    strncpy( new_shockwave->name, temp->name, NAME_LEN-1 );
    new_shockwave->name[NAME_LEN-1] = '\0';
    if( shockwave_list[curspace] == NULL )
    {
        shockwave_list[curspace] = new_shockwave;
        shockwave_tail[curspace] = new_shockwave;
        new_shockwave->prev = NULL;
    }
    else
    {
        shockwave_tail[curspace]->next = new_shockwave;
        new_shockwave->prev = shockwave_tail[curspace];
        shockwave_tail[curspace] = new_shockwave;
    }
    new_shockwave->next = NULL;
    return 0;
}

void deactivate_shockwave( SHOCKWAVE *shockwave, dbref enactor )
{
    SHIP *ship;

    /* this is an easy one.  Simply zorch it from the linked list */
    if(( shockwave_list[current_space] == shockwave )
    && ( shockwave_tail[current_space] == shockwave ) )
    {
        shockwave_list[current_space] = NULL;
        shockwave_tail[current_space] = NULL;
    }
    else if( shockwave_list[current_space] == shockwave )
    {
        shockwave_list[current_space] = shockwave_list[current_space]->next;
        shockwave_list[current_space]->prev = NULL;
    }
    else if( shockwave_tail[current_space] == shockwave )
    {
        shockwave_tail[current_space] = shockwave_tail[current_space]->prev;
        shockwave_tail[current_space]->next = NULL;
    }
    else
    {
        shockwave->prev->next = shockwave->next;
        shockwave->next->prev = shockwave->prev;
    }
    /* go through and remove it from any shockwave lists it may be on */
    ship = space_list[current_space];
    while( ship != NULL )
    {
        remove_shockwave( ship, shockwave );
        ship = ship->next;
    }
    JFREE( shockwave );
    if( GoodObject(enactor) )
    {
        notify( enactor, "Shockwave is zorched." );
    }
    return;
}


void ship_shockwave_checks( SHIP *ship )
{
    SHOCKWAVE *shockwave;
    int in_range;
    float range;
    SWCONTACT *contact;
    if( ship == NULL ){
       return; }
       
    
    for(shockwave=shockwave_list[current_space];shockwave!=NULL;shockwave=shockwave->next)
    {
        in_range = FALSE;
        range = distance( ship->pos, shockwave->pos );
        if( range < UMAX(0,shockwave->range2) )
        {
            range = UMAX(0,shockwave->range2) - range;
        }
        else if( range > shockwave->range1 )
        {
            range = range - shockwave->range1;
        }
        else
        {
            range = 0.0;
        }
        if( ship->flags[OMNISCIENT] )
        {
            in_range = TRUE;
        }
        else if ( inside_shockwave(ship, shockwave) )
        {
            in_range = TRUE;
        }
        else if( ship->sensor_power * ship->nebula_visibility * shockwave->size >= range )
        {
            in_range = TRUE;
        }
        contact = find_shockwave_contact(ship,shockwave);
        if( in_range )
        {
            add_shockwave( ship, shockwave );
        }
        else if( contact!=NULL )
        {
            remove_shockwave( ship, shockwave );
        }
    }
    return;
}


void add_shockwave( SHIP *ship, SHOCKWAVE *shockwave )
{
    SWCONTACT *contact;
    XYZ xyz_rel;
    SPH sph_rel;
    dbref helmsman;
    dbref navigator;
    float range;


    if( ship == NULL )
    {
	    return;
    }
    /* check inside if it's already on the list */
    contact = ship->shockwave_list;

    helmsman = match_result(HOWIE, my_atr_get_raw(ship->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
    navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

    while( (contact != NULL) )
    {
        if( contact->listref == shockwave )
        {
            if( contact->inside && inside_shockwave(ship, shockwave)
            && FRAND <= contact->listref->density )
            {
                shockwave_damage( ship, contact );
            }
            else if( !contact->inside && inside_shockwave(ship, shockwave) )
            {
                enter_shockwave( ship, contact );
            }
            else if( contact->inside && !inside_shockwave(ship, shockwave) )
            {
                sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.", ANSI_HILITE, ANSI_RED,
                    ANSI_NORMAL, shockwave->name );
                notify_room( BRIDGE(ship), writebuf );
                contact->inside = 0;
            }
            return;
        }
        contact = contact->next;
    }
    if( ( contact = (SWCONTACT *)JMALLOC(sizeof( CONTACT ))) == NULL )
    {
        return;
    }
    contact->listref = shockwave;
    if( ship->shockwave_list == NULL )
    {
        ship->shockwave_list = contact;
        ship->shockwave_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->shockwave_tail->next = contact;
        contact->prev = ship->shockwave_tail;
        contact->next = NULL;
        ship->shockwave_tail = contact;
    }
    if( inside_shockwave(ship, shockwave) )
    {
        enter_shockwave( ship, contact );
    }
    else
    {
        xyz_rel.x = shockwave->pos.x - ship->pos.x;
        xyz_rel.y = shockwave->pos.y - ship->pos.y;
        xyz_rel.z = shockwave->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );
        range = distance( ship->pos, shockwave->pos );
        if( range < UMAX(0,shockwave->range2) )
        {
            range = UMAX(0,shockwave->range2) - range;
            sph_rel.elevation = 0 - sph_rel.elevation;
            if( (sph_rel.bearing - 180) < 0 )
            {
                sph_rel.bearing = sph_rel.bearing + 180;
            }
            else
            {
                sph_rel.bearing = sph_rel.bearing - 180;
            }
        }
        else if( range > shockwave->range1 )
        {
            range = range - shockwave->range1;
        }
        else
        {
            range = 0;
        }
        sph_rel.range = abs(range);
        fnotify( helmsman, "%s%s now in sensor range bearing %s%s%d%+d%s%s at range %s%s%ld%s%s.%s",
            ANSI_CYAN, shockwave->name, ANSI_HILITE, ANSI_RED, (int)sph_rel.bearing,
             (int)sph_rel.elevation, ANSI_NORMAL, ANSI_CYAN, ANSI_HILITE, ANSI_RED,
             (long)sph_rel.range, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL );
        contact->inside = 0;
    }
    return;
}

void enter_shockwave( SHIP *ship, SWCONTACT *contact )
{
    sprintf( writebuf, "%s%sWARNING:%s Entering the %s.", ANSI_HILITE, ANSI_RED,
        ANSI_NORMAL, contact->listref->name );
    notify_room( BRIDGE(ship), writebuf );
    contact->inside = 1;
    return;
}

void shockwave_damage( SHIP *ship, SWCONTACT *contact)
{
    SHIP fake_ship;
    int damage;
    WDATA weapon = {WPN_RAM,1.0,1.0,0.1,1};
    
    if( ship == NULL )
    {
	    return;
    }
    
    damage = (int)( contact->listref->base_dam * (float)( ship->size ) * (float)( FRAND ) );
    /* if the ship is set invincible, set the damage to zero */
    if( ship->flags[INVINCIBLE] )
    {
        damage = 0;
    }
    if( damage <= 0 )
    {
        return;
    }
    fake_ship = (*ship);
    fake_ship.pos = contact->listref->pos;
    fake_ship.target_system = SYSTEM_HULL;
    sprintf( writebuf, "%s%sA shockwave slams into the ship!%s", ANSI_HILITE,
        ANSI_RED, ANSI_NORMAL);
    notify_room( BRIDGE(ship), writebuf );
    battle_damage( &fake_ship, ship, damage, weapon );
    return;
}

void remove_shockwave( SHIP *ship, SHOCKWAVE *shockwave )
{
    SWCONTACT *contact, *found = NULL;
    dbref helmsman;
    float range;
    XYZ xyz_rel;
    SPH sph_rel;

    if( ship==NULL)
    {
	    return;
    }

    contact = ship->shockwave_list;

    for(contact=ship->shockwave_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref == shockwave )
        {
            found = contact;
        }
    }
    if( found == NULL )
    {
        return;
    }
    helmsman = match_result(HOWIE, my_atr_get_raw(ship->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
    if(found->inside)
    {
        sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL, shockwave->name );
        notify_room( BRIDGE(ship), writebuf );
    }
    else
    {
        xyz_rel.x = shockwave->pos.x - ship->pos.x;
        xyz_rel.y = shockwave->pos.y - ship->pos.y;
        xyz_rel.z = shockwave->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );
        range = distance( ship->pos, shockwave->pos );
        if( range < UMAX(0,shockwave->range2) )
        {
            sph_rel.elevation = 0 - sph_rel.elevation;
            if( (sph_rel.bearing - 180) < 0 )
            {
                sph_rel.bearing = sph_rel.bearing + 180;
            }
            else
            {
                sph_rel.bearing = sph_rel.bearing - 180;
            }
            range = UMAX(0,shockwave->range2) - range;
        }
        else if( range > shockwave->range1 )
        {
            range = range - shockwave->range1;
        }
        else
        {
            range = 0;
        }
        sph_rel.range = abs(range);
        fnotify( helmsman, "%s%s no longer in sensor range. Last seen bearing %s%s%d%+d%s%s at range %s%s%ld%s%s.%s",
            ANSI_CYAN, shockwave->name, ANSI_HILITE, ANSI_RED, (int)sph_rel.bearing, 
            (int)sph_rel.elevation, ANSI_NORMAL, ANSI_CYAN, ANSI_HILITE, ANSI_RED,
            (long)sph_rel.range, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL );
    }
    if( ship->shockwave_list == ship->shockwave_tail )
    {
        ship->shockwave_list = NULL;
        ship->shockwave_tail = NULL;
    }
    else if( found == ship->shockwave_list )
    {
        ship->shockwave_list = found->next;
        ship->shockwave_list->prev=NULL;
    }
    else if( found == ship->shockwave_tail )
    {
        ship->shockwave_tail = found->prev;
        ship->shockwave_tail->next = NULL;
    }
    else if( ( found != ship->shockwave_list)
    && ( found != ship->shockwave_tail ) )
    {
        (found->prev)->next = found->next;
        (found->next)->prev = found->prev;
    }
    JFREE( found );
    return;
}


void shockwave_checks( void )
{
    SHOCKWAVE *shockwave,*nextshock;
    SHIP *ship;
    for(shockwave=shockwave_list[current_space];shockwave!=NULL;shockwave=nextshock)
    {
        nextshock=shockwave->next;
        shockwave->range1 += shockwave->speed;
        shockwave->range2 += shockwave->speed;
        shockwave->base_dam -= shockwave->falloff;
        if( shockwave->base_dam <= 0 )
        {
            deactivate_shockwave(shockwave,-1);
        }
    }
    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        ship_shockwave_checks( ship );
    }
    return;
}


void list_shockwaves( SHIP *ship, dbref enactor )
{
    SHOCKWAVE *shockwave;
    SWCONTACT *contact;
    XYZ xyz_rel;
    SPH sph_rel;
    char inside_ast[2];
    char rel_range[5];
    char shockwave_density[3];
    float range;

    if( ship==NULL || ship->shockwave_list==NULL )
    {
        return;
    }
    fnotify( enactor, "\n%s%sIn Shockwave Name     Bearing Range  Density  Size  Center XYZ Location%s",
         ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    for(contact=ship->shockwave_list;contact!=NULL;contact=contact->next)
    {
        shockwave=contact->listref;
        xyz_rel.x = contact->listref->pos.x - ship->pos.x;
        xyz_rel.y = contact->listref->pos.y - ship->pos.y;
        xyz_rel.z = contact->listref->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );
        range = distance( ship->pos, shockwave->pos );
        if( range < UMAX(0,shockwave->range2) )
        {
            sph_rel.elevation = 0 - sph_rel.elevation;
            if( (sph_rel.bearing - 180) < 0 )
            {
                sph_rel.bearing = sph_rel.bearing + 180;
            }
            else
            {
                sph_rel.bearing = sph_rel.bearing - 180;
            }
            range = UMAX(0,shockwave->range2) - range;
        }
        else if( range > shockwave->range1 )
        {
            range = range - shockwave->range1;
        }
        else
        {
            range = 0;
        }
        sph_rel.range = abs(range);
        if( sph_rel.range >= 10000000.0 )
        {
            sprintf( rel_range, "%4.0fM", sph_rel.range / 1000000.0 );
        }
        else if( sph_rel.range >= 100000.0 )
        {
            sprintf( rel_range, "%4.0fK", sph_rel.range / 1000.0 );
        }
        else
        {
            sprintf( rel_range, "%5.0f", sph_rel.range );
        }
        sprintf( shockwave_density, "%3.0f", contact->listref->density * 100.0 );
        if( contact->inside )
        {
            sprintf( inside_ast, "*" );
        }
        else
        {
            sprintf( inside_ast, " " );
        }
        fnotify( enactor, "%s%s%-3s%s%s%-18.18s %s%s%-3.0f %-+3.0f %-5s  %s%s %-3s%%    %s%s%-4.1f  %s%-9.0f %-9.0f %-9.0f%s", 
            ANSI_HILITE, ANSI_RED, inside_ast, ANSI_NORMAL, ANSI_CYAN,
            contact->listref->name, ANSI_HILITE, ANSI_CYAN,
            sph_rel.bearing, sph_rel.elevation, rel_range, ANSI_NORMAL,
            ANSI_MAGENTA, shockwave_density, ANSI_HILITE, ANSI_WHITE, contact->listref->size,
            ANSI_BLACK, contact->listref->pos.x, contact->listref->pos.y,
            contact->listref->pos.z, ANSI_NORMAL );
    }
    return;
}

int inside_shockwave(SHIP *ship, SHOCKWAVE *shockwave)
{
    float range;

    if( ship == NULL )
    {
	    return 0;
    }
    
    range = distance( ship->pos, shockwave->pos );
    if( range <= shockwave->range1 && range >= shockwave->range2 )
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

SWCONTACT *find_shockwave_contact( SHIP *ship, SHOCKWAVE *shock )
{
    SWCONTACT *contact;

    if( ship == NULL )
    {
	    return NULL;
    }
    
    for(contact=ship->shockwave_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref==shock )
        {
            return contact;
        }
    }
    return NULL;
}
