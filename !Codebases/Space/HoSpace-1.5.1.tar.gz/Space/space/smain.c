/*
 * $Id: smain.c,v 1.4 1993/09/28 05:21:13 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: smain.c,v $
 * Howie Revsions: 1999/03/14
 * started adding things such as warp_accel and repaired get_dbref crash bug
 *
 * Revision 1.4  1993/09/28  05:21:13  chuckles
 * all kinds of sensornet stuff.  major restructuring of the sensor_checks()
 * function. (see comments)
 *
 * Revision 1.3  1993/09/25  20:39:40  chuckles
 * cleaned up logging code. SENSOR_DEBUG stuff.  planet sensor effects.
 *
 * Revision 1.2  1993/09/24  23:09:41  chuckles
 * use jmalloc library.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS 24 May 93 - separated into smain.c
 * JMS/DJB ?? Jul 92 - original code
 */

void rotate_ships( void );

void notify_room(dbref location, const char *msg) {
  notify_except(db[location].contents, NOTHING, msg);
} 

void space_update( void )
{ 
    
#if defined(unix)
  signal(SIGFPE,SIG_IGN);
#endif

  
  
  for( current_space = 0; current_space < SPACE_LIMIT; current_space++ )
  {  
    if( space_pause[current_space] )
    {
       continue;
    }
    /* tactical turn functions every six seconds */
    if( tcount == 0 )
    {
       tactical_turn();
       planet_tactical();
    }
    /* beacon checks every six seconds */
    if( tcount == 1 )
    {
        beacon_checks();
    }
    /* nebula checks every six seconds */
    if( tcount == 2 )
    {
        nebula_checks();
    }
    /* sensor checking every six seconds */
    if( tcount == 3 )
    {
        sensor_checks();
        planet_sensor_checks();
    }    
    /* repairs every six seconds */
    if( tcount == 4 )
    {
        ship_repairs();
    }
    /* nav hazards every six seconds */
    if( tcount == 5 )
    {
        planet_checks();
        star_checks();
        wormhole_checks();
        asteroids_checks();
        plasma_checks();
    }
    rotate_ships();
    
    /* move ships every two seconds */
    /* JMS 12 Sep 93 -- move every second instead */
    /* Philip July 96 - move every second is bad for combat */
    /* Change course to intercept when ship is moved. */
    if( tcount % 2 == 1 )
    {
        move_ships();
    }
    else
    {
        shockwave_checks();
    }
  }

	if( hcount == 1)
		orbit_planets();  //Orbits moons around planets once an hour
	
	if( dcount == 1 )
		orbit_stars();   //Orbits planets around their star once a day
  /* update tcount */
  tcount = (tcount + 1) % 6;
  
  /* gotta have one for once an hour things too. */
  hcount = (hcount + 1) % 3600;
  if(hcount == 1)
	  log_space( "Moon Orbit time on the hour!");
  /* gotta have one for once a day */
  dcount = (dcount + 1) % 86400;
 
}

 
void tactical_turn( void )
{
  SHIP *ship,*next_ship,fake_ship;
  int old_battery_level,old_overload_points;
  float etemp_change,old_etemp,lock_chance;
  int overload_change;
  dbref engineer, navigator, helmsman, engineering;
  int time_left;
  int old_shield_level[4];
  int i,*iptr,x=0;
  int shield_additions[4];
  int weapon_charge;
  static char *shield_strings[] =
  {
        (char *) "Fore",
        (char *) "Aft",
        (char *) "Port",
        (char *) "Starboard"
  };

  for(ship=space_list[current_space];ship!=NULL;ship=next_ship)
  {
    next_ship = ship->next;
    helmsman = attrib_dbref( ship->helm, "XB" );
    ship->helmsman = helmsman;
    navigator = attrib_dbref( ship->nav, "XB" );
    ship->navigator = navigator;
    engineer = attrib_dbref( ship->eng, "XB" );
    ship->engineer = engineer;

    if( ship->battle_timer > 0 )
    {
        ship->battle_timer--;
    }
    engineering = db[ship->eng].location;
    old_battery_level = ship->battery_level;

    /* charge battery */
    if( ship->smart_alloc==2 && ship->battery_level < ship->battery_capacity
    && ship->battery_status!=BTTY_ONLINE && ship->alloc_batt==0 )
    {
        ship->battery_level += remaining_opt_power(ship);
    }
    else
    {
        ship->battery_level += ship->alloc_batt;
    }
    /* deplete battery */
    ship->battery_level -= ship->battery_discharge;

    /* bleed batteries */
    if( ship->battery_status == BTTY_ONLINE )
    {
      ship->battery_level *= BATTERY_BLEED;
    }
    /* check for bettery overcharge */
    if( ship->battery_level > ship->battery_capacity )
    {
      ship->battery_level = ship->battery_capacity;
    }
    /* force a reallocation if batts are too low */
    if( ship->battery_discharge > ship->battery_level )
    {
      eng_alloc_check( ship, -1 );
    }
    if( ship->battery_level > old_battery_level
    && ship->battery_level==ship->battery_capacity )
    {
      fnotify(engineer, "%s%sBatteries fully charged.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
      if( ship->smart_alloc && ship->battery_status==BTTY_OFFLINE )
      {
        if( ship->smart_alloc==2 )
        {
            free_power( ship, POWER_ENG_BATTS, ship->alloc_batt );
        }
        else
        {
            ship->alloc_batt = 0;
        }
      }
    }
    old_overload_points = ship->overload_points;
    /* update ship overload points */
    if( ship->reactor_setting > ship->reactor_stress_level )
    {
      /* we're accruing overload points */
      overload_change = ship->reactor_setting - ship->reactor_stress_level;

      if( ship->reactor_setting > 100 )
        overload_change += (( ship->reactor_overload_penalty ) *
                	    ( ship->reactor_setting - 100 ));

      /* add them in and flash a message */
      ship->overload_points += overload_change;

      /* if reactor has overloaded too long damage may occur */
      /* call some kind of damage function here! */
      if(( FRAND < (( ship->overload_points / ship->max_overload_points ) -
           1 )) & ( ship->damage[SYSTEM_CRYSTAL].status != '9' ))
      {

        /* fracture the crystal 1-3 points */
        ship->damage[SYSTEM_CRYSTAL].status += (int)(( FRAND * 2 ) + 1 );

        if( ship->damage[SYSTEM_CRYSTAL].status > '9' )
          ship->damage[SYSTEM_CRYSTAL].status = '9';

        ship->damage[SYSTEM_CRYSTAL].time_to_fix += 200;
        ship->current_reactor_output_max = ship->reactor_output_max *
        ( 1 - ((float)( ship->damage[SYSTEM_ENGINE].status - '0' ) * 0.1 )) *
        ( 1 - ((float)( ship->damage[SYSTEM_CRYSTAL].status - '0' ) * 0.1 ));
        fnotify( engineer, "%s%sDilithium crystal fracture due to overstress. New max power is %s%d%s.%s",
               ANSI_HILITE, ANSI_RED, ANSI_YELLOW, ship->current_reactor_output_max,
               ANSI_RED, ANSI_NORMAL );
        eng_alloc_check( ship, engineer );
      }
      /* calculate the time left at this pace */
      time_left = (int)( 6.0 * ( ship->max_overload_points -
                  ship->overload_points ) / overload_change);

      if(( time_left < 6 ) && ship->eng_safeties )
      {
        /* force a reactor slowdown */
        fnotify( engineer, "%s%sReactor crystals at critical stress. Emergency override initiated.%s",
               ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        set_reactor_output( ship, engineer, ship->reactor_stress_level );
      }
      else if( time_left < 0 && ship->eng_warnings )
      {
        sprintf( writebuf, "%s%sWARNING: Crystals overstressing.  Critical stress exceeded.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
      }
      else if( ( time_left < 61 ) && ship->eng_warnings )
      {
        sprintf( writebuf, "%s%sWARNING: Crystals overstressing.  Critical stress in %d seconds.%s",
               ANSI_HILITE, ANSI_RED, time_left, ANSI_NORMAL );
        notify_room(engineering, writebuf);
      }
    }

    if(( ship->reactor_setting < ship->reactor_stress_level ) &&
       ( ship->overload_points > 0 )) {

      /* we're losing overload points.  Whee! */
      ship->overload_points -= (( ship->reactor_stress_level -
                		  ship->reactor_setting ) / 2 );

      if( ship->overload_points < 0 )
        ship->overload_points = 0;
    }
    if( (ship->overload_points == 0) && (old_overload_points != 0) )
    {
      fnotify(engineer, "%s%sReactor fully destressed.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
    }
    etemp_change = ship->warp_speed - ship->etemp_speed;
    if( ship->flags[SPEEDY] )
    {
        etemp_change = 0.0;
    }
    if( etemp_change > 0.0 )
    {
        time_left = (int)( 6.0 * ( ship->max_etemp_points - ship->etemp_points ) / etemp_change);
        if( time_left < 61 && time_left > 0 )
        {
            sprintf( writebuf, "%s%sWARNING: Warp engines overheating. Critical temp. in %d seconds.%s",
                ANSI_HILITE, ANSI_RED, time_left, ANSI_NORMAL );
            notify_room( BRIDGE(ship), writebuf );
        }
        else if( time_left <= 0 )
        {
            sprintf( writebuf, "%s%sWARNING: Warp engines exceeding critical temperature!%s",
                ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
            notify_room( BRIDGE(ship), writebuf );
        }
        if( time_left <= 6 && ship->eng_safeties )
        {
            set_warp( ship, navigator, ship->etemp_speed );
        }
    }
    old_etemp = ship->etemp_points;
    ship->etemp_points += etemp_change;
    if( ship->etemp_points < 0.0 )
    {
        ship->etemp_points = 0.0;
    }
    else if( ship->etemp_points > ship->max_etemp_points )
    {
        if( FRAND < ( (ship->etemp_points/ship->max_etemp_points)-1.0 ) )
        {
            sprintf( writebuf, "%s%sWarp engines damaged by overheating.%s",
                ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
            break_system( ship, SYSTEM_WARP );
        }
    }
    if( ship->etemp_points==0.0 && old_etemp!=0.0 )
    {
        sprintf(writebuf,"%s%sWarp engines fully cooled.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        notify( engineer, writebuf );
        if( engineer!=navigator )
        {
            notify( navigator, writebuf );
        }
    }
    /* shield maintenance */
    if( ship->cloak_status == CLOAK_ON )
    {
      /* do...well, don't do anything, yet.  We'll see. */
    }
    else
    {
      /* store previous values, remove overload energy, and bleed */
      for( i = 0; i < 4; i++ )
      {
        old_shield_level[i] = ship->shield_level[i];

        if( ship->shield_level[i] > ship->shield_max[i] )
          ship->shield_level[i] = ship->shield_max[i];

	/* +++ Changed by Maverick +++ */
	/* Hybrid Chuckspace/TNG shields */

	/* Mav: Bleed 0% when up, 2% when down */
        ship->shield_level[i] *= ( ship->shield_status[i] == SHLD_READY ) ?
            1.00 : 0.98;
      }

      /* calculate amounts to be added. */
      shield_additions[0] = ship->nalloc_fore;
      shield_additions[1] = ship->nalloc_aft;
      shield_additions[2] = ship->nalloc_port;
      shield_additions[3] = ship->nalloc_starboard;
      /* truncate those amounts at the shield max allocation */
      for( i = 0; i < 4; i++ )
      {
        if( shield_additions[i] > ship->shield_max_charge[i] )
          shield_additions[i] = ship->shield_max_charge[i];

	/* Mav: When shields are up, only 20% of overload goes to recharging the shields */
        if ( ship->shield_status[i] == SHLD_UP )
        {
          if( shield_additions[i] > (0.02 * ship->shield_level[i]) )
          {
            shield_additions[i] -= (0.02 * ship->shield_level[i]);
            shield_additions[i] *= 0.20;
            shield_additions[i] += (0.02 * ship->shield_level[i]);
          }
        }
      }

      /* now add any allocated points if the shield is working and      *
       * truncate overloads at overload max and update action registers */
      for( i = 0; i < 4; i++ )
      {
        switch(i)
        {
            default:
                iptr = &x;
                break;
            case 0:
                iptr = &ship->nalloc_fore;
                break;
            case 1:
                iptr = &ship->nalloc_aft;
                break;
            case 2:
                iptr = &ship->nalloc_port;
                break;
            case 3:
                iptr = &ship->nalloc_starboard;
                break;
        }
        if( ship->shield_status[i] !=SHLD_DAMAGED )
        {
            ship->shield_level[i] += (int)( shield_additions[i] *
                		   ship->shield_factor );
        }
        if( ship->shield_status[i] != SHLD_UP )
        {
            if( ship->shield_level[i] > ship->shield_max[i] )
                ship->shield_level[i] = ship->shield_max[i];
        }
	/* Mav: With the hybrid system, TNG_SHIELDS will just mess it up. */
/*
#if defined(TNG_SHIELDS)
        else if( ship->shield_status[i]==SHLD_UP )
        {
            ship->shield_level[i] = UMIN( ship->shield_level[i], old_shield_level[i] );
        }
#endif
*/
        if ((ship->shield_level[i] >= ship->shield_max[i])
        && (old_shield_level[i] < ship->shield_max[i]))
        {
          fnotify(navigator, "%s%s shield fully charged.%s", ANSI_GREEN, shield_strings[i],
                 ANSI_NORMAL );

	/* Mav: This stuff doesn't do anything yet, so let's not use it */
/*
          if( ship->smart_alloc==2 )
          {
            if( ship->shield_status[i]==SHLD_UP )
            {
                max = (int)( (float)ship->shield_max[i]/ship->shield_factor + 0.999999 );
            }
            else
            {
                max = (int)( (float)ship->shield_max[i]*(1.0-SHLD_READY_BLEED)/ship->shield_factor + 0.999999 );
            }
            if( (*iptr) > max )
            {
                free_power( ship, POWER_NAV_SHIELD + i, max - (*iptr) );
            }
          }
*/
        }
        if( ship->shield_level[i] > ship->shield_max[i] )
          ship->shield_action[i] = SHLD_OVERLOADED;
        else if( ship->shield_level[i] == old_shield_level[i] )
          ship->shield_action[i] = SHLD_STABLE;
        else
          ship->shield_action[i] = ( ship->shield_level[i] >
                old_shield_level[i] ) ? SHLD_CHARGING : SHLD_FALLING;
      }
    }
	/* --- End Maverick's Changes --- */

    /* resolve any pending lock */
    if( ship->pending_lock != NULL )
    {
        switch( ship->damage[SYSTEM_TARGETTING].status )
        {
            case 'x':
            case 'X':
            case '9':
            case '8':
            case '7':
                lock_chance = 0.0;
                break;
            case '6':
            case '5':
                lock_chance = 0.25;
                break;
            case '4':
            case '3':
                lock_chance = 0.50;
                break;
            case '2':
                lock_chance = 0.75;
                break;
            case '1':
                lock_chance = 0.90;
                break;
            default:
                lock_chance = 1.0;
                break;
        }
        if( FRAND <= lock_chance )
        {
            ship->locked_target = ship->pending_lock;
            ship->pending_lock = NULL;
            fnotify( helmsman, "%s%sLock achieved.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        }
    }

    /* charge phaser banks that are online.  Just drain the others. */
    for( i = 0; i < ship->number_of_phasers; i++ ) {
      ship->phaser[i].old_charge = ship->phaser[i].charge;
      ship->phaser[i].charge *= 0.9;
      if( ship->phaser[i].status == PHASER_ONLINE )
      {
        weapon_charge = ship->halloc_phasers / ship->num_phasers_online;

        if( weapon_charge > ship->phaser[i].charge_per_turn )
          weapon_charge = ship->phaser[i].charge_per_turn;

        ship->phaser[i].charge += weapon_charge;

        if( ship->phaser[i].charge > ship->phaser[i].power )
          ship->phaser[i].charge = ship->phaser[i].power;

        /* check for a NEW full charge */
        if(( ship->phaser[i].charge == ship->phaser[i].power ) &&
           ( ship->phaser[i].old_charge != ship->phaser[i].power )) {

          /* just now fully charged.  Notify */
          fnotify( helmsman, "%s%s%s %d fully charged.%s", ANSI_HILITE, ANSI_GREEN,
                 ship->phaser_string, i+1, ANSI_NORMAL );
        }
      }
    }

    /* expire tubes that are too old */
    for( i = 0; i < ship->number_of_photons; i++ )
    {
      switch( ship->photon[i].status ) {
        case PHOTON_ONLINE:
        case PHOTON_ARMED:
          /* increment and see if it is time to expire */
          if( ++(ship->photon[i].turns_charged ) > ship->torp_max_num_turns_online )
          {
            /* we have an expired photon.  zorch it */
            if( ship->photon[i].status == PHOTON_ONLINE )
            {
              --ship->num_photons_online;
            }
            ship->torps_remaining--;
            write_damage( ship );
            ship->photon[i].status = PHOTON_EMPTY;
            ship->photon[i].turns_charged = 0;
            ship->photon[i].charge = 0;

            fnotify( helmsman, "%s%s%s %d expired.%s", ANSI_HILITE, ANSI_RED,
                   ship->photon_string, i+1, ANSI_NORMAL );

            /* if there's no other photon loading and we're  *
             * set for autoreload, reload the expired tube   */
            if(( ship->reloading_tube == NO_RELOAD ) && ( ship->auto_reload ))
            {
              reload_photon( ship, helmsman, i );
            }
            if( ship->smart_alloc==2 )
            {
              free_power( ship, POWER_HELM_TORPS, ship->photon[i].charge_per_turn );
            }
          }

          break;

        default:
          break;
      }
    }

    /* charge photon tubes that are online */
    if( ship->num_photons_online )
    {
      for( i = 0; i < ship->number_of_photons; i++ )
      {
        if( ship->photon[i].status == PHOTON_ONLINE )
        {
          /* calculate weapon charge.  Make sure it's legal limit */
          weapon_charge = ship->halloc_photons / ship->num_photons_online;
          if( weapon_charge > ship->photon[i].charge_per_turn )
            weapon_charge = ship->photon[i].charge_per_turn;

          ship->photon[i].charge += weapon_charge;

          if( ship->photon[i].charge >= ( ship->photon[i].power / 2 ) )
          {
            ship->photon[i].status = PHOTON_ARMED;
            ship->photon[i].charge = 0;
            ship->num_photons_online--;
            if( ship->smart_alloc==2 )
            {
              free_power( ship, POWER_HELM_TORPS, ship->photon[i].charge_per_turn );
            }
            fnotify( helmsman,  "%s%s%s %d armed.%s", ANSI_HILITE, ANSI_GREEN, 
                   ship->photon_string, i+1, ANSI_NORMAL );
          }
        }
      }
    }

    /* reload photon tube if it is time.  */
    if( ship->reloading_tube != NO_RELOAD )
    {
      if( --( ship->turns_to_reload ) == 0 )
      {
        ship->photon[ship->reloading_tube].status = PHOTON_LOADED;
        fnotify( helmsman, "%s%s%s tube %d reloaded.%s", ANSI_HILITE, ANSI_GREEN, 
                 ship->photon_string, ship->reloading_tube + 1, ANSI_NORMAL );

        /* if set for automatic charging, do it */
        if( ship->auto_online )
          photon_online( ship, helmsman, ship->reloading_tube );

        /* reset ship->reloading_tube */
        /* Philip Mak - moved this to after photon_online! Jul 30 '96 */
        ship->reloading_tube = NO_RELOAD;

        /* if we're on auto-reload, check and see if  *
         * another tube needs reloading.             */ 
        if( ship->auto_reload ) {
          for( i = 0; i < ship->number_of_photons; i++ ) {
            if( ship->photon[i].status == PHOTON_EMPTY ) {
              reload_photon( ship, helmsman, i );

              /* break out of the loop */
              i = ship->number_of_photons;
            }
          }
        }
      }
    }
    /* bomb! */
    if( ship->orbitting!=NULL && ship->bombarding )
    {
        ship->battle_timer = TIMER_RESET;
        fake_ship = (*ship);
        fake_ship.pos = ship->orbitting->listref->pos;
        i = facing_shield( &fake_ship, ship );
        /* if shields are down, drop bombs */
        if( ship->shield_status[i]!=SHLD_UP && ship->number_of_photons > 0 )
        {
            for(i=0;i<ship->number_of_photons;i++)
            {
                if( ship->torps_remaining <= ship->number_of_photons )
                {
                    break;
                }
                ship->torps_remaining--;
                damage_planet( ship->orbitting->listref, ship->photon[i].power, WPN_TORP );
            }
            fnotify( helmsman, "%s%sBombarding planet %s, %d bombs dropped.%s",
                ANSI_HILITE, ANSI_RED, ship->orbitting->name, i, ANSI_NORMAL );
        }
        for(i=0;i<ship->number_of_phasers;i++)
        {
            if( ship->phaser[i].charge==ship->phaser[i].power )
            {
                fnotify( helmsman, "%s%sBombarding planet %s with %s %d.%s",
                    ANSI_HILITE, ANSI_MAGENTA, ship->orbitting->name,
                    ship->phaser_string, i+1, ANSI_NORMAL );
                damage_planet( ship->orbitting->listref, ship->phaser[i].charge, WPN_GUN );
                ship->phaser[i].charge = 0;
            }
        }
        for(i=0;i<ship->number_of_photons;i++)
        {
            if( ship->photon[i].status==PHOTON_ARMED )
            {
                fnotify( helmsman, "%s%sBombarding planet %s with %s %d.%s",
                    ANSI_HILITE, ANSI_RED, ship->orbitting->name,
                    ship->photon_string, i, ANSI_NORMAL );
                damage_planet( ship->orbitting->listref, ship->photon[i].power, WPN_TORP );
                ship->photon[i].status = PHOTON_EMPTY;
                ship->photon[i].turns_charged = 0;
                ship->photon[i].charge = 0;
                ship->torps_remaining--;
                if( ship->reloading_tube==NO_RELOAD && ship->auto_reload )
                {
                    reload_photon( ship, helmsman, i );
                }
                if( ship->smart_alloc==2 )
                {
                    free_power( ship, POWER_HELM_TORPS, ship->photon[i].charge_per_turn );
                }
            }
        }
    }
    ship_interdict_check( ship );
    if( ship->transwarp_engaging )
    {
        ship->battle_timer=TIMER_RESET;
        ship->transwarp_charge += ship->nalloc_warp;
        if( ship->transwarp_charge >= ship->transwarp_power )
        {
            transwarp_jump( ship );
        }
    }
  
  if ( ship->warp_speed == ship->warpset && ship->warp_speed >= 1 && ship->wnotify !=0 )
  {
  ship->wnotify=0;
  fnotify( navigator, "%sShip now at warp %1.1f.%s", ANSI_CYAN, ship->warpset, ANSI_NORMAL );
  }
  }  
  return;
  
}

void rotate_ships( void )
{
    float dist,change,speed_squared,mul;
    char turned,slow;
    int nrg_extra=0;
    SHIP *ship;

    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        /* perform any rotation */
        if( ship->rotation != (float)0.0 )
        {
            ship->motion.bearing += ship->rotation;
            if( ship->motion.bearing >= 360.0 )
                ship->motion.bearing -= 360.0;
            else if( ship->motion.bearing < 0.0 )
                ship->motion.bearing += 360.0;
            ship->course = ship->motion;
        }
        turned = FALSE;
        slow = FALSE;
        /* adjust course */
        if( ship->motion.bearing!=ship->course.bearing )
        {
            if( ship->smart_alloc==2 && !turned )
            {
                requisition_power( ship, POWER_NAV_WARP, remaining_opt_power(ship) );
            }
            nrg_extra=ship->nalloc_warp-(int)((WARP_CONST+10.0*ship->warp_speed*ship->warp_speed) * ship->current_warp_factor);
            speed_squared = ((float)nrg_extra / 10.0 /
                ship->current_warp_factor - WARP_CONST/10.0 );
            if( speed_squared > 1.0 )
            {
                mul = sqrt( speed_squared );
            }
            else
            {
                mul = 1.0;
            }
            change = ship->yaw_dps * mul;
            dist=ship->course.bearing-ship->motion.bearing;
            if( abs(dist) > 180.0 )
            {
                dist = -dist;
            }
            change = (dist < 0.0 ? -1.0 : 1.0) * change;
            if( abs(change) >= abs(dist) )
            {
                ship->motion.bearing = ship->course.bearing;
            }
            else
            {
                ship->motion.bearing += change;
            }
            ship->motion = fix_sph_coord( ship->motion );
            ship->inc = sph_to_xyz( ship->motion );
            turned = TRUE;
        }
        if( ship->motion.elevation!=ship->course.elevation )
        {
            if( ship->smart_alloc==2 && !turned )
            {
                requisition_power( ship, POWER_NAV_WARP, remaining_opt_power(ship) );
            }
            nrg_extra=ship->nalloc_warp-(int)((WARP_CONST+10.0*ship->warp_speed*ship->warp_speed) * ship->current_warp_factor);
            speed_squared = ((float)nrg_extra / 10.0 /
                ship->current_warp_factor - WARP_CONST/10.0);
            if( speed_squared > 1.0 )
            {
                mul = sqrt( speed_squared );
            }
            else
            {
                mul = 1.0;
            }
            change = ship->pitch_dps * mul;
            dist = ship->course.elevation - ship->motion.elevation;
            change = (dist < 0.0 ? -1.0 : 1.0) * change;
            if( abs(change) >= abs(dist) )
            {
                ship->motion.elevation = ship->course.elevation;
            }
            else
            {
                ship->motion.elevation += change;
            }
            ship->motion = fix_sph_coord( ship->motion );
            ship->inc = sph_to_xyz( ship->motion );
            turned = TRUE;
        }
        if( turned )
        {
            sprintf( writebuf, "changed course to %.0f%+.0f",
                ship->motion.bearing, ship->motion.elevation );
            watch_message( ship, writebuf );
            if( ship->motion.bearing==ship->course.bearing
            && ship->motion.elevation==ship->course.elevation )
            {
                sprintf( writebuf, "%sCourse now set to %s%s%.0f%+.0f%s%s.%s",
                    ANSI_GREEN, ANSI_HILITE, ANSI_RED,
                    ship->course.bearing, ship->course.elevation,
                    ANSI_NORMAL, ANSI_GREEN, ANSI_NORMAL );
                notify_room( BRIDGE(ship), writebuf );
                if( ship->smart_alloc==2 && nrg_extra > 0 )
                {
                    free_power( ship, POWER_NAV_WARP, nrg_extra );
                }
            }
            else if( ship->on_autopilot && ship->motion.range!=ship->course.range )
            {
                slow = TRUE;
            }
            else if( ship->on_autopilot && ship->motion.range==ship->course.range
            && distance(ship->pos,ship->autopilot_destination) < ship->motion.range*5 )
            {
                sprintf(writebuf, "%s%sAUTOPILOT: Slowing down to make turn.%s",
                    ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
                notify_room( BRIDGE(ship), writebuf );
                set_warp( ship, -42, 0.0 );
                slow = TRUE;
            }
        }
        if( !slow && ship->motion.range!=ship->course.range )
        {
            set_warp( ship, -1, pow(ship->course.range,1.0/3.0) );
        }
    }
    return;
}

void move_ships( void )
{ 
  SHIP *ship = space_list[current_space];
  SHIP *towee = NULL;
  int speed=0,speed_squared=0;
  SPH motion;
  XYZ inc,cpos;   

  while( ship != NULL )
  { 
    if ( ship->warp_speed < ship->warpset && ship->warpset > ship->wnot && ship->warpset !=0)
    {
       ship->warp_speed = (ship->warp_accel + ship->warp_speed);
 	if( ship->warp_speed > ship->warpset)
	{
	 ship->warp_speed = ship->warpset;
	 
	}
    }
    else if( (fabs(ship->warp_speed) <= ship->warp_decel) && ship->warpset==0)
    {       
	    ship->warp_speed = ship->warpset;
   
    }
    else
     {
      ship->warp_speed = fabs(ship->warp_speed - ship->warp_decel);
	if( ship->warp_speed < ship->warpset || fabs(ship->warp_speed) < ship->warp_decel)
	{ 
	 ship->warp_speed = ship->warpset;
	 
	}
    }
/* if( (fabs(ship->warp_speed) > ship->warpset) && (ship->warpset < ship->wnot) && (fabs(ship->warp_speed) > ship->warp_decel)) */
    if( ship->warp_speed > 0.0 && ship->orbitting )
    {
        orbit( ship, -1, NULL );
    }

    /* move current ship */
    if( ship->inc_set != 0 )
    {
    ship->motion.range = translate_warp( ship->warp_speed );
    if( ship->ienactor!=-42 )
    {
        ship->course.range = ship->motion.range;
    }
    ship->inc = sph_to_xyz( ship->motion );
    }
    ship->pos.x += ship->inc.x;
    ship->pos.y += ship->inc.y;
    ship->pos.z += ship->inc.z;

    sprintf( writebuf, "%.0f %.0f %.0f", ship->pos.x, ship->pos.y, ship->pos.z );
    atr_add(ship->ship_object, (char *)"STARTPOS", writebuf, HOWIE, NOTHING);

    /* check for autopilots arriving at their destinations */
    if( ship->on_autopilot )
    {
        autopilot_dest_check( ship );
    }
    /* check tractor beaming */
    if( ship->tractor_target!=NULL
    && ( towee=ship->tractor_target->listref )!=NULL )
    {
        if( distance(ship->pos,towee->pos) > ship->tractor_range )
        {
            drop_tractor( ship, -1 );
        }
        else if( ship->tractor_mode==MODE_TRACTOR || ship->tractor_mode==MODE_PRESSOR )
        {
            if( ship->tractor_mode==MODE_PRESSOR )
            {
                cpos.x = towee->pos.x - ship->pos.x;
                cpos.y = towee->pos.y - ship->pos.y;
                cpos.z = towee->pos.z - ship->pos.z;
            }
            else
            {
                cpos.x = ship->pos.x - towee->pos.x;
                cpos.y = ship->pos.y - towee->pos.y;
                cpos.z = ship->pos.z - towee->pos.z;
            }
            if( towee->warp_speed < 1.0 && ( towee->flags[DISABLED]
            || towee->damage[SYSTEM_IMPULSE].status=='9'
            || towee->damage[SYSTEM_IMPULSE].status=='8'
            || towee->damage[SYSTEM_IMPULSE].status=='7'
            || tolower(towee->damage[SYSTEM_IMPULSE].status)=='x' ) )
            {
                towee->motion.range = 0;
                towee->inc = sph_to_xyz( towee->motion );
            }
            motion=xyz_to_sph( cpos );
            speed_squared = ((float) ship->halloc_tractor / 10.0 /
                towee->warp_factor - WARP_CONST/10.0 );
#if defined(WARP_IMPULSE)
            if( speed_squared > 0.0 && !towee->flags[PINNED] )
#else
            if( speed_squared > 1.0 && !towee->flags[PINNED] )
#endif

            {              
                speed = sqrt( speed_squared );
                motion.range = translate_warp( speed );
                if( ship->tractor_mode==MODE_PRESSOR )
                {
                    motion.range = UMIN( motion.range, ship->tractor_range-distance(ship->pos,towee->pos) );
                }
                else
                {
                    motion.range = UMIN( motion.range,distance(ship->pos,towee->pos));
                }
                if( motion.range > 0.0 && towee->orbitting!=NULL )
                {
                    orbit( towee, -1, NULL );
                }
                inc = sph_to_xyz( motion );
                towee->pos.x += inc.x;
                towee->pos.y += inc.y;
                towee->pos.z += inc.z;
            }
        }
    }
    /* set pointer to next ship */
    ship = ship->next;
  }
  return;
  
}


/*
 * JMS 27 Sep 93 - Major changes here.  Old way: expire stale contacts
 * immediately.  New way:  Do normal checks.  Flag expired contacts for
 * removal.  All clients report to servers.  All servers report to clients.
 * In so doing, remove the expire flag on any contacts that are sustained.
 * THEN go through all the contacts and expire dead ones.
 */
void sensor_checks( void )
{
  SHIP *senser;
  SHIP *sensee;
  float range;

  senser = space_list[current_space];
  
  {
  while( senser != NULL )
  { 
    sensee = senser->next;

    while( sensee != NULL )
    {
      if(!strcmp(fetch_attribute(sensee->ship_object,"UNDOCKED"),"1") && !strcmp(fetch_attribute(senser->ship_object,"UNDOCKED"),"1") )
      {
      range = distance( senser->pos, sensee->pos );
      do_sensors( senser, sensee, range );
      do_sensors( sensee, senser, range );
      }
      sensee = sensee->next;
    }

    senser = senser->next;
  }
  

  senser = space_list[current_space];
  
  while( senser != NULL )
  {
    if( senser->server.status == SNS_ON )
    {
      update_server( senser );
    }
    senser = senser->next;
  }

  senser = space_list[current_space];

  while( senser != NULL )
  {
    if( senser->active_clients )
    {
#if defined(SENSOR_DEBUG)
        log_space( "%d clients:", senser->active_clients );
#endif
        update_clients( senser );
    }
    senser = senser->next;
  }

  senser = space_list[current_space];
  
  while( senser != NULL )
  {
    if( senser->contact_list!=NULL )
    {
        kill_stale_contacts( senser );
    }
    senser = senser->next;
  }
  }
}


/*
 * do_sensors()
 *
 *  input:
 *    SHIP *senser      ship who's looking
 *    SHIP *sensee      ship who's getting looked at
 *    float range     distance between them
 *
 *  purpose:
 *    updates the contact status
 *
 * JMS ?? July 92
 * JMS 25 May 93 - general cleanup
 * JMS 25 May 93 - assess 2*photon penalty for armed torps.
 * JMS 25 May 93 - cut border sensor effectivness from .5 to .3
 * JMS 25 Sep 93 - DEBUG_SENSORS stuff, planet effect
 */
void do_sensors( SHIP *senser, SHIP *sensee, float range )
{
    CONTACT *contact;
    float effective_aspect_ratio;
    float prob;   /* probability of acquiring the target */
    float aprob;    /* probability with the remote array */
    float roll;         /* our random number */
    float planet_effect;  /* between 0 and .8 - effect of planets */
    int i; /* loop counter */
    int new_info_level;

    /* return if sensors are damaged or nonexistent */
    if( tolower(senser->damage[SYSTEM_SENSORS].status) > 'x'
    && tolower(senser->damage[SYSTEM_AUX_SENSORS].status) > 'x' )
    {
        return;
    }
    if( senser->damage[SYSTEM_SENSORS].status > '6'
    && senser->damage[SYSTEM_AUX_SENSORS].status > '6' )
    {
        return;
    }
    /* begin by searching for the sensee in senser's contact list */
     contact = find_contact(senser,sensee);


    /* calculate probability of aquisition */
    effective_aspect_ratio = sensee->aspect_ratio;

    /* calculate the planet effect - JMS 25 Sep 93 */
/*
    planet_effect = sensee->near_planet_size * 0.80 / (sensee->near_planet_size + 
                  (sensee->near_planet_range * sensee->near_planet_range /
                  1000000.0));
*/
    planet_effect = 0; /* planet effect is fudged */

#ifdef SENSOR_DEBUG
    fnotify( DEBUG_CHAR, "------------------------------" );
    fnotify( DEBUG_CHAR, "%s sensing %s", senser->name, sensee->name );
    fnotify( DEBUG_CHAR, " sensee aspect ratio: %f", effective_aspect_ratio );
    fnotify( DEBUG_CHAR, " planet_effect: %f", planet_effect );
#endif

    /* apply it only if it's at least 5% */
    if( planet_effect >= 0.05 )
    {
        if( sensee->cloak_status == CLOAK_ON )
            effective_aspect_ratio *= ( 1.0 + ( 2 * planet_effect ));
        else
            effective_aspect_ratio *= ( 1.0 - planet_effect );
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " new aspect ratio: %f", effective_aspect_ratio );
#endif
    }
    /* weapons on line bonus only applies if the target is cloaked */
    if( sensee->cloak_status == CLOAK_ON )
    {
        effective_aspect_ratio += (((float)( sensee->num_photons_online )
            * PHOTON_CHARGING_PENALTY ) + ((float)( sensee->num_phasers_online )
            * PHASER_ONLINE_PENALTY ));
        /* count armed photons */
        for( i = 0; i < sensee->number_of_photons; i++ )
        {
            if( sensee->photon[i].status == PHOTON_ARMED )
                effective_aspect_ratio += PHOTON_ARMED_PENALTY;
        }
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " sensee aspect ratio after weapon penalties: %f",
             effective_aspect_ratio );
#endif
    }
    else
    {
        /* if target is 'hazy', cut aspect ratio unless cloaked */
        if( sensee->flags[HAZY] )
        {
            effective_aspect_ratio *= 0.3;
#ifdef SENSOR_DEBUG
            fnotify( DEBUG_CHAR, " sensee HAZY: new aspect ratio: %f",
                effective_aspect_ratio );
#endif
        }
    }
    /* if seer has cataracts, cut the aspect ratio */
    if( senser->flags[CATARACTS] )
    {
        effective_aspect_ratio *= 0.3;
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " senser CATARACTS: new aspect ratio: %f",
            effective_aspect_ratio );
#endif
    }
    /* It's Really Really easy to detect someone who locks weapons on you */
    if( sensee->locked_target!=NULL )
    {
        if( sensee->locked_target->listref==senser )
        {
            effective_aspect_ratio += 10.0;
#ifdef SENSOR_DEBUG
            fnotify( DEBUG_CHAR, " lock bonus: new aspect ratio: %f",
                effective_aspect_ratio );
#endif
        }
    }
    /* check for a pending lock too. */
    else if( sensee->pending_lock != NULL )
    {
        if( sensee->pending_lock->listref==senser )
        {
            effective_aspect_ratio += 5.0;
#ifdef SENSOR_DEBUG
            fnotify( DEBUG_CHAR, " pending lock bonus: new aspect ratio: %f",
                effective_aspect_ratio );
#endif
        }
    }
    /* It's SUPER-SUPER easy to see someone who has locked tractors */
    if( sensee->tractor_target!=NULL )
    {
        if( sensee->tractor_target->listref==senser )
        {
            effective_aspect_ratio += 100.0;
#ifdef SENSOR_DEBUG
            fnotify( DEBUG_CHAR, " tractor bonus: new aspect ratio: %f",
                effective_aspect_ratio );
#endif
        }
    }
    if( senser->sensor_power > 0
    && senser->damage[SYSTEM_SENSORS].status < '7'
    && tolower(senser->damage[SYSTEM_SENSORS].status)!='x'
    && in_arc(senser->sensor_arc,facing_vector(senser,sensee->pos)) )
    {
        prob = ((senser->nebula_visibility + sensee->nebula_visibility) / 2 )*
            ( 1.0 - ( range / (senser->sensor_power) / effective_aspect_ratio ) );
    }
    else
    {
        prob = -1000.0;
    }
    if( senser->aux_sensor_power > 0
    && senser->damage[SYSTEM_AUX_SENSORS].status < '7'
    && tolower(senser->damage[SYSTEM_AUX_SENSORS].status)!='x'
    && in_arc(senser->aux_sensor_arc,facing_vector(senser,sensee->pos)) )
    {
        aprob = ((senser->nebula_visibility + sensee->nebula_visibility) / 2 )*
            ( 1.0 - ( range / (senser->aux_sensor_power) / effective_aspect_ratio ) );
    }
    else
    {
        aprob = -1000.0;
    }
#ifdef SENSOR_DEBUG
    fnotify( DEBUG_CHAR, " prob: %f     aprob: %f", prob, aprob );
#endif
    if( aprob > prob )
    {
        prob = aprob;
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " aprob is better: prob: %f", prob );
#endif
    }
    /* warp speed adjustment */
    prob += (( sensee->warp_speed - senser->warp_speed ) / 50.0 );
#ifdef SENSOR_DEBUG
    fnotify( DEBUG_CHAR, " Warp speed adjustment: prob: %f", prob );
#endif
    /* prior acquisition/lock-on bonus */
    if( contact != NULL )
    {
        prob += 0.25;
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " prior acquisition bonus: prob: %f", prob );
#endif
        if( senser->locked_target==contact )
        {
            prob += 0.25;
#ifdef SENSOR_DEBUG
            fnotify( DEBUG_CHAR, " prior lock bonus: prob: %f", prob );
#endif
        }
    }
    /* if senser is nearsighted, set the prob */
    if( senser->flags[NEARSIGHTED] )
    {
        if( range >= senser->sensor_power )
        {
            prob = 0.0;
        }
        else
        {
            prob = 1.0;
        }
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " senser nearsighted: prob: %f", prob );
#endif
    }
    /* if the target is invisble, set prob to zero */
    if( sensee->flags[INVISIBLE] )
    {
        prob = 0.0;
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " sensee invisible: prob: %f", prob );
#endif
    }
    if( senser->flags[BLIND] )
    {
        prob = 0.0;
    }
    /* if senser is omniscient, set the prob */
    if( senser->flags[OMNISCIENT] )
    {
        prob = 1.0;
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " senser omniscient: prob: %f", prob );
#endif
    }
    if( contact==NULL && ( sensee->flags[DEADMAN] || ( sensee->orbitting!=NULL
    && !sensee->num_phasers_online && !sensee->num_photons_online && !sensee->bombarding
    && !sensee->pending_lock && !sensee->locked_target && !sensee->tractor_target ) ) )
    {
        prob = 0.0;
    }
    /* if senser and sensee are a client_server pair in comm range, prob = 1 */
    if( ( senser->server.ship==sensee || sensee->server.ship==senser )
    && net_range(senser,sensee) )
    {
        prob = 1.0;
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, " client/server pair in comm range: prob: %f", prob );
#endif
    }
    else if( sensee->cloak_status!=CLOAK_ON
    && !strcmp( senser->transponder, sensee->transponder )
    && distance(senser->pos,sensee->pos) <= senser->transmitter_range )
    {
        prob = 1.0;
    }
    /* now check for it */
    if( FRAND < prob )
    {
        /* we got him. */
        if( contact == NULL )
        {
            /* add this new contact to the linked list and notify the helmsman */
            if( add_contact( senser, sensee ) == SERR_MALLOC )
            {
                log_space( "JMALLOC failure - contact list for #%d.",
                    senser->ship_object );
                return;
            }
            /* load the contact */
            contact = senser->contact_tail;
        }
        contact->turns_of_contact++;
        contact->turns_since_last_contact = 0;

        contact->last_pos.x = contact->listref->pos.x;
        contact->last_pos.y = contact->listref->pos.y;
        contact->last_pos.z = contact->listref->pos.z;

        /* return if info level is already five */
        if( contact->info_level==5 )
            return;

        prob = (float)( contact->turns_of_contact ) / 20.0;
        roll = FRAND;

        if( senser->flags[OMNISCIENT] || senser->flags[NEARSIGHTED] )
            roll = 0;

        if( roll < prob )
            new_info_level = 5;
        else if( roll < ( prob + .10 ))
            new_info_level = 4;
        else if( roll < ( prob + .20 ))
            new_info_level = 3;
        else if( roll < ( prob + .30 ))
            new_info_level = 2;
        else
            new_info_level = 1;

        /* if the ship is cloaked, never give full information */
        if( contact->listref->cloak_status==CLOAK_ON && !senser->flags[OMNISCIENT] )
        {
            if( new_info_level > 3 )
                new_info_level = 3;
        }
        /* the contact new info assignment line has to be duplicated like this *
         * so that we can tell the difference between new contacts and updates.*/
        if( contact->info_level == 0 )
        {
            contact->info_level = new_info_level;
            display_sensor_info( senser, contact, -1, DSD_NEW );
        }
        else if( new_info_level > contact->info_level )
        {
            contact->info_level = new_info_level;
            display_sensor_info( senser, contact, -1, DSD_UPDATE );
        }
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, "CONTACT" );
#endif
    }
    else
    {
        /* no contact */
        if( contact!=NULL )
        {
            /* increment turns_since_last_contact */
            contact->turns_since_last_contact++;

            /* if we've now missed him three times in a row, drop the contact *
             * or, drop him in one if he's cloaked, invisible, or out of range */
            if( contact->listref->cloak_status==CLOAK_ON
            || contact->listref->flags[INVISIBLE]
            || ( prob <= 0.0 && !on_snet(senser) ) )
            {
                contact->stale = TRUE;
            }
            else if( ( contact->turns_since_last_contact>=3 && !on_snet(senser) )
            || contact->turns_since_last_contact>=9 )
            {
                contact->stale = TRUE;
            }
        }
#ifdef SENSOR_DEBUG
        fnotify( DEBUG_CHAR, "NO CONTACT" );
#endif
    }
#ifdef SENSOR_DEBUG
    fnotify( DEBUG_CHAR, "------------------------------" );
#endif
    return;
}

void kill_stale_contacts( SHIP *ship )
{
    CONTACT *contact,*next;

    for(contact=ship->contact_list;contact!=NULL;contact=next)
    {
        next = contact->next;
        if( contact->stale == TRUE )
            remove_contact( ship, contact );
    }
    return;
}


void update_server( SHIP *ship )
{
    CONTACT *client_contact, *server_contact;
    float range;

    if( ship->server.status!=SNS_ON || ship->server.ship==NULL )
    {
        return;
    }
    if( check_jammed(ship,ship) )
    {
        sever_link( ship, ship->server.ship, TS_INTERRUPTED, TN_BOTH );
        return;
    }
    client_contact = ship->contact_list;

    for(client_contact=ship->contact_list;client_contact!=NULL;client_contact=client_contact->next)
    {
        if( client_contact->stale && client_contact->listref->motion.range > 0.0 )
        {
            range=distance(ship->pos,client_contact->listref->pos);
            if( !( range<=ship->sensor_power && in_arc(ship->sensor_arc,facing_vector(ship,client_contact->listref->pos)) )
            && !(range<=ship->aux_sensor_power && in_arc(ship->aux_sensor_arc,facing_vector(ship,client_contact->listref->pos)) ) )
            {
                continue;
            }
        }
        if( client_contact->listref!=ship->server.ship )
        {
            server_contact = find_contact(ship->server.ship,client_contact->listref);

            if( server_contact == (CONTACT *)NULL )
            {
                new_net_contact( ship->server.ship, client_contact );
            }
            else if( server_contact->info_level < client_contact->info_level )
            {
                upgrade_contact( ship->server.ship, server_contact, client_contact );
                server_contact->stale = FALSE;
                server_contact->last_pos = client_contact->last_pos;
            }
            else if( server_contact->stale )
            {
                server_contact->stale = FALSE;
                server_contact->last_pos = client_contact->last_pos;
                server_contact->turns_since_last_contact = UMIN(client_contact->turns_since_last_contact,server_contact->turns_since_last_contact);
            }
        }
        else
        {
            client_contact->info_level = 5;
        }      
    }
    return;
}


void update_clients( SHIP *ship )
{
    CONTACT *client_contact, *server_contact;
    char jammed=check_jammed(ship,ship);
    unsigned int i;

    if( jammed )
    {
        while( ship->active_clients > 0 )
        {
            sever_link( ship, ship->clients[0].ship, TS_INTERRUPTED, TN_BOTH );
        }
    }
    for(server_contact=ship->contact_list;server_contact!=NULL;server_contact=server_contact->next)
    {
        for(i=0;i<ship->active_clients;i++)
        {
            if( ship->clients[i].status!=SNS_ON || ship->clients[i].ship==NULL )
            {
                continue;
            }
            if( ship->clients[i].ship!=server_contact->listref )
            {
                client_contact = find_contact( ship->clients[i].ship,
                		       server_contact->listref );

                if( client_contact == (CONTACT *)NULL )
                {
                    new_net_contact( ship->clients[i].ship, server_contact );
                }
                else if( client_contact->info_level < server_contact->info_level )
                {
                    upgrade_contact( ship->clients[i].ship, client_contact, server_contact );
                    client_contact->stale = FALSE;
                    client_contact->last_pos = server_contact->last_pos;
                }
                else if( client_contact->stale )
                {
                    client_contact->stale = FALSE;
                    client_contact->last_pos = server_contact->last_pos;
                    client_contact->turns_since_last_contact = UMIN(client_contact->turns_since_last_contact,server_contact->turns_since_last_contact);
                }
            }
            else
            {
                server_contact->info_level = 5;
            }
        }
    }
    return;
}


void new_net_contact( SHIP *ship, CONTACT *their_contact )
{
CONTACT *contact;

  add_contact( ship, their_contact->listref );
  contact = ship->contact_tail;
  contact->info_level = their_contact->info_level;
  contact->info_level = their_contact->info_level;
  contact->turns_since_last_contact = their_contact->turns_since_last_contact;
  contact->last_pos = their_contact->last_pos;
  display_sensor_info( ship, contact, -1, DSD_NEW );
  
}


void upgrade_contact( SHIP *ship, CONTACT *our_contact, CONTACT *their_contact )
{
  our_contact->info_level = their_contact->info_level;
  our_contact->info_level = their_contact->info_level;
  our_contact->turns_since_last_contact = UMIN(our_contact->turns_since_last_contact,their_contact->turns_since_last_contact);
  display_sensor_info( ship, our_contact, -1, DSD_UPDATE );
}

SPH fix_sph_coord( SPH coord )
{
    for( ;coord.elevation>90||coord.elevation<-90; )
    {
        if( coord.elevation < -90 )
        {
            coord.elevation += 90;
            coord.bearing += 180;
        }
        else if( coord.elevation > 90 )
        {
            coord.elevation -= 90;
            coord.bearing += 180;
        }
    }
    for( ;coord.bearing>=360||coord.bearing<0; )
    {
        coord.bearing += coord.bearing < 360 ? 360 : -360;
    }
    return coord;
}

SPH fix_spharc_coord( SPH coord )
{
    for( ;coord.elevation>180||coord.elevation<-180; )
    {
        if( coord.elevation < -180 )
        {
            coord.elevation += 180;
        }
        else if( coord.elevation > 180 )
        {
            coord.elevation -= 180;
        }
    }
  coord.bearing = (int) coord.bearing % 360;
  if (coord.bearing < 0) coord.bearing += 360;
  else if (coord.bearing >= 360) coord.bearing -= 360;
/*
    for( ;coord.bearing>=360||coord.bearing<0; )
    {
        coord.bearing += coord.bearing < 360 ? 360 : -360;
    }
*/
    return coord;
}

int in_arc( ARC arc, SPH vector )
{
    SPH var;

    vector = fix_sph_coord( vector );
    var.bearing = vector.bearing - arc.center.bearing;
    var.elevation = abs(vector.elevation - arc.center.elevation);
    var.range = 1.0;
    var = fix_spharc_coord( var );
    if( var.bearing > 180 )
    {
        var.bearing = 360 - var.bearing;
    }
    if( var.bearing <= arc.htraverse && fabs(var.elevation) <= arc.vtraverse )
    {
        return 1;
    }
    return 0;
}

SPH facing_vector( SHIP *ship, XYZ target )
{
    SPH bearing;
    XYZ cpos;

    cpos.x = target.x - ship->pos.x;
    cpos.y = target.y - ship->pos.y;
    cpos.z = target.z - ship->pos.z;
    bearing = xyz_to_sph( cpos );
    bearing.bearing -= ship->motion.bearing;
    bearing.elevation -= ship->motion.elevation;
    bearing.range = 1.0;
    return fix_sph_coord(bearing);
}

/*void do_intercept()
{

  SHIP *ship = space_list[current_space];
  
  
  if( ship->intercepting == 1 )
   {
    if( (distance(ship->pos,ship->interceptor->pos) > 500) && !strcmp(fetch_attribute(ship->ship_object,"UNDOCKED"),"1") )
    {
  
    * set the new course *
    ship->course.bearing = ship->interceptor->motion.bearing;
    ship->course.elevation = ship->interceptor->motion.elevation;
    ship->course = fix_sph_coord( ship->course );
  
    }
    * If too close, stop intercepting *
    else
    {
     ship->intercepting = 0;
    }
   }
 }
*/
