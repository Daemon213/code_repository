/* What the hell is this file?  It has no comments or anything.
 * I HOPE to put something here in explanation.  
 * -- Howie
 */


FUNCTION(fun_cim_info)
{
    dbref ship_object=0;
    CONTACT *contact;
    char temp[4096];
    SHIP *ship;
    XYZ cpos;
    SPH sph;

    for(current_space=0;current_space<SPACE_LIMIT;current_space++)
    {
        for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
        {
            if( BRIDGE(ship)==Location(enactor) )
            {
                ship_object = ship->ship_object;
                break;
            }
        }
        if( ship_object )
        {
            break;
        }
    }
    if( ship_object==0 )
    {
        safe_str("#-1 NOT ON SHIP OR SHIP NOT ACTIVE", buff, bp );
        return;
    }        
    bzero( temp, 4096 );
    if( !strcmp(args[0],"xyzpos") )
    {
        sprintf( writebuf, "%.0f %.0f %.0f", ship->pos.x, ship->pos.y, ship->pos.z );
        safe_str( writebuf, buff, bp );
        return;
    }
    else if( !strcmp(args[0],"sphpos") )
    {
        cpos.x = ship->pos.x - ship->origin.x;
        cpos.y = ship->pos.y - ship->origin.y;
        cpos.z = ship->pos.z - ship->origin.z;
        sph = xyz_to_sph( cpos );
        sprintf(writebuf,"%.3f %.3f %.3f", sph.bearing, sph.elevation, sph.range );
        safe_str( writebuf, buff, bp );
        return;
    }
    else if( !strcmp(args[0],"shield_status") )
    {
        sprintf( writebuf, "%d %d %d %d", ship->shield_level[0],
            ship->shield_level[1], ship->shield_level[2],
            ship->shield_level[3] );
        safe_str( writebuf, buff, bp );
        return;
    }
    else if( !strcmp(args[0],"contact_nums") )
    {
        bzero( writebuf, 4096 );
        writebuf[0] = '\0';
        for(contact=ship->contact_list;contact!=NULL;contact=contact->next)
        {
            sprintf( temp, "%d ", contact->contact_number );
            strcat( writebuf, temp );
        }
        writebuf[strlen(writebuf)-1]='\0';
        safe_str( writebuf, buff, bp );
        return;
    }
    else if( !strcmp(args[0],"contact_xyzpos") && args[1]!=NULL )
    {
        if( current_space==REAL
        && !( ship->flags[STARBASE] || Wizard(enactor) ) )
        {
            safe_str( "#-1 PERMISSION DENIED", buff, bp );
            return;
        }
        if( ( contact=match_contact(ship,args[1]) )!=NULL )
        {
            sprintf( writebuf, "%.0f %.0f %.0f", contact->listref->pos.x,
                contact->listref->pos.y, contact->listref->pos.z );
        }
        else
        {
            sprintf( writebuf, "#-1 NO CONTACT FOUND" );
        }
        safe_str( writebuf, buff, bp );
        return;
    }
    else if( !strcmp(args[0],"contact_sphpos") && args[1]!=NULL )
    {
        if( current_space==REAL
        && !( ship->flags[STARBASE] || Wizard(enactor) ) )
        {
            safe_str( "#-1 PERMISSION DENIED", buff, bp );
            return;
        }
        if( ( contact=match_contact(ship,args[1]) )!=NULL )
        {
            cpos.x = contact->listref->pos.x - ship->pos.x;
            cpos.y = contact->listref->pos.y - ship->pos.y;
            cpos.z = contact->listref->pos.z - ship->pos.z;
            sph = xyz_to_sph( cpos );
            sprintf( writebuf, "%.5f %.5f %.5f", sph.bearing,
                sph.elevation, sph.range );
        }
        else
        {
            sprintf( writebuf, "#-1 NO CONTACT FOUND" );
        }
        safe_str( writebuf, buff, bp );
        return;
    }
    else if( !strcmp(args[0],"contact_string_terse") && args[1]!=NULL )
    {
        if( ( contact=match_contact(ship,args[1]) )!=NULL )
        {
            contact_string( temp, contact, INFO_TERSE );
            strcpy( writebuf, temp );
        }
        else
        {
            sprintf( writebuf, "#-1 NO CONTACT FOUND" );
        }
        safe_str( writebuf, buff, bp );
        return;
    }
    else if( !strcmp(args[0],"contact_string_verbose") && args[1]!=NULL )
    {
        if( ( contact=match_contact(ship,args[1]) )!=NULL )
        {
            contact_string( temp, contact, INFO_VERBOSE );
            sprintf( writebuf, "%s <%.2f>", temp, contact->listref->size );
        }
        else
        {
            sprintf( writebuf, "#-1 NO CONTACT FOUND" );
        }
        safe_str( writebuf, buff, bp );
        return;
    }
    else
    {
        safe_str( "#-1 UNRECOGNIZED CIMINFO REQUEST", buff, bp );
    }
    return;
}
