/*
 * $Id: watch.c,v 1.3 1993/09/25 20:39:40 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: watch.c,v $
 * Revision 1.3  1993/09/25  20:39:40  chuckles
 * cleanup logging code.
 *
 * Revision 1.2  1993/09/24  23:09:41  chuckles
 * use jmalloc library.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS  2 Jun 93 - cleanup
 * JMS 24 May 93 - separated into watch.c
 * JMS/DJB ?? Dec 92 - original code
 */


void add_watch( SHIP *ship, dbref enactor, char *target, int who )
{
  CONTACT *contact;
  char shipname[120];

  contact = match_contact( ship, target );
  if( contact == NULL ) {
    sprintf( writebuf, "No contact matches '%s.'", target );
    notify( enactor, writebuf );
    return;
  }

  /* valid contact.  Now make sure we aren't already watching it */
  contact_string( shipname, contact, INFO_TERSE );
  if( contact->watcher & who ) {
    sprintf( writebuf, "Already watching %s.", shipname );
    notify( enactor, writebuf );
    return;
  }

  /* not watching.  add it */
  contact->watcher |= who;
  add_watch_ref( contact->listref, ship );
  sprintf( writebuf, "Now watching %s.", shipname );
  notify( enactor, writebuf );
}


void remove_watch( SHIP *ship, dbref enactor, char *target, int who )
{
  char shipname[80];
  CONTACT *contact;

  contact = match_contact( ship, target );

  if( contact == NULL ) {
    sprintf( writebuf, "No contact matches '%s.'", target );
    notify( enactor, writebuf );
    return;
  }

  /* valid contact.  Make sure we're already watching it */
  contact_string( shipname, contact, INFO_TERSE );

  if( !( contact->watcher & who )) {
    sprintf( writebuf, "Not currently watching %s.", shipname );
    notify( enactor, writebuf );
    return;
  }

  contact->watcher -= who;
  if( contact->watcher == W_NOBODY )
    remove_watch_ref( contact->listref, ship );

  sprintf( writebuf, "No longer watching %s.", shipname );
  notify( enactor, writebuf );

  return;
}


void remove_watch_ref( SHIP *ship, SHIP *unwatcher )
{
  WATCH *watch;

  watch = ship->watch_list;

  while( watch != NULL ) {
    if( watch->listref == unwatcher ) {
      /* this is our guy.  Weave it out of the list */
      if( ship->watch_list == ship->watch_tail ) {
        ship->watch_list = NULL;
        ship->watch_tail = NULL;
      }
      else if( watch->prev == NULL ) {
        ship->watch_list = ship->watch_list->next;
        ship->watch_list->prev = NULL;
      }
      else if( watch->next == NULL ) {
        ship->watch_tail = ship->watch_tail->prev;
        ship->watch_tail->next = NULL;
      }
      else {
        watch->prev->next = watch->next;
        watch->next->prev = watch->prev;
      }

      JFREE( watch );
      return;
    }
    else
      watch = watch->next;
  }
}


void add_watch_ref( SHIP *watchee, SHIP *watcher )
{
  WATCH *watch;
  CONTACT *contact;

  watch = (WATCH *)JMALLOC( sizeof( WATCH ));
  if( watch == NULL )
    return;

  watch->prev = watchee->watch_tail;

  watch->next = NULL;

  if( watchee->watch_tail )
    watchee->watch_tail->next = watch;
  else
    watchee->watch_list = watch;

  watchee->watch_tail = watch;

  watch->listref = watcher;

  contact = watcher->contact_list;

  while( contact != NULL ) {
    if( contact->listref == watchee ) {
      watch->watcher_contact = contact;
      return;
    }

    contact = contact->next;
  }

  /* we should never reach this point.  add_watch_ref should never be    *
   * called unless the enactor is trying to put a watch on a valid contact. *
   * if we get to this point, it means that the contact wasn't in the    *
   * list for the calling ship.  throw a wobbly.                         */

  log_space( "ERROR! - add_watch_ref@%s:%d", __FILE__, __LINE__ );

  return;
}


void list_watches( SHIP *ship, dbref enactor, int who )
{
  CONTACT *contact;
  char shipname[80];
  int refs;

  contact = ship->contact_list;
  refs = 0;

  while( contact != NULL ) {
    if( contact->watcher & who ) {
      if( refs == 0 )
        notify( enactor, "Watched ships:" );

      refs++;

      contact_string( shipname, contact, INFO_TERSE );
      sprintf( writebuf, "[%d] -- %s", contact->contact_number, shipname );
      notify( enactor, writebuf );
    }

    contact = contact->next;
  }

  if( refs == 0 )
    notify( enactor, "No watches active." );
}


void watch_message( SHIP *ship, char *message )
{
    WATCH *watch;
    dbref helmsman, navigator;
    char shipname[80];
    char full_message[640];

    for(watch=ship->watch_list;watch!=NULL;watch=watch->next)
    {
        contact_string( shipname, watch->watcher_contact, INFO_TERSE );
        sprintf( full_message, "Contact [%d]: %s %s.",
            watch->watcher_contact->contact_number, shipname,
            message );

        if( watch->watcher_contact->watcher & W_HELM )
        {
            helmsman = match_result(HOWIE, my_atr_get_raw(watch->listref->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
            notify( helmsman, full_message );
        }
        if( watch->watcher_contact->watcher & W_NAV )
        {
            navigator = match_result(HOWIE, my_atr_get_raw(watch->listref->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
            notify( navigator, full_message );
        }
    }
    return;
}
