/*
 * $Id: navhaz.c,v 1.1 1993/09/01 04:22:16 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: navhaz.c,v $
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS 24 May 93 - File separated from space.c
 * JMS ?? Dec 92 - Original code
 */

/**************************************
 *
 * haz_accelerate()
 *
 *  input:
 *    PLANET *planet       accelerator
 *    SHIP *ship           ship being tossed about
 *
 *  purpose:
 *    gives the target ship a good kick in the pants
 *
 *  return value:
 *    none
 *
 * JMS ?? Dec 92
 * JMS 24 May 93 - cleanup
 *
 *************************************/

void haz_accelerate( PLANET *planet, SHIP *ship )
{
  dbref bridge;
  float multiplier;

  multiplier = planet->accel_base + FRAND * planet->accel_extension;

  /* now move the ship multiplier 2-second turns worth */
  ship->pos.x += ( ship->inc.x * multiplier );
  ship->pos.y += ( ship->inc.y * multiplier );
  ship->pos.z += ( ship->inc.z * multiplier );

  /* find the bridge */
  bridge = match_result(HOWIE, my_atr_get_raw(ship->ship_object, "XA"), NOTYPE, MAT_ABSOLUTE);

  /* Send the goofy message. */
  sprintf( writebuf, my_atr_get_raw( planet->planet_object, "HAZ_MESSAGE" ));
  notify_room(db[bridge].location, writebuf);

  /* and return */
  return;
}

FUNCTION(fun_asteroids_cmd)
{
    ASTER *asteroids;
    int i;

    if( !Wizard(executor) || args[0]==NULL )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    /* switch on the argument */
    if( !strcmp( args[0], "activate" ))
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            asteroids = asteroids_list[i];
            while( asteroids != NULL )
            {
                if( executor == asteroids->asteroids_object )
                {
                    notify( enactor, "These asteroids are already activated." );
                    return;
                }
                asteroids = asteroids->next;
            }
        }
        /* okay, we've made it to this point so the asteroids in question
         * must be inactive so far.  Cool.  Activate it
         */
        if ( activate_asteroids( executor, enactor ))
            notify( enactor, "Error initializing asteroids." );

        return;
    }
    else if( !strcmp( args[0], "deactivate" ) )
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            asteroids = asteroids_list[i];
            while( asteroids != NULL )
            {
                if( executor == asteroids->asteroids_object )
                {
                    current_space = i;
                    deactivate_asteroids( asteroids, enactor );
                    return;
                }
                asteroids = asteroids->next;
            }
        }

        /* okay, we've made it to this point so the asteroids in question
         * must not be active.  Warn and return.
         */
        notify( enactor, "Asteroids aren't active." );
        return;
    }
    else
    {
        notify( enactor, "Unrecognized asteroids_command() call." );
    }
    return;
}


int activate_asteroids( dbref executor, dbref enactor )
{
    ASTER *new_asteroids;
    char *curspace;

    if(!(new_asteroids=(ASTER *)JMALLOC(sizeof(ASTER))))
        return SERR_MALLOC;

    /* asteroids space -- either real space, or a sim space */
    curspace = fetch_attribute( executor, "SPACE" );
    if( !strcmp( curspace, "real" ))
        current_space = REAL;
    else if( !strcmp( curspace, "1" ))
        current_space = 1;
    else if( !strcmp( curspace, "2" ))
        current_space = 2;
    else if( !strcmp( curspace, "3" ))
        current_space = 3;
    else if( !strcmp( curspace, "4" ))
        current_space = 4;
    else if( !strcmp( curspace, "5" ))
        current_space = 5;
    else if( !strcmp( curspace, "6" ))
        current_space = 6;
    else if( !strcmp( curspace, "7" ))
        current_space = 7;
    else if( !strcmp( curspace, "8" ))
        current_space = 8;
    else if( !strcmp( curspace, "9" ))
        current_space = 9;
    else if( !strncmp( curspace, "10", 2 ))
        current_space = 10;
    else if( !strncmp( curspace, "11", 2 ))
        current_space = 11;
    else
        current_space = SIM;

    sscanf( fetch_attribute( executor, "LOCATION" ), "%f %f %f", &new_asteroids->pos.x,
        &new_asteroids->pos.y, &new_asteroids->pos.z );

    new_asteroids->name = (char *)Name( executor );
    new_asteroids->size = atof( fetch_attribute( executor, "SIZE" ));
    new_asteroids->density = atof( my_atr_get_raw( executor, "DENSITY" ));
    new_asteroids->asteroids_object = executor;

    if( asteroids_list[current_space]==NULL )
    {
        asteroids_list[current_space] = new_asteroids;
        asteroids_tail[current_space] = new_asteroids;
        new_asteroids->prev = NULL;
    }
    else
    {
        asteroids_tail[current_space]->next = new_asteroids;
        new_asteroids->prev = asteroids_tail[current_space];
        asteroids_tail[current_space] = new_asteroids;
    }
    new_asteroids->next = NULL;
    fnotify( enactor, "Asteroids %s activated in %s space.",
        Name( executor), space_names[current_space] );
    return 0;
}
   
void deactivate_asteroids( ASTER *asteroids, dbref enactor )
{
    SHIP *ship;

    /* this is an easy one.  Simply zorch it from the linked list */
    if( ( asteroids_list[current_space]==asteroids )
    && ( asteroids_tail[current_space]==asteroids ) )
    {
        asteroids_list[current_space] = NULL;
        asteroids_tail[current_space] = NULL;
    }
    else if( asteroids_list[current_space] == asteroids )
    {
        asteroids_list[current_space] = asteroids_list[current_space]->next;
        asteroids_list[current_space]->prev = NULL;
    }
    else if( asteroids_tail[current_space] == asteroids )
    {
        asteroids_tail[current_space] = asteroids_tail[current_space]->prev;
        asteroids_tail[current_space]->next = NULL;
    }
    else
    {
        asteroids->prev->next = asteroids->next;
        asteroids->next->prev = asteroids->prev;
    }
    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        remove_asteroids( ship, asteroids );
    }
    JFREE( asteroids );
    notify( enactor, "Asteroids are zorched." );
    return;
}

void asteroids_checks( void )
{
    SHIP *ship,*ship_next;
    ASTER *asteroids;
    int in_range;
    float range;

    for(ship=space_list[current_space];ship!=NULL;ship=ship_next)
    {
        ship_next = ship->next;
        for(asteroids=asteroids_list[current_space];asteroids!=NULL;asteroids=asteroids->next)
        {
            in_range = FALSE;
            range = distance( ship->pos, asteroids->pos );

            if( ship->flags[OMNISCIENT] || asteroids->size > range
            || UMAX(ship->sensor_power,ship->aux_sensor_power) > range-asteroids->size )
            {
                in_range = TRUE;
            }
            if( in_range )
            {
                add_asteroids( ship, asteroids );
            }
            else
            {
                remove_asteroids( ship, asteroids );
            }            
        }
    }
    return;
}

void add_asteroids( SHIP *ship, ASTER *asteroids )
{
    struct asteroids_contact *contact;
    XYZ xyz_rel;
    SPH sph_rel;

    /* check inside if it's already on the list */
    ship->navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
    for(contact=ship->asteroids_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref==asteroids )
        {
            if( !contact->inside && asteroids->size >= distance(ship->pos,asteroids->pos) )
            {
                enter_asteroids( ship, asteroids, contact );
            }
            else if( contact->inside && !(asteroids->size > ( distance( ship->pos, asteroids->pos ))) )
            {
                /* Inform bridge of new asteroids */
                sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.", ANSI_HILITE, ANSI_RED,
                    ANSI_NORMAL, asteroids->name );
                notify_room( BRIDGE(ship), writebuf );

                contact->inside = 0;
            }
            else if( contact->inside && FRAND < asteroids->density )
            {
                if( asteroid_damage( ship ) )
                {
                    return;
                }
            }
            return;
        }        
    }

    /* allocate memory for the contact and the asteroids name. */
    if( ( contact=(struct asteroids_contact *)JMALLOC(sizeof(struct asteroids_contact)) )==NULL )
        return;

    /* okay, the asteroids isn't on our list.  Add it. */
    contact->listref = asteroids;
    if( ship->asteroids_list == NULL )
    {   /* empty list */
        ship->asteroids_list = contact;
        ship->asteroids_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->asteroids_tail->next = contact;
        contact->prev = ship->asteroids_tail;
        contact->next = NULL;
        ship->asteroids_tail = contact;
    }

    if( asteroids->size >= distance(ship->pos,asteroids->pos) )
    {
        enter_asteroids( ship, asteroids, contact );
    }
    else
    {
        xyz_rel.x = asteroids->pos.x - ship->pos.x;
        xyz_rel.y = asteroids->pos.y - ship->pos.y;
        xyz_rel.z = asteroids->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );
        sph_rel.range = abs(sph_rel.range - asteroids->size);

        fnotify( ship->navigator, "%s%sAsteroid field %s now in sensor range bearing %s%d%+d%s at range %s%ld%s.%s",
            ANSI_HILITE, ANSI_BLUE, asteroids->name, ANSI_RED, (int)sph_rel.bearing, (int)sph_rel.elevation,
            ANSI_BLUE, ANSI_RED, (long int)sph_rel.range, ANSI_BLUE, ANSI_NORMAL );
        contact->inside = 0;
    }
    return;
}

void remove_asteroids( SHIP *ship, ASTER *asteroids )
{
    struct asteroids_contact *contact;

    for(contact=ship->asteroids_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref==asteroids )
        {
            if( contact->inside )
            {
                sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.",
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL, asteroids->name );
                notify_room( BRIDGE(ship), writebuf );
            }
            sprintf( writebuf, "Asteroid field %s is no longer in sensor range.",
                contact->listref->name );

            ship->navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
            notify( ship->navigator, writebuf );

            if( ship->asteroids_list == ship->asteroids_tail )
            {
                ship->asteroids_list = NULL;
                ship->asteroids_tail = NULL;
                JFREE( contact );
                return;
            }
            if( contact==ship->asteroids_list )
            {
                ship->asteroids_list = contact->next;
                ship->asteroids_list->prev=NULL;
                JFREE( contact );
                return;
            }
            if( contact==ship->asteroids_tail )
            {
                ship->asteroids_tail = contact->prev;
                ship->asteroids_tail->next = NULL;
                JFREE( contact );
                return;
            }
            if( ( contact!=ship->asteroids_list )
            && ( contact!=ship->asteroids_tail ) )
            {
                (contact->prev)->next = contact->next;
                (contact->next)->prev = contact->prev;
                JFREE( contact );
                return;
            }
        }
    }
    return;
}

void list_asteroids( SHIP *ship, dbref enactor )
{
    struct asteroids_contact *contact;
    char inside_ast[2],rel_range[5];
    char asteroids_size[5];
    char asteroids_density[3];
    SHIP fake_ship;
    XYZ xyz_rel;
    SPH sph_rel;
    int range;
    static char *shield_strings[] = { (char *)"Fore", (char *)"Aft", (char *)"Port", (char *)"Starboard" };

    contact = ship->asteroids_list;

    if( contact == NULL )
    {
        return;
    }
    for(contact=ship->asteroids_list;contact!=NULL;contact=contact->next)
    {
        range = distance( ship->pos, contact->listref->pos );
        xyz_rel.x = contact->listref->pos.x - ship->pos.x;
        xyz_rel.y = contact->listref->pos.y - ship->pos.y;
        xyz_rel.z = contact->listref->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );

        if( sph_rel.range >= 10000000.0 )
            sprintf( rel_range, "%4.0fM", sph_rel.range / 1000000.0 );
        else if( sph_rel.range >= 100000.0 )
            sprintf( rel_range, "%4.0fK", sph_rel.range / 1000.0 );
        else
            sprintf( rel_range, "%5.0f", sph_rel.range );

        if( contact->listref->size >= 10000 )
            sprintf( asteroids_size, "%3.0dK", contact->listref->size / 1000 );
        else
            sprintf( asteroids_size, "%4.0d", contact->listref->size );

        sprintf( asteroids_density, "%3.0f", contact->listref->density * 100.0 );

        fake_ship.pos = contact->listref->pos;

        if( contact->inside )
            sprintf( inside_ast, "*" );
        else
            sprintf( inside_ast, " " );

        fnotify( enactor, "%s%s   %s   %s%s%-20.20s %s%s%-3.0f %-+3.0f %-5s      %s%s%-3s%%   %s%s%-4s   %s%-10s%s", 
            ANSI_HILITE, ANSI_RED, inside_ast, ANSI_NORMAL, ANSI_CYAN,
            contact->listref->name, ANSI_HILITE, ANSI_CYAN,
            sph_rel.bearing, sph_rel.elevation, rel_range, ANSI_NORMAL,
            ANSI_MAGENTA, asteroids_density, ANSI_HILITE, ANSI_WHITE, asteroids_size,
            ANSI_BLACK, shield_strings[ facing_shield( &fake_ship, ship ) ], ANSI_NORMAL );

    }
    return;
}

void enter_asteroids( SHIP *ship, ASTER *asteroids, struct asteroids_contact *contact )
{
    sprintf( writebuf, "%s%sWARNING:%s Entering the %s.", ANSI_HILITE, ANSI_RED,
             ANSI_NORMAL, asteroids->name );
    notify_room( BRIDGE(ship), writebuf );

    contact->inside = 1;

    return;
}

char asteroid_damage( SHIP *ship )
{
    char victim_string[120];
    SHIP rock,*observer;
    CONTACT *victim;
    XYZ cpos,move;
    SPH motion;
    int damage;
    WDATA weapon = {WPN_TORP,1.0,1.0,0.1,1};
    
    motion = ship->motion;
    motion.range = 10000;
    move = sph_to_xyz( motion );
    cpos.x = ship->pos.x + move.x;
    cpos.y = ship->pos.y + move.y;
    cpos.z = ship->pos.z + move.z;
    rock = (*ship);
    rock.pos = cpos;
    rock.target_system = SYSTEM_HULL;
    damage = (int)( 225 * (float)( ship->size ) * (float)( FRAND ) * (float)( FRAND ) * (float)( ship->warp_speed ) );
    /* if the ship is set invincible, set the damage to zero */
    if( ship->flags[INVINCIBLE] )
    {
        damage = 0;
    }
    if( damage <= 0 )
    {
        return 0;
    }
    sprintf(writebuf,"%s%sAn asteroid collides with the ship!%s",ANSI_HILITE,ANSI_RED,ANSI_NORMAL);
    notify_room( BRIDGE(ship), writebuf );
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer!=ship && ( victim=find_contact(observer,ship) )!=NULL )
        {
            contact_string( victim_string, victim, INFO_TERSE );
            sprintf( writebuf, "%s%sContact [%d]: %s collides with asteroid!%s",
                ANSI_MAGENTA, ANSI_NORMAL, victim->contact_number,
                victim_string, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
        }
    }
    return battle_damage( &rock, ship, damage, weapon );
}



FUNCTION(fun_plasma_cmd)
{
    PLASMA *plasma;
    int i;

    if( !Wizard(executor) || args[0]==NULL )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    /* switch on the argument */
    if( !strcmp( args[0], "activate" ))
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            plasma = plasma_list[i];
            while( plasma != NULL )
            {
                if( executor == plasma->plasma_object )
                {
                    notify( enactor, "This plasma storm already activated." );
                    return;
                }
                plasma = plasma->next;
            }
        }
        /* okay, we've made it to this point so the plasma storm in question
         * must be inactive so far.  Cool.  Activate it
         */
        if ( activate_plasma( executor, enactor ))
            notify( enactor, "Error initializing plasma storm." );

        return;
    }
    else if( !strcmp( args[0], "deactivate" ) )
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            plasma = plasma_list[i];
            while( plasma != NULL )
            {
                if( executor == plasma->plasma_object )
                {
                    current_space = i;
                    deactivate_plasma( plasma, enactor );
                    return;
                }
                plasma = plasma->next;
            }
        }

        /* okay, we've made it to this point so the plasma storm in question
         * must not be active.  Warn and return.
         */
        notify( enactor, "Plasma Storm isn't active." );
        return;
    }
    else
    {
        notify( enactor, "Unrecognized plasma_command() call." );
    }
    return;
}

int activate_plasma( dbref executor, dbref enactor )
{
    PLASMA *new_plasma;
    char *curspace;

    if(!(new_plasma=(PLASMA *)JMALLOC(sizeof(PLASMA))))
        return SERR_MALLOC;

    /* plasma space -- either real space, or a sim space */
    curspace = fetch_attribute( executor, "SPACE" );
    if( !strcmp( curspace, "real" ))
        current_space = REAL;
    else if( !strcmp( curspace, "1" ))
        current_space = 1;
    else if( !strcmp( curspace, "2" ))
        current_space = 2;
    else if( !strcmp( curspace, "3" ))
        current_space = 3;
    else if( !strcmp( curspace, "4" ))
        current_space = 4;
    else if( !strcmp( curspace, "5" ))
        current_space = 5;
    else if( !strcmp( curspace, "6" ))
        current_space = 6;
    else if( !strcmp( curspace, "7" ))
        current_space = 7;
    else if( !strcmp( curspace, "8" ))
        current_space = 8;
    else if( !strcmp( curspace, "9" ))
        current_space = 9;
    else if( !strncmp( curspace, "10", 2 ))
        current_space = 10;
    else if( !strncmp( curspace, "11", 2 ))
        current_space = 11;
    else
        current_space = SIM;

    sscanf( fetch_attribute( executor, "LOCATION" ), "%f %f %f", &new_plasma->pos.x,
        &new_plasma->pos.y, &new_plasma->pos.z );

    new_plasma->name = (char *)Name( executor );
    new_plasma->size = atof( fetch_attribute( executor, "SIZE" ));
    new_plasma->density = atof( my_atr_get_raw( executor, "DENSITY" ));
    new_plasma->plasma_object = executor;

    if( plasma_list[current_space]==NULL )
    {
        plasma_list[current_space] = new_plasma;
        plasma_tail[current_space] = new_plasma;
        new_plasma->prev = NULL;
    }
    else
    {
        plasma_tail[current_space]->next = new_plasma;
        new_plasma->prev = plasma_tail[current_space];
        plasma_tail[current_space] = new_plasma;
    }
    new_plasma->next = NULL;
    fnotify( enactor, "Plasma Storm %s activated in %s space.",
        Name( executor), space_names[current_space] );
    return 0;
}
   
void deactivate_plasma( PLASMA *plasma, dbref enactor )
{
    SHIP *ship;

    /* this is an easy one.  Simply zorch it from the linked list */
    if( ( plasma_list[current_space]==plasma )
    && ( plasma_tail[current_space]==plasma ) )
    {
        plasma_list[current_space] = NULL;
        plasma_tail[current_space] = NULL;
    }
    else if( plasma_list[current_space] == plasma )
    {
        plasma_list[current_space] = plasma_list[current_space]->next;
        plasma_list[current_space]->prev = NULL;
    }
    else if( plasma_tail[current_space] == plasma )
    {
        plasma_tail[current_space] = plasma_tail[current_space]->prev;
        plasma_tail[current_space]->next = NULL;
    }
    else
    {
        plasma->prev->next = plasma->next;
        plasma->next->prev = plasma->prev;
    }
    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        remove_plasma( ship, plasma );
    }
    JFREE( plasma );
    notify( enactor, "Plasma sotrm are zorched." );
    return;
}

void plasma_checks( void )
{
    SHIP *ship,*ship_next;
    PLASMA *plasma;
    int in_range;
    float range;

    for(ship=space_list[current_space];ship!=NULL;ship=ship_next)
    {
        ship_next = ship->next;
        for(plasma=plasma_list[current_space];plasma!=NULL;plasma=plasma->next)
        {
            in_range = FALSE;
            range = distance( ship->pos, plasma->pos );

            if( ship->flags[OMNISCIENT] || plasma->size > range
            || UMAX(ship->sensor_power,ship->aux_sensor_power) > range-plasma->size )
            {
                in_range = TRUE;
            }
            if( in_range )
            {
                add_plasma( ship, plasma );
            }
            else
            {
                remove_plasma( ship, plasma );
            }            
        }
    }
    return;
}

void add_plasma( SHIP *ship, PLASMA *plasma )
{
    struct plasma_contact *contact;
    XYZ xyz_rel;
    SPH sph_rel;

    /* check inside if it's already on the list */
    ship->navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
    for(contact=ship->plasma_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref==plasma )
        {
            if( !contact->inside && plasma->size >= distance(ship->pos,plasma->pos) )
            {
                enter_plasma( ship, plasma, contact );
            }
            else if( contact->inside && !(plasma->size > ( distance( ship->pos, plasma->pos ))) )
            {
                /* Inform bridge of new plasma storm */
                sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.", ANSI_HILITE, ANSI_RED,
                    ANSI_NORMAL, plasma->name );
                notify_room( BRIDGE(ship), writebuf );

                contact->inside = 0;
            }
            else if( contact->inside && FRAND < plasma->density )
            {
                if( plasma_damage( ship ) )
                {
                    return;
                }
            }
            return;
        }        
    }

    /* allocate memory for the contact and the plasma  storm name. */
    if( ( contact=(struct plasma_contact *)JMALLOC(sizeof(struct plasma_contact)) )==NULL )
        return;

    /* okay, the plasma isn't on our list.  Add it. */
    contact->listref = plasma;
    if( ship->plasma_list == NULL )
    {   /* empty list */
        ship->plasma_list = contact;
        ship->plasma_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->plasma_tail->next = contact;
        contact->prev = ship->plasma_tail;
        contact->next = NULL;
        ship->plasma_tail = contact;
    }

    if( plasma->size >= distance(ship->pos,plasma->pos) )
    {
        enter_plasma( ship, plasma, contact );
    }
    else
    {
        xyz_rel.x = plasma->pos.x - ship->pos.x;
        xyz_rel.y = plasma->pos.y - ship->pos.y;
        xyz_rel.z = plasma->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );
        sph_rel.range = abs(sph_rel.range - plasma->size);
        fnotify( ship->navigator, "Plasma storm %s now in sensor range bearing %s%d%+d%s at range %s%ld%s.%s",
            ANSI_HILITE, ANSI_BLUE, plasma->name, ANSI_RED, (int)sph_rel.bearing, (int)sph_rel.elevation,
            ANSI_BLUE, ANSI_RED, (long int)sph_rel.range, ANSI_BLUE, ANSI_NORMAL );
        contact->inside = 0;
    }
    return;
}

void remove_plasma( SHIP *ship, PLASMA *plasma )
{
    struct plasma_contact *contact;

    for(contact=ship->plasma_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref==plasma )
        {
            if( contact->inside )
            {
                sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.",
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL, plasma->name );
                notify_room( BRIDGE(ship), writebuf );
            }
            sprintf( writebuf, "Asteroid field %s is no longer in sensor range.",
                contact->listref->name );

            ship->navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
            notify( ship->navigator, writebuf );

            if( ship->plasma_list == ship->plasma_tail )
            {
                ship->plasma_list = NULL;
                ship->plasma_tail = NULL;
                JFREE( contact );
                return;
            }
            if( contact==ship->plasma_list )
            {
                ship->plasma_list = contact->next;
                ship->plasma_list->prev=NULL;
                JFREE( contact );
                return;
            }
            if( contact==ship->plasma_tail )
            {
                ship->plasma_tail = contact->prev;
                ship->plasma_tail->next = NULL;
                JFREE( contact );
                return;
            }
            if( ( contact!=ship->plasma_list )
            && ( contact!=ship->plasma_tail ) )
            {
                (contact->prev)->next = contact->next;
                (contact->next)->prev = contact->prev;
                JFREE( contact );
                return;
            }
        }
    }
    return;
}

void list_plasma( SHIP *ship, dbref enactor )
{
    struct plasma_contact *contact;
    char inside_ast[2],rel_range[5];
    char plasma_size[5];
    char plasma_density[3];
    SHIP fake_ship;
    XYZ xyz_rel;
    SPH sph_rel;
    int range;
    static char *shield_strings[] = { (char *)"Fore", (char *)"Aft", (char *)"Port", (char *)"Starboard" };

    contact = ship->plasma_list;

    if( contact == NULL )
    {
        return;
    }
    for(contact=ship->plasma_list;contact!=NULL;contact=contact->next)
    {
        range = distance( ship->pos, contact->listref->pos );
        xyz_rel.x = contact->listref->pos.x - ship->pos.x;
        xyz_rel.y = contact->listref->pos.y - ship->pos.y;
        xyz_rel.z = contact->listref->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );

        if( sph_rel.range >= 10000000.0 )
            sprintf( rel_range, "%4.0fM", sph_rel.range / 1000000.0 );
        else if( sph_rel.range >= 100000.0 )
            sprintf( rel_range, "%4.0fK", sph_rel.range / 1000.0 );
        else
            sprintf( rel_range, "%5.0f", sph_rel.range );

        if( contact->listref->size >= 10000 )
            sprintf( plasma_size, "%3.0dK", contact->listref->size / 1000 );
        else
            sprintf( plasma_size, "%4.0d", contact->listref->size );

        sprintf( plasma_density, "%3.0f", contact->listref->density * 100.0 );

        fake_ship.pos = contact->listref->pos;

        if( contact->inside )
            sprintf( inside_ast, "*" );
        else
            sprintf( inside_ast, " " );

        fnotify( enactor, "%s%s   %s   %s%s%-20.20s %s%s%-3.0f %-+3.0f %-5s      %s%s%-3s%%   %s%s%-4s   %s%-10s%s", 
            ANSI_HILITE, ANSI_RED, inside_ast, ANSI_NORMAL, ANSI_CYAN,
            contact->listref->name, ANSI_HILITE, ANSI_CYAN,
            sph_rel.bearing, sph_rel.elevation, rel_range, ANSI_NORMAL,
            ANSI_MAGENTA, plasma_density, ANSI_HILITE, ANSI_WHITE, plasma_size,
            ANSI_BLACK, shield_strings[ facing_shield( &fake_ship, ship ) ], ANSI_NORMAL );

    }
    return;
}

void enter_plasma( SHIP *ship, PLASMA *plasma, struct plasma_contact *contact )
{
    sprintf( writebuf, "%s%sWARNING:%s Entering the %s.", ANSI_HILITE, ANSI_RED,
             ANSI_NORMAL, plasma->name );
    notify_room( BRIDGE(ship), writebuf );

    contact->inside = 1;

    return;
}

char plasma_damage( SHIP *ship )
{
    char victim_string[120];
    SHIP rock,*observer;
    CONTACT *victim;
    XYZ cpos,move;
    SPH motion;
    int damage;
    WDATA weapon = {WPN_TORP,1.0,1.0,0.1,1};
    
    motion = ship->motion;
    motion.range = 10000;
    move = sph_to_xyz( motion );
    cpos.x = ship->pos.x + move.x;
    cpos.y = ship->pos.y + move.y;
    cpos.z = ship->pos.z + move.z;
    rock = (*ship);
    rock.pos = cpos;
    rock.target_system = SYSTEM_HULL;
    damage = (int)( 225 * (float)( ship->size ) * (float)( FRAND ) * (float)( FRAND ) * (float)( ship->warp_speed ) );
    /* if the ship is set invincible, set the damage to zero */
    if( ship->flags[INVINCIBLE] )
    {
        damage = 0;
    }
    if( damage <= 0 )
    {
        return 0;
    }
    sprintf(writebuf,"%s%sA plasma eruption rocks the ship!%s",ANSI_HILITE,ANSI_RED,ANSI_NORMAL);
    notify_room( BRIDGE(ship), writebuf );
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer!=ship && ( victim=find_contact(observer,ship) )!=NULL )
        {
            contact_string( victim_string, victim, INFO_TERSE );
            sprintf( writebuf, "%s%sContact [%d]: %s collides with a plasma eruption!%s",
                ANSI_MAGENTA, ANSI_NORMAL, victim->contact_number,
                victim_string, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
        }
    }
    return battle_damage( &rock, ship, damage, weapon );
}

