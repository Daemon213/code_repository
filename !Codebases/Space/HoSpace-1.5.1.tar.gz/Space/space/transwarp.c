char find_tw_beacon( SHIP *ship, XYZ dest )
{
    SHIP *beacon;

    if( ship->flags[INVINCIBLE] )
    {
        return 1;
    }
    for(beacon=space_list[current_space];beacon!=NULL;beacon=beacon->next)
    {
        if( !strcmp(beacon->transponder,ship->transponder)
        && distance( beacon->pos, dest ) < 5 && !check_jammed(beacon,ship) )
        {
            return 1;
        }
    }
    return 0;
}

void engage_transwarp( SHIP *ship, dbref enactor )
{
    char target_string[120];
    CONTACT *contact;
    SHIP *observer;
    
    if( !strcmp( fetch_attribute( ship->ship_object,"UNDOCKED"), "0" ))
    {
      fnotify( enactor, "%s%sYou cannot do that while docked!%s", ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL );
      return;
    }
    if( !ship->transwarp_capable )
    {
        fnotify( enactor, "%s%sThis ship is not transwarp capable.%s",
            ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        return;
    }
    if( ship->damage[SYSTEM_TRANSWARP].status!='0'
    && ship->damage[SYSTEM_TRANSWARP].status!='1' )
    {
        fnotify( enactor, "%s%sThe transwarp drive is damaged and inoperative.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( ship->transwarp_engaging )
    {
        fnotify( enactor, "%s%sThe transwarp drive is already engaging.%s",
            ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
        return;
    }
    if( !ship->on_autopilot )
    {
        fnotify( enactor, "%s%sNo destination plotted, unable to engage.%s",
            ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        return;
    }
    if( distance( ship->pos, ship->autopilot_destination ) < 500 )
    {
        fnotify( enactor, "%s%sTranswarp conduit cannot be made that small.%s",  ANSI_HILITE, ANSI_CYAN,                    ANSI_NORMAL);
        return;
    }
    if( !find_tw_beacon(ship,ship->autopilot_destination) )
    {
        fnotify( enactor, "%s%sWARNING! WARNING: No locator beacon found, attempting blind jump!\nType \"abort transwarp\" to abort!%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    }
    else
    {
        fnotify( enactor, "%s%sLocator beacon pinpointed, transwarp locked. All systems ready.%s",
            ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    }
    ship->navigator = attrib_dbref( ship->nav, "XB" );
    lower_shields( ship, ship->navigator, (char *)"all" );
    disengage_cloak( ship, ship->navigator );
    set_warp( ship, ship->navigator, 0.0 );
    ship->transwarp_engaging = 1;
    ship->transwarp_charge = 0;
    ship->transwarp_power = compute_tw_cost( ship, ship->autopilot_destination );
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship )
        {
            continue;
        }
        if( ( contact=find_contact( observer, ship ) )!=NULL )
        {
            contact_string( target_string, contact, INFO_TERSE );
            sprintf( writebuf, "%s%sContact [%d]: %s is engaging transwarp drive.%s",
                ANSI_HILITE, ANSI_NORMAL, contact->contact_number,
                target_string, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
        }
    }
    return;
}

void abort_transwarp( SHIP *ship, dbref enactor )
{
    char target_string[120];
    CONTACT *contact;
    SHIP *observer;

    if( !ship->transwarp_capable )
    {
        fnotify( enactor, "%s%sThis ship is not transwarp capable.%s",
            ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        return;
    }
    if( !ship->transwarp_engaging )
    {
        fnotify( enactor, "%s%sThe transwarp drive is not currently engaging.%s",
            ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        return;
    }
    fnotify( enactor, "%s%sTranswarp drive shutting down.%s",
        ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    ship->transwarp_engaging = 0;
    ship->transwarp_charge = 0;
    ship->transwarp_power = 1;
    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer==ship )
        {
            continue;
        }
        if( ( contact=find_contact( observer, ship ) )!=NULL )
        {
            contact_string( target_string, contact, INFO_TERSE );
            sprintf( writebuf, "%s%sContact [%d]: %s is powering down transwarp drive.%s",
                ANSI_HILITE, ANSI_NORMAL, contact->contact_number,
                target_string, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
        }
    }
    return;
}

int compute_tw_cost( SHIP *ship, XYZ dest )
{
    return distance( ship->pos, dest ) / 10 + 1000;
}

void murphy( SHIP *ship )
{
    SHIP *observer;
    PLANET *planet;
    char fusion = 0;

    for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
    {
        if( observer!=ship
        && distance(observer->pos,ship->autopilot_destination) < observer->size
        && !observer->flags[INVISIBLE] )
        {
            ship->autopilot_destination = observer->pos;
            fusion = 1;
            break;
        }
    }
    for(planet=planet_list[current_space];planet!=NULL&&!fusion;planet=planet->next)
    {
        if( distance(planet->pos,ship->autopilot_destination) < planet->size )
        {
            ship->autopilot_destination = planet->pos;
            fusion = 1;
            break;
        }
    }
    if( !fusion )
    {
        ship->autopilot_destination.x += FRAND * ship->transwarp_tolerance;
        ship->autopilot_destination.x -= FRAND * ship->transwarp_tolerance;
        ship->autopilot_destination.y += FRAND * ship->transwarp_tolerance;
        ship->autopilot_destination.y -= FRAND * ship->transwarp_tolerance;
        ship->autopilot_destination.z += FRAND * ship->transwarp_tolerance;
        ship->autopilot_destination.z -= FRAND * ship->transwarp_tolerance;
    }
    return;
}

char transwarp_jump( SHIP *ship )
{
    char target_string[120],blind,fusion=0;
    CONTACT *contact=NULL;
    SHIP *observer,*towee;
    PLANET *planet;

    blind=!find_tw_beacon(ship,ship->autopilot_destination);
    if( blind )
    {
        murphy( ship );
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if( observer!=ship
            && distance(observer->pos,ship->autopilot_destination) < observer->size
            && !observer->flags[INVISIBLE] )
            {
                fusion = 1;
                break;
            }
        }
        for(planet=planet_list[current_space];planet!=NULL&&!fusion;planet=planet->next)
        {
            if( distance(planet->pos,ship->autopilot_destination) < planet->size )
            {
                fusion = 1;
                break;
            }
        }
    }
    if( fusion )
    {
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if( observer==ship || ( contact=find_contact(observer,ship) )==NULL )
            {
                continue;
            }
            contact_string( target_string, contact, INFO_TERSE );
            sprintf( writebuf, "%s%sContact [%d]: %s undergoes ATOMIC FUSION!%s",
                ANSI_HILITE, ANSI_RED, contact->contact_number,
                target_string, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
        }
        log_space( "%s undergoes atomic fusion attempting to transwarp to %.0f %.0f %.0f\n",
            ship->name, ship->autopilot_destination.x,
            ship->autopilot_destination.y, ship->autopilot_destination.z );
        ship->damage[SYSTEM_TRANSWARP].status = '9';
        explode_ship( ship );
    }
    else
    {
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if( observer==ship || ( contact=find_contact(observer,ship) )==NULL )
            {
                continue;
            }
            contact_string( target_string, contact, INFO_TERSE );
            sprintf( writebuf, "%s%sContact [%d]: %s has engaged transwarp drive.%s",
                ANSI_HILITE, ANSI_RED, contact->contact_number,
                target_string, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
            sprintf( writebuf, "%s%sContact [%d]: %s has entered transwarp.%s",
                ANSI_HILITE, ANSI_RED, contact->contact_number,
                target_string, ANSI_NORMAL );
            notify_room( BRIDGE(observer), writebuf );
        }
        sprintf( writebuf, "%s%sTranswarp drive <<< *E*N*G*A*G*E*D* >>>!%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
        if( BRIDGE(ship)!=ENGINE(ship) )
        {
            notify_room( ENGINE(ship), writebuf );
        }
        if( ship->tractor_target!=NULL && ship->transwarp_capable > 1
        && ( towee=ship->tractor_target->listref )!=NULL
        && distance(towee->pos,ship->pos) < ship->size
        && ship->size >= towee->size && !towee->flags[PINNED]
        && !towee->flags[STARBASE] && towee->warp_speed==0.0 )
        {
            for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
            {
                if( observer==towee
                || ( contact=find_contact(observer,towee) )==NULL )
                {
                    continue;
                }
                contact_string( target_string, contact, INFO_TERSE );
                sprintf( writebuf, "%s%sContact [%d]: %s has entered transwarp.%s",
                    ANSI_HILITE, ANSI_RED, contact->contact_number,
                    target_string, ANSI_NORMAL );
                notify_room( BRIDGE(observer), writebuf );
            }
            towee->pos = ship->autopilot_destination;
            sprintf( writebuf, "%s%sShip transwarped to %.0f %.0f %.0f.%s",
                ANSI_HILITE, ANSI_GREEN, towee->pos.x, towee->pos.y,
                towee->pos.z, ANSI_NORMAL );
            notify_room( BRIDGE(towee), writebuf );
        }
        ship->pos = ship->autopilot_destination;
        ship->on_autopilot = 0;
        ship->transwarp_power = 1;
        ship->transwarp_charge = 0;
        ship->transwarp_engaging = 0;
    }
    return fusion;
}
