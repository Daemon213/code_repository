/*
 * $Id: damcon.c,v 1.1 1993/09/01 04:22:16 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


/*
 * $Log: damcon.c,v $
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0 port
 * JMS 24 May 93 - separated into damcon.c
 * JMS ?? Oct 92 - original code
 */


/*
 * JMS 26 Aug 93 - use SHIP_OBJECT instead of XA
 */
FUNCTION(fun_damcon_cmd)
{
   SHIP *ship;
   dbref ship_object;
   int i, j; /* loop variables */
   int count;  /* another general use int */
   int dtime, hours, minutes, seconds; /* repair time */
   int numteams; /* number of teams working on a system */
   char hull_string[79];
   char team_string[10];

   if (!Wizard(executor)) {
     strcpy( buff, "#-1 PERMISSION DENIED" );
     return;
   }

   /* get the dbref of the ship object */
   ship_object = attrib_dbref( executor, "SHIP_OBJECT" );
   if( !GoodObject( ship_object )) {
     strcpy( buff, "#-1 BAD SHIP OBJECT" );
     return;
   }

   /* now set the ship pointer to the proper ship and also set the
    * space list to the list that contains it (handled by cfind_ship).
    */
   ship = cfind_ship( ship_object );

   /* Everything is fine so far.  Switch on the command argument
    * note that some checks come before the active check, and some
    * come after.
    */

   if( ship == NULL )
   {
      fnotify( enactor, "%sShip must be active to use that command.%s", ANSI_CYAN, ANSI_NORMAL );
      return;
   }
/* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
  else if( ship->flags[DEADMAN] ) {
    fnotify( enactor, "%s%sShip is deadmanned. That command is unavailable.%s",
           ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
    return;
  }
/* Deadman Check - Jeremy Huddleston (N'tok) - 6/10/97 */
   else if( current_space==REAL && !Wizard(executor) )
   {
       safe_str("#-1 PERMISSION DENIED", buff, bp );
       return;
   }
   else if( !strcmp( args[0], "team_status" ))
   {
      fnotify( enactor, "%s%sDamage control team status:%s", ANSI_HILITE, ANSI_BLUE,
               ANSI_NORMAL );
      fnotify( enactor, "%s%sTeam      Job                     ETA%s", ANSI_HILITE, ANSI_BLUE,
               ANSI_NORMAL );
      fnotify( enactor, "%s%s----     -----                -----------%s", ANSI_HILITE,
               ANSI_BLUE, ANSI_NORMAL );

      for( i = 0; i < ship->damcon_teams; i++ ) {
         if( ship->team[i] == -1 )
            sprintf( writebuf, "%s%sTeam %d:  %-20s     N/A%s", ANSI_HILITE, ANSI_RED, i,
                     "Idle", ANSI_NORMAL );
         else {
            numteams = 0;
            team_string[0] = '\0'; 
            for (j = 0; j < ship->damcon_teams; ++j) {
               if ( ship->team[i] == ship->team[j] ) {
        	  ++numteams;
        	  strcat( team_string, "*" );
               }
            }	
            if (!numteams) numteams = 1; /* NOTREACHED divby0 safeguard */
            if ( ship->team[i] == SYSTEM_HULL )
            {
               dtime = (((ship->hull_integrity - ship->permanent_hull_damage) 
        	       - ship->current_integrity) * 6) / numteams 
        	       - tcount + (tcount < 4 ? 3 : 9); 
               hours = dtime / 3600;
               minutes = (dtime % 3600) / 60;
               seconds = dtime % 60;
               sprintf( writebuf, "%s%sTeam %d:  %-20s %2ih %2im %2is %s%s", ANSI_HILITE,
                        ANSI_RED, i, system_names[SYSTEM_HULL], hours, minutes, seconds,
        		team_string, ANSI_NORMAL );
            }
            else
            {
               dtime = ship->damage[ship->team[i]].time_to_fix / numteams
        		- tcount + (tcount < 4 ? 3 : 9);
               minutes = dtime / 60;
               seconds = dtime % 60;
               sprintf( writebuf, "%s%sTeam %d:  %-20s     %2im %2is %s%s", ANSI_HILITE,
        		ANSI_RED, i, system_names[ship->team[i]], minutes, seconds,
        		team_string, ANSI_NORMAL );
            }
         }

         notify( enactor, writebuf );
      }

      notify( enactor, "" );

   }
   else if( !strcmp( args[0], "system_status" ))
   {
      fnotify( enactor, "%s%sDamage control system status:%s", ANSI_HILITE, ANSI_BLUE,
               ANSI_NORMAL );
      fnotify( enactor, "%s%sSystem            Condition                ETA", ANSI_HILITE,
               ANSI_BLUE, ANSI_NORMAL );
      fnotify( enactor, "%s%s------            ---------            -----------%s", ANSI_HILITE,
               ANSI_BLUE, ANSI_NORMAL );

      count = 0;

      for( i = 0; i < NUM_SYSTEMS; i++ )
      {
         numteams = 0;
         team_string[0] = '\0'; 
         for (j = 0; j < ship->damcon_teams; ++j) {
            if ( ship->team[j] == i ) {
               ++numteams;
               strcat( team_string, "*" );
            }
         }
         if ( !numteams ) numteams = 1; 
         /* hull is a special case.  Do it differenty. */
         if(( i == SYSTEM_HULL ) && ( ship->current_integrity < ship->hull_integrity ))
         {
            /* two cases.  Depends on whether or not reparable damage remains */
            if( ship->hull_integrity - ship->permanent_hull_damage >
        	ship->current_integrity ) {
               /* there's damage yet that we can repair */
               dtime = (( ship->hull_integrity - ship->permanent_hull_damage )
        		- ship->current_integrity ) * 6 / numteams
        		- tcount + (tcount < 4 ? 3 : 9) ;
               hours = dtime / 3600;
               minutes = (dtime % 3600) / 60;
               seconds = dtime % 60;
               sprintf( hull_string, "%d%% -- patchable",
        		(100*ship->current_integrity / ship->hull_integrity) );
               sprintf( writebuf, "%s%s%-16s  %-20s %s%2ih %2im %2is %s%s%s", ANSI_HILITE, ANSI_RED,
        		system_names[i], hull_string, ANSI_YELLOW, hours, minutes, seconds,
                        ANSI_BLUE, team_string, ANSI_NORMAL);
               notify( enactor, writebuf );
            }
            else
            {
               /* no damage that we can repair */
               sprintf( hull_string, "%d%% -- fully patched",
        		(100*ship->current_integrity / ship->hull_integrity) );
               sprintf( writebuf, "%s%s%-16s  %-20s     %sN/A%s", ANSI_HILITE, ANSI_RED,
        		system_names[i], hull_string, ANSI_YELLOW, ANSI_NORMAL );
               notify( enactor, writebuf );
            }
            continue;
         }

         dtime = ship->damage[i].time_to_fix / numteams
        	 - tcount + (tcount < 4 ? 3 : 9);
         minutes = dtime / 60;
         seconds = dtime % 60;
         switch( ship->damage[i].status )
         {
            case '0':   /* normal working order */
               break;
            case '1':   /* field repaired */
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %sN/A%s", ANSI_HILITE, ANSI_RED,
                        system_names[i], "field repair", ANSI_YELLOW, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
            case '2':   /* light damage */
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %s%2im %2is %s%s%s", ANSI_HILITE,
        		ANSI_RED, system_names[i], "light damage", ANSI_YELLOW, minutes, seconds,
                        ANSI_BLUE, team_string, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
            case '3':   /* moderate damage */
            case '4':
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %s%2im %2is %s%s%s", ANSI_HILITE,
                        ANSI_RED, system_names[i], "moderate damage", ANSI_YELLOW, minutes,
                        seconds, ANSI_BLUE, team_string, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
            case '5':   /* heavy damage */
            case '6':
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %s%2im %2is %s%s%s", ANSI_HILITE,
                        ANSI_RED, system_names[i], "heavy damage", ANSI_YELLOW, minutes,
                        seconds, ANSI_BLUE, team_string, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
            case '7':   /* inoperable */
            case '8':
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %s%2im %2is %s%s%s", ANSI_HILITE,
        		ANSI_RED, system_names[i], "inoperative", ANSI_YELLOW, minutes,
                        seconds, ANSI_BLUE, team_string, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
            case '9':   /* destroyed */
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %sN/A%s", ANSI_HILITE, ANSI_RED,
                        system_names[i], "destroyed", ANSI_YELLOW, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
            case 'x':
               break;
            case 'X':
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %sN/A%s", ANSI_HILITE, ANSI_RED,
                        "?!?", "FUBAR", ANSI_YELLOW, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
            default:
               count++;
               sprintf( writebuf, "%s%s%-16s  %-20s     %sN/A%s", ANSI_HILITE, ANSI_RED,
                        system_names[i], "unknown", ANSI_YELLOW, ANSI_NORMAL );
               notify( enactor, writebuf );
               break;
         }
      }

      if( !count )
         fnotify( enactor, "%s%sAll systems in normal working order.%s", ANSI_HILITE,
                  ANSI_RED, ANSI_NORMAL );

      notify( enactor, "" );
   }
   else if( !strcmp( args[0], "repair" ))
   {
      assign_team( ship, enactor, atoi( args[1] ), args[2] );
   }
   else if( !strcmp( args[0], "manual_break" ) && args[1]!=NULL )
   {
      break_system( ship, atoi( args[1] ) );
   }
   else
   {
      notify( enactor, "Unrecognized damcon_cmd() call." );
   }

   return;
}

void assign_team( SHIP *ship, dbref enactor, int team, char *dsystem )
{
    int i;

    /* valid team check */
    if( team >= ship->damcon_teams || team < 0 )
    {
        fnotify( enactor, "%s%sInvalid team number.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* figure out which system we're fixing */
    i = 0;
    while(( i < NUM_SYSTEMS ) && ( !strstr( system_names[i], dsystem ) ))
    {
        i++;
    }
    if( i >= NUM_SYSTEMS
    || ship->damage[i].status=='x' || ship->damage[i].status=='X' )
    {
        /* we didn't find the system.  Go home */
        fnotify( enactor, "%s%sInvalid system.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( i==SYSTEM_HULL )
    {
        if( ship->current_integrity >= ship->hull_integrity - ship->permanent_hull_damage
        && ( !ship->fullrepair || ( ship->armor_strength[0]>=ship->max_armor_strength
        && ship->armor_strength[1]>=ship->max_armor_strength
        && ship->armor_strength[2]>=ship->max_armor_strength
        && ship->armor_strength[3]>=ship->max_armor_strength ) ) )
        {
            fnotify( enactor, "%sNo further hull repairs are possible.%s", ANSI_MAGENTA,
                ANSI_NORMAL );
            return;
        }
    }
    else
    {
        if(( ship->damage[i].status == '1' ) || ( ship->damage[i].status == '0' ))
        {
            sprintf( writebuf, "%s%s is undamaged.%s", ANSI_MAGENTA, system_names[i], ANSI_NORMAL );
            notify( enactor, writebuf );
            return;
        }
    }
    /* don't let them fix a destroyed system */
    if( ship->damage[i].status=='9' )
    {
        fnotify( enactor, "%s%sYou can't repair a destroyed system.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return;
    }
    /* make sure there's room on the new job to accomodate them */
    if( ship->damage[i].teams == ship->damage[i].maxteams )
    {
        sprintf( writebuf, "%s%sThe maximum possible number of teams is already working on %s.%s",
            ANSI_HILITE, ANSI_RED, system_names[i], ANSI_NORMAL );
        notify( enactor, writebuf );
        return;
    }
    if( ship->team[team] != -1 )
    {
        /* The team is on another job.  Remove them from it. */
        ship->damage[ship->team[team]].teams--;
    }
    /* now put then on the new job */
    ship->damage[i].teams++;
    ship->team[team]=i;
    /* and notify the enactor */
    sprintf( writebuf, "%s%sTeam %d now working on %s.%s", ANSI_HILITE, ANSI_BLUE, team,
        system_names[i], ANSI_NORMAL );
    notify( enactor, writebuf );
    return;
}

void ship_repairs( void )
{
    SHIP *ship;
    int i,x;

    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        for(i=0;i<ship->damcon_teams;i++)
        {
            /* for each team, deduct time of the job they're on */
            if( ship->team[i] != -1 )
            {
                /* Do hull separately */
                if( ship->team[i] == SYSTEM_HULL )
                {
                   if( ship->current_integrity < ship->hull_integrity - ship->permanent_hull_damage )
                    {
                    ship->current_integrity++;
                    }
                    if( ship->fullrepair )
                    {
                        for(x=0;x<4;x++)
                        {
                            if( ship->armor_strength[x] < ship->max_armor_strength )
                            {
                                ship->armor_strength[x]++;
                            }
                        }
                    }
                    if( ship->flags[DISABLED] && ship->current_integrity > 15)
                    {
                        ship->flags[DISABLED] = 0;
                    }
                    if( ship->current_integrity + ship->permanent_hull_damage >= ship->hull_integrity
                    && ( !ship->fullrepair || ( ship->armor_strength[0]>=ship->max_armor_strength
                    && ship->armor_strength[1]>=ship->max_armor_strength
                    && ship->armor_strength[2]>=ship->max_armor_strength
                    && ship->armor_strength[3]>=ship->max_armor_strength ) ) )
                    {
                        repair_system( ship, SYSTEM_HULL );
                    }
                    continue;
                }
                ship->damage[ship->team[i]].time_to_fix -= 6;
                /* now check and see if the job is finished */
                if( ship->damage[ship->team[i]].time_to_fix < 1
                && ship->damage[ship->team[i]].status != '9' )
                {
                    repair_system( ship, ship->team[i] );
                }
            }
        }
        write_damage( ship );
    }
    return;
}

void repair_system( SHIP *ship, int dsystem )
{
    int i;
    dbref helmsman, navigator, engineer, dmg_officer;

    /* get the dbrefs of all the console officers */
    helmsman=match_result(HOWIE, my_atr_get_raw(ship->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
    navigator=match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
    engineer=match_result(HOWIE, my_atr_get_raw( ship->eng, "XB"), NOTYPE, MAT_ABSOLUTE);
    dmg_officer=match_result(HOWIE, my_atr_get_raw(ship->damcon, "XB"), NOTYPE, MAT_ABSOLUTE);

    /* switch on the system and effect the repair */
    switch( dsystem )
    {
        case SYSTEM_GUN_0:
        case SYSTEM_GUN_1:
        case SYSTEM_GUN_2:
        case SYSTEM_GUN_3:
        case SYSTEM_GUN_4:
        case SYSTEM_GUN_5:
        case SYSTEM_GUN_6:
        case SYSTEM_GUN_7:
        case SYSTEM_GUN_8:
        case SYSTEM_GUN_9:
        case SYSTEM_GUN_10:
        case SYSTEM_GUN_11:
        case SYSTEM_GUN_12:
        case SYSTEM_GUN_13:
        case SYSTEM_GUN_14:
        case SYSTEM_GUN_15:
        case SYSTEM_GUN_16:
        case SYSTEM_GUN_17:
        case SYSTEM_GUN_18:
        case SYSTEM_GUN_19:
            ship->phaser[dsystem - SYSTEM_GUN_0].power = atoi( my_atr_get_raw( ship->ship_object, "WU" )) * 0.9;
            ship->phaser[dsystem - SYSTEM_GUN_0].range = atoi( my_atr_get_raw( ship->ship_object, "WV" )) * 0.9;
            ship->phaser[dsystem - SYSTEM_GUN_0].charge = 0;
            ship->phaser[dsystem - SYSTEM_GUN_0].charge_per_turn = atoi( my_atr_get_raw( ship->ship_object, "VO" )) * 0.9;

            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( helmsman, writebuf );
            if( helmsman != dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_TORP_0:
        case SYSTEM_TORP_1:
        case SYSTEM_TORP_2:
        case SYSTEM_TORP_3:
        case SYSTEM_TORP_4:
        case SYSTEM_TORP_5:
        case SYSTEM_TORP_6:
        case SYSTEM_TORP_7:
        case SYSTEM_TORP_8:
        case SYSTEM_TORP_9:
        case SYSTEM_TORP_10:
        case SYSTEM_TORP_11:
        case SYSTEM_TORP_12:
        case SYSTEM_TORP_13:
        case SYSTEM_TORP_14:
        case SYSTEM_TORP_15:
        case SYSTEM_TORP_16:
        case SYSTEM_TORP_17:
        case SYSTEM_TORP_18:
        case SYSTEM_TORP_19:
            ship->photon[dsystem - SYSTEM_TORP_0].status = PHOTON_EMPTY;
            ship->photon[dsystem - SYSTEM_TORP_0].charge = 0;
            ship->photon[dsystem - SYSTEM_TORP_0].turns_charged = 0;
            if( ship->fullrepair )
            {
                ship->photon[dsystem - SYSTEM_TORP_0].base_accuracy = atof( my_atr_get_raw( ship->ship_object, "WZ" ));
            }
            else
            {
                ship->photon[dsystem - SYSTEM_TORP_0].base_accuracy = atof( my_atr_get_raw( ship->ship_object, "WZ" )) * 0.9;
            }
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( helmsman, writebuf );
            if( helmsman != dmg_officer )
                notify( dmg_officer, writebuf );
            if( ship->reloading_tube==NO_RELOAD && ship->auto_reload )
            {
                reload_photon( ship, helmsman, dsystem-SYSTEM_TORP_0 );
            }
            break;
        case SYSTEM_SCANNERS:
            if( ship->fullrepair )
            {
                ship->scanner_range = atof( my_atr_get_raw( ship->ship_object, "WL" ));
            }
            else
            {
                ship->scanner_range = atof( my_atr_get_raw( ship->ship_object, "WL" )) * 0.9;
            }
            ship->damage[SYSTEM_SCANNERS].status = '1'; 
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( helmsman, writebuf );
            if( helmsman != dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_SENSORS:
            if( ship->fullrepair )
            {
                ship->sensor_power = atof( my_atr_get_raw( ship->ship_object, "WK" ));
            }
            else
            {
                ship->sensor_power = atof( my_atr_get_raw( ship->ship_object, "WK" )) * 0.9;
            }
            ship->damage[SYSTEM_SENSORS].status = '1'; 
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( helmsman, writebuf );
            if( helmsman != dmg_officer )
               notify( dmg_officer, writebuf );
            break;
        case SYSTEM_SHIELD_FORE:
        case SYSTEM_SHIELD_AFT:
        case SYSTEM_SHIELD_PORT:
        case SYSTEM_SHIELD_STARBOARD:
            if( ship->fullrepair )
            {
                ship->shield_max[dsystem - SYSTEM_SHIELD_FORE] = atoi( my_atr_get_raw( ship->ship_object, "WF" ));
                ship->shield_max_charge[dsystem - SYSTEM_SHIELD_FORE] = atoi( my_atr_get_raw( ship->ship_object, "VN" ));
            }
            else
            {
                ship->shield_max[dsystem - SYSTEM_SHIELD_FORE] = atoi( my_atr_get_raw( ship->ship_object, "WF" )) * 0.9;
                ship->shield_max_charge[dsystem - SYSTEM_SHIELD_FORE] = atoi( my_atr_get_raw( ship->ship_object, "VN" )) * 0.9;
            }
            ship->shield_level[dsystem - SYSTEM_SHIELD_FORE] = 0;
            ship->shield_status[dsystem - SYSTEM_SHIELD_FORE] = SHLD_READY;
            ship->shield_action[dsystem - SYSTEM_SHIELD_FORE] = SHLD_STABLE;
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( navigator, writebuf );
            if( navigator != dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_CLOAK:
            ship->cloak_status = CLOAK_OFF;
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( navigator, writebuf );
            if( navigator != dmg_officer )
            {
                notify( dmg_officer, writebuf );
            }
            if( ship->damage[dsystem].status=='7' && !ship->fullrepair )
            {
                ship->cloak_ratio *= 1.5;
            }
            break;
        case SYSTEM_BATTERIES:
            if( ship->fullrepair )
            {
                ship->battery_discharge_max = (int) ((float) atoi( my_atr_get_raw( ship->ship_object, "WA" )));
            }
            else
            {
                ship->battery_discharge_max = (int) ((float) atoi( my_atr_get_raw( ship->ship_object, "WA" )) * 0.9);
            }
            ship->battery_status = BTTY_OFFLINE;
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( engineer, writebuf );
            if( engineer != dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_ENGINE:
            if( ship->fullrepair )
            {
                ship->damage[SYSTEM_ENGINE].status = '0';
            }
            else
            {
                ship->damage[SYSTEM_ENGINE].status = '1';
            }
            /* recalculate max_engine_output */
            ship->current_reactor_output_max = ship->reactor_output_max *
                ( 1 - ((float)( ship->damage[SYSTEM_ENGINE].status - '0' ) * 0.1 )) * 
                ( 1 - ((float)( ship->damage[SYSTEM_CRYSTAL].status - '0' ) * 0.1 ));
            sprintf( writebuf, "%s%sReactor repaired.%s", ANSI_HILITE,
                ANSI_BLUE, ANSI_NORMAL );
            notify( engineer, writebuf );
            if( engineer != dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_HULL:
            /* This one is a little different.  There's no status change.
             * This function is simply called when the patch is as good
             * as it can get.  This notifies and removes teams from the job.
             */
            fnotify( dmg_officer, "%s%sHull patches completed.%s", ANSI_HILITE,
                ANSI_BLUE, ANSI_NORMAL );
            break;
        case SYSTEM_TRACTOR:
            if( !ship->fullrepair && ship->damage[dsystem].status=='7' )
            {
                ship->tractor_range *= 0.9;
            }
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE,
                system_names[dsystem], ANSI_NORMAL );
            notify( helmsman, writebuf );
            if( helmsman != dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_PAINT_JOB:
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE,
                system_names[dsystem], ANSI_NORMAL );
            notify( dmg_officer, writebuf );
            break;
        case SYSTEM_WARP:
            if( !ship->fullrepair )
            {
                ship->current_warp_factor = ship->warp_factor * 1.05;
            }
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE,
                system_names[dsystem], ANSI_NORMAL );
            notify( navigator, writebuf );
            if( navigator!=dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_TARGETTING:
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE,
                system_names[dsystem], ANSI_NORMAL );
            notify( helmsman, writebuf );
            if( helmsman!=dmg_officer )
            {
                notify( dmg_officer, writebuf );
            }
            break;
        case SYSTEM_LANDING_GEAR:
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE,
                system_names[dsystem], ANSI_NORMAL );
            notify( navigator, writebuf );
            if( navigator!=dmg_officer )
            {
                notify( dmg_officer, writebuf );
            }
            ship->landing_capable = 1;
            break;
        case SYSTEM_TRANSWARP:
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE,
                system_names[dsystem], ANSI_NORMAL );
            notify( navigator, writebuf );
            if( navigator!=dmg_officer )
            {
                notify( dmg_officer, writebuf );
            }
            if( ship->damage[dsystem].status=='7' && !ship->fullrepair )
            {
                ship->transwarp_tolerance *= 1.25;
                break;
            }
            break;
        case SYSTEM_DISSIPATOR:
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE,
                system_names[dsystem], ANSI_NORMAL );
            notify( navigator, writebuf );
            if( navigator!=dmg_officer )
            {
                notify( dmg_officer, writebuf );
            }
            if( ship->damage[dsystem].status=='7' && !ship->fullrepair )
            {
                ship->interdict_range *= 0.9;
                break;
            }
            break;
        case SYSTEM_AUX_SENSORS:
            ship->aux_sensor_power = atof( my_atr_get_raw( ship->ship_object, "WM" )) * 0.9;
            ship->damage[SYSTEM_AUX_SENSORS].status = '1'; 
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( helmsman, writebuf );
            if( helmsman != dmg_officer )
                notify( dmg_officer, writebuf );
            break;
        case SYSTEM_TRANSPORTERS:
            ship->transporter_range = abs(ship->transporter_range);
            if( ship->damage[SYSTEM_TRANSPORTERS].status=='8' && !ship->fullrepair )
            {
                ship->transporter_range *= 0.9;
            }
            sprintf( writebuf, "%s%s%s repaired.%s", ANSI_HILITE, ANSI_BLUE, system_names[dsystem],
                ANSI_NORMAL );
            notify( dmg_officer, writebuf );
            break;
        default:
            break;
    }
    /* remove all teams from the job */
    for( i = 0; i < ship->damcon_teams; i++ )
    {
        if( ship->team[i] == dsystem )
        {
            ship->team[i] = -1;
            sprintf( writebuf, "%s%sTeam %d now free.%s", ANSI_HILITE, ANSI_BLUE, i, ANSI_NORMAL );
            notify( dmg_officer, writebuf );
        }
    }
    /* reset the damage register */
    ship->damage[dsystem].time_to_fix = 0;
    if( dsystem == SYSTEM_HULL );
    else if( dsystem==SYSTEM_PAINT_JOB || dsystem==SYSTEM_LANDING_GEAR
    || ship->fullrepair )
    {
        ship->damage[dsystem].status = '0';
    }
    else
    {
        ship->damage[dsystem].status = '1';
    }  
    ship->damage[dsystem].teams = 0;
    return;
}
