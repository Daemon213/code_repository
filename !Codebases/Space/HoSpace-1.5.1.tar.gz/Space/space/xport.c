/*
 * $Id: xport.c,v 1.1 1993/09/01 04:22:16 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: xport.c,v $
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 * JMS 24 May 93 - separated into xport.c
 * JMS/DJB ?? Aug 92 - original code
 */


/*
 * JMS 26 Aug 93 - use SHIP_OBJECT instead of XA
 */
FUNCTION(fun_trans_cmd)
{
   dbref ship_object;        /* which MAY turn out to be a planet */
   SHIP *ship;
   PLANET *planet;
   CONTACT *contact;
   struct planet_contact *planet_con;
   dbref target, docking_bay, shuttle_bay, contents, contents_ship, obj;
   char *c, *buff2;
   PLANET *target_planet;
   SHIP *target_ship;
   SHIP fake_ship;        /* we need this to build our fake     *
        		   * ship for the shield_facing stuff.  */

   if (!Wizard(executor)) {
     safe_str("#-1 PERMISSION DENIED", buff, bp);
     return;
   }

   /* figure out who gave the command */
  ship_object = attrib_dbref( executor, "SHIP_OBJECT" ); 
  if( !GoodObject( ship_object )) {
      safe_str("#-1 BAD SHIP OBJECT", buff, bp);
      return;
   }

   /* initialize */
   ship = NULL;
   planet = NULL;
   target_planet = NULL;

   /* okay, it might be a ship.  Run a ship check */
   ship = cfind_ship( ship_object );

   /* if it isn't, see if it's a planet */
   if( ship == NULL )
      planet = find_planet( ship_object );

   /* okay, if both ship and planet are null, this is a limbo transporter
    * and it can only beam to things in the docking bay.  This function
    * has nothing to say about such matters, so we'll go home.
    */

   if(( ship == NULL ) && ( planet == NULL ) && (strcmp(args[0],"coords")) ) {
      safe_str("OK-DOCKED", buff, bp);
      return;
   }
             
   /* clear out buff */
   buff[0]='\0';

   /* switch on the argument */
   if( !strcmp( args[0], "coords" ))
   {
      /* okay, we need to return the people on the contact list.
       * If this is a planet, we just return the uncloaked ships within
       * range of the transporter in question.
       */

	/* Ok, it's redundant, but necessary...need to return something to user if the ship is
	 * inactive */
 
       if( ship == NULL && planet == NULL )
	{
        fnotify(enactor, "%s%sYou need power to opertate the transporter system.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
       	return;
	}

       if( ship != NULL )
      {
	/* If it's a ship or a planet, need to return itself first */
   
	    sprintf( writebuf, "#%d ", ship->ship_object);
	    safe_str(writebuf, buff, bp);

	
         /* it's a ship */
         for( contact = ship->contact_list; contact != NULL;
              contact = contact->next )
         {
            /* loop through the contact list, and return ship object dbrefs
             * of any ships in range.
             */

            if( contact->listref->flags[DEADMAN] )
            {
               continue;
            }
            if( distance( ship->pos, contact->listref->pos ) <= ship->transporter_range )
            {
               sprintf( writebuf, "#%d ", contact->listref->ship_object );
               safe_str(writebuf, buff, bp);
            }
         }
         for( planet_con = ship->planet_list; planet_con != NULL; planet_con = planet_con->next )
         {
            /* loop through the contact list, and return planet object dbrefs
             * of any planets in range.
             */

            if( distance( ship->pos, planet_con->listref->pos ) <= ship->transporter_range )
            {
               sprintf( writebuf, "#%d ", planet_con->listref->planet_object );
               safe_str(writebuf, buff, bp);
            }
         }
	  /* Now loop through all things in docking bay and see if they are docked with us */
	  shuttle_bay = match_result(HOWIE, fetch_attribute(ship->ship_object,"SHUTTLE_BAY"), NOTYPE, MAT_ABSOLUTE);
         docking_bay = match_result(HOWIE, fetch_attribute(ship->ship_object, "DOCK"), NOTYPE, MAT_ABSOLUTE);
	 


         if( (atoi(fetch_attribute(ship->ship_object,"CLAMPS_ON")) != 1) && GoodObject(docking_bay))
	 {
	  for(contents=Contents(docking_bay); GoodObject(contents); contents=Next(contents))
            {
	   contents_ship = attrib_dbref(contents,"SHIP_OBJECT");
	   if( GoodObject(contents_ship) && (attrib_dbref(contents_ship,"DOCKED_AT") == ship->ship_object))
	   {
		sprintf( writebuf, "#%d ", contents_ship );
		safe_str( writebuf, buff, bp );
           }
	 }
	}
 
	/* I give credit:  This was mostly Darian's code.  Or at least his idea for attacking it. */
	 else
	 {   
            buff2 = fetch_attribute(ship->ship_object, "CLAMPS"); 
            if(buff)
	    {
              c = trim_space_sep(buff2, ' ');
             while(c)
             {
	       obj = parse_dbref(split_token(&c, ' '));
	       contents_ship = attrib_dbref(obj, "SHIP_OBJECT");
	       if( GoodObject(contents_ship) )
		 {
		   sprintf( writebuf, "#%d ", contents_ship );
		   safe_str( writebuf, buff, bp );
		 }

	     }
	   }
       	 }

        if( GoodObject(shuttle_bay) )
        {
        for(contents=Contents(shuttle_bay); GoodObject(contents); contents=Next(contents))
        {
	  contents_ship = attrib_dbref(contents,"SHIP_OBJECT");
	  if( GoodObject(contents_ship) && (attrib_dbref(contents_ship,"DOCKED_AT") == ship->ship_object))
	  {
		sprintf( writebuf, "#%d ", contents_ship );
		safe_str( writebuf, buff, bp );
          }
	}   
        }

         return;
      }
      else
      {
         /* it's a planet */
         /* for now we won't check for other planets.  They'll never be close
          * enough for transporting
          */
          
          /* Once again, please return the planet first for site2site */
  
	
	      sprintf( writebuf, "#%d ", planet->planet_object);
	      safe_str(writebuf, buff, bp);

        for( ship = space_list[current_space]; ship != NULL; ship = ship->next ) {
            if(( distance( ship->pos, planet->pos ) <=
        	  planet->transporter_range )) {
               sprintf( writebuf, "#%d ", ship->ship_object );
               safe_str(writebuf, buff, bp);
            }
         }

         return;
      }
   }
   else if( !strcmp( args[0], "comm_ships" ) )
   {
       /* returns dbref#s of all ships in comm range */ 
       if( ship == NULL )
       {
           safe_str("#-1 NOT A SHIP", buff, bp);
           return;
       }
       if( check_jammed(ship,ship) )
       {
           return;
       }
       for(target_ship=space_list[current_space];target_ship!=NULL;target_ship=target_ship->next)
       {
           /* loop through the contact list, and return planet object dbrefs
            * of any planets in range.
            */

           if( distance(ship->pos,target_ship->pos)<=ship->transmitter_range
           && !check_jammed(target_ship,ship) )
           {
               sprintf( writebuf, "#%d ", target_ship->ship_object );
               safe_str(writebuf, buff, bp);
           }
       }
       return;
   }
   
   /* Ok, this file sucks.  It's not at all like the other ones.
    * The organization of this code is horrible, this lower shields
    * function is my first attempt to bring some order to this chaos.
    * So far I've seen about a dozen active ship checks in here. 
    * That stuff can be done before any args are switched for the 
    * most part.  First function call of the file is here.  I find 
    * that odd.  Will clean up the code and reorder it later
    * 		--Howie
    */
    
   else if(!strcmp( args[0], "lower_shields"))
   {
   	trans_lower_shields( enactor, ship, args[1]);
   	return;   	
   }
   else if( !strcmp( args[0], "comm_planets" ))
   {
     /* returns dbref#s of all planets in comm range */ 
     
     /* A decade later, Howie wonders what the hell these comm_* functions are for
      * and why they are in xport.c instead of commo.c where all the other communications
      * stuff is. Perhaps I'll move these when I make this a more efficient file (function
      * oriented like all other C programs are.  No wonder space eats memory like a fat woman 
      * at the Hershey's Chocolate planet) */
      
     if( ship == NULL ) {
        safe_str("#-1 NOT A SHIP", buff, bp);
        return;
     }  
     for( planet_con = ship->planet_list; planet_con != NULL;
          planet_con = planet_con->next ) {
        /* loop through the contact list, and return planet object dbrefs
         * of any planets in range.
         */

        if( distance( ship->pos, planet_con->listref->pos ) <=
            ship->transmitter_range ) {
           sprintf( writebuf, "#%d ", planet_con->listref->planet_object );
           safe_str(writebuf, buff, bp);
        }
     }
     return;
   }
   else if( !strcmp( args[0], "permission" ))
   {
      /* We no longer know for sure that args[1] is valid.  Check it *
       * first.                                                      */
      if( nargs < 2 )
      {
         safe_str("NOT FOUND", buff, bp);
         return;
      }
      
      /* okay, args[1] is a dbref.  Match it first. */
      target = match_result(HOWIE, args[1], NOTYPE, MAT_ABSOLUTE);
      
	  /* First Check...see if it's the same ship/planet */
	  if( target == ship_object)
	  {
	  	safe_str("OKAY", buff, bp);
	  	return;
	  }
	
      target_ship = cfind_ship( target );

      if( target_ship == NULL )
         target_planet = find_planet( target );

      if( ship != NULL )
      {
         /* it's a ship */
         if( target_ship != NULL )
         {
            /* check range and shields */
            if( distance( ship->pos, target_ship->pos ) > ship->transporter_range )
            {
               safe_str("OUT OF RANGE", buff, bp);
               return;
            }
            if( ship->shield_status[facing_shield( target_ship, ship )]==SHLD_UP
            && ship->shield_level[facing_shield(target_ship,ship)] > 0 )
            {
               safe_str("SOURCE SHIELD", buff, bp );
               return;
            }

            if( target_ship->shield_status[facing_shield( ship, target_ship )]==SHLD_UP
            && target_ship->shield_level[facing_shield(ship,target_ship)] > 0 )
            {
               safe_str("TARGET SHIELD", buff, bp );
               return;
            }

            /* The ship is in range and the proper shields are down. */
            safe_str("OKAY", buff, bp );
            return;

         }
         else if( target_planet != NULL )
         {
            /* check range and shields */
            if( distance( ship->pos, target_planet->pos ) > ship->transporter_range )
            {
               safe_str("OUT OF RANGE",buff, bp );
               return;
            }

            fake_ship.pos.x = target_planet->pos.x;
            fake_ship.pos.y = target_planet->pos.y;
            fake_ship.pos.z = target_planet->pos.z;

            if( ship->shield_status[facing_shield( &fake_ship, ship )]==SHLD_UP
            && ship->shield_level[facing_shield(&fake_ship,ship)] > 0 )
            {
               safe_str("SOURCE SHIELD", buff, bp );
               return;
            }
            if( target_planet->shield_status==SHLD_UP
            && target_planet->shield_level > 0 )
            {
               safe_str("TARGET SHIELD", buff, bp );
               return;
            }
            safe_str("OKAY", buff, bp );
            return;

         }
         else {
            safe_str("NOT FOUND", buff, bp );
            return;
         }
      }
      else {
         /* it's a planet */
         if( target_ship != NULL )
         {
            /* planet to ship */
            if( distance( planet->pos, target_ship->pos ) >
        		  planet->transporter_range ) {
               safe_str("OUT OF RANGE", buff, bp );
               return;
            }

            fake_ship.pos.x = planet->pos.x;
            fake_ship.pos.y = planet->pos.y;
            fake_ship.pos.z = planet->pos.z;
            if( planet->shield_status==SHLD_UP && planet->shield_level > 0 )
            {
               safe_str("SOURCE SHIELD", buff, bp );
               return;
            }
            if( target_ship->shield_status[facing_shield( &fake_ship,
        				   target_ship )] == SHLD_UP )
            {
               safe_str("TARGET SHIELD", buff, bp );
               return;
            }

            safe_str("OKAY", buff, bp );
            return;
         }
         else {
            safe_str("NOT FOUND", buff, bp );
            return;
         }
      }
   }
   else
      notify( enactor, "Unrecognized trans_cmd() call." );
}


 /* Ok, finally begin functions which were called.  First
  * up is the new lower_shields call which we added to use
  * a code so to prevent sabatoge. I'll cleanup the rest of 
  * the trans code later and make it more function oriented
  * instead of running all these redundant checks in each
  * arg switch */
  
  
  /* Only need a lower shields...no need for security on raise shields */
  void trans_lower_shields( dbref enactor, SHIP *ship, char *prefix )
  {
  	
  	
  	if( ship == NULL )
  	{
  		fnotify(enactor, "%s%sShip not running.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
  		return;
  	}
  	
  	if( !strcmp( prefix, fetch_attribute(ship->ship_object,"SHIP_PREFIX")) )
  	{
  		lower_shields(ship, enactor, (char *) "all");
  		return;
  	}
  	else
  	{
  		fnotify( enactor, "%s%sInvalid ship code.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL);
  		return;
  	}
  }
  