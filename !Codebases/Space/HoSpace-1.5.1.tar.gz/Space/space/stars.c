/*************************************************
/ Wheee!  Another Howie addition to HoSpace!
/ Stars.c -- Something every space system needs:
/ realism!  This is stuff for adding in stars and 
/ such into space and allowing them to add damage.
************************************************/
FUNCTION(fun_star_cmd)
{
	
	if( !Wizard(enactor) || args[0] == NULL )	
	{
		safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    
    if( !strcmp(args[0],"activate"))
    	star_activate( executor, enactor );
    else if( !strcmp(args[0], "deactivate"))
    	star_deactivate( executor, enactor );
    else
    {
    	fnotify( enactor, "Unrecognized star_cmd call." );
    	return;
    }
	
}

void star_activate( dbref star_object, dbref enactor)
{
  int i;
  STAR *star;
  dbref executor;

   
  executor = star_object;

  for( i = 0; i < SPACE_LIMIT; i++ )
        {
            star = star_list[i];
            while( star != NULL )
            {
                if( executor == star->star_object )
                {
                    notify( enactor, "This star is already activated." );
                    return;
                }
                star = star->next;
            }
        }
   /* okay, we've made it to this point so the star in question
         * must be inactive so far.  Cool.  Activate it
         */
        if( !activate_star( executor, enactor ) )
        {
            notify( enactor, "Error initializing star." );
            log_space( "Error initializing star %s (%#d)", Name(executor), executor);
        }
        return;
   
	
}

void star_deactivate( dbref star_object, dbref enactor )
{
	STAR *star;
	SHIP *ship;
	
	star = find_star( star_object );
	
	    /* this is an easy one.  Simply zorch it from the linked list */
    if( star_list[current_space]==star && star_tail[current_space]==star )
    {
        star_list[current_space] = NULL;
        star_tail[current_space] = NULL;
    }
    else if( star_list[current_space] == star )
    {
        star_list[current_space] = star_list[current_space]->next;
        star_list[current_space]->prev = NULL;
    }
    else if( star_tail[current_space] == star )
    {
        star_tail[current_space] = star_tail[current_space]->prev;
        star_tail[current_space]->next = NULL;
    }
    else
    {
        star->prev->next = star->next;
        star->next->prev = star->prev;
    }
        /* go through and remove it from any stars lists it may be on */
    ship = space_list[current_space];
    while( ship != NULL )
    {
        remove_star( ship, star );
        ship = ship->next;
    }

    JFREE( star );
    notify( enactor, "Star is F*&^in gone!" );
    return;

}

int activate_star( dbref executor, dbref enactor )
{
    STAR *new_star;
    char *curspace;
  

    if( !(new_star=(STAR *)JMALLOC(sizeof(STAR))))
    {
        return SERR_MALLOC;
    }
    bzero( new_star, sizeof(STAR) );
    new_star->star_object = executor;
    /* planet space -- either real space, or a sim space */
    curspace = fetch_attribute( executor, "SPACE" );
    if( !strcmp( curspace, "real" ))
        current_space = REAL;
    else if( !strcmp( curspace, "1" ))
        current_space = 1;
    else if( !strcmp( curspace, "2" ))
        current_space = 2;
    else if( !strcmp( curspace, "3" ))
        current_space = 3;
    else if( !strcmp( curspace, "4" ))
        current_space = 4;
    else if( !strcmp( curspace, "5" ))
        current_space = 5;
    else if( !strcmp( curspace, "6" ))
        current_space = 6;
    else if( !strcmp( curspace, "7" ))
        current_space = 7;
    else if( !strcmp( curspace, "8" ))
        current_space = 8;
    else if( !strcmp( curspace, "9" ))
        current_space = 9;
    else if( !strncmp( curspace, "10", 2 ))
        current_space = 10;
    else if( !strncmp( curspace, "11", 2 ))
        current_space = 11;
    else
        current_space = SIM;
        
        
    
    strcpy( writebuf, fetch_attribute( executor, "NAME" ));
    strncpy( new_star->name, writebuf, NAME_LEN-1 );
    new_star->name[NAME_LEN-1] = '\0';
    sscanf( my_atr_get_raw( executor, "LOCATION" ), "%f %f %f", &new_star->pos.x,
        &new_star->pos.y, &new_star->pos.z );
    new_star->size = atof( fetch_attribute( executor, "SIZE" ));
    
     
  /* It's allocated.  Now add it to the list */
    if( star_list[current_space] == NULL ) {   /* empty list */

       star_list[current_space] = new_star;
       star_tail[current_space] = new_star;
       new_star->prev = NULL;
       new_star->next = NULL;
   }
  else {
    star_tail[current_space]->next=new_star;
 
    new_star->prev = star_tail[current_space];
    new_star->next = NULL;
    star_tail[current_space] = new_star;
     
}

   
    

   
    fnotify( enactor, "Star %s is activated", new_star->name );
 return 1;
}


STAR *find_star( dbref target )
{
  STAR *star;

  for( current_space = 0; current_space < SPACE_LIMIT; current_space++ ) {
    star = star_list[current_space];

    while( star != NULL ) {
      if( star->star_object == target )
        return star;
      star = star->next;
    }
  }
  return NULL;
}

/* Let's make a planet orbit a star. */
void orbit_stars()
{
	STAR *star;
	SHIP *ship;
	PLANET *planet, *satellite, *oplanet, *sorbitting;
	XYZ relative_location, temp, dpos;

	
	/*Let's do all planets...maybe make orbitting bases later.*/
	for( planet = planet_list[current_space]; planet != NULL; planet=planet->next)
	{
		star=find_star(attrib_dbref(planet->planet_object,"ORBITTING"));
		if( (star!=NULL)  )
		  { 
		   
			relative_location.x=(planet->pos.x-star->pos.x);
			relative_location.y=(planet->pos.y-star->pos.y);
			relative_location.z=(planet->pos.z-star->pos.z);	 
		
	 
		/* Note: Speed is in DEGREEs per DAY */
		
		
		if( planet->orbit.range==0)		
		{
			planet->orbit=xyz_to_sph(relative_location);
		}
		
			planet->orbit.bearing = planet->orbit.bearing + planet->orbit_speed;
		/* This isn't so hard to code...especially if it's circular orbits which
		* it WILL be for now.  I don't seem to have a geometry book handy so
		* I'll keep the math relatively simple...well..for me :-) 
		*
		* Now edit the planet's position */
		
		temp = sph_to_xyz(planet->orbit);
		
		/* First gotta keep a record of change for the orbitting ships and moons */
		dpos.x=round((star->pos.x + temp.x)-planet->pos.x);
		dpos.y=round((star->pos.y + temp.y)-planet->pos.y);
		dpos.z=round((star->pos.z + temp.z)-planet->pos.z);
		
		planet->pos.x=star->pos.x + temp.x;
		planet->pos.y=star->pos.y + temp.y;
		planet->pos.z=star->pos.z + temp.z;
		
		sprintf(writebuf,"%d %d %d",(int)planet->pos.x, (int) planet->pos.y,(int) planet->pos.z);
		put_attribute(planet->planet_object,(char*) "LOCATION",writebuf);
		
		/* Got to move the moon relatively..same distance to keep their orbits the same distance */
		for( satellite = planet_list[current_space]; satellite != NULL; satellite=satellite->next)
		{
			oplanet=find_planet(attrib_dbref(satellite->planet_object,"ORBITTING"));
			
			if ( oplanet == planet )//Already checked to see if it was NULL
				{
				/* Done the old way cause it makes it easier for me anyway. For now. */
				
				
			    /* Relatively change the moon's position */
			    
			    satellite->pos.x=satellite->pos.x + dpos.x;
				satellite->pos.y=satellite->pos.y + dpos.y;
				satellite->pos.z=satellite->pos.z + dpos.z;
			    
				sprintf(writebuf,"%d %d %d",(int)satellite->pos.x, (int) satellite->pos.y,(int) satellite->pos.z);
				put_attribute(satellite->planet_object,(char*) "LOCATION",writebuf);
				
				/* Added this so the angle will be recalculated on next orbit_planet call */
				satellite->orbit.range=0;

				}
		 }
		 /* Now move the bases which are orbitting this planet */
		 for(ship=space_list[current_space]; ship!= NULL; ship= ship->next)
		 {
		 	sorbitting=find_planet(attrib_dbref(ship->ship_object,"ORBITTING"));
		 	
		 		if ( sorbitting == planet )//Already checked to see if it was NULL
				{
				/* Done the old way cause it makes it easier for me anyway. For now. */
				
				
			    /* Relatively change the moon's position */
			    
			    ship->pos.x=ship->pos.x + dpos.x;
				ship->pos.y=ship->pos.y + dpos.y;
				ship->pos.z=ship->pos.z + dpos.z;
			    
				sprintf(writebuf,"%d %d %d",(int)ship->pos.x, (int) ship->pos.y,(int) ship->pos.z);
				put_attribute(ship->ship_object,(char*) "LOCATION",writebuf);
		 	  }
		 }
		}
	}

	return;
}

/* Perhaps this next funtion should be in planets.c,    *
 * or maybe I should've called this file orbits.c which *
 * would have made more sense, but it's here and we'll  *
 * cope for now.  */
 
 
/* Now moons and such need to orbit the moving planets...
 * and they will do so much faster than the planets orbit
 * the stars */
void orbit_planets( )
{
	PLANET *planet;
	PLANET *satellite; /* Moon or other body orbitting a planet */
	XYZ relative_location, temp;
	
	
	/* gonna only start with moons, then do bases later */
	
	for( satellite = planet_list[current_space]; satellite != NULL; satellite=satellite->next)
	{
		planet=find_planet(attrib_dbref(satellite->planet_object,"ORBITTING"));
		if( (planet!=NULL)  )
		{   
		  
		relative_location.x=(satellite->pos.x-planet->pos.x);
		relative_location.y=(satellite->pos.y-planet->pos.y);
		relative_location.z=(satellite->pos.z-planet->pos.z);	 
		

				
	

		/* Angle moved to hardcode calc.  To prevent user error in setting up planets and moons *
		* Initial calc anyway, then store in the planet struct. */
		

		if( satellite->orbit.range==0 )
			satellite->orbit=xyz_to_sph( relative_location );

		satellite->orbit.bearing = satellite->orbit.bearing + satellite->orbit_speed;
		
		/* This kept in strictly for debugging purposes. */
		sprintf(writebuf,"%f",satellite->orbit.bearing);		
		put_attribute(satellite->planet_object,(char*) "ANGLE",writebuf);
		
		
		
		/* This isn't so hard to code...especially if it's circular orbits which
		* it WILL be for now.  I don't seem to have a geometry book handy so
		* I'll keep the math relatively simple...well..for me :-) 
		*
		* Now edit the planet's position */
		/*
		satellite->pos.x=round((satellite->orbit.range * cos(angle)) + planet->pos.x);
		satellite->pos.y=round((satellite->orbit.range * sin(angle)) + planet->pos.y);
		*/
		temp = sph_to_xyz(satellite->orbit);
		satellite->pos.x=planet->pos.x + temp.x;
		satellite->pos.y=planet->pos.y + temp.y;
		satellite->pos.z=planet->pos.z + temp.z;
		sprintf(writebuf,"%d %d %d",(int)satellite->pos.x, (int) satellite->pos.y,(int) satellite->pos.z);
		put_attribute(satellite->planet_object,(char*) "LOCATION",writebuf);
		
	 }	
	}

	return;
	
	
}
void list_stars( SHIP *ship, dbref enactor )
{
	struct stars_contact *contact;
	
	/*Just a sensor thing */
	fnotify( enactor, "%s%s------------------------------%sStars in Sensor Range%s-------------------------%s", ANSI_HILITE, ANSI_BLUE, ANSI_YELLOW, ANSI_BLUE, ANSI_NORMAL);
	fnotify( enactor, "%s%sStar         Range                 X         Y        Z        %s", ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL);
	
	for( contact=ship->stars_list; contact != NULL; contact=contact->next )
	{
		 fnotify( enactor, "%s%s%s %15d %22d %9d %7d %s", ANSI_HILITE, ANSI_WHITE, contact->listref->name, (int) distance(ship->pos, contact->listref->pos),(int) contact->listref->pos.x,(int) contact->listref->pos.y,(int) contact->listref->pos.z, ANSI_NORMAL);
	}
	
	fnotify(enactor,"%s%s----------------------------------------------------------------------------%s", ANSI_HILITE, ANSI_BLUE, ANSI_NORMAL);

	return;		
}

/* I never understood why C doesn't have this funtion built in *
 * So I made one myself.  I also don't know how we got this    *
 * far into space without a function like this.  I suppose I   *
 * always made the 3 extra if else lines :)    */
 
int round( float x )
{
	
	if( ((int) (x + 0.5)) > ((int) (x)) )
		return (int) (x+1);
	else
		return (int) x;
}

/* More code 'borrowed' from the planets setup..changed a bit for stars */
void star_checks( void )
{
  int sensor_power;
  STAR *star;
  float range;
  SHIP *ship;
  dbref navigator;

  ship = space_list[current_space];

  while( ship != NULL )
  {
  	
    if(!strcmp(fetch_attribute( ship->ship_object,"UNDOCKED"),"1")) 
    {
    star = star_list[current_space];

    navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
    
    while( star != NULL )
    {
      range = distance( ship->pos, star->pos );

      sensor_power = UMAX( ship->sensor_power, ship->aux_sensor_power );
      
        /* It's a star!  Whee! */
        if( range < ( ship->nebula_visibility * sensor_power * star->size ) || ship->flags[OMNISCIENT] )
          add_star( ship, star );
        else
          remove_star(ship, star);

	  /* To be continued at a later date for gravity 'slingshot' effect 
      * if( star->accelerator == 1 ) {
      *   /* it's an accelerator!  Whee! 
      * if( distance( ship->pos, star->pos ) <= star->accel_range )
      *   star_accelerate( planet, star );  
       } */

      star = star->next;
    } 
   }
    ship = ship->next;
  }
  return;
}


void add_star( SHIP *ship, STAR *star )
{
	
 struct stars_contact *contact;
    XYZ xyz_rel;
    SPH sph_rel;
    dbref navigator;

    /* go home if it's already on the list */
    contact = ship->stars_list;
    while( contact != NULL )
    {
        if( contact->listref == star ) return;
        contact = contact->next;
    }
    /* allocate memory for the contact and the star name. */
    if(( contact = (struct stars_contact *)JMALLOC( sizeof( struct stars_contact ))) == NULL )
        return;

    if( ( contact->name = (char *)JMALLOC( 48 ) )==NULL )
        return;

    /* okay, the star isn't on our list.  Add it. */
    xyz_rel.x = star->pos.x - ship->pos.x;
    xyz_rel.y = star->pos.y - ship->pos.y;
    xyz_rel.z = star->pos.z - ship->pos.z;

    sph_rel = xyz_to_sph( xyz_rel );

    navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

    switch( ship->owner )
    {
        default:
            strncpy( contact->name, Name(star->star_object), 48 );
            break;
    }
    fnotify( navigator, "%sStar %s now in sensor range bearing %s%s%d%+d%s%s at range %s%s%ld%s%s.%s",
        ANSI_CYAN, contact->name, ANSI_HILITE, ANSI_MAGENTA, (int)sph_rel.bearing,
        (int)sph_rel.elevation, ANSI_NORMAL, ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA,
        (long int)sph_rel.range, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL );

    contact->listref = star;
    if( ship->stars_list == NULL )
    {
        ship->stars_list = contact;
        ship->stars_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->stars_tail->next = contact;
        contact->prev = ship->stars_tail;
        contact->next = NULL;
         ship->stars_tail = contact;
    }
    return;
	

}

void remove_star( SHIP *ship, STAR *star )
{	
 struct stars_contact *contact;
  dbref navigator;

  /* search the stars list for it.  Remove it if it's there. */
  contact = ship->stars_list;

  while( contact != NULL )
  {
    if( contact->listref == star )
    {
      navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

      sprintf( writebuf, "Star %s is no longer in sensor range.",
               contact->name );
      notify( navigator, writebuf );

      if( ship->stars_list == ship->stars_tail ) { 
        ship->stars_list = NULL;
        ship->stars_tail = NULL;
        JFREE( contact );
        return;
      }

      if( contact == ship->stars_list ) {
        ship->stars_list = contact->next;
        ship->stars_list->prev=NULL;
        JFREE( contact );
        return;
      }

      if( contact == ship->stars_tail ) {
        ship->stars_tail = contact->prev;
        ship->stars_tail->next = NULL;
        JFREE( contact );
        return;
      }

      if(( contact != ship->stars_list) &&
        ( contact != ship->stars_tail )) {
        (contact->prev)->next = contact->next;
        (contact->next)->prev = contact->prev;
        JFREE( contact );
        return;
      }
    }
    contact = contact->next;
  }
}
 
