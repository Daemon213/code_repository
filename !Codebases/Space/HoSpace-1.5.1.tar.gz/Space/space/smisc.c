/*
 * $Id: smisc.c,v 1.5 1993/09/25 20:39:40 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: smisc.c,v $
 * Revision 1.5  1993/09/25  20:39:40  chuckles
 * cleaned up logging code.
 *
 * Revision 1.4  1993/09/24  23:45:27  chuckles
 * log_space function.  log_position now uses it too.
 *
 * Revision 1.3  1993/09/21  02:27:58  chuckles
 * fetch_attribute now uses atr_pget and a revolving queue of lbufs
 *
 * Revision 1.2  1993/09/13  04:29:43  chuckles
 * bugfix - match_contact wasn't matching names.  It is now.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 26 Aug 93 - put_attribute(), attrib_dbref(), fnotify()
 * JMS 25 Aug 93 - fetch_attribute()
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port
 */

/* For dumping space and such */
#include <stdio.h>

char *HappyName(dbref object)
{
  if (!GoodObject(object))
    return NULL;
  else 
    return ((char *) Name(object));
}

/**************************************
 *
 * sph_to_xyz()
 *
 *  input:
 *    sph_coord coord                 a position in spherical polar
 *
 *  purpose:
 *    converts from spherical polar to rectangular
 *
 *  return value:
 *    the rectangular equivalent of the input value
 *
 * JMS ?? Jul 92
 * JMS 24 May 93 - general cleanup
 *
 *************************************/

XYZ sph_to_xyz( SPH coord )
{
  XYZ new_coord;
  float r = coord.range;
  float elev = coord.elevation;
  float bearing = coord.bearing;

  new_coord.x = r * cos(bearing / 180.0 * PI) * cos(elev / 180.0 * PI);
  new_coord.y = r * sin(bearing / 180.0 * PI) * cos(elev / 180.0 * PI);
  new_coord.z = r * sin(elev / 180.0 * PI);

  return( new_coord );
}


/**************************************
 *
 * xyz_to_sph()
 *
 *  input:
 *    XYZ coord               a position in rectangular format
 *
 *  purpose:
 *    converts from rectangular to spherical polar
 *
 *  return value:
 *    the spherical polar equivalent of the input value
 *
 * JMS ?? Jul 92
 * JMS 24 May 93 - general cleanup
 *
 *************************************/

SPH xyz_to_sph( XYZ coord )
{
  SPH new_coord;
  float x = coord.x;
  float y = coord.y;
  float z = coord.z;

  if( coord.x==0.0 && coord.y==0.0 && coord.z==0.0 )
  {
    new_coord.bearing = 90.0;
  }
  else if( y == 0.0 )
  {
    if( x >= 0.0 ) new_coord.bearing = 0.0;
    else new_coord.bearing = 180.0;
  }
  else if( x == 0.0 )
  {
    if( y > 0.0 ) new_coord.bearing = 90.0;
    else new_coord.bearing = 270.0;
  }
  else
  {
    new_coord.bearing = atan( y / x ) * 180.0 / PI;
    if( x < 0.0 ) new_coord.bearing +=180.0;
  }

  if( z == 0.0 )
  {
    new_coord.elevation = 0.0;
  }
  else if(( x == 0.0 ) && ( y == 0.0 ))
  {
    if( z > 0 ) new_coord.elevation = 90.0;
    else new_coord.elevation = -90.0;
  }
  else
  {
    new_coord.elevation = atan( z / sqrt( x*x + y*y )) * 180.0 / PI;
  }

  new_coord.range = sqrt( x*x + y*y + z*z );

  /* bring bearing into range */
  if( new_coord.bearing < 0.0 ) new_coord.bearing += 360.0;
  if( new_coord.bearing >= 360.0 ) new_coord.bearing -=360.0;

  return( new_coord );
}


/**************************************
 *
 * distance()
 *
 *  input:
 *    XYZ a                                     point #1
 *    XYZ b                                     point #2
 *
 *  purpose:
 *    computes the distance between two points
 *
 *  return value:
 *    the distance
 *
 * JMS ?? Jul 92
 * JMS 24 May 93 - general cleanup
 *
 *************************************/

float distance( XYZ a, XYZ b )
{
  float dx, dy, dz;

  dx = b.x - a.x;
  dy = b.y - a.y;
  dz = b.z - a.z;

  return( sqrt( dx*dx + dy*dy + dz*dz ));
}


/**************************************************************************
 *                                                                        *
 *     Two functions that aren't used by space but belong here anyway     *
 *                                                                        *
 * - okay, they don't really belong here, but we'll cope. - JMS 24 May 93 *
 *                                                                        *
 **************************************************************************/

FUNCTION(fun_sph_to_xyz)
{
  SPH sphere;
  XYZ cart;

  sphere.bearing = atof(args[0]);
  sphere.elevation = atof(args[1]);
  sphere.range = atof(args[2]);

  cart = sph_to_xyz( sphere );

  sprintf( writebuf, "%f %f %f", cart.x, cart.y, cart.z );
  safe_str(writebuf, buff, bp);
}

FUNCTION(fun_xyz_to_sph)
{
  SPH sphere;
  XYZ cart;

  cart.x = atof( args[0] );
  cart.y = atof( args[1] );
  cart.z = atof( args[2] );

  sphere = xyz_to_sph( cart );

  sprintf( writebuf, "%d %+d %d", (int)sphere.bearing,
	   (int)sphere.elevation, (int)sphere.range );
  safe_str(writebuf, buff, bp);
}

FUNCTION(fun_distance)
{
  XYZ cart, cart2;

  cart.x = atof( args[0] );
  cart.y = atof( args[1] );
  cart.z = atof( args[2] );
  cart2.x = atof( args[3] );
  cart2.y = atof( args[4] );
  cart2.z = atof( args[5] );

  sprintf(writebuf, "%ld", (long)distance(cart, cart2));
  safe_str(writebuf, buff, bp);
}


/* match_contact() -- This function takes a pointer to a ship entry and
 * a character string that could represent a contact number or a ship name.
 * The function searches the contact list of ship for a contact matching
 * target, and returns a pointer to the contact entry if found, or a NULL
 * if it's not there.
 */

CONTACT *match_contact( SHIP *ship, char *target_string )
{
  int target_number;
  CONTACT *contact;

  target_number = atoi( target_string );

  if( target_number ) {
    /* they gave us a number */
    contact = ship->contact_list;
    while( contact != NULL ) {
      if( contact->contact_number == target_number )
      return( contact );

      contact = contact->next;
    }

    /* If we made it this far, they gave us an invalid contact number. *
     * Return a NULL pointer.                                          */

    return( NULL );
  }

  /* the wimps gave us a name, a zero, or nothing.  Oh well. */
  /* first check for a null string */
  if( !strcmp( target_string, "" )) {
    return( NULL );
  }

  /* terrific.  We've got a valid string.  Go to town */
  contact = ship->contact_list;
  while( contact != NULL ) {
    /* only check if they can actually see the name */
    if( contact->info_level == 5 ) {
      if( strstr( contact->listref->name, target_string) ) {
	/* whee! We found it */
	return( contact );
      }
    }
    contact = contact->next;
  }

  /* Again, if we've made it to this point, the name didn't match up. *
   * Return a NULL.                                                   */

  return( NULL );
}

/* Just like match_contact, but it works for planets */
struct planet_contact *match_planet( SHIP *ship, char *target_string )
{
  struct planet_contact *planet;

    /* they gave us a name hopefully*/
    planet = ship->planet_list;
    while( planet != NULL ) {
      if( strstr(planet->name, target_string ) )
	      return( planet );
      planet = planet->next;
    }

    /* If we made it this far, they gave us an invalid name. *
     * Return a NULL pointer.                                */

    return( NULL );
}

/*
 * find_contact
 * this is similar to match_contact, except that instead of a text string,
 * it takes a ship pointer.
 */

CONTACT *find_contact( SHIP *from, SHIP *to )
{
    CONTACT *contact;

    for(contact=from->contact_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref == to )
        {
            return contact;
        }
    }
    return NULL;
}

/**************************************
 *
 * write_damage()
 *
 *  input:
 *    SHIP *ship                                pointer to ship to be written
 *
 *  purpose:
 *    updates damage attributes on the corresponding ship object
 *
 * JMS ?? Jul 92
 * JMS 24 May 93 - cleanup
 *
 *************************************/

void write_damage( SHIP *ship )
{
    int i;

    if( current_space )
    {
        return;
    }
    for( i = 0; i < NUM_SYSTEMS; i++ )
        writebuf[i] = ship->damage[i].status;

    writebuf[NUM_SYSTEMS] = '\0';
    atr_add(ship->ship_object, "SYSTEM_DAMAGE", writebuf, (HOWIE), NOTHING);

    sprintf(writebuf, "%d %d", ship->hull_integrity - ship->current_integrity,
        ship->permanent_hull_damage );
    atr_add(ship->ship_object, "HULL_DAMAGE", writebuf, (HOWIE), NOTHING );

    sprintf(writebuf, "%d %d %d %d",
        ship->max_armor_strength - ship->armor_strength[0],
        ship->max_armor_strength - ship->armor_strength[1],
        ship->max_armor_strength - ship->armor_strength[2],
        ship->max_armor_strength - ship->armor_strength[3] );
    atr_add(ship->ship_object, "ARMOR_DAMAGE", writebuf, (HOWIE), NOTHING );

    sprintf( writebuf, "%d", ship->torp_capacity - ship->torps_remaining );
    atr_add( ship->ship_object, "TORPEDOES", writebuf, (HOWIE), NOTHING );
    return;
}


/*
 * log_position()
 *  input:
 *    SHIP *ship                                pointer to ship to be logged
 *  purpose:
 *    writes the position of ship to the space log
 * JMS ?? Jul 92
 * JMS 24 May 93 - cleanup
 * JMS 24 May 93 - bugfix - added a count to the strncpy
 * JMS 24 Sep 93 - use the new log_space function
 */
void log_position( SHIP *ship )
{

  if( ship == NULL )
  {
    log_space( "Log position called with null argument." );
    return;
  }
  log_space( "%s is at %d %d %d.", ship->name, (int)(ship->pos.x),
	     (int)(ship->pos.y), (int)(ship->pos.z));
}

/*
 * my_atr_get_raw()
 *
 * If you pass null pointers to functions like atof() or strstr(), they
 * blow a fuse.  If a given attribute isn't set, my_atr_get_raw() returns
 * a NULL.  This function sits on top of my_atr_get_raw() and changes
 * return NULL's to "#-1"
 *
 * JMS 24 Aug 93
 */

char *my_atr_get_raw( dbref obj, const char *attrib )
{
ATTR *a;

  a = atr_get_noparent( obj, attrib );

  if( !a )
    return (char *)"#-1";
  else 
    return (char *)uncompress(a->value);
}

/*
 * fetch_attribute
 *
 * pass an object dbref and a name of an attribute.  returns a pointer
 * to the text of the attribute if it exists and is set on the object,
 * or a pointer to a zero-length string otherwise.
 *
 * Note:  This function uses a chain of lbufs of length FETCH_LBUFS,
 * as defined in ../space.h.   Thus the results of the last FETCH_LBUFS
 * calls to this function will remain fresh.  After that, old values
 * start getting overwritten.
 *
 * JMS 25 Aug 93
 * JMS 20 Sep 93 - use atr_pget_str instead.
 */

char *fetch_attribute( dbref object, const char *attribute )
{
static char null_char = '\0';
ATTR *a;

  a = atr_get(object, strupper(attribute));

  if(!a) {
    /* can't find the requested attribute.  note it in the log */
    if ((attribute != "XB") && (attribute != "DESC"))
    	log_space( "Request for undef'd attribute: %s (#%d)", attribute, object );
    return &null_char;
  }

  return ((char *)uncompress(a->value));
}

/*
 * put_attribute
 *
 *  writes text to attribute on object, only if the attribute is defined.
 *
 * JMS 26 Aug 93
 */
void put_attribute( dbref object, char *attribute, char *text )
{
  atr_add(object, strupper(attribute), text, (HOWIE), NOTHING);
  return;
}

/*
 * attrib_dbref
 *
 *  pass a dbref and an attribute string, function extracts the string and
 *  processes it into a valid dbref or NOTHING.
 *
 * JMS 26 Aug 93
 */
dbref attrib_dbref(dbref object, const char *attribute )
{

  ATTR *a;
  dbref result;

  a = atr_get(object, strupper(attribute));
  if (!a) {
    if ((attribute != "XB") && (attribute != "DESC"))
    	log_space( "Request for undef'd attribute: %s (#%d)", attribute, object );  
    return NOTHING;
  }
  result = match_result(HOWIE, ((char *) uncompress(a->value)), NOTYPE, MAT_ABSOLUTE);

  if( result == AMBIGUOUS ) result = NOTHING;

  return result;
}

/*
 * fnotify
 *
 *  printf/notify combination.  saves a few lines of code here and there.
 *
 * JMS 26 Aug 93
 */
void fnotify(target, va_alist)
dbref target; 
va_dcl
{
va_list list;
char *fmt;
char tbuf1[BUFFER_LEN];

  va_start(list);
  fmt = va_arg(list, char *);
  vsprintf(tbuf1, fmt, list );
  va_end( list );

  notify( target, tbuf1);
}

void log_space( va_alist )
va_dcl
{
    va_list list;
    char *fmt;
    char tbuf1[BUFFER_LEN];
    CHAN *chan=NULL;

    va_start(list);
    fmt = va_arg(list, char *);
    vsprintf(tbuf1, fmt, list);
    find_channel("Log_Space", &chan, HOWIE);
    channel_broadcast(chan, HOWIE, 0, "<%sLog_Space%s> %s", ANSI_HILITE, ANSI_NORMAL, tbuf1);
    do_log(LT_CHECK, NOTHING, NOTHING, tbuf1);
}

void dump_space(void)
{
	SHIP *ship;
	PLANET *planet;
	FILE *dbase;
	BEACON *beacon;
	int ships=0, planets=0, beacons=0, i;

	if((dbase = fopen("data/space.db", "w")) == NULL)
                {
                fnotify(HOWIE,"can't open file\n");
                return;
                }
	else
	{
	
 	 /* Tell number of ships in space on dump */
	 for( ship=space_list[0]; ship != NULL; ship=ship->next )
	 {
	   ships++;
	 }
	fprintf( dbase, "%d \n", ships );


	/* Load info from the ship. */
	for( ship=space_list[0]; ship != NULL; ship=ship->next )
	 {
	  fprintf( dbase, "%d ", ship->ship_object);
	  fprintf( dbase, "%d ", ship->reactor_setting);
	  fprintf( dbase, "%d ", ship->alloc_helm);
	  fprintf( dbase, "%d ", ship->alloc_nav);
	  fprintf( dbase, "%d ", ship->alloc_batt);
	  fprintf( dbase, "%d ", ship->nalloc_warp);
	  fprintf( dbase, "%d ", ship->nalloc_fore);
	  fprintf( dbase, "%d ", ship->nalloc_aft);
	  fprintf( dbase, "%d ", ship->nalloc_port);
	  fprintf( dbase, "%d ", ship->nalloc_starboard);
	  fprintf( dbase, "%d ", ship->halloc_phasers);
	  fprintf( dbase, "%d ", ship->halloc_photons);
       fprintf( dbase, "%d ", ship->halloc_tractor);
       /* Shields */
       for( i=0; i<4;i++ )
       {
       	fprintf( dbase, "%d ", ship->shield_status[1]);
       }
       /* Comm stuff */
       for(i=0; i < MAX_CHANNEL; i++) 
         {
       	fprintf( dbase, "%d " , ship->channel[i].frequency );       	 
	     }
	  	
	     /* Temporary removal -- Wait, I put it back in and forgot to remove the comment :-) */
	  for(i=0; i < MAX_CHANNEL; i++ ) 
         {
       	fprintf( dbase, "%-16s", ship->channel[i].label );       	 
	     }    
	     fprintf( dbase, "\n");
	 }


    /* Ships are done, do planets now */
    for( planet=planet_list[0]; planet!=NULL; planet=planet->next )
    {
      planets++;
    }

    //Number of planets 

    fprintf( dbase, "%d \n", planets );

	for( planet=planet_list[0]; planet!=NULL; planet=planet->next )
	{
      fprintf( dbase, "%d \n", planet->planet_object );    
	}
	/* Do Beacons now */
	for( beacon=beacon_list[0]; beacon != NULL; beacon=beacon->next)
	{
		beacons++;
	}
	//Number of beacons
	fprintf( dbase, "%d \n", beacons);
	
	for( beacon=beacon_list[0]; beacon != NULL; beacon=beacon->next)
	{
	  fprintf( dbase, "%d \n", beacon->beacon_object );
	}  

	 /* END OF DUMP */
	}

	fclose(dbase);
}


void load_space(void)
{	
	
	int num, i, j, object, esr, helm, nav, batt, warp, fore, aft, port, starboard, phasers, photons, tractor;
	int shield0, shield1, shield2, shield3, chan0, chan1, chan2, chan3, chan4, chan5;
     int planets=0, planet, beacons=0, beacon;
     char label0[17] = {0};
     char label1[17] = {0};
     char label2[17] = {0};
     char label3[17] = {0};
     char label4[17] = {0};
     char label5[17] = {0};  
	FILE *dbase;
	SHIP *ship;
          
        /* Open the file */
	if((dbase = fopen("data/space.db", "r")) == NULL)
                {
                fnotify(HOWIE,"can't open space database\n");
                return;
                }
	else
	      {
	         /* START LOADING */
		
	    fscanf(dbase, "%d", &num);
	       
 		for( i=1; i<=num; i++)
		{
			/*  Ok, here it changes if you change the # of MAX_CHANNELS (NOT Reccomended) */
		  fscanf(dbase, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d ", &object, &esr, &helm, &nav, &batt, &warp, &fore, &aft, &port, &starboard, &phasers, &photons, &tractor,&shield0, &shield1, &shield2, &shield3, &chan0, &chan1, &chan2, &chan3, &chan4, &chan5);
		  
		  fgets( label0, 17, dbase);
		  fgets( label1, 17, dbase);
		  fgets( label2, 17, dbase);
		  fgets( label3, 17, dbase);
		  fgets( label4, 17, dbase);
		  fgets( label5, 17, dbase);
		  
		  /* VERY generic valid ship check.  Made for accidentally nuked space objects NOT
		   * cleared from spacedb */
		    	
		  
		  if( !GoodObject(attrib_dbref(object,"ENG")) || !GoodObject(object) )
		  {
		  	log_space( "Unable to load ship object %d.", object);
		    	continue; /*Skip this and move to the next part of the loop.
		    			   *I'll write some db-correcting code later. */
		    			   /* Heh.  WHy correct it...it just won't load
		    			    * then won't dump on the next one :-) */
		  }
		  start_reactor( NULL, -1, object );
		  ship = cfind_ship(object);
		  set_reactor_output(ship, -1, esr);
		   /* eng allocations */
	          ship->alloc_helm=helm;
			  ship->alloc_nav = nav;
              ship->alloc_batt = batt;
                  /* nav stuff */
	          ship->nalloc_warp = warp;
    		  ship->nalloc_fore = fore;
    		  ship->nalloc_aft = aft;
    		  ship->nalloc_port = port;
    		  ship->nalloc_starboard = starboard;
    		  /* Helm stuff */
	           ship->halloc_phasers = phasers;
                  ship->halloc_photons = photons;
                  ship->halloc_tractor = tractor;
                  /* Shields */                
                  ship->shield_status[0]=shield0;
                  ship->shield_status[1]=shield1;
                  ship->shield_status[2]=shield2;
                  ship->shield_status[3]=shield3;
                  /* Ok, Comm stuff */
                  ship->channel[0].frequency=chan0;
                  ship->channel[1].frequency=chan1;
                  ship->channel[2].frequency=chan2;
                  ship->channel[3].frequency=chan3;
                  ship->channel[4].frequency=chan4;
                  ship->channel[5].frequency=chan5;
                  strcpy(ship->channel[0].label,label0);
                  strcpy(ship->channel[1].label,label1);
                  strcpy(ship->channel[2].label,label2);
                  strcpy(ship->channel[3].label,label3);
                  strcpy(ship->channel[4].label,label4);
                  strcpy(ship->channel[5].label,label5); 
			
		}

        /*Ships done, do planets next */
        fscanf(dbase, "%d", &planets);

        for( j=1; j<=planets; j++ )
        {
           fscanf( dbase, "%d ", &planet );
           /* Make sure it's a good valid planet */
           if( !strcmp(fetch_attribute(planet,"SPACE"),"real") && GoodObject(planet) )
             activate_planet( planet, -1 );
           else
             log_space( "Unable to load planet %d", planet );
             
        }

        /* Planets done, beacons next */
        fscanf(dbase, "%d", &beacons);
        
        for( j=1; j<=beacons; j++)
        {
         fscanf(dbase, "%d", &beacon);
         /* Make sure it's a good valid beacon */
         if( !strcmp(fetch_attribute(beacon,"SPACE"),"real") && GoodObject(beacon) ) 
           activate_beacon(beacon, -1);
         else
           log_space( "Unable to load beacon %d", beacon );
         }
        
		/*END OF LOAD CODE */
		
		/* NOTE: No anomolies are saved nor loaded due to the fact
		 * that there are few of them and they are usually made and
		 * destroyed quite randomly.  The few in space will not lag
		 * too much on restarts if they are set startup. */
             }

	fclose(dbase);
}

