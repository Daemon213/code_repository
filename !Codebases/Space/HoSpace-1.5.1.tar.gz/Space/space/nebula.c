/*
 * $Id: nebula.c,v 1.2 1993/09/24 23:09:41 chuckles Exp chuckles $
 *    Copyright (C) 1997 Jeremy R. Huddleston
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: nebula.c,v $
 * 
 */


/*
void fun_nebula_cmd( char *buff, char *args[],
                     int nargs, dbref executor, dbref enactor )
*/
FUNCTION(fun_nebula_cmd) 
{
    NEBULA *nebula;
    int i;

    if( !Wizard(executor) || args[0]==NULL )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    /* switch on the argument */
    if( !strcmp( args[0], "activate" ))
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            nebula = nebula_list[i];
            while( nebula != NULL )
            {
                if( executor == nebula->nebula_object )
                {
                    notify( enactor, "This nebula is already activated." );
                    return;
                }
                nebula = nebula->next;
            }
        }
        /* okay, we've made it to this point so the nebula in question  *
         * must be inactive so far.  Cool.  Activate it                 */

        if( activate_nebula( executor, enactor ))
            notify( enactor, "Error initializing nebula." );
        return;
    }
    else if( !strcmp( args[0], "deactivate" ))
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            nebula = nebula_list[i];
            while( nebula != NULL )
            {
                if( executor == nebula->nebula_object )
                {
                    current_space = i;
                    deactivate_nebula( nebula, enactor );
                    return;
                }

                nebula = nebula->next;
            }
        }

        /* okay, we've made it to this point so the nebula in question *
         * must not be active.  Warn and return.                       */
        notify( enactor, "Nebula isn't active." );
        return;
    }
    else
    {
        notify( enactor, "Unrecognized nebula_command() call." );
    }
    return;
}


int activate_nebula( dbref executor, dbref enactor )
{
NEBULA *new_nebula;
char *curspace; 

  if(!(new_nebula=(NEBULA *)JMALLOC(sizeof(NEBULA))))
    return SERR_MALLOC;

  /* ship space -- this is either real or one of the sim spaces */
  curspace = my_atr_get_raw( executor, "SPACE" ); 
  if( !strcmp( curspace, "real" ))
    current_space = REAL;
  else if( !strcmp( curspace, "1" ))
    current_space = 1;
  else if( !strcmp( curspace, "2" ))
    current_space = 2;
  else if( !strcmp( curspace, "3" ))
    current_space = 3;
  else if( !strcmp( curspace, "4" ))
    current_space = 4;
  else if( !strcmp( curspace, "5" ))
    current_space = 5;
  else if( !strcmp( curspace, "6" ))
    current_space = 6;
  else if( !strcmp( curspace, "7" ))
    current_space = 7;
  else if( !strcmp( curspace, "8" ))
    current_space = 8;
  else if( !strcmp( curspace, "9" ))
    current_space = 9;
  else if( !strncmp( curspace, "10", 2 ))
    current_space = 10;
  else if( !strncmp( curspace, "11", 2 ))
    current_space = 11;
  else
    current_space = SIM;

  new_nebula->nebula_object = executor;

  new_nebula->density = atof( my_atr_get_raw( executor, "DENSITY" ));

  new_nebula->pos.x = atof( my_atr_get_raw( executor, "VX" ));
  new_nebula->pos.y = atof( my_atr_get_raw( executor, "VY" ));
  new_nebula->pos.z = atof( my_atr_get_raw( executor, "VZ" ));

  new_nebula->size = atof( my_atr_get_raw( executor, "SIZE" ));

  new_nebula->name = (char *)Name( executor );

  if( nebula_list[current_space] == NULL ) {
    nebula_list[current_space] = new_nebula;
    nebula_tail[current_space] = new_nebula;
    new_nebula->prev = NULL;
  }
  else {
    nebula_tail[current_space]->next = new_nebula;
    new_nebula->prev = nebula_tail[current_space];
    nebula_tail[current_space] = new_nebula;
  }

  new_nebula->next = NULL;

  /* and that's it for this nebula.  Return */
  fnotify( enactor, "Nebula %s activated in %s space.",
           new_nebula->name,
           space_names[current_space] );

  return( 0 );
}


void deactivate_nebula( NEBULA *nebula, dbref enactor )
{
SHIP *ship;

  /* this is an easy one.  Simply zorch it from the linked list */
  if(( nebula_list[current_space] == nebula ) &&
     ( nebula_tail[current_space] == nebula )) {
    nebula_list[current_space] = NULL;
    nebula_tail[current_space] = NULL;
  }
  else if( nebula_list[current_space] == nebula ) {
    nebula_list[current_space] = nebula_list[current_space]->next;
    nebula_list[current_space]->prev = NULL;
  }
  else if( nebula_tail[current_space] == nebula ) {
    nebula_tail[current_space] = nebula_tail[current_space]->prev;
    nebula_tail[current_space]->next = NULL;
  }
  else {
    nebula->prev->next = nebula->next;
    nebula->next->prev = nebula->prev;
  }

  /* go through and remove it from any nebula lists it may be on */
  ship = space_list[current_space];

  while( ship != NULL ) {
    remove_nebula( ship, nebula );
    ship = ship->next;
  }

  JFREE( nebula );

  notify( enactor, "Nebula is zorched." );

  return;
}


void ship_nebula_checks( SHIP *ship )
{
    NEBULA *nebula;
    char in_range;
    float range;

    nebula = nebula_list[current_space];

    while( nebula !=NULL )
    {
        in_range = FALSE;
        range = distance( ship->pos, nebula->pos );

        if( ship->flags[OMNISCIENT] || nebula->size >= range
        || UMAX(ship->sensor_power,ship->aux_sensor_power) > range-nebula->size )
        {
            in_range = TRUE;
        }
        if( in_range )
        {
            add_nebula( ship, nebula );
        }
        else
        {
            remove_nebula( ship, nebula );
        }
        nebula = nebula->next;
    }
    return;
}


void add_nebula( SHIP *ship, NEBULA *nebula )
{
    struct nebula_contact *contact;
    XYZ xyz_rel;
    SPH sph_rel;

    /* check inside if it's already on the list */
    contact = ship->nebula_list;

    ship->navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

    while( contact!=NULL )
    {
        if( contact->listref == nebula )
        {
            if( !contact->inside && nebula->size >= distance(ship->pos,nebula->pos) )
            {
                enter_nebula( ship, nebula, contact, ship->navigator );
            }
            else if( contact->inside && !( nebula->size > distance(ship->pos,nebula->pos) ) )
            {
                ship->nebula_visibility = (float)(ship->nebula_visibility / (1 - nebula->density) );

                /* Inform bridge of new nebula */
                sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.", ANSI_HILITE, ANSI_RED,
                    ANSI_NORMAL, nebula->name );
                notify_room( BRIDGE(ship), writebuf );
                contact->inside = FALSE;
            }
            return;
        }
        contact = contact->next;
    }
    /* allocate memory for the contact and the nebula name. */
    if( ( contact=(struct nebula_contact *)JMALLOC(sizeof(struct nebula_contact)) )==NULL )
    {
        return;
    }
    /* okay, the nebula isn't on our list.  Add it. */
    contact->listref = nebula;
    if( ship->nebula_list==NULL )
    {
        ship->nebula_list = contact;
        ship->nebula_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->nebula_tail->next = contact;
        contact->prev = ship->nebula_tail;
        contact->next = NULL;
        ship->nebula_tail = contact;
    }
    if( nebula->size > ( distance( ship->pos, nebula->pos )) )
    {
        enter_nebula( ship, nebula, contact, ship->navigator );
    }
    else
    {
        xyz_rel.x = nebula->pos.x - ship->pos.x;
        xyz_rel.y = nebula->pos.y - ship->pos.y;
        xyz_rel.z = nebula->pos.z - ship->pos.z;
        sph_rel = xyz_to_sph( xyz_rel );
        sph_rel.range = abs(sph_rel.range - nebula->size);

        fnotify( ship->navigator, "%s%sNebula %s now in sensor range bearing %s%d%+d%s at range %s%ld%s.%s",
            ANSI_HILITE, ANSI_BLUE, nebula->name, ANSI_RED, (int)sph_rel.bearing, (int)sph_rel.elevation,
            ANSI_BLUE, ANSI_RED, (long int)sph_rel.range, ANSI_BLUE, ANSI_NORMAL );
        contact->inside = FALSE;
    }
    return;
}

void enter_nebula( SHIP *ship, NEBULA *nebula, struct nebula_contact *contact, dbref navigator )
{
    ship->nebula_visibility = (float)(ship->nebula_visibility * (1 - nebula->density) );

    sprintf( writebuf, "%s%sWARNING:%s Entering the %s.", ANSI_HILITE, ANSI_RED,
             ANSI_NORMAL, nebula->name );
    notify_room( BRIDGE(ship), writebuf );

    contact->inside = 1;

    if( ship->nebula_visibility < .2 )
    {
        fnotify( navigator, "%s%sShields inoperative inside very thick nebulas.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        lower_shields( ship, navigator, (char *)"all" );
    }
    if( ship->cloak_status==CLOAK_ON && ship->nebula_visibility < .5 )
    {
        fnotify( navigator, "%s%sCloak inoperative inside thick nebulas.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        disengage_cloak( ship, navigator );
    }
    return;
}

void remove_nebula( SHIP *ship, NEBULA *nebula )
{
    struct nebula_contact *contact, *found = NULL;

    contact = ship->nebula_list;

    while( (contact != NULL) )
    {
        if( contact->listref == nebula )
            found = contact;
        contact = contact->next;
    }
    if( found == NULL )
        return;

    if( ship->nebula_list == ship->nebula_tail )
    {
        ship->nebula_list = NULL;
        ship->nebula_tail = NULL;
    }
    else if( found == ship->nebula_list )
    {
        ship->nebula_list = found->next;
        ship->nebula_list->prev=NULL;
    }
    else if( found == ship->nebula_tail )
    {
        ship->nebula_tail = found->prev;
        ship->nebula_tail->next = NULL;
    }
    else if( found!=ship->nebula_list && found!=ship->nebula_tail )
    {
        found->prev->next = found->next;
        found->next->prev = found->prev;
    }
    ship->navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

    if( found->inside )
    {
        ship->nebula_visibility = (float)(ship->nebula_visibility / (1 - nebula->density) );
        sprintf( writebuf, "%s%sWARNING:%s Leaving the %s.",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL, nebula->name );
        notify_room( BRIDGE(ship), writebuf );
    }
    JFREE( found );
    return;
}


void nebula_checks( void )
{
    SHIP *ship,*ship_next;

    for(ship=space_list[current_space];ship!=NULL;ship=ship_next)
    {
        ship_next = ship->next;
        ship_nebula_checks( ship );
    }
    return;
}


void list_nebulas( SHIP *ship, dbref enactor )
{
  struct nebula_contact *contact;
  XYZ xyz_rel;
  SPH sph_rel;
  char inside_ast[2];
  char rel_range[5];
  char nebula_size[5];
  char nebula_density[3];
  SHIP fake_ship; /* used for shield facing */

  static char *shield_strings[] = {
     (char *)"Fore", (char *)"Aft", (char *)"Port", (char *)"Starboard" };

  contact = ship->nebula_list;

  if( contact == NULL )
  {
/*
      fnotify( enactor, "%s%sNo nebulas detected.%s", ANSI_HILITE, ANSI_YELLOW, ANSI_NORMAL );
*/
      return;
  }

  while( contact != NULL )
  {
    xyz_rel.x = contact->listref->pos.x - ship->pos.x;
    xyz_rel.y = contact->listref->pos.y - ship->pos.y;
    xyz_rel.z = contact->listref->pos.z - ship->pos.z;
    sph_rel = xyz_to_sph( xyz_rel );

    if( sph_rel.range >= 10000000.0 )
       sprintf( rel_range, "%4.0fM", sph_rel.range / 1000000.0 );
    else if( sph_rel.range >= 100000.0 )
       sprintf( rel_range, "%4.0fK", sph_rel.range / 1000.0 );
    else
       sprintf( rel_range, "%5.0f", sph_rel.range );

    if ( contact->listref->size >= 10000 )
       sprintf( nebula_size, "%3.0dK", contact->listref->size / 1000 );
    else
       sprintf( nebula_size, "%4.0d", contact->listref->size );

       sprintf( nebula_density, "%3.0f", contact->listref->density * 100.0 );

    fake_ship.pos = contact->listref->pos;

    if(contact->inside)
       sprintf( inside_ast, "*" );
    else
       sprintf( inside_ast, " " );

    fnotify( enactor, "%s%s   %s   %s%s%-20.20s %s%s%-3.0f %-+3.0f %-5s      %s%s%-3s%%   %s%s%-4s   %s%-10s%s", 
	     ANSI_HILITE, ANSI_RED, inside_ast, ANSI_NORMAL, ANSI_CYAN,
	     contact->listref->name, ANSI_HILITE, ANSI_CYAN,
	     sph_rel.bearing, sph_rel.elevation, rel_range, ANSI_NORMAL,
	     ANSI_MAGENTA, nebula_density, ANSI_HILITE, ANSI_WHITE, nebula_size,
	     ANSI_BLACK, shield_strings[ facing_shield( &fake_ship, ship ) ], ANSI_NORMAL );

    contact = contact->next;
  }
  return;
}
