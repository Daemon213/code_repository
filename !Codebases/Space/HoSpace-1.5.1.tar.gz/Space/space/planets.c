/*
 * $Id: planets.c,v 1.3 1993/09/24 23:09:41 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: planets.c,v $
 * Revision 1.3  1993/09/24  23:09:41  chuckles
 * use jmalloc library.
 *
 * Revision 1.2  1993/09/12  15:32:36  chuckles
 * brought up to spec for Mush.  Uses the mnemonic attributes instead of
 * the V- and W- attribs.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 19 - begin MUSH2.0.p9 port
 * JMS 24 May 93 - separated into planets.c
 * JMS ?? Oct 92 - original code
 */



FUNCTION(fun_planet_cmd)
{
    dbref ship_object;
    int i;
    PLANET *planet;
    SHIP *ship;

    if( !Wizard(executor) || args[0]==NULL )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    /* switch on the argument */
    
    if( !strcmp( args[0], "activate" ) )
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            planet = planet_list[i];
            while( planet != NULL )
            {
                if( executor == planet->planet_object )
                {
                    notify( enactor, "This planet is already activated." );
                    return;
                }
                planet = planet->next;
            }
        }
        /* okay, we've made it to this point so the planet in question
         * must be inactive so far.  Cool.  Activate it
         */
        if( activate_planet( executor, enactor ) )
            notify( enactor, "Error initializing planet." );
        return;
    }
  
    else if( !strcmp( args[0], "deactivate" ) )
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            planet = planet_list[i];
            while( planet != NULL )
            {
                if( executor == planet->planet_object )
                {
                    current_space = i;
                    deactivate_planet( planet, enactor );
                    return;
                }
                planet = planet->next;
            }
        }
        /* okay, we've made it to this point so the planet in question
         * must not be active.  Warn and return.
         */
        notify( enactor, "Planet isn't active." );
        return;
    }
    


    else if( !strcmp( args[0], "blowup" ) )
    {
        current_space = -1;
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            for(planet=planet_list[i];planet!=NULL;planet=planet->next)
            {
                if( executor == planet->planet_object )
                {
                    current_space = i;
                    break;
                }
            }
            if( current_space==i )
            {
                break;
            }
        }
        if( current_space!=i || planet==NULL )
        {
            safe_str( "#-1 PLANET NOT ACTIVE", buff, bp );
            return;
        }
        else if( enactor!=HOWIE )
        {
            safe_str("#-1 PERMISSION DENIED", buff, bp );
            return;
        }
        else
        {
            sprintf( writebuf, "%d", blowup_planet(planet,enactor) );
            safe_str( writebuf, buff, bp );
        }
        return;
    }
    else if( !strcmp( args[0], "ship_range" ) )
    {
        /* find the ship */
        ship = cfind_ship( match_result(HOWIE, args[1], NOTYPE, MAT_ABSOLUTE));
        planet = find_planet( match_result(HOWIE, my_atr_get_raw(executor, "XA"), NOTYPE, MAT_ABSOLUTE));
        if( planet == NULL )
        {
            safe_str("NOT FOUND", buff, bp );
            return;
        }
        if( ship == NULL )
        {
            safe_str("NOT FOUND", buff, bp );
            return;
        }
        sprintf( writebuf, "%d", (int)( distance( planet->pos, ship->pos )));
        safe_str(writebuf, buff, bp);
        return;
    }
    else if( !strcmp( args[0], "planet_list" ) )
    {
        for( i = 0; i < SPACE_LIMIT; i++ )
        {
            planet = planet_list[i];
            if( planet == NULL )
            {
                sprintf( writebuf, "No planets in %s space.", space_names[i] );
                notify( enactor, writebuf );
            }
            else
            {
                fnotify( enactor, "Planet list for %s space.", space_names[i] );
                while( planet != NULL )
                {
                    fnotify( enactor, "#  dbref  - name                 X Y Z size" );
                    fnotify( enactor, "%2d #%5d - %-20s %3.0f %3.0f %3.0f %4.1f",
                        i, planet->planet_object,
                        Name(planet->planet_object),
                        planet->pos.x, planet->pos.y, planet->pos.z, planet->size );
                    planet = planet->next;
                }
            }
        }
        return;
    }
    /* woohoo, I must be a console */
    /* get the dbref of the ship object */
    ship_object = attrib_dbref( executor, "SHIP_OBJECT" );
    if( !GoodObject( ship_object ) )
    {
        safe_str("#-1 BAD PLANET OBJECT", buff, bp );
        return;
    }
    /* now set the ship pointer to the proper ship and also set the
     * space list to the list that contains it (handled by cfind_ship).
     */
    planet = find_planet( ship_object );
    if( planet==NULL )
    {
        notify( enactor, "Planet must be active to use that command." );
        return;
    }
    else if( current_space==REAL && !Wizard(executor) )
    {
        safe_str("#-1 PERMISSION DENIED", buff, bp );
        return;
    }
    else if( !strcmp( args[0], "status" ) )
    {
        planet_status( planet, enactor );
    }
    else if( !strcmp( args[0], "lock" ) && args[1]!=NULL )
    {
        planet_lock( planet, enactor, args[1] );
    }
    else if( !strcmp( args[0], "unlock" ) )
    {
        planet_unlock( planet, enactor );
    }
    else if( !strcmp( args[0], "target_system" ) && args[1]!=NULL )
    {
        planet_target_system( planet, enactor, args[1] );
    }
    else if( !strcmp( args[0], "fire_phaser" ) && args[1]!=NULL )
    {
        planet_fire_phaser( planet, enactor, atoi(args[1]), INFO_VERBOSE );
    }
    else if( !strcmp( args[0], "raise_shield" ) )
    {
        planet_raise( planet, enactor );
    }
    else if( !strcmp( args[0], "lower_shield" ) )
    {
        planet_lower( planet, enactor );
    }
    else if( !strcmp( args[0], "sensor_report" ) )
    {
        planet_sensor_report( planet, enactor );
    }
    else if( !strcmp( args[0], "short_sensor_report" ) )
    {
        planet_short_sensor_report( planet, enactor );
    }
    else
    {
        notify( enactor, "Unrecognized planet_command() call." );
    }
    return;
}

int activate_planet( dbref executor, dbref enactor )
{
    struct phaser_entry phaser;
    struct photon_entry photon;
    PLANET *new_planet;
    char *curspace;
    char *pcomms;
    char *comms;
    int i, numcomms = 0;

    if( !(new_planet=(PLANET *)JMALLOC(sizeof(PLANET))))
    {
        return SERR_MALLOC;
    }
    bzero( new_planet, sizeof(PLANET) );
    /* planet space -- either real space, or a sim space */
    curspace = fetch_attribute( executor, "SPACE" );
    if( !strcmp( curspace, "real" ))
        current_space = REAL;
    else if( !strcmp( curspace, "1" ))
        current_space = 1;
    else if( !strcmp( curspace, "2" ))
        current_space = 2;
    else if( !strcmp( curspace, "3" ))
        current_space = 3;
    else if( !strcmp( curspace, "4" ))
        current_space = 4;
    else if( !strcmp( curspace, "5" ))
        current_space = 5;
    else if( !strcmp( curspace, "6" ))
        current_space = 6;
    else if( !strcmp( curspace, "7" ))
        current_space = 7;
    else if( !strcmp( curspace, "8" ))
        current_space = 8;
    else if( !strcmp( curspace, "9" ))
        current_space = 9;
    else if( !strncmp( curspace, "10", 2 ))
        current_space = 10;
    else if( !strncmp( curspace, "11", 2 ))
        current_space = 11;
    else
        current_space = SIM;

    sscanf( fetch_attribute( executor, "LOCATION" ), "%f %f %f", &new_planet->pos.x,
        &new_planet->pos.y, &new_planet->pos.z );
    strncpy(new_planet->name,fetch_attribute(executor,"NAME"),NAME_LEN-1);
    new_planet->name[NAME_LEN-1] = '\0';
    new_planet->size = atof( fetch_attribute( executor, "SIZE" ));
    new_planet->transporter_range = atof( fetch_attribute( executor,"TRANSPORTER_RANGE" ));
    new_planet->planet_object = executor;
    new_planet->orbit.bearing=0;
    new_planet->orbit.elevation=0;
    new_planet->orbit.range=0;
    /* Note: Orbit_Speed is in Degrees per HOUR */
    new_planet->orbit_speed=atof( fetch_attribute(executor,"ORBIT_SPEED"));
    
    for(i=0;i<MAX_PHASERS;i++)
    {
        new_planet->phaser[i] = phaser;
    }
    for(i=0;i<MAX_PHOTONS;i++)
    {
        new_planet->photon[i] = photon;
    }
    new_planet->reciever_sensitivity=atoi(fetch_attribute(new_planet->planet_object, "SENSITIVITY"));    
    pcomms= my_atr_get_raw(new_planet->planet_object, "COMMS");
            
    comms=split_token(&pcomms, ' ');
    while(comms && pcomms)
    {
         {
           
           new_planet->comm[numcomms] = parse_dbref(comms);
           numcomms++;
         }
          new_planet->numcomms=numcomms;
     }
    for(i=0;i<MAX_CHANNEL;i++)
    {
    	new_planet->channel[0].frequency = 1;
    	strcpy(new_planet->channel[i].label , "none");
    	new_planet->channel[i].receive_status=1;
    }
    
    
    /* read in the flags */
    strncpy( new_planet->flags, fetch_attribute( executor, "FLAGS" ), 3 );
    /* check for an accelerator */
    if( new_planet->flags[1] == '1' )
    {
        new_planet->accel_range = atof( my_atr_get_raw( executor, "ACCEL_RANGE" ));
        new_planet->accel_base = atof( my_atr_get_raw( executor, "ACCEL_BASE" ));
        new_planet->accel_extension = atof( my_atr_get_raw( executor, "ACCEL_EXTENSION" ));
    }
    if( planet_list[current_space] == NULL )
    {
        planet_list[current_space] = new_planet;
        planet_tail[current_space] = new_planet;
        new_planet->prev = NULL;
    }
    else
    {
        planet_tail[current_space]->next = new_planet;
        new_planet->prev = planet_tail[current_space];
        planet_tail[current_space] = new_planet;
    }
    new_planet->next = NULL;
    /* and that's it for this planet.  Return */
    fnotify( enactor, "Planet %s activated in %s space.",
        Name( executor), space_names[current_space] );
    return 0;
}
   
void deactivate_planet( PLANET *planet, dbref enactor )
{
    CONTACT *contact,*contact_next;
    SHIP *ship,fake_ship;

    /* this is an easy one.  Simply zorch it from the linked list */
    if( planet_list[current_space]==planet && planet_tail[current_space]==planet )
    {
        planet_list[current_space] = NULL;
        planet_tail[current_space] = NULL;
    }
    else if( planet_list[current_space] == planet )
    {
        planet_list[current_space] = planet_list[current_space]->next;
        planet_list[current_space]->prev = NULL;
    }
    else if( planet_tail[current_space] == planet )
    {
        planet_tail[current_space] = planet_tail[current_space]->prev;
        planet_tail[current_space]->next = NULL;
    }
    else
    {
        planet->prev->next = planet->next;
        planet->next->prev = planet->prev;
    }
    /* go through and remove it from any planet lists it may be on */
    ship = space_list[current_space];
    while( ship != NULL )
    {
        remove_planet( ship, planet );
        ship = ship->next;
    }
    for(contact=planet->contact_list;contact!=NULL;contact=contact_next)
    {
        contact_next = contact->next;
        JFREE( contact );
    }
    JFREE( planet );
    notify( enactor, "Planet is zorched." );
    return;
}

/* planet_checks() -- This func is responsible for checking to see if any ships
 * enter/leave sensor range of planets, and updating their lists accordingly.
 */

void planet_checks( void )
{
  /* this is simple.  You can either see a planet or you can't.  No
   * random stuff at all.  With a large number of planets, this code
   * might become something of a cycle hog.  If it does, there's no
   * reason at all why it couldn't go off every 12, or even 18 seconds
   * instead of six.  Freq is no big deal here.
   */

  /* 11 October:  Things have gotten more complicated.  Planets are now
   * a subset of nav hazards.  We'll keep adding cases to this sucker as
   * the number of possibilities grow.
   */

  int sensor_power;
  PLANET *planet;
  float range;
  SHIP *ship;

  ship = space_list[current_space];

  while( ship != NULL )
  {
    if(!strcmp(fetch_attribute( ship->ship_object,"UNDOCKED"),"1")) 
    {
    planet = planet_list[current_space];

    /* clear the closest_planet counter */
    ship->near_planet_range = -1;
    ship->near_planet_size = 0.00001;
    
    while( planet != NULL )
    {
      range = distance( ship->pos, planet->pos );

      sensor_power = UMAX( ship->sensor_power, ship->aux_sensor_power );
      if( planet->flags[0] == '1' )
      {
        /* It's a planet!  Whee! */
        if( range < ( ship->nebula_visibility * sensor_power * planet->size )
        || ship->flags[OMNISCIENT] )
          add_planet( ship, planet );
        else
          remove_planet( ship, planet );

        if(( ship->near_planet_range == -1 ) ||
           ( range < ship->near_planet_range )) {
          ship->near_planet_range = range;
          ship->near_planet_size = planet->size;
        }
      }

      if( planet->flags[1] == '1' ) {
        /* it's an accelerator!  Whee! */
        if( distance( ship->pos, planet->pos ) <= planet->accel_range )
          haz_accelerate( planet, ship );
      }

      planet = planet->next;
    } 
   }
    ship = ship->next;
  }
  return;
}

void add_planet( SHIP *ship, PLANET *planet )
{
    struct planet_contact *contact;
    XYZ xyz_rel;
    SPH sph_rel;
    dbref navigator;

    /* go home if it's already on the list */
    contact = ship->planet_list;
    while( contact != NULL )
    {
        if( contact->listref == planet ) return;
        contact = contact->next;
    }
    /* allocate memory for the contact and the planet name. */
    if(( contact = (struct planet_contact *)JMALLOC( sizeof( struct planet_contact ))) == NULL )
        return;

    if( ( contact->name = (char *)JMALLOC( 48 ) )==NULL )
        return;

    /* okay, the planet isn't on our list.  Add it. */
    xyz_rel.x = planet->pos.x - ship->pos.x;
    xyz_rel.y = planet->pos.y - ship->pos.y;
    xyz_rel.z = planet->pos.z - ship->pos.z;

    sph_rel = xyz_to_sph( xyz_rel );

    navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);

    switch( ship->owner )
    {
        default:
            strncpy( contact->name, Name( planet->planet_object), 48 );
            break;
    }
    fnotify( navigator, "%sPlanet %s now in sensor range bearing %s%s%d%+d%s%s at range %s%s%ld%s%s.%s",
        ANSI_CYAN, contact->name, ANSI_HILITE, ANSI_MAGENTA, (int)sph_rel.bearing,
        (int)sph_rel.elevation, ANSI_NORMAL, ANSI_CYAN, ANSI_HILITE, ANSI_MAGENTA,
        (long int)sph_rel.range, ANSI_NORMAL, ANSI_CYAN, ANSI_NORMAL );

    contact->listref = planet;
    if( ship->planet_list == NULL )
    {
        ship->planet_list = contact;
        ship->planet_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->planet_tail->next = contact;
        contact->prev = ship->planet_tail;
        contact->next = NULL;
         ship->planet_tail = contact;
    }
    return;
}

void remove_planet( SHIP *ship, PLANET *planet )
{
  struct planet_contact *contact;
  dbref navigator;

  /* search the planet list for it.  Remove it if it's there. */
  contact = ship->planet_list;

  while( contact != NULL )
  {
    if( contact->listref == planet )
    {
      navigator = match_result(HOWIE, my_atr_get_raw(ship->nav, "XB"), NOTYPE, MAT_ABSOLUTE);
      if( ship->orbitting == contact )
      {
        orbit( ship, navigator, NULL );
      }
      sprintf( writebuf, "Planet %s is no longer in sensor range.",
               contact->name );
      notify( navigator, writebuf );

      if( ship->planet_list == ship->planet_tail ) { 
        ship->planet_list = NULL;
        ship->planet_tail = NULL;
        JFREE( contact );
        return;
      }

      if( contact == ship->planet_list ) {
        ship->planet_list = contact->next;
        ship->planet_list->prev=NULL;
        JFREE( contact );
        return;
      }

      if( contact == ship->planet_tail ) {
        ship->planet_tail = contact->prev;
        ship->planet_tail->next = NULL;
        JFREE( contact );
        return;
      }

      if(( contact != ship->planet_list) &&
        ( contact != ship->planet_tail )) {
        (contact->prev)->next = contact->next;
        (contact->next)->prev = contact->prev;
        JFREE( contact );
        return;
      }
    }
    contact = contact->next;
  }
}

PLANET *find_planet( dbref target )
{
  PLANET *planet;

  for( current_space = 0; current_space < SPACE_LIMIT; current_space++ ) {
    planet = planet_list[current_space];

    while( planet != NULL ) {
      if( planet->planet_object == target )
        return planet;
      planet = planet->next;
    }
  }
  return NULL;
}

struct planet_contact *find_planet_contact( SHIP *ship, PLANET *planet )
{
    struct planet_contact *contact;

    for(contact=ship->planet_list;contact!=NULL;contact=contact->next)
    {
        if( contact->listref==planet )
        {
            return contact;
        }
    }
    return NULL;
}

int blowup_planet( PLANET *planet, dbref enactor )
{
    SHOCKWAVE temp;
    SHIP *ship;
    if( enactor!=HOWIE && enactor!=-1 )
    {
        return 1;
    }
    fnotify( enactor, "Planet %s exploded.", Name(planet->planet_object) );
    for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
    {
        if( find_planet_contact(ship,planet)==NULL )
        {
            continue;
        }
        sprintf( writebuf, "%s%sWARNING: Planet %s has exploded!%s",
            ANSI_HILITE, ANSI_RED, Name(planet->planet_object), ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
    }
    temp.pos = planet->pos;
    temp.size = planet->size;
    temp.density = 0.99;
    temp.base_dam = planet->size * 10000;
    temp.falloff = 100;
    temp.speed = 1000;
    temp.shockwave_object = planet->planet_object;
    sprintf( writebuf, "%s", Name(planet->planet_object) );
    strncpy( temp.name, writebuf, NAME_LEN-1 );
    temp.name[NAME_LEN-1] = '\0';
    auto_active_shockwave( &temp, current_space );
    deactivate_planet( planet, -1 );
    return 0;
}

void planet_tactical( void )
{
    dbref operator;
    PLANET *planet;
    int i,old;

    for(planet=planet_list[current_space];planet!=NULL;planet=planet->next)
    {
        operator = match_result(HOWIE, my_atr_get_raw(planet->console, "XB"), NOTYPE, MAT_ABSOLUTE);
        planet->shield_level = UMIN(planet->shield_level,planet->shield_max);
        old = planet->shield_level;
        i = planet->shield_level - planet->shield_level * planet->shield_status==SHLD_READY ? SHLD_READY_BLEED : SHLD_UP_BLEED;
        if( planet->shield_status==SHLD_UP )
        {
            planet->shield_level -= i - UMIN(planet->shield_max_charge,i);
        }
        else
        {
            planet->shield_level -= i;
            planet->shield_level += planet->shield_max_charge;
        }
        if( planet->shield_level >= planet->shield_max
        && planet->shield_max > 0 && planet->shield_max_charge > 0 )
        {
            planet->shield_level = UMIN(planet->shield_level,planet->shield_max);
            if( old < planet->shield_level )
            {
                fnotify( operator, "%s%sShields fully charged.%s",ANSI_HILITE,
                    ANSI_GREEN, ANSI_NORMAL );
            }
        }
        for(i=0;i<planet->number_of_phasers;i++)
        {
            planet->phaser[i].old_charge = planet->phaser[i].charge;
            planet->phaser[i].charge *= 0.9;
            if( planet->phaser[i].status==PHASER_ONLINE )
            {
                planet->phaser[i].charge += planet->phaser[i].charge_per_turn;
                if( planet->phaser[i].charge >= planet->phaser[i].power )
                {
                    planet->phaser[i].charge = planet->phaser[i].power;
                    if( planet->phaser[i].old_charge < planet->phaser[i].charge )
                    {
                        fnotify( operator, "%s%s%s %d fully charged.%s",
                            ANSI_HILITE, ANSI_GREEN,
                            planet->phaser_string, i, ANSI_NORMAL );
                    }
                }
            }
        }
        for(i=0;i<planet->number_of_photons;i++)
        {
            if( planet->photon[i].status==PHOTON_ONLINE
            || planet->photon[i].status==PHOTON_ARMED )
            {
                if( ++planet->photon[i].turns_charged > planet->photon_max_turns_online )
                {
                    if( planet->photon[i].status==PHOTON_ONLINE )
                    {
                        --planet->num_photons_online;
                    }
                }
                planet->photon[i].turns_charged = 0;
                planet->photon[i].charge = 0;
                planet->photon[i].status = PHOTON_EMPTY;
                continue;
            }
            if( planet->photon[i].status==PHOTON_ONLINE )
            {
                planet->photon[i].charge += planet->photon[i].charge_per_turn;
                if( planet->photon[i].charge >= planet->photon[i].power/2 )
                {
                    planet->photon[i].status = PHOTON_ARMED;
                    planet->photon[i].charge = 0;
                    planet->num_photons_online--;
                    fnotify( operator, "%s%s%s %d armed.%s",
                        ANSI_HILITE, ANSI_RED,
                        planet->photon_string, i, ANSI_NORMAL );
                }
            }
        }
    }
    return;
}

void planet_fire_phaser( PLANET *planet, dbref enactor, int bank, int control )
{
    struct planet_contact *contact,*shooter;
    dbref helmsman;
    char target_string[120];
    CONTACT *target,*shootee;
    SHIP *observer,fake_ship;
    float damage_coeff;
    int i,damage,effective_max_range;
    WDATA weapon = {WPN_GUN,0.9,1.0,0.9,1};
    
    shootee = planet->locked_target;
    if( shootee==NULL )
    {
        fnotify( enactor, "%s%sWeapons must be locked in order to fire.%s", ANSI_HILITE, ANSI_RED,
            ANSI_NORMAL );
        return;
    }
    if( shootee->listref->flags[DEADMAN] )
    {
        fnotify( enactor, "%s%sTargeted ship is deadmanned. Unable to fire.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    /* check for fire all banks */
    if( bank==FIRE_ALL && shootee==planet->locked_target )
    {
        fnotify( enactor, "%sFiring all available %ss.%s", ANSI_CYAN, planet->phaser_string,
            ANSI_NORMAL );

        for( i = 0; i < planet->number_of_phasers; i++ )
        {
            if( planet->phaser[i].charge != 0 )
            {
                planet_fire_phaser( planet, enactor, i, control++ );
            }
        }
        return;
    }
    /* valid bank check */
    if( ( bank < 0 ) || ( bank >= planet->number_of_phasers ) )
    {
        fnotify( enactor, "%s%sInvalid %s number.%s", ANSI_HILITE, ANSI_RED,
            planet->phaser_string, ANSI_NORMAL );
        return;
    }
    if( planet->phaser[bank].charge==0 )
    {
        fnotify( enactor, "%s%sA %s must be charged before firing.%s", ANSI_HILITE, ANSI_RED,
            planet->phaser_string, ANSI_NORMAL );
        return;
    }
    effective_max_range = planet->phaser[bank].range * planet->phaser[bank].charge / planet->phaser[bank].power;
    if((int)( distance( planet->pos, shootee->listref->pos ) + 0.5 ) > effective_max_range )
    {
        fnotify( enactor, "%s%sThe max range for %s %i at current charge is %i.%s", ANSI_HILITE,
            ANSI_RED, planet->phaser_string, bank, effective_max_range, ANSI_NORMAL );
        return;
    }
    /* phasers away! Compute the damage coefficient of a hit.
     * that is, range_percent +- 25% of that
     */
    damage_coeff = planet->phaser[bank].range_percent +
        ( FRAND - 0.5 ) * 0.5 * planet->phaser[bank].range_percent;
    /* see if shooter is on the receiver's contact list */
    shooter = NULL;
    contact = shootee->listref->planet_list;
    while( contact != NULL )
    {
        if( contact->listref == planet )
        {
            shooter = contact;
            contact = NULL;
        }
        else
            contact = contact->next;
    }
    /* Well gee, let's tell them about it. */
    if( shooter == NULL )
    {
        sprintf( writebuf, "%s%sEnemy %s fired from XYZ: %.0f %.0f %.0f!%s", ANSI_HILITE,
            ANSI_RED, planet->phaser_string,
            planet->pos.x, planet->pos.y, planet->pos.z, ANSI_NORMAL );
        notify_room(BRIDGE(shootee->listref), writebuf );
    }
    else
    {
        sprintf( writebuf, "%s%sEnemy %s fired by planet %s%s", ANSI_HILITE, ANSI_RED,
            shooter->listref->phaser_string, ANSI_NORMAL, shooter->name );
        notify_room(BRIDGE(shootee->listref), writebuf);
    }
    if( control == INFO_VERBOSE )
    {
        for(observer=space_list[current_space];observer!=NULL;observer=observer->next)
        {
            if( observer==shootee->listref )
            {
                continue; /* continue looping */
            }
            target = find_contact( observer, shootee->listref );
            shooter = find_planet_contact( observer, planet );
            /* find observer helmsman's dbref */
            helmsman = match_result(HOWIE, my_atr_get_raw(observer->helm, "XB"), NOTYPE, MAT_ABSOLUTE);
            if( shooter==NULL && target==NULL )
            {
            }
            else if( shooter == NULL )
            {
                contact_string( target_string, target, INFO_TERSE );
                fnotify( helmsman, "%sUnknown source at %.0f %.0f %.0f fired %ss upon contact [%s%s%d%s%s]: %s%s", ANSI_CYAN,
                    planet->pos.x, planet->pos.y, planet->pos.z,
                    planet->phaser_string, ANSI_HILITE, ANSI_MAGENTA, target->contact_number, ANSI_NORMAL,
                    ANSI_CYAN, ANSI_NORMAL, target_string );
            }
            else if( target==NULL )
            {
                fnotify( helmsman, "%s%sPlanet %s%s%s fired %ss upon XYZ: %.0f %.0f %.0f.%s",
                    ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL, shooter->name,
                    ANSI_CYAN, planet->phaser_string, shootee->listref->pos.x,
                    shootee->listref->pos.y, 
                    shootee->listref->pos.z, ANSI_NORMAL );
            }
            else
            {
                contact_string( target_string, target, INFO_TERSE );
                fnotify( helmsman, "%s%sPlanet %s%s%s fired %ss upon contact [%s%s%d%s%s]: %s%s",
                    ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL, shooter->name, ANSI_CYAN,
                    planet->phaser_string, ANSI_HILITE, ANSI_MAGENTA,
                    target->contact_number, ANSI_NORMAL, ANSI_CYAN,
                    ANSI_NORMAL, target_string );
            }
        }
    }
    /* OK everyone has seen this shot go off.  Let's see the damage! */
    /* note that the range we use is not the phaser max range.  We adjust
     * that range for a less than full charge and use effective_max_range.
     */
    damage = (int)( (float)( planet->phaser[bank].charge ) *
             ( 1.0 + ( damage_coeff - 1.0 ) *
             distance( planet->pos, shootee->listref->pos ) /
             (float)( effective_max_range )) + 0.5);
    fnotify( enactor, "%s%s%s %d fired.  Hit for %2.0f%% yield.%s", ANSI_HILITE, ANSI_GREEN,
        planet->phaser_string, bank,
        (float)damage / (float)(planet->phaser[bank].charge) * 100.0, ANSI_NORMAL );
    planet->phaser[bank].charge = 0;
    fake_ship = (*shootee->listref);
    fake_ship.pos = planet->pos;
    fake_ship.target_system = planet->target_system;
    battle_damage( &fake_ship, shootee->listref, damage, weapon );
    return;
}

void planet_lock( PLANET *planet, dbref enactor, char *target )
{
    struct planet_contact *pcontact;
    SHIP *ship,fake_ship;
    CONTACT *contact;

    fake_ship = planet_fake_ship( planet );
    if( ( contact=match_contact(&fake_ship,target) )==NULL
    || ( ship=contact->listref )==NULL )
    {
        fnotify( enactor, "%s%sNo target '%s' detected for targetting.%s",
            ANSI_HILITE, ANSI_RED, target, ANSI_NORMAL );
        return;
    }
    if( ( pcontact=find_planet_contact(ship,planet) )==NULL )
    {
        sprintf( writebuf, "%s%sWarning!  Weapons have been locked from an unknown source.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
    }
    else
    {
        sprintf( writebuf, "%s%sWarning! Weapons systems on planet %s have locked on!%s",
            ANSI_HILITE, ANSI_RED, pcontact->name, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
    }
    fnotify( enactor, "%s%sWeapons locked on target.%s", ANSI_HILITE,
        ANSI_RED, ANSI_NORMAL );
    planet->locked_target = contact;
    return;
}

void planet_unlock( PLANET *planet, dbref enactor )
{
    struct planet_contact *contact;
    SHIP *ship;

    if( planet->locked_target==NULL )
    {
        fnotify( enactor, "%s%sWeapons not locked.%s", ANSI_HILITE,
            ANSI_GREEN, ANSI_NORMAL );
        return;
    }
    if( ( ship=planet->locked_target->listref )!=NULL
    && ( contact=find_planet_contact(ship,planet) )!=NULL )
    {
        sprintf( writebuf, "%s%sWeapons lock from planet %s has been broken.%s",
            ANSI_HILITE, ANSI_GREEN, contact->name, ANSI_NORMAL );
        notify_room( BRIDGE(ship), writebuf );
    }
    fnotify( enactor, "%s%sUnlocked.%s", ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    planet->locked_target = NULL;
    return;
}

void planet_raise( PLANET *planet, dbref enactor )
{
    if( planet==NULL )
    {
        fnotify( enactor, "%sPlanet inactive.  Shield controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    if( planet->shield_max <= 0 || planet->shield_max_charge <= 0 )
    {
        fnotify( enactor, "%s%sThis planet does not have shields.%s",
            ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
        return;
    }
    switch( planet->shield_status )
    {
        default:
            planet->shield_status = SHLD_UP;
            fnotify( enactor, "%sPlanetary shields raised.%s", ANSI_GREEN, ANSI_NORMAL );
            break;
        case SHLD_UP:
            fnotify( enactor, "%sPlanetary shields are already up.%s", 
                 ANSI_MAGENTA, ANSI_NORMAL );
             break;
        case SHLD_DAMAGED:
          fnotify( enactor, "%s%sPlanetary shields are damaged and may not be raised or lowered.%s", 
                 ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
          break;
    }
    return;
}

void planet_lower( PLANET *planet, dbref enactor )
{
    if( planet==NULL )
    {
        fnotify( enactor, "%sPlanet inactive.  Shield controls inoperative.%s", ANSI_CYAN, ANSI_NORMAL );
        return;
    }
    switch( planet->shield_status )
    {
        default:
            planet->shield_status = SHLD_READY;
            fnotify( enactor, "%sPlanetary shields lowered.%s", ANSI_GREEN, ANSI_NORMAL );
            break;
        case SHLD_READY:
            fnotify( enactor, "%sPlanetary shields are already down.%s", 
                ANSI_MAGENTA, ANSI_NORMAL );
            break;
        case SHLD_DAMAGED:
            fnotify( enactor, "%s%sPlanetary shields are damaged and may not be raised or lowered.%s", 
                ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            break;
    }
    return;
}

void scan_planet( SHIP *ship, dbref enactor, struct planet_contact *planet )
{
    char shielded = 0;

    if( planet==NULL )
    {
        fnotify( enactor, "%s%sNo such planet.%s", ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        return;
    }
    if( planet->listref->shield_status==SHLD_UP && planet->listref->shield_level > 0 )
    {
        shielded = 1;
    }
    fnotify( enactor, "%s%sName: %s%s%s", ANSI_HILITE, ANSI_CYAN, planet->name,
        shielded ? ANSI_HILITE ANSI_RED " <<< SHIELDED >>>" ANSI_CYAN : "", ANSI_NORMAL );
    fnotify( enactor, "%s%sClass: %s%s", ANSI_HILITE, ANSI_GREEN,
        fetch_attribute(planet->listref->planet_object,"CLASS"), ANSI_NORMAL );
    fnotify( enactor, "%s%sType: %s%s", ANSI_HILITE, ANSI_GREEN,
        fetch_attribute(planet->listref->planet_object,"TYPE"), ANSI_NORMAL );
    fnotify( enactor, "%s%sPopulation: %s%s", ANSI_HILITE, ANSI_GREEN,
        shielded ? ANSI_HILITE ANSI_RED "<<< SHIELDED >>>" ANSI_GREEN : 
            fetch_attribute(planet->listref->planet_object,"POPULATION"),
        ANSI_NORMAL );
    fnotify( enactor, "%s%sArmies: %s%s", ANSI_HILITE, ANSI_MAGENTA,
        shielded ? ANSI_HILITE ANSI_RED "<<< SHIELDED >>>" ANSI_MAGENTA : 
            fetch_attribute(planet->listref->planet_object,"ARMIES"),
        ANSI_NORMAL );
    fnotify( enactor,"\n\r%s%s --- DEFENSES ---%s", ANSI_HILITE, ANSI_RED,
        ANSI_NORMAL );
    if( !shielded )
    {
        fnotify( enactor, "%s%s%d %s%s, %d %s%s%s", ANSI_HILITE, ANSI_CYAN,
            planet->listref->number_of_phasers, planet->listref->phaser_string,
            planet->listref->number_of_phasers-1 ? "s" : "",
            planet->listref->number_of_photons, planet->listref->photon_string,
            planet->listref->number_of_photons-1 ? "s" : "", ANSI_NORMAL );
    }
    else
    {
        fnotify( enactor, "%s%sUnable to scan for weapons, planetary shields are up.%s",
            ANSI_HILITE, ANSI_MAGENTA, ANSI_NORMAL );
    }
    if( planet->listref->shield_max > 0 && planet->listref->shield_max_charge > 0 )
    {
        fnotify( enactor, "%s%sShields: %s%d/%d(%d%%) *%s%s%s*",
            ANSI_HILITE, ANSI_CYAN, ANSI_NORMAL,
            planet->listref->shield_level, planet->listref->shield_max,
            100*planet->listref->shield_level/planet->listref->shield_max,
            ANSI_HILITE, shielded ? ANSI_RED "UP" : ANSI_GREEN "DOWN",
            ANSI_NORMAL );
    }
    else
    {
        fnotify( enactor, "%s%sNo planetary shields detected.%s",
            ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
    }
    return;
}

void planet_short_sensor_report( PLANET *planet, dbref enactor )
{
    SHIP fake_ship;

    fake_ship = planet_fake_ship( planet );
    short_sensor_report( &fake_ship, enactor );
    return;
}

void planet_sensor_report( PLANET *planet, dbref enactor )
{
    SHIP fake_ship;

    fake_ship = planet_fake_ship( planet );
    helm_sensor_report( &fake_ship, enactor );
    return;
}

void planet_status( PLANET *planet, dbref enactor )
{
    int i;

    fnotify( enactor,"%sPlanetary status report for %s%s%s.%s",
        ANSI_CYAN, ANSI_NORMAL, planet->name, ANSI_CYAN, ANSI_NORMAL );

    for(i=0;i<planet->number_of_phasers;i++)
    {
        switch( planet->phaser[i].status )
        {
            case PHASER_ONLINE:
                if( planet->phaser[i].charge==planet->phaser[i].power )
                    fnotify( enactor, "%s%s %d:%s%s Fully Charged%s", ANSI_CYAN,
                        planet->phaser_string, i, ANSI_HILITE, ANSI_GREEN, ANSI_NORMAL );
                else
                    fnotify( enactor, "%s%s %d:%s%s On-Line (%d of %d)%s", ANSI_CYAN,
                        planet->phaser_string, i, ANSI_HILITE, ANSI_MAGENTA, planet->phaser[i].charge,
                        planet->phaser[i].power, ANSI_NORMAL );
                break;
            case PHASER_OFFLINE:
                fnotify( enactor, "%s%s %d:%s%s Off-Line (%d of %d)%s", ANSI_CYAN,
                    planet->phaser_string, i, ANSI_HILITE, ANSI_RED, planet->phaser[i].charge,
                    planet->phaser[i].power, ANSI_NORMAL );
                break;
            case PHASER_DAMAGED:
                fnotify( enactor, "%s%s %d:%s%s Damaged (%d of %d)%s", ANSI_CYAN,
                    planet->phaser_string, i, ANSI_HILITE, ANSI_RED, planet->phaser[i].charge,
                    planet->phaser[i].power, ANSI_NORMAL );
                break;
        }
    }
    /* print a photon */
    for(i=0;i<planet->number_of_photons;i++)
    {
        switch( planet->photon[i].status )
        {
            case PHOTON_EMPTY:
                fnotify( enactor, "%stube %d: %s%sEmpty%s", ANSI_CYAN, i, 
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                break;
            case PHOTON_LOADED:
                fnotify( enactor, "%stube %d: %s%sLoaded%s", ANSI_CYAN, i,
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                break;
            case PHOTON_ONLINE:
                fnotify( enactor, "%stube %d: %s%scharging %d of %d (%is)%s", ANSI_CYAN, i,
                    ANSI_HILITE, ANSI_MAGENTA,
                    planet->photon[i].charge, planet->photon[i].power / 2,
                    (planet->photon_max_turns_online - planet->photon[i].turns_charged)*6
                         - tcount + (tcount == 0 ? 0 : 6), ANSI_NORMAL);
                break;
            case PHOTON_ARMED:
                fnotify( enactor, "%stube %d: %s%sArmed (%is)%s", ANSI_CYAN, i,
                   ANSI_HILITE, ANSI_GREEN,
                   (planet->photon_max_turns_online - planet->photon[i].turns_charged)*6
                        - tcount + (tcount == 0 ? 0 : 6), ANSI_NORMAL);
                break;
            case PHOTON_DAMAGED:
                fnotify( enactor, "%stube %d: %s%sDamaged%s",ANSI_CYAN, i,
                    ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
                break;
        }
    }
    if( planet->locked_target!=NULL )
    {
        fnotify( enactor, "%sWeapons: %s%sLocked on contact [%s%d%s]:%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_RED, ANSI_MAGENTA,
            planet->locked_target->contact_number, ANSI_RED, ANSI_NORMAL);
        contact_string( writebuf, planet->locked_target, INFO_VERBOSE );
        notify( enactor, writebuf );
    }
    else
    {
        fnotify( enactor, "%sWeapons: %s%sUnlocked%s", ANSI_CYAN, ANSI_HILITE,
            ANSI_GREEN, ANSI_NORMAL );
    }
    if( planet->target_system!=SYSTEM_HULL )
    {
        fnotify( enactor, "%sWeapons currently targetting: %s%s%s%s",
            ANSI_CYAN, ANSI_HILITE, ANSI_GREEN, system_names[planet->target_system], ANSI_NORMAL );
    }
    if( planet->shield_max > 0 && planet->shield_max_charge > 0 )
    {
        fnotify( enactor, "%s%sShields: %d/%d (%d%%) *%s%s*",
            ANSI_HILITE, ANSI_CYAN, planet->shield_level, planet->shield_max,
            100*planet->shield_level/planet->shield_max,
            planet->shield_status==SHLD_UP ? ANSI_GREEN "UP" : ANSI_RED "DOWN",
            ANSI_NORMAL );
    }
    else
    {
        fnotify( enactor, "%s%sShields: none%s", ANSI_HILITE,
            ANSI_CYAN, ANSI_NORMAL );
    }
    return;
}

void planet_target_system( PLANET *planet, dbref enactor, const char *dsystem )
{
    int i=0;

    while( i < NUM_SYSTEMS && !strstr( system_names[i], dsystem ) )
    {
        i++;
    }
    if( i>=NUM_SYSTEMS || i==SYSTEM_HULL || i < 0 )
    {
        fnotify( enactor, "%s%sRandom destruction selected.%s",
            ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
        planet->target_system = SYSTEM_HULL;
        return;
    }
    fnotify( enactor, "%s%sWeapons targetting enemy %s for destruction.%s",
        ANSI_HILITE, ANSI_RED, system_names[i], ANSI_NORMAL );
    planet->target_system = i;
    return;
}

void damage_planet( PLANET *planet, int damage, int wpn )
{
    double population;
    int armies,killed;

    switch( wpn )
    {
        case WPN_GUN:
            damage /= 2;
            break;
    }
    if( planet->shield_status==SHLD_UP && planet->shield_level > 0 )
    {
        if( wpn==WPN_GUN )
        {
            damage *= 0.9;
        }
        if( damage < planet->shield_level )
        {
            planet->shield_level -= damage;
            sprintf( writebuf, "%s%sShields reduced %d - down to %i%%!%s",
                ANSI_HILITE, ANSI_GREEN, damage,
                100*planet->shield_level/planet->shield_max, ANSI_NORMAL );
            notify_room( CONTROL(planet), writebuf );
            damage = 0;
        }
        else
        {
            damage -= planet->shield_level;
            planet->shield_level = 0;
            sprintf( writebuf, "%s%sPlanetary shields have failed!%s",
                ANSI_HILITE, ANSI_RED, ANSI_NORMAL );
            notify_room( CONTROL(planet), writebuf );
            if( wpn==WPN_TORP )
            {
                damage /= 10;
            }
        }
    }
    if( planet->shield_max > 0 && planet->shield_max_charge > 0 )
    {
        if( FRAND < (float)damage / 50000.0 )
        {
            planet->shield_max /= 2;
            planet->shield_max_charge = planet->shield_max / 10;
            sprintf( writebuf, "%s%sPlanetary shields damaged, max capacity reduced to %d.%s",
                ANSI_HILITE, ANSI_RED, planet->shield_max, ANSI_NORMAL );
            notify_room( CONTROL(planet), writebuf );
        }
    }
    population = atof( fetch_attribute( planet->planet_object, "POPULATION" ) );
    armies = atoi( fetch_attribute( planet->planet_object, "ARMIES" ) );
    if( population > damage * 10 * FRAND )
    {
        killed = UMIN( damage * 10 * FRAND , population );
        population -= killed;
        if( killed > 0 )
        {
            sprintf( writebuf, "%s%s%d people killed by bombardment!%s",
                ANSI_HILITE, ANSI_RED, killed, ANSI_NORMAL );
            notify_room( CONTROL(planet), writebuf );
        }
    }
    if( armies > 4 && 25*FRAND < armies/planet->size )
    {
        killed = UMIN( damage / 500, armies );
        armies -= killed;
        if( killed > 0 )
        {
            sprintf( writebuf, "%s%s%d armies destroyed by bombardment!%s",
                ANSI_HILITE, ANSI_RED, killed, ANSI_NORMAL );
            notify_room( CONTROL(planet), writebuf );
        }
    }
    sprintf(writebuf,"%d",planet->shield_max);
    atr_add(planet->planet_object, "SHIELD_POWER", writebuf, (HOWIE), NOTHING );
    sprintf(writebuf,"%.0f",population);
    atr_add(planet->planet_object, "POPULATION", writebuf, (HOWIE), NOTHING );
    sprintf(writebuf,"%d", armies );
    atr_add(planet->planet_object, "ARMIES", writebuf, (HOWIE), NOTHING );
    return;
}

void planet_sensor_checks( void )
{
    SHIP *ship,fake_ship;
    PLANET *planet;

    for(planet=planet_list[current_space];planet!=NULL;planet=planet->next)
    {
        if( planet->sensor_power <= 0 )
        {
            continue;
        }
        for(ship=space_list[current_space];ship!=NULL;ship=ship->next)
        {
            do_planet_sensors( planet, ship, distance(planet->pos,ship->pos) );
        }
        fake_ship = planet_fake_ship( planet );
        kill_stale_contacts( &fake_ship );
        planet->contact_list = fake_ship.contact_list;
        planet->contact_tail = fake_ship.contact_tail;
        bzero( &fake_ship, sizeof(SHIP) );
    }
    return;
}

void do_planet_sensors( PLANET *senser, SHIP *sensee, float range )
{
    float effective_aspect_ratio,prob,aprob,roll;
    int i,new_info_level,found=FALSE;
    CONTACT *contact;
    SHIP fake_ship;

    /* begin by searching for the sensee in senser's contact list */
    fake_ship = planet_fake_ship( senser );
    if( ( contact=find_contact(&fake_ship,sensee) )!=NULL )
    {
        found = TRUE;
    }
    bzero( &fake_ship, sizeof(SHIP) );
    /* calculate probability of aquisition */
    effective_aspect_ratio = sensee->aspect_ratio;

    if( sensee->cloak_status == CLOAK_ON )
    {
        effective_aspect_ratio += (((float)( sensee->num_photons_online )
            * PHOTON_CHARGING_PENALTY ) + ((float)( sensee-> num_phasers_online )
            * PHASER_ONLINE_PENALTY ));
        for( i = 0; i < sensee->number_of_photons; i++ )
        {
            if( sensee->photon[i].status == PHOTON_ARMED )
                effective_aspect_ratio += PHOTON_ARMED_PENALTY;
        }
    }
    else
    {
        /* if target is 'hazy', cut aspect ratio unless cloaked */
        if( sensee->flags[HAZY] )
        {
            effective_aspect_ratio *= 0.3;
        }
    }
    prob = ( 1.0 - ( range / (senser->sensor_power) / effective_aspect_ratio ) );
    /* warp speed adjustment */
    prob += sensee->warp_speed / 50.0;
    /* prior acquisition/lock-on bonus */
    if( contact!=NULL )
    {
        prob += 0.25;
        if( senser->locked_target==contact )
        {
            prob += 0.25;
        }
    }
    /* if the target is invisble, set prob to zero */
    if( sensee->flags[INVISIBLE] )
    {
        prob = 0.0;
    }
    if( contact==NULL && ( sensee->flags[DEADMAN] || ( sensee->orbitting!=NULL
    && !sensee->num_phasers_online && !sensee->num_photons_online && !sensee->bombarding
    && !sensee->pending_lock && !sensee->locked_target && !sensee->tractor_target ) ) )
    {
        if( sensee->orbitting!=NULL && sensee->orbitting->listref!=senser )
        {
            prob = 0.0;
        }
    }
    /* now check for it */
    if( FRAND < prob )
    {
        /* we got him. */
        if( contact==NULL )
        {
            fake_ship = planet_fake_ship( senser );
            if( add_contact( &fake_ship, sensee )==SERR_MALLOC )
            {
                log_space( "JMALLOC failure - contact list for #%d.",
                    senser->planet_object );
                return;
           }
           senser->contact_list = fake_ship.contact_list;
           senser->contact_tail = fake_ship.contact_tail;
           senser->next_contact_number = fake_ship.next_contact_number;
           bzero( &fake_ship, sizeof(SHIP) );
           contact = senser->contact_tail;
        }
        contact->turns_of_contact++;
        contact->turns_since_last_contact = 0;
        contact->last_pos.x = contact->listref->pos.x;
        contact->last_pos.y = contact->listref->pos.y;
        contact->last_pos.z = contact->listref->pos.z;
        if( contact->info_level == 5 )
            return;

        /* Make the information roll */
        prob = (float)( contact->turns_of_contact ) / 20.0;
        roll = FRAND;
        if( senser->flags[OMNISCIENT] || senser->flags[NEARSIGHTED] )
            roll = 0;

        if( roll < prob )
            new_info_level = 5;
        else if( roll < ( prob + .10 ))
            new_info_level = 4;
        else if( roll < ( prob + .20 ))
            new_info_level = 3;
        else if( roll < ( prob + .30 ))
            new_info_level = 2;
        else
            new_info_level = 1;
        if( contact->listref->cloak_status==CLOAK_ON && !senser->flags[OMNISCIENT] )
        {
            if( new_info_level > 3 )
                new_info_level = 3;
        }
        fake_ship = planet_fake_ship( senser );
        if( contact->info_level == 0 )
        {
            contact->info_level = new_info_level;
            display_sensor_info( &fake_ship, contact, fake_ship.helmsman, DSD_NEW );
        }
        else if( new_info_level > contact->info_level )
        {
            contact->info_level = new_info_level;
            display_sensor_info( &fake_ship, contact, fake_ship.helmsman, DSD_UPDATE );
        }
    }
    else
    {
        /* no contact */
        if( contact!=NULL )
        {
            /* increment turns_since_last_contact */
            contact->turns_since_last_contact++;
            if(( contact->listref->cloak_status == CLOAK_ON )
            || ( contact->listref->flags[INVISIBLE] ) || ( prob < 0.0 ))
            {
                contact->stale = TRUE;
            }
            else if( contact->turns_since_last_contact == 3 )
            {
                contact->stale = TRUE;
            }
        }
    }
    return;
}

SHIP planet_fake_ship( PLANET *planet )
{
    SHIP fake_ship;
    int i;

    bzero( &fake_ship, sizeof(SHIP) );
    fake_ship.ship_object = planet->planet_object;
    strncpy( fake_ship.name, planet->name, NAME_LEN-1 );
    strncpy( fake_ship.class, fetch_attribute(planet->planet_object,"CLASS"), NAME_LEN-1 );
    strncpy( fake_ship.type, fetch_attribute(planet->planet_object,"TYPE"), TYPE_LEN-1 );
    fake_ship.contact_list = planet->contact_list;
    fake_ship.contact_tail = planet->contact_tail;
    fake_ship.pos = planet->pos;
    for(i=0;i<MAX_PHOTONS;i++)
    {
        fake_ship.phaser[i] = planet->phaser[i];
        fake_ship.photon[i] = planet->photon[i];
    }
    fake_ship.number_of_phasers = planet->number_of_phasers;
    fake_ship.number_of_photons = planet->number_of_photons;
    fake_ship.torp_max_num_turns_online = planet->photon_max_turns_online;
    fake_ship.locked_target = planet->locked_target;
    fake_ship.target_system = planet->target_system;
    fake_ship.sensor_power = planet->sensor_power;
    fake_ship.helm = planet->console;
    fake_ship.nav = planet->console;
    fake_ship.eng = planet->console;
    fake_ship.damcon = planet->console;
    fake_ship.trans = planet->console;
    fake_ship.comm = planet->console;
    fake_ship.command = planet->console;
    fake_ship.next_contact_number = planet->next_contact_number;
    fake_ship.helmsman = attrib_dbref( planet->console, "XB" );
    fake_ship.navigator = fake_ship.helmsman;
    fake_ship.eng = fake_ship.helmsman;
    fake_ship.comm_officer = fake_ship.helmsman;
    fake_ship.commander = fake_ship.commander;
    fake_ship.trans_dude = fake_ship.helmsman;
    fake_ship.flags[STARBASE] = TRUE;
    fake_ship.flags[INVINCIBLE] = TRUE;
    fake_ship.flags[ISPLANET] = TRUE;
    return fake_ship;
}
