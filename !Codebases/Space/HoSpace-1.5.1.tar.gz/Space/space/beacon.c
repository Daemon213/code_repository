/*
 * $Id: beacon.c,v 1.2 1993/09/24 23:09:41 chuckles Exp chuckles $
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: beacon.c,v $
 * Revision 1.2  1993/09/24  23:09:41  chuckles
 * use jmalloc library.
 *
 * Revision 1.1  1993/09/01  04:22:16  chuckles
 * Initial revision
 *
 * JMS 19 Aug 93 - begin MUSH2.0.p9 port.
 * JMS  2 Jun 93 - cleanup
 * JMS 24 May 93 - separated into beacon.c
 * JMS ?? Sep 92 - original code
 * MRR  3 Apr 97 - Fixed beacons, no longer crash us.
 */


/*
void fun_beacon_cmd( char *buff, char *args[],
                     int nargs, dbref executor, dbref enactor )
*/
FUNCTION(fun_beacon_cmd) 
{
int i;

BEACON *beacon;

  if (!Wizard(executor)) {
    safe_str("#-1 PERMISSION DENIED", buff, bp );
    return;
  }

  /* switch on the argument */
  if( !strcmp( args[0], "activate" ))
  {
    for( i = 0; i < SPACE_LIMIT; i++ ) {
      beacon = beacon_list[i];
      while( beacon != NULL ) {
        if( executor == beacon->beacon_object ) {
          notify( enactor, "This beacon is already activated." );
          return;
        }

        beacon = beacon->next;
      }
    }

    /* okay, we've made it to this point so the beacon in question  *
     * must be inactive so far.  Cool.  Activate it                 */

    if( activate_beacon( executor, enactor ))
      notify( enactor, "Error initializing beacon." );

    return;
  }
  else if( !strcmp( args[0], "deactivate" ))
  {
    for( i = 0; i < SPACE_LIMIT; i++ ) {
      beacon = beacon_list[i];
      while( beacon != NULL ) {
        if( executor == beacon->beacon_object ) {
          current_space = i;
          deactivate_beacon( beacon, enactor );
          return;
        }

        beacon = beacon->next;
      }
    }

    /* okay, we've made it to this point so the beacon in question *
     * must not be active.  Warn and return.                       */

    notify( enactor, "Beacon isn't active." );

    return;
  }
  else if( !strcmp( args[0], "beacon_list" ))
  {
    master_beacon_list( enactor );
  }
  else
    notify( enactor, "Unrecognized beacon_command() call." );

  return;
}


int activate_beacon( dbref executor, dbref enactor )
{
BEACON *new_beacon;
char type_string[80];
char *curspace; 

  if(!(new_beacon=(BEACON *)JMALLOC(sizeof(BEACON))))
    return SERR_MALLOC;

  /* ship space -- this is either real or one of the sim spaces */
  curspace = my_atr_get_raw( executor, "SPACE" ); 
  if( !strcmp( curspace, "real" ))
    current_space = REAL;
  else if( !strcmp( curspace, "1" ))
    current_space = 1;
  else if( !strcmp( curspace, "2" ))
    current_space = 2;
  else if( !strcmp( curspace, "3" ))
    current_space = 3;
  else if( !strcmp( curspace, "4" ))
    current_space = 4;
  else if( !strcmp( curspace, "5" ))
    current_space = 5;
  else if( !strcmp( curspace, "6" ))
    current_space = 6;
  else if( !strcmp( curspace, "7" ))
    current_space = 7;
  else if( !strcmp( curspace, "8" ))
    current_space = 8;
  else if( !strcmp( curspace, "9" ))
    current_space = 9;
  else if( !strncmp( curspace, "10", 2 ))
    current_space = 10;
  else if( !strncmp( curspace, "11", 2 ))
    current_space = 11;
  else
    current_space = SIM;

  new_beacon->beacon_object = executor;
  new_beacon->c1.x = atof( my_atr_get_raw( executor, "VX" ));
  new_beacon->c1.y = atof( my_atr_get_raw( executor, "VY" ));
  new_beacon->c1.z = atof( my_atr_get_raw( executor, "VZ" ));

  new_beacon->c2.x = atof( my_atr_get_raw( executor, "VD" ));
  new_beacon->c2.y = atof( my_atr_get_raw( executor, "VE" ));
  new_beacon->c2.z = atof( my_atr_get_raw( executor, "VF" ));

  new_beacon->s1.bearing = atof( my_atr_get_raw( executor, "VG" ));
  new_beacon->s1.elevation = atof( my_atr_get_raw( executor, "VH" ));
  new_beacon->s1.range = atof( my_atr_get_raw( executor, "RANGE" ));

  new_beacon->s2.bearing = atof( my_atr_get_raw( executor, "VJ" ));
  new_beacon->s2.elevation = atof( my_atr_get_raw( executor, "VK" ));
  new_beacon->s2.range = atof( my_atr_get_raw( executor, "VL" ));

  strncpy( type_string, my_atr_get_raw( executor, "SHAPE" ), 80 );

  if( !strcmp( type_string, "SPHERICAL" ))
    new_beacon->type = BEACON_SPHERICAL;
  else if( !strcmp( type_string, "RECTANGLE" ))
    new_beacon->type = BEACON_RECTANGLE;
  else if( !strcmp( type_string, "CYLINDER" ))
    new_beacon->type = BEACON_CYLINDER;
  else if( !strcmp( type_string, "SHELL" ))
    new_beacon->type = BEACON_SHELL;
  else if( !strcmp( type_string, "ELLIPTICAL" ) )
    new_beacon->type = BEACON_ELLIPTICAL;

  new_beacon->owner = atoi( my_atr_get_raw( executor, "OWNER" ));
  new_beacon->priority = atoi( my_atr_get_raw( executor, "PRIORITY" ));

  strncpy(new_beacon->enter_message,my_atr_get_raw(executor,"ENTER_MESSAGE"),160);
  strncpy(new_beacon->leave_message,my_atr_get_raw(executor,"LEAVE_MESSAGE"),160);

  if( beacon_list[current_space] == NULL ) {
    beacon_list[current_space] = new_beacon;
    beacon_tail[current_space] = new_beacon;
    new_beacon->prev = NULL;
  }
  else {
    beacon_tail[current_space]->next = new_beacon;
    new_beacon->prev = beacon_tail[current_space];
    beacon_tail[current_space] = new_beacon;
  }

  new_beacon->next = NULL;

  /* and that's it for this beacon.  Return */
  fnotify( enactor, "Beacon %s activated in %s space.",
           Name(new_beacon->beacon_object),
           space_names[current_space] );

  return( 0 );
}


void deactivate_beacon( BEACON *beacon, dbref enactor )
{
SHIP *ship;

  /* this is an easy one.  Simply zorch it from the linked list */
  if(( beacon_list[current_space] == beacon ) &&
     ( beacon_tail[current_space] == beacon )) {
    beacon_list[current_space] = NULL;
    beacon_tail[current_space] = NULL;
  }
  else if( beacon_list[current_space] == beacon ) {
    beacon_list[current_space] = beacon_list[current_space]->next;
    beacon_list[current_space]->prev = NULL;
  }
  else if( beacon_tail[current_space] == beacon ) {
    beacon_tail[current_space] = beacon_tail[current_space]->prev;
    beacon_tail[current_space]->next = NULL;
  }
  else {
    beacon->prev->next = beacon->next;
    beacon->next->prev = beacon->prev;
  }

  /* go through and remove it from any beacon lists it may be on */
  ship = space_list[current_space];

  while( ship != NULL ) {
    remove_beacon( ship, beacon );
    ship = ship->next;
  }

  JFREE( beacon );

  notify( enactor, "Beacon is zorched." );

  return;
}


void ship_beacon_checks( SHIP *ship )
{
  BEACON *beacon;
  int in_range, top_priority;

  beacon = beacon_list[current_space];

  top_priority = 0;

  ship->beacon_change = FALSE;

  while( (beacon !=NULL) && (!strcmp(fetch_attribute(ship->ship_object,"UNDOCKED"),"1") ) )
  {
    /* if the beacon would ignore this ship anyway, ignore it */
    if(( beacon->owner ) && ( beacon->owner != ship->owner )) {
      beacon = beacon->next;
      continue;
    }

    /* switch on the type of beacon.  Each way is a different check */
    in_range = FALSE;

    switch( beacon->type ) {
      case BEACON_SPHERICAL:
        if( beacon->s1.range > ( distance( ship->pos, beacon->c1 )))
        in_range = TRUE;
        break;
      case BEACON_RECTANGLE:
        if(( beacon->c1.x < ship->pos.x ) && ( ship->pos.x < beacon->c2.x ) &&
           ( beacon->c1.y < ship->pos.y ) && ( ship->pos.x < beacon->c2.y ) &&
           ( beacon->c1.z < ship->pos.z ) && ( ship->pos.x < beacon->c2.z ))
          in_range = TRUE;
        break;
      case BEACON_CYLINDER:
        break;
      case BEACON_SHELL:
        if( distance(ship->pos,beacon->c1) < beacon->s1.range
        && distance(ship->pos,beacon->c1) > beacon->s2.range )
           in_range = TRUE;
        break;
      case BEACON_ELLIPTICAL:
          if( distance(ship->pos,beacon->c1)+distance(ship->pos,beacon->c2) <= beacon->s1.range )
          {
              in_range = TRUE;
          }
          break;
      default:
        break;
    }

    if( in_range )
      add_beacon( ship, beacon );
    else
      remove_beacon( ship, beacon );

    beacon = beacon->next;
  }
  return;
}


void add_beacon( SHIP *ship, BEACON *beacon )
{
    struct beacon_contact *contact;
    int top_priority = 0;
    CHAN *chan=NULL;


    /* go home if it's already on the list */
    /* take the top priority while we're at it */
    contact = ship->beacon_list;

    while( contact != NULL )
    {
        if( contact->listref == beacon )
            return;

        if( contact->listref->priority > top_priority )
            top_priority = contact->listref->priority;

        contact = contact->next;
    }

    /* allocate memory for the contact and the planet name. */
    if(( contact=(struct beacon_contact *)JMALLOC(sizeof( struct beacon_contact )))==NULL )
        return;

    /* okay, the beacon isn't on our list.  Add it. */
    contact->listref = beacon;

    if( ship->beacon_list == NULL )
    {   /* empty list */
        ship->beacon_list = contact;
        ship->beacon_tail = contact;
        contact->prev = NULL;
        contact->next = NULL;
    }
    else
    {
        ship->beacon_tail->next = contact;
        contact->prev = ship->beacon_tail;
        contact->next = NULL;
        ship->beacon_tail = contact;
    }
    /* if the priority of the new beacon is such that we'll now see it, *
     * set the change flag.                                             */
    if( beacon->priority >= top_priority )
    {
        ship->beacon_change = TRUE;
        notify_room(BRIDGE(ship), beacon->enter_message);
        /* Howie addition, report IC sensor crossings */
   
        find_channel("HoSpace_Net", &chan);
        channel_broadcast( chan, HOWIE, 0, "%s<HoSpace_Net> %s has entered %s",
ANSI_HILITE, ship->name, db[beacon->beacon_object].name, ANSI_NORMAL);
    }
    return;
}


void remove_beacon( SHIP *ship, BEACON *beacon )
{
    struct beacon_contact *contact, *found = NULL;
    int top_priority = 0;
    CHAN *chan;

    /* find the offending beacon and figure the top priority for our ship */
    contact = ship->beacon_list;

    while( contact != NULL )
    {
        if( contact->listref->priority > top_priority )
        top_priority = contact->listref->priority;

        if( contact->listref == beacon )
            found = contact;

        contact = contact->next;
    }
    /* Thus endeth the search.  Now go home if we didn't find him. */
    if( found == NULL )
        return;

    /* We see the beacon.  Update beacon_change if neccesary, then remove it. */
    if( beacon->priority >= top_priority )
        ship->beacon_change = TRUE;

    if( ship->beacon_list == ship->beacon_tail )
    {
        ship->beacon_list = NULL;
        ship->beacon_tail = NULL;
    }
    else if( found == ship->beacon_list )
    {
        ship->beacon_list = found->next;
        ship->beacon_list->prev=NULL;
    }
    else if( found == ship->beacon_tail )
    {
        ship->beacon_tail = found->prev;
        ship->beacon_tail->next = NULL;
    }
    else if( found!=ship->beacon_list && found!=ship->beacon_tail )
    {
        (found->prev)->next = found->next;
        (found->next)->prev = found->prev;
    }
    JFREE( contact );

    /* Inform bridge of outgoing beacon message */
    if( beacon->priority >= top_priority )
    {
        notify_room(BRIDGE(ship),beacon->leave_message);
          
        /* Code for Howie's IC channel */
        find_channel("HoSpace_Net", &chan);
        channel_broadcast( chan, HOWIE, 0, "%s<HoSpace_Net> %s has left %s %s", ANSI_HILITE, ship->name, db[beacon->beacon_object].name, ANSI_NORMAL);
    }
    return;
}


void beacon_checks( void )
{
  SHIP *ship;

  for( ship = space_list[current_space]; ship != NULL; ship = ship->next )
    ship_beacon_checks( ship );

  return;
}


void master_beacon_list( dbref enactor )
{
  BEACON *beacon;

  for( current_space = 0; current_space < SPACE_LIMIT; current_space++ ) {
    beacon = beacon_list[current_space];

    if( beacon == NULL ) {
      fnotify( enactor, "No beacons in %s space.", space_names[current_space] );
    }
    else {
      fnotify( enactor, "Beacon list for %s space.", space_names[current_space] );
    }

    while( beacon != NULL ) {
      fnotify( enactor, "%s -- %s", Name(beacon->beacon_object),
                beacon->enter_message );

      beacon = beacon->next;
    }

    notify( enactor, "" );

  }

  return;
}


void list_beacons( SHIP *ship, dbref enactor )
{
  struct beacon_contact *contact;
  int top_priority = 0;

  if( ship->beacon_list == NULL ) {
    notify( enactor, "No beacons detected." );
    return;
  }

  /* prelim loop.  find the highest priority beacon */
  for( contact = ship->beacon_list; contact != NULL;
       contact = contact->next ) {
    if( contact->listref->priority > top_priority )
      top_priority = contact->listref->priority;
  }

  /* loop again displaying the messages from any that match top_priority */
  for( contact = ship->beacon_list; contact != NULL;
       contact = contact->next ) {
    if( contact->listref->priority == top_priority )
      notify( enactor, my_atr_get_raw( contact->listref->beacon_object, "DESCRIBE" ));
  }
}
