/*
 *      EVAL.C
 *
 *  Arithmetic expression evaluator
 *
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * JMS 4 Aug 93 - Started
 *
 *.Last mod - 8/6/93 19:09
 */


#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "jmalloc.h"
#include "eval.h"
#include "eval.i"

int eval_initialized = FALSE;
UNIT *units;
unsigned int allocated_units, used_units;


/*
 * eval_initialize
 *
 *  purpose:
 *    initializes the evaluator.
 *
 * JMS 4 Aug 93 - created
 */

void eval_initialize( void )
{
  if( eval_initialized )
    return;

  eval_initialized = TRUE;
  units = (UNIT *)JMALLOC( NUM_UNITS * sizeof( UNIT ));
  allocated_units = NUM_UNITS;
  used_units = 0;
  return;
}


/*
 * arith_eval
 *
 *  input:
 *    char *string           String to evaluate
 *
 *  purpose:
 *    evaluates string arithmetically.  Note that the string can contain
 *    only numbers and operators.  All token matching should be done
 *    BEFORE this function is called.  Text tokens that make it here will
 *    evaluate as zeros.
 *
 *  output:
 *    an integer equivalent
 *
 * JMS 4 Aug 93 - created, barely.  very stupid at this point.
 */

int arith_eval( char *string )
{
int val = 0;       /* by default */

  /* initialize if this is the very first call */
  if( !eval_initialized )
    eval_initialize();

  /* convert the input string to a series of units */
  if( string_to_units( string ) == BAD_EXPRESSION )
    return 0;

  /* now evaluate the unit chain */
  val = evaluate_unit_chain( 0 );

  return( val );
}


/*
 * string_to_units
 *
 *  input:
 *    char *string           String to convert.
 *
 *  purpose:
 *    converts a character string to a series of arithmetic units.
 *
 *  returns:
 *    zero if successful, or an error code if not.
 *
 * JMS 4 Aug 93 - created
 */

int string_to_units( char *string )
{
unsigned int i, j;
char unit_string[UNIT_SIZE];

  j = 0;
  used_units = 1;
  units[0].val = 0;
  units[0].operator = E_LPARENS;

  for( i = 0; i <= strlen( string ); i++ ) {
    unit_string[j++] = string[i];

    if(( char_state( string[i+1] ) != char_state( string[i] )) ||
       ( char_state( string[i+1] ) == IN_OPERATOR )) {
      /* we've reached the end of a unit */                                                      
      unit_string[j] = '\0';

      switch( char_state( unit_string[0] )) {
	case END_OF_LINE:
	  break;
	case IN_BAD:
	  return BAD_EXPRESSION;
	case IN_SPACE:
	  break;
	case IN_NUM:
	  used_units++;
	  if( used_units >= allocated_units )
	    allocate_more_units();
	  units[used_units-1].val = atoi( unit_string );
	  units[used_units-1].operator = E_NONE;
	  break;
	case IN_OPERATOR:
	  used_units++;
	  if( used_units >= allocated_units )
	    allocate_more_units();
	  units[used_units-1].val = 0;
	  units[used_units-1].operator = match_opcode( unit_string );
	  break;
	default:
	  /* very bad. */
	  assert( FALSE );
	  break;
      }

      j = 0;
    }
  }

  used_units++;
  if( used_units >= allocated_units )
    allocate_more_units();
  units[used_units-1].val = 0;
  units[used_units-1].operator = E_RPARENS;
  return NO_ERROR;
}


/*
 * char_state
 *
 *  input:
 *    char ch                character to evaluate
 *
 *  purpose:
 *    identifies the kind of character
 *
 *  returns:
 *    IN_BAD, IN_SPACE, IN_NUM, or IN_OPERATOR.
 *
 * JMS 4 Aug 93 - created
 */

int char_state( char ch )
{
  if( ch == '\0' )
    return END_OF_LINE;

  if( isspace( ch ))
    return IN_SPACE;

  if( isdigit( ch ))
    return( IN_NUM );

  switch( ch ) {
    case '+':  case '-':
    case '*':  case '/':
    case '(':  case ')':
      return IN_OPERATOR;
    default:
      break;
  }

  return IN_BAD;
} 


/* 
 * allocate_more_units
 *
 *  purpose:
 *    lengthens the unit chain.
 *
 * JMS 4 Aug 93 - created
 */

void allocate_more_units( void )
{
  allocated_units += ALLOC_UNITS;

  units = (UNIT *)realloc( units, allocated_units * sizeof( UNIT ));
}


/*
 * match_opcode
 *
 *  input:
 *    char *string           string to match
 *
 *  purpose:
 *    string should be some kind of operator.  function figures out which
 *    one it is.
 *
 *  returns:
 *    an operator identifier, #defined in eval.i.
 *
 * JMS 4 Aug 93 - created
 */

int match_opcode( char *string )
{
  switch( string[0] ) {
    case '+':
      return E_ADD;
    case '-':
      return E_SUBTRACT;
    case '*':
      return E_MULTIPLY;
    case '/':
      return E_DIVIDE;
    case '(':
      return E_LPARENS;
    case ')':
      return E_RPARENS;
    default:
      return E_BAD;
  }
}


/*
 * evaluate_unit_chain
 *
 *  input:
 *    int start              index of unit from which to start
 *
 *  purpose:
 *    evaluates the current unit chain
 *
 *  returns:
 *    a duck.
 *
 * JMS 4 Aug 93 - created
 */

int evaluate_unit_chain( int start )
{
int index;

  /* step through the unit chain and recurse any time we hit a
   * left parens, until we hit a right parens.
   */
  for( index = start+1; units[index].operator != E_RPARENS; index++ ) {
    if( units[index].operator == E_LPARENS )
      evaluate_unit_chain( index );
  }

  /* alright, we've cleared out any parens inside our domain.  now
   * evaluate what's left
   */

  /* multiply and divide */
  for( index = start+1; units[index].operator != E_RPARENS; index++ ) {
    if( units[index].operator == E_MULTIPLY ) {
      units[index-1].val *= units[index+1].val;
      delete_unit( index );
      delete_unit( index );
      index--;
    }
    if( units[index].operator == E_DIVIDE ) {
      units[index-1].val /= units[index+1].val;
      delete_unit( index );
      delete_unit( index );
      index--;
    }
  }

  /* add and subtract */
  for( index = start+1; units[index].operator != E_RPARENS; index++ ) {
    if( units[index].operator == E_ADD ) {
      units[index-1].val += units[index+1].val;
      delete_unit( index );
      delete_unit( index );
      index--;
    }
    if( units[index].operator == E_SUBTRACT ) {
      units[index-1].val -= units[index+1].val;
      delete_unit( index );
      delete_unit( index );
      index--;
    }
  }

  /* kill off our parentheses */
  delete_unit( start );
  delete_unit( start+1 );

  return( units[start].val );
}


/*
 * delete_unit
 *
 *  input:
 *    int index              position of unit to kill
 *
 *  purpose:
 *    removes the specified unit from the list, the shuffles the rest
 *    down to fill the space.
 *
 * JMS 4 Aug 93 - created
 */

void delete_unit( int index )
{
unsigned int i;

  for( i = index; i < ( used_units - 1 ); i++ )
    units[i] = units[i+1];

  used_units--;

  return;
}
