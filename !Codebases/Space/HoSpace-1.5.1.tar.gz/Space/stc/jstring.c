/*
 *      JSTRING.C
 *
 *  My special string operations.
 *
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * JMS ?? Nov 92 - started
 *
 *.Last mod - 8/6/93 19:09
 */

#include <ctype.h>
#include <string.h>
#include <stdlib.h>

#include "jstring.h"


/***********************************
 *
 * insertchar() :
 *
 *  arguments:
 *    char *string     The string to be modified.
 *    char c           The character to be inserted.
 *    int n            The position at which to insert c.
 *
 *  function:
 *    inserts character c at position n in *string.
 *
 *  returns:
 *    a pointer to the amended string.
 *
 *  note:  *string must already be big enough to hold another
 *         character.  No checking is performed.
 *
 ***********************************/

char *insertchar( char *string, char c, int n )
{
  int i;

  for( i = 1 + strlen( string ); i > n; i-- )
    string[i] = string[i-1];

  string[n] = c;

  return( string );
}


/***********************************
 *
 * deletechar()
 *
 *  arguments:
 *    char *string         string to be modified
 *    int n                index of character to be deleted
 *
 *  function:
 *    deletes from *string the character at position n.
 *
 *  return value:
 *    a pointer to the modified string
 *
 ***********************************/

char *deletechar( char *string, int n )
{
unsigned int i;

  for( i = n; i < strlen( string ); i++ )
    string[i] = string[i+1];

  return( string );
}


/***********************************
 *
 * decapitate()
 *
 *  arguments:
 *    char *string          string to be modified
 *
 *  function:
 *    converts all characters in *string to lowercase
 *
 *  return value:
 *    a pointer to the modified string
 *
 ***********************************/

char *decapitate( char *string )
{
unsigned int i;

  for( i = 0; i < strlen( string ); i++ )
    string[i] = (char)tolower( string[i] );

  return( string );
}


/***********************************
 *
 * strcasestr()
 *
 *  arguments:
 *    char *string, *string2     strings to be compared
 *
 *  function:
 *    case-insensitive strstr()
 *
 *  returns:
 *    a pointer to the first incidence of string2 in string1
 *
 ***********************************/

char *strcasestr( char *string1, char *string2 )
{
char copy1[80], copy2[80];
char *index;

  strncpy( copy1, string1, 79 );
  strncpy( copy2, string2, 79 );

  copy1[79] = '\0';
  copy2[79] = '\0';

  decapitate( copy1 );
  decapitate( copy2 );

  index = strstr( copy1, copy2 );

  if( !index )
    return( NULL );

  return( &string1[(int)(index - copy1)] );

}

/*
 * trim_leading_whitespace()
 *
 *  input:
 *    char *string                     string to be trimmed
 *
 *  purpose:
 *    removes all leading whitespace
 *
 *  returns:
 *    a pointer to the modified string
 *
 * JMS 2 Aug 93
 */

char *trim_leading_whitespace( char *string )
{
  while( isspace( string[0] ))
    string = deletechar( string, 0 );

  return( string );
}

/*
 * trim_trailing_whitespace()
 *
 *  input:
 *    char *string                     string to be trimmed
 *
 *  purpose:
 *    removes all trailing whitespace
 *
 *  returns:
 *    a pointer to the modified string
 *
 * JMS 2 Aug 93
 */

char *trim_trailing_whitespace( char *string )
{
  if( strlen( string )) {
    while( isspace( string[strlen(string) - 1] ))
      string = deletechar( string, ( strlen( string ) -1 ));
  }

  return( string );
}

char *one_argument( char *argument, char *arg_first )
{
    char cEnd;

    while ( isspace(*argument) )
	argument++;

    cEnd = ' ';
    if ( *argument == '\'' || *argument == '"' )
	cEnd = *argument++;

    while ( *argument != '\0' )
    {
	if ( *argument == cEnd )
	{
	    argument++;
	    break;
	}
        if( arg_first!=NULL )
        {
            *arg_first = *argument;
            arg_first++;
        }
	argument++;
    }
    if( arg_first!=NULL )
    {
        *arg_first = '\0';
    }
    while ( isspace(*argument) )
	argument++;

    return argument;
}
