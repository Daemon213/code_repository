/*
 * TOKEN.C
 *
 *  Routines for defining, undefining, and looking up tokens.
 *
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * JMS 2 Aug 93 - started
 *
 *.Last mod - 8/6/93 19:17
 */

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "jmalloc.h"
#include "token.h"
#include "token.i"
#include "jstring.h"


TOKEN *tokens;
unsigned int num_tokens;
unsigned int allocated_tokens;


/*
 * initialize_tokens
 *
 *  Initializes the token array.
 *
 * JMS 2 Aug 93
 */

int initialize_tokens( void )
{
  if(( tokens = (TOKEN *)JMALLOC( NUM_TOKENS * sizeof( TOKEN ))) == NULL )
    return FALSE;

  allocated_tokens = NUM_TOKENS;
  num_tokens = 0;

  return TRUE;
}


/*
 * lookup_token
 *
 *  input:
 *    char *name             Token name to search for
 *
 *  purpose:
 *    searches the token array for the input token name.
 *
 *  returns:
 *    a pointer to the match of the token if found, NULL if not found.
 *
 *  note:  The return val points to a statis local variable here. Don't
 *         try to free it, and note that it will last only until the next
 *         time this function is called, so make your own copy of the
 *         string if you want to hang on to it for any length of time.
 *
 * JMS 2 Aug 93
 */

char *lookup_token( char *intoken )
{
unsigned int i;
char result[EQUIV_SIZE];

  for( i = 0; i < num_tokens; i++ ) {
    if( !strcmp( intoken, tokens[i].match )) {
      strcpy( result, tokens[i].equiv );
      return( result );
    }
  }

  return NULL;
}


/*
 * define_token
 *
 *  input:
 *    char *match            Token name
 *    char *equiv            text to be substituted
 *
 *  purpose:
 *    defines a token matching the input paramaters.
 *
 *  returns:
 *    TKE_FAIL          failure
 *    TKE_REDEF         redefinition of existing token
 *    TKE_OKAY          no problem
 *
 * JMS 2 Aug 93
 */

int define_token( char *match, char *equiv )
{
TOKEN *new_block;

  /* check for an existing token */
  if( lookup_token( match ) != NULL ) {
    undefine_token( match );

    switch( define_token( match, equiv )) {
      case TKE_FAIL:
        return TKE_FAIL;
      case TKE_OKAY:
        return TKE_REDEF;
      default:
        return TKE_FAIL;
    }
  }

  /* token doesn't already exist */

  /* enlarge array if we need to */
  if( num_tokens == allocated_tokens ) {
    new_block = (TOKEN *)realloc( tokens, (( allocated_tokens + BLOCK_SIZE)
                                          * sizeof( TOKEN )));
    if( new_block == NULL )
      return TKE_FAIL;

    tokens = new_block;
  }

  strncpy( tokens[num_tokens].match, match, MATCH_SIZE );
  strncpy( tokens[num_tokens].equiv, equiv, EQUIV_SIZE );
  num_tokens++;

  return TKE_OKAY;
}


/*
 * undefine_token
 *
 *  input:
 *    char *match            Token name
 *
 *  purpose:
 *    undefines any tokens matching the input paramaters.
 *
 * JMS 2 Aug 93
 */

int undefine_token( char *match )
{
unsigned int i;
  if( !lookup_token( match ))
    return TKE_FAIL;

  /* it exists.  find it */
  for( i = 0; strcmp( match, tokens[i].match ); i++ );

  /* found.  kill */
  for( ; i < ( num_tokens - 1); i++ )
    tokens[i] = tokens[i+1];

  num_tokens--;

  return TKE_OKAY;
}


/*
 * substitute_tokens
 *
 *  input:
 *    char *string           The string upon which token substitutuion
 *                           is to be performed.
 *
 *  purpose:
 *    finds any tokens in instring and replaces them with their equivs.
 *
 *  returns:
 *    a pointer to the modified string.
 *
 *  note:
 *    no reallocation is performed on the original string.  It had better
 *    be big enough to hold the expanded tokens.
 *
 * JMS 3 Aug 93
 */

char *substitute_tokens( char *string )
{
char *substring;
char match[161], equiv[EQUIV_SIZE];
int i, j;
int start, end;


  /* "clock, scan for tokens */
  /* the loop is <= string because we may need that terminating null to
   * also serve as an end_of_token character.
   */

  start = -1;
  end = -1;

  for( i = 0; i <= (int)strlen( string ); i++ ) {
    if( is_token_char( string[i] )) {
      /* it's a token character */
      if(( start != -1 )) {
        /* we're still inside the potential token.  keep going. */
      }
      else {
        /* this is the beginning of a new potential token */
        start = i;
      }
    }
    else {
      /* it's not a token character */
      if(( start != -1 )) {
        /* this is the end of a potential token */
        end = i;
        for( j = start; j < end; j++ )
          match[j-start] = string[j];

        match[j-start] = '\0';

        /* we've constructed a copy.  now do a lookup */
        substring = lookup_token( match );

        if( substring ) {
          /* found a match */
          strcpy( equiv, substring );

          /* delete the match part */
          for( j = 0; j < (int)strlen( match ); j++ )
            deletechar( string, start );

          /* insert the token */
          for( j = 0; j < (int)strlen( equiv ); j++ )
            insertchar( string, equiv[j], start + j );
        }

        start = -1;
        end = -1;

      }
      else {
        /* we're still outside any potential token.  keep going */
      }
    }
  }

  return( string );
}

/*
 * is_token_char
 *
 *  input:
 *    char inchar            The character to be tested.
 *
 *  purpose:
 *    determines whether or not the character is a valid token character.
 *
 *  returns:
 *    TRUE if it is, FALSE if it's not.
 *
 * JMS 3 Aug 93
 */

int is_token_char( char inchar )
{
  return(( isalpha( inchar )) || ( isdigit( inchar )) || ( inchar == '_' ));
}
