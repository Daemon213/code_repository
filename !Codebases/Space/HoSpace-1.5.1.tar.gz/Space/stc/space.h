/*
 * space.h  -- Created 21 July 1992
 *
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#define USE_CSPACE /* */

#ifdef USE_CSPACE
#define FALSE 0
#define TRUE  -1
#define penn1 mikerocks
/* location of template files */
#define TEMPLATE_DIRECTORY        "../src/specs"
#define TEMPLATE_EXTENDER        ".bct"
#define VERSION_CHAR        	5	/* template compat thing */

/* Define cool options */
#define WARP_IMPULSE     1

/* debugging stuff */
/* #define SENSOR_DEBUG      1 */
#define DEBUG_CHAR        694

/* number of lbufs that fetch_attribute should keep track of */
#define FETCH_LBUFS        4

/* space error codes */
#define SERR_MALLOC       1
#define SERR_NOT_FOUND    2
#define SERR_BAD_SHIP_OBJ 3

/* battery status values */
#define BTTY_OFFLINE        '0'
#define BTTY_ONLINE        '1'
#define BTTY_DAMAGED        '2'
#define BTTY_NONE       '3'

/* shield status values */
#define SHLD_BASE    '0'
#define SHLD_READY   '0'
#define SHLD_UP            '1'
#define SHLD_DAMAGED        '2'

#define SHLD_STABLE           3
#define SHLD_CHARGING        4
#define SHLD_FALLING           5
#define SHLD_OVERLOADED 6

/* shield indices */
#define FORE_SHIELD            0
#define AFT_SHIELD            1
#define PORT_SHIELD            2
#define STARBOARD_SHIELD 3

/* cloak status values */
#define CLOAK_NONE  '0'
#define CLOAK_OFF   '1'
#define CLOAK_ON    '2'

/* display_ship_data control words */
#define DSD_NEW      0
#define DSD_UPDATE   1
#define DSD_ROUTINE  2
#define DSD_DETAILED 3
#define DSD_UPDATE2  4

/* photon tube status values */
#define PHOTON_EMPTY        0
#define PHOTON_LOADED        1
#define PHOTON_ONLINE        2
#define PHOTON_ARMED    3
#define PHOTON_DAMAGED        4

/* photon performance specs */
/* jms 24 may 93 - think about moving these to the ship template for        *
 * extra configurability.                                            */
#define NO_RELOAD      -1

#define FIRE_ALL        41
#define ARM_ALL        	41

#define TIMER_RESET     300

/* phaser status values */
#define PHASER_ONLINE   0
#define PHASER_OFFLINE        1
#define PHASER_DAMAGED  4

#define SPACE_LOCKED        0
#define SPACE_UNLOCKED        1 

#define INFO_VERBOSE         0
#define INFO_TERSE        1

/* comm stuff */
#define MAX_CHANNEL     6

#define CR_COMM_ONLY        0
#define CR_BRIDGE_AUDIO 1
#define CR_ON_SCREEN        2

#define CS_COMM_ONLY        0
#define CS_BRIDGE_AUDIO 1
#define CS_VISUALS        2

#define MSG_AUDIO  0
#define MSG_VISUAL 1

#define SS_SCAN   0
#define SS_REPORT 1

#define MODE_HOLD    0
#define MODE_TRACTOR 1
#define MODE_PRESSOR 2
#define MODE_DET     3

#define ARMR_ABLT    0
#define ARMR_PLATE   1

#define IDICT_NONE   0
#define IDICT_OFF    1
#define IDICT_ON     2
#define IDICT_BROKEN 3

/* owner identifiers */
/* Are these actually used? - JMS 5/24/93 */
/* At this point, it's HoSpace and I never use them, they just take up room.  - Howie: howie69@hotmail.com*/
#define RACE_UNKNOWN 0
#define RACE_FED     1
#define RACE_ROM     2
#define RACE_KLING   3
#define RACE_FNGI    4
#define RACE_GORN    5
#define RACE_INDIE   6
#define RACE_CARD    7
#define RAGE_GOOF    3.14

/* docking bay doors stuff */
#define DOORS_NONE  -1
#define DOORS_CLOSED 0
#define DOORS_OPEN   1

/* beacon types */
#define BEACON_SPHERICAL  0
#define BEACON_RECTANGLE  1
#define BEACON_SHELL          2
#define BEACON_CYLINDER   3
#define BEACON_ELLIPTICAL 4

/* ship system identifiers */
#define SYSTEM_SHIELD_FORE      0
#define SYSTEM_SHIELD_AFT       1
#define SYSTEM_SHIELD_PORT      2
#define SYSTEM_SHIELD_STARBOARD 3
#define SYSTEM_GUN_0            4
#define SYSTEM_GUN_1            5
#define SYSTEM_GUN_2            6
#define SYSTEM_GUN_3            7
#define SYSTEM_GUN_4            8
#define SYSTEM_GUN_5            9
#define SYSTEM_GUN_6            10
#define SYSTEM_GUN_7            11
#define SYSTEM_GUN_8            12
#define SYSTEM_GUN_9            13
#define SYSTEM_GUN_10           14
#define SYSTEM_GUN_11           15
#define SYSTEM_GUN_12           16
#define SYSTEM_GUN_13           17
#define SYSTEM_GUN_14           18
#define SYSTEM_GUN_15           19
#define SYSTEM_GUN_16           20
#define SYSTEM_GUN_17           21
#define SYSTEM_GUN_18           22
#define SYSTEM_GUN_19           23
#define SYSTEM_TORP_0           24
#define SYSTEM_TORP_1           25
#define SYSTEM_TORP_2           26
#define SYSTEM_TORP_3           27
#define SYSTEM_TORP_4           28
#define SYSTEM_TORP_5           29
#define SYSTEM_TORP_6           30
#define SYSTEM_TORP_7           31
#define SYSTEM_TORP_8           32
#define SYSTEM_TORP_9           33
#define SYSTEM_TORP_10          34
#define SYSTEM_TORP_11          35
#define SYSTEM_TORP_12          36
#define SYSTEM_TORP_13          37
#define SYSTEM_TORP_14          38
#define SYSTEM_TORP_15          39
#define SYSTEM_TORP_16          40
#define SYSTEM_TORP_17          41
#define SYSTEM_TORP_18          42
#define SYSTEM_TORP_19          43
#define SYSTEM_BATTERIES        44
#define SYSTEM_CLOAK            45
#define SYSTEM_WARP             46
#define SYSTEM_ENGINE           47
#define SYSTEM_CRYSTAL          48
#define SYSTEM_SENSORS          49
#define SYSTEM_SCANNERS         50
#define SYSTEM_HULL             51
#define SYSTEM_TRACTOR          52
#define SYSTEM_PAINT_JOB        53
#define SYSTEM_TARGETTING       54
#define SYSTEM_LANDING_GEAR     55
#define SYSTEM_TRANSWARP        56
#define SYSTEM_DISSIPATOR       57
#define SYSTEM_AUX_SENSORS      58
#define SYSTEM_TRANSPORTERS     59
#define SYSTEM_IMPULSE          60
#define SYSTEM_THRUSTER         61
#define SYSTEM_PLASMASHIELDS    62
#define NUM_SYSTEMS             63

/* ship max damage control teams */
#define MAX_TEAMS 16

/* ship status flag array indices */
#define STARBASE       0     /* is a starbase */
#define INVISIBLE      1     /* can't be seen at all */
#define INVINCIBLE     2     /* weapons don't hurt */
#define SPEEDY         3     /* any allowed warp is free */
#define OMNISCIENT     4     /* infinite power sensors */
#define NEARSIGHTED    5     /* sees all, but only to extent of base range */
#define POKEY          6     /* warp costs double */
#define NAKED          7     /* no shields */
#define BLIND               8     /* can't see */
#define CATARACTS      9     /* sensor range cut to 30% */
#define HAZY              10     /* aspect ratio cut to 30% */
#define DISABLED      11     /* can't do squat */
#define PINNED              12     /* can't move */
#define PACIFIST      13     /* can't shoot */
#define SHUTTLECRAFT  14     /* can dock at starships */
#define ISPLANET      15     /* it's a planet */
#define DEADMAN       16     /* deadmanned ship */
#define NUM_FLAGS     17


static char *flag_names[] =
{ 
    (char *)"starbase", 
    (char *)"invisible", 
    (char *)"invincible", 
    (char *)"speedy",
    (char *)"omniscient", 
    (char *)"nearsighted", 
    (char *)"pokey", 
    (char *)"naked",
    (char *)"blind", 
    (char *)"cataracts", 
    (char *)"hazy", 
    (char *)"disabled",
    (char *)"pinned", 
    (char *)"pacifist",
    (char *)"shuttlecraft",
    (char *)"isplanet",
    (char *)"deadman"
};

/* identifies the source of a watch */
#define W_NOBODY        0
#define W_HELM          1
#define W_NAV           2
#define W_ALL           W_HELM | W_NAV

/* sensor penalties for cloaked ships */
#define PHASER_ONLINE_PENALTY   0.05
#define PHOTON_CHARGING_PENALTY 0.15
#define PHOTON_ARMED_PENALTY    0.30

/* miscellaneous configurable paramaters */
#define DOCK_RANGE        	5	/* how close to starbase must you be */
#define BATTERY_BLEED        	0.995	/* % of btty lost per turn online */
#if defined(TNG_SHIELDS)
#define SHLD_READY_BLEED        1.00    /* loss on ready shields */
#define SHLD_UP_BLEED           0.99    /* loss on raised shields */
#else
#define SHLD_READY_BLEED        0.99    /* loss on ready shields */
#define SHLD_UP_BLEED        	0.90    /* loss on raised shields */
#endif
#if defined(WARP_IMPULSE)
#define LIGHTSPEED              500.0
#define WARP_CONST              290.0
#else
#define WARP_CONST              290.0
#endif

/* ship text field sizes - JMS 23 Aug 93 */
#define NAME_LEN        32
#define CLASS_LEN       32
#define TYPE_LEN        32
#define SHORT_TYPE_LEN  4
#define OWNER_LEN       32

/* sensor net stuff */
#define MAX_SNETCLIENTS        	9
#define SNS_OFF        		0
#define SNS_PENDING        	1
#define SNS_ON        		2

#define TS_TIMEOUT        	0
#define TS_CUT_BY_CLIENT        1
#define TS_CUT_BY_SERVER        2
#define TS_INTERRUPTED        	3

#define TN_NONE        		0x00
#define TN_CLIENT        	0x01
#define TN_SERVER        	0x02
#define TN_BOTH        		TN_CLIENT | TN_SERVER

/* smart power stuff */
#define POWER_CLEANUP           -1
#define POWER_HELM_GUNS         0
#define POWER_HELM_TORPS        1
#define POWER_HELM_TRACTOR      2
#define POWER_NAV_WARP          3
#define POWER_NAV_SHIELD        4
#define POWER_NAV_SHIELD_FORE   (POWER_NAV_SHIELD)
#define POWER_NAV_SHIELD_AFT    (POWER_NAV_SHIELD + 1)
#define POWER_NAV_SHIELD_PORT   (POWER_NAV_SHIELD + 2)
#define POWER_NAV_SHIELD_STAR   (POWER_NAV_SHIELD + 3)
#define POWER_ENG_BATTS         8

/* forward-declarations */
typedef struct beacon_entry BEACON;
typedef struct contact_entry CONTACT;

/* cartesian coordinate struct */
typedef struct xyz_coord
{
    float x;
    float y;
    float z;
} XYZ;

/* sperical coordinate struct */
#include "howie.h"

typedef struct weapon_info_data WDATA;
struct weapon_info_data
{
    int type;
    float sfactor;
    float hfactor;
    float carryover;
    int taps;
};

struct phaser_entry
{
    char label[30];
    ARC wpn_arc;
    int range;
    int power;
    float range_percent;  /* deliverable percent at max range */
    int charge;
    int old_charge;
    int status;
    int charge_per_turn;
    float reliability;
    WDATA wpn_data;
};

struct photon_entry
{
    char label[30];
    ARC wpn_arc;
    int range;
    float base_accuracy;
    int power;
    int charge;
    int turns_charged;
    int status;
    int charge_per_turn;
    float reliability;
    WDATA wpn_data;
};

struct seeker_entry
{
    char label[30];
    ARC wpn_arc;
    int range;
    int power;
    int charge;
    int turns_charged;
    int status;
    int charge_per_turn;
    float reliability;
    WDATA wpn_data;
};

/* planet entry in linked list */
typedef struct planet_entry PLANET;
struct planet_entry
{
    dbref planet_object;
    char name[NAME_LEN];
    XYZ pos;
    float size;
    float transporter_range;
    PLANET *prev;
    PLANET *next;
    char flags[3];

    /* battle data */
    dbref console;
    int number_of_photons;
    int number_of_phasers;
    char phaser_string[80];
    char photon_string[80];
    char seeker_string[80];
    struct phaser_entry phaser[MAX_PHASERS];
    struct photon_entry photon[MAX_PHOTONS];
    struct seeker_entry seeker[MAX_SEEKERS];
    int photon_max_turns_online;
    int num_photons_online;

    int sensor_power;
    CONTACT *contact_list;
    CONTACT *contact_tail;
    int next_contact_number;
    CONTACT *locked_target;
    int target_system;

    int shield_max;
    int shield_max_charge;
    int shield_level;
    int shield_status;

    /* accelerator data */
    float accel_range;
    float accel_base;
    float accel_extension;
};

/* planet contact entry.  each ship has a linked list of these */
struct planet_contact
{
   char *name;
   struct planet_contact *prev;
   struct planet_contact *next;
   PLANET *listref;
};

/* wormhole entry in linked list */
typedef struct wormhole_entry WORMH;
struct wormhole_entry
{
   char *name;
   dbref wormhole_object;
   XYZ pos[2];
   float size;
   WORMH *prev;
   WORMH *next;
};

/* wormhole contact entry.  each ship has a linked list of these */
struct wormhole_contact
{
   char *name;
   struct wormhole_contact *prev;
   struct wormhole_contact *next;
   WORMH *listref;
};

/* asteriuds entry in linked list */
typedef struct asteroids_entry ASTER;
struct asteroids_entry
{
   char *name;
   ASTER *prev;
   ASTER *next;
   dbref asteroids_object;
   int size;
   float density;
   XYZ pos;
};

/* asteroids contact entry.  each ship has a linked list of these */
struct asteroids_contact
{
   int inside;
   struct asteroids_contact *prev;
   struct asteroids_contact *next;
   ASTER *listref;
};

typedef struct nebula_entry NEBULA;
struct nebula_entry
{
    char *name;
    NEBULA *prev;
    NEBULA *next;
    dbref nebula_object;
    long flags;
    int size;
    float density;
    XYZ pos;
};

struct nebula_contact
{
    int inside;
    struct nebula_contact *prev;
    struct nebula_contact *next;
    NEBULA *listref;
};


struct beacon_entry {
   BEACON *prev;
   BEACON *next;
   dbref beacon_object;
   int type;
   int owner;
   int priority;
   int visible;
   XYZ c1, c2;   /* for cartesian 1, 2 */
   SPH s1, s2;   /* for spherical 1, 2 */
   char enter_message[160];
   char leave_message[160];
};

struct beacon_contact {
   char *name;
   struct beacon_contact *prev;
   struct beacon_contact *next;
   BEACON *listref;
   int visible;   /* is this a beacon that we can currently see */
};

/* ship entry needs to be forward-declared */
typedef struct ship_entry SHIP;

typedef struct watch_entry WATCH;
struct watch_entry
{
  WATCH *next;   /* linked list pointers */
  WATCH *prev;
  SHIP *listref;
  CONTACT *watcher_contact;
};

struct contact_entry
{
    CONTACT *next;
    CONTACT *prev;
    SHIP *listref;
    int contact_number;
    int turns_of_contact;
    int turns_since_last_contact;
    int info_level;
    XYZ last_pos;
    int watcher;
    int stale;
    int ignored;
    char type;
};

typedef struct shockwave_list SHOCKWAVE;
struct shockwave_list
{
   char name[NAME_LEN];
   SHOCKWAVE *prev;
   SHOCKWAVE *next;
   dbref shockwave_object;
   float size;
   float density;
   XYZ pos;
   float speed;
   float range1;
   float range2;
   int base_dam;
   int falloff;
};

typedef struct shockwave_contact SWCONTACT;
struct shockwave_contact
{
    struct shockwave_contact *prev;
    struct shockwave_contact *next;
    SHOCKWAVE *listref;
    int inside;
};


/* sensor net client/server entry struct */
typedef struct _sensorlink
{
  SHIP *ship;
  int status;
} SENSORLINK;

struct channel_entry
{
   unsigned frequency;
   int send_status;
   int receive_status;
   char label[17];
};

struct damage_entry {
   char status;
   int teams;
   int maxteams;
   int time_to_fix;
};

struct ship_entry
{
    SHIP *next;
    SHIP *prev;

    CONTACT *contact_list;
    CONTACT *contact_tail;

    CONTACT *locked_target;
    CONTACT *tractor_target;
    CONTACT *pending_lock;

    struct planet_contact *orbitting;
    struct planet_contact *planet_list;
    struct planet_contact *planet_tail;

    struct wormhole_contact *wormhole_list;
    struct wormhole_contact *wormhole_tail;

    struct asteroids_contact *asteroids_list;
    struct asteroids_contact *asteroids_tail;

    struct shockwave_contact *shockwave_list;
    struct shockwave_contact *shockwave_tail;

    struct nebula_contact *nebula_list;
    struct nebula_contact *nebula_tail;
    float nebula_visibility; /* cut visibility in nebulas */

    struct beacon_contact *beacon_list;
    struct beacon_contact *beacon_tail;
    int beacon_change;        /* temp flag used by the beacon checker */

    WATCH *watch_list;
    WATCH *watch_tail;

    dbref ship_object;

    /* name fields - JMS 23 Aug 93 */
    char name[NAME_LEN];
    char class[CLASS_LEN];
    char type[TYPE_LEN];
    char short_type[SHORT_TYPE_LEN];
    char owner_name[OWNER_LEN];
    char transponder[5];

    dbref helm;           /* dbrefs of the various control consoles */
    dbref nav;
    dbref eng;
    dbref trans;
    dbref damcon;
    dbref comm;
    dbref command;
    dbref science;

    dbref helmsman;  /* dbrefs of people manning consoles */
    dbref navigator;
    dbref engineer;
    dbref comm_officer;
    dbref trans_dude;
    dbref dmg_officer;
    dbref commander;
    dbref scienceofficer;

    int owner;

    XYZ pos;    /* position */
    XYZ inc;    /* incremental change per tacturn */
    SPH motion; /* heading, elevation, and speed in gsu */
    SPH course; /* heading/elevation/speed desired */
    float rotation;            /* degrees per 2 seconds of clockwise
                               rotation. */
    XYZ origin; /* point from which we report ship position */
    char origin_name[4];     /* name of system, e.g. HRC, or KRC */

    float warp_speed;            /* warp speed */
    float warpset;               /* warp setting */
    float inc_set;
    float ienactor;
    float wnot;
    int wnotify;
    float intercepting;          /* Whether or not you are intercepting */
    CONTACT *interceptor;           /* Ship that you are intercepting */

    int flags[NUM_FLAGS];

    int hull_integrity;
    int current_integrity;
    int permanent_hull_damage;
    int armor_strength[4];
    int max_armor_strength;
    char armor_type;
    float durability;

    int reactor_output_max;
    int current_reactor_output_max;
    int reactor_setting;
    int reactor_output;
    int reactor_setting_limit;
    int reactor_stress_level;
    float reactor_overload_penalty;
   
    int max_overload_points;
    int overload_points;

    int eng_warnings;
    int eng_safeties;
    int smart_alloc;      /* allocate smarter */

    float size;
    float aspect_ratio;
    float current_warp_factor;
    float warp_factor;
    float warp_max;
    float max_etemp_points;
    float etemp_points;
    float etemp_speed;
    float impulse_max;
    float yaw_dps;
    float pitch_dps;
    float warp_accel;
    float warp_decel;
   

    float sensor_power;
    float aux_sensor_power;
    ARC sensor_arc;
    ARC aux_sensor_arc;

    float scanner_range;

    SENSORLINK server;
    SENSORLINK clients[MAX_SNETCLIENTS];
    unsigned int active_clients;
    unsigned int max_clients;

    float transporter_range;
    float tractor_range;

    float transmitter_range;         /* comm panel stuff */
    float receiver_sensitivity;
    struct channel_entry channel[MAX_CHANNEL];
    char jammer_status;

    char cloak_status;
    int cloak_cost;
    float cloak_ratio;
   
    int battery_capacity;
    int battery_level;
    int battery_discharge_max;
    int battery_discharge;
    char battery_status;

    int shield_max[4];
    float shield_factor;
    int shield_max_charge[4];  /* max that can be added per turn */

    int alloc_nav;       /* allocations from engineering */
    int alloc_helm;
    int alloc_batt;

    int nalloc_warp;     /* allocations from the nav console */
    int nalloc_fore;     /* shields */
    int nalloc_aft;
    int nalloc_port;
    int nalloc_starboard;

    int shield_level[4];
    int shield_status[4];
    int shield_action[4];

    int halloc_phasers;        	 /* helm energy allocations */
    int halloc_photons;
    int halloc_tractor;

    int num_photons_online;
    int num_phasers_online;
    int auto_online;
    int auto_reload;

    int number_of_photons;         /* for looping */
    int number_of_phasers;
    int tractor_mode;

    int reloading_tube;        	 /* reloading stuff here */
    int turns_to_reload;
    int torps_remaining;
    int torp_capacity;

    int torp_max_num_turns_online;
    int torp_reload_time;

    char phaser_string[80];
    char photon_string[80];
    struct phaser_entry phaser[MAX_PHASERS];
    struct photon_entry photon[MAX_PHOTONS];
    int target_system;

    char bombarding;
    int armies_onboard;
    int max_armies;

    int door_status; /* 1 = open, 0 = closed, -1 = no docking */
    float dock_capacity;
    float dock_max_size;
    float shuttlebay_capacity;
    char landing_capable;

    struct damage_entry damage[NUM_SYSTEMS+1];

    int damcon_teams;
    int team[MAX_TEAMS]; /* shows what each team is up to */
    char fullrepair;

    char transwarp_capable;
    char transwarp_engaging;
    int transwarp_tolerance;
    int transwarp_charge;
    int transwarp_power;

    char interdict_status;
    int interdict_range;
    float interdict_speed;

    char on_autopilot;
    dbref autopilot_doer;
    XYZ autopilot_destination;
    char autopilot_alarm[80];
    float previous_distance;
    float near_planet_range;        	/* JMS 25 Sep 93 */
    float near_planet_size;        	/* JMS 25 Sep 93 */
    int next_contact_number;
    int battle_timer;
    
   /* Stuff for subspace */
   int numsubchan;                /* Howie added stuff here, number of subspace channels a ship already has */
   int subchan[7];                  /* What the channels are */
   char *sublabel[7];              /* Subspace channel labels array. */
};

/* function prototypes */

/* update functions */
void ship_update( void );
void tactical_turn( void );
void planet_tactical( void );
void move_ships( void );
void sensor_checks( void );
void do_sensors( SHIP *, SHIP *, float );
void planet_checks( void );
void wormhole_checks( void );
void ship_repairs( void );
void beacon_checks( void );
void nebula_checks( void );
void shockwave_checks( void );
void update_server( SHIP * );
void update_clients( SHIP * );
void kill_stale_contacts( SHIP * );
void new_net_contact( SHIP *, CONTACT * );
void upgrade_contact( SHIP *, CONTACT *, CONTACT * );

char *HappyName(dbref); /* Name(-1) causes crashes; this is a kludge fix */

/* mathematical functions */
XYZ sph_to_xyz( SPH );
SPH xyz_to_sph( XYZ );
float distance( XYZ, XYZ );
SPH fix_sph_coord( SPH );
SPH fix_spharc_coord( SPH );
int in_arc( ARC, SPH );
SPH facing_vector( SHIP *, XYZ );

/* miscellaneous functions */
CONTACT *match_contact( SHIP *, char * );
CONTACT *find_contact( SHIP *, SHIP * );
void write_damage( SHIP * );
void log_position( SHIP * );
char *my_atr_get_raw( dbref, const char * );
char *fetch_attribute( dbref, const char * );
void write_attribute( dbref, const char *, const char * );
dbref attrib_dbref(dbref, const char * );
void fnotify();
void log_space();

/* helm functions */
void helm_sensor_report( SHIP *, dbref );
void short_sensor_report( SHIP *, dbref );  
int add_contact( SHIP *, SHIP * );
void remove_contact( SHIP *, CONTACT * );
void display_sensor_info( SHIP *, CONTACT *, dbref, int );
void display_short_sensor_report( SHIP *, CONTACT *, dbref );
void intercept(SHIP *, dbref, char *);
void lock_weapons( SHIP *, dbref, char * );
void lock_tractor( SHIP *, dbref, char * );
void target_system( SHIP *, dbref, const char * );
void set_tractor_mode( SHIP *, dbref, char * );
void contact_string( char *, CONTACT *, int );
void break_lock( SHIP * );
void break_tractor( SHIP * );
void drop_lock( SHIP *, dbref );
void drop_tractor( SHIP *, dbref );
void helm_status( SHIP *, dbref );
void helm_allocate(SHIP *, dbref, int, int, int);
void helm_alloc_check( SHIP * );
int fire_photon( SHIP *, dbref, int, int );
void fire_phaser( SHIP *, dbref, int, int, CONTACT * );
void xyz_fire_phaser( SHIP *, dbref, int, int, int, int );
void manual_fire_photon( SHIP *, dbref, int, char *, char *, char * );
void reload_photon(SHIP *, dbref, int );
void photon_online( SHIP *, dbref, int );
void photon_offline( SHIP *, dbref, int );
void phaser_online( SHIP *, dbref, int );
void phaser_offline( SHIP *, dbref, int );
void scan_ship( SHIP *, dbref, char *, int );
void dscan_ship( SHIP *, dbref, char * );
void toggle_auto_online( SHIP *, dbref );
void toggle_auto_reload( SHIP *, dbref );
void man_helm( SHIP *, dbref, dbref );
void identify_ship( SHIP *, dbref, char * );
void id_list( SHIP *, dbref );
void tactical_display( SHIP *, dbref );
const char *get_tractor_mode( SHIP * );
void toggle_ignore_contact( SHIP *, dbref, char * );
void bombard_planet( SHIP *, dbref );
char ship_is_safe( SHIP * );

/* engineering functions */
SHIP *cfind_ship( dbref );
int initialize_ship( dbref );
int load_ship_template( dbref, SHIP * );
int deallocate_ship( SHIP * );
void start_reactor( SHIP *, dbref, dbref );
void shutdown_reactor( SHIP *, dbref );
void toggle_safeties( SHIP *, dbref );
void toggle_smartmode( SHIP *, dbref, char * );
void set_reactor_output( SHIP *, dbref, int );
void eng_status( SHIP *, dbref );
void eng_allocate( SHIP *, dbref, int, int, int );
void eng_alloc_check( SHIP *, dbref );
void ship_specs( SHIP *, dbref );
float calc_warp_speed( float, int );

/* navigation functions */
void nav_status( SHIP *, dbref );
void nav_new_course( int, int, SHIP *, dbref );
void nav_allocate( SHIP *, dbref, int, int, int, int, int );
void nav_quick_alloc( SHIP *, dbref, int, int );
void warp_speed( SHIP *, dbref, int );
void warp_cost( SHIP *, dbref, float );
void warp_table( SHIP *, dbref );
void set_warp( SHIP *, dbref, float );
void nav_alloc_check( SHIP * );
void raise_shields( SHIP *, dbref, char * );
void lower_shields( SHIP *, dbref, char * );
void engage_cloak( SHIP *, dbref );
void disengage_cloak( SHIP *, dbref );
void list_planets( SHIP *, dbref );
void scan_planet( SHIP *, dbref, struct planet_contact * ); 
void set_coordinates( SHIP *, dbref, char *, char * );
void reset_coordinates( SHIP *, dbref );
void short_position( SHIP *, dbref );
void xyz_position( SHIP *, dbref );
void sensor_sweep( SHIP *, dbref );
void kamikaze_attack( SHIP *, dbref, char * );
void fire_shields( SHIP *, dbref );
void ship_interdict_check( SHIP * );
void toggle_interdict( SHIP *, dbref );
void remote_down( SHIP *, dbref, char *, char * );
void remote_undock( dbref, dbref, char * );
void remote_up( dbref, dbref);
void remote_raise_shields( dbref, SHIP *, char *, char * );
void remote_lower_shields( dbref, SHIP *, char *, char * );
void remote_decloak( SHIP *, dbref, char *, char * );
void remote_cloak( SHIP *, dbref, char *, char * );
void eta( SHIP *, dbref);
float translate_warp( float );


/* comm functions */
void comm_status( SHIP *, dbref );
void set_channel( SHIP *, dbref, int, unsigned );
void label_channel( SHIP *, dbref, int, char * );
void comm_send( SHIP *, dbref, int, char * );
void send_comm_message( SHIP *, unsigned, char *, int );
void audio_send( SHIP *, char * );
void visual_send( SHIP *, char * );
void set_channel_setting( SHIP *, dbref, char *, int, char * );
int net_range( SHIP *, SHIP * );
void net_stat( SHIP *, dbref );
void extend_link( SHIP *, dbref, char * );
void accept_link( SHIP *, dbref, char * );
void cut_link( SHIP *, dbref, char * );
int is_client( SHIP *, SHIP * );
void rearrange_clients( SHIP * );
void sever_link( SHIP *, SHIP *, int, int );
int check_jammed( SHIP *, SHIP * );
void toggle_jamming( SHIP *, dbref );
void manual_snet_client( SHIP *, dbref, char * );
void manual_snet_server( SHIP *, dbref, char * );
void set_transpond( SHIP *, dbref, char * );
void quadrant( SHIP *, dbref, char *, char ** );
char on_snet( SHIP * );
void subspace_add( SHIP *, dbref, char *);
void subspace_hail( SHIP *, dbref, char *, char * );
void subspace_change( SHIP *, dbref, char *, char * );
void sub_status( SHIP *, dbref );
void subspace_label( SHIP *, dbref, char *, char * );
void netchan_off( dbref, char *, char *, char ** );

/* damage functions */
int  facing_shield( SHIP *, SHIP * );
int  battle_damage( SHIP *, SHIP * , int, WDATA );
int  damage_hull( SHIP *, int, int );
int  specific_system_damage( SHIP *, int, int, int );
int  system_damage( SHIP *, int, int );
int  break_system( SHIP *, int );
void self_destruct( SHIP *, dbref );
void explode_ship( SHIP * );
void eject_warp_core( SHIP *, dbref );
void eject_phaser_core( SHIP *, dbref );

/* planet functions */
int activate_planet( dbref, dbref );
void deactivate_planet( PLANET *, dbref );
void add_planet( SHIP *, PLANET * );
void remove_planet( SHIP *, PLANET * );
PLANET *find_planet( dbref );
struct planet_contact *find_planet_contact( SHIP *, PLANET * );
int blowup_planet( PLANET *, dbref );
void planet_fire_phaser( PLANET *, dbref, int, int );
void planet_lock( PLANET *, dbref, char * );
void planet_unlock( PLANET *, dbref );
void planet_raise( PLANET *, dbref );
void planet_lower( PLANET *, dbref );
void planet_sensor_report( PLANET *, dbref );
void planet_short_sensor_report( PLANET *, dbref );
void planet_status( PLANET *, dbref );
void planet_target_system( PLANET *, dbref, const char * );
void damage_planet( PLANET *, int, int );
void planet_sensor_checks( void );
void do_planet_sensors( PLANET *, SHIP *, float );
SHIP planet_fake_ship( PLANET * );

/* wormhole functions */
int activate_wormhole( dbref, dbref );
void deactivate_wormhole( WORMH *, dbref );
void add_wormhole( SHIP *, WORMH * );
void remove_wormhole( SHIP *, WORMH * );
WORMH *find_wormhole( dbref );
void wormhole_jump( SHIP *, dbref );
void list_wormholes( SHIP *, dbref );
      
/* docking functions */
dbref dock( SHIP *, dbref, char * );
dbref undock( SHIP *, dbref, dbref );
void orbit( SHIP *, dbref, char * );
void door_control( SHIP *, dbref, int );
dbref tractor_dock( SHIP *, dbref );
void land_ok( SHIP *, dbref, struct planet_contact *, char *, char **);
void dock_ok( SHIP *, dbref, char *, char *, char **);

/* beacon functions */
int activate_beacon( dbref, dbref );
void deactivate_beacon( BEACON *, dbref );
void ship_beacon_checks( SHIP * );
void add_beacon( SHIP *, BEACON * );
void remove_beacon( SHIP *, BEACON * );
void list_beacons( SHIP *, dbref );

/* damage control functions */
void assign_team( SHIP *, dbref, int, char * );
void repair_system( SHIP *, int );
long ship_cost( SHIP *, dbref );

/* nav hazard functions */
void haz_accelerate( PLANET *, SHIP * );

/* autopilot goodies */
void engage_autopilot( SHIP *, dbref, char *, char *, char *, char * );
void engage_xyzautopilot( SHIP *, dbref, char *, char *, char *, char * );
void disengage_autopilot( SHIP *, dbref );
void autopilot_dest_check( SHIP * );

/* sensorwatch functions */
void add_watch( SHIP *, dbref, char *, int );
void remove_watch( SHIP *, dbref, char *, int );
void list_watches( SHIP *, dbref, int );
void add_watch_ref( SHIP *, SHIP * );
void remove_watch_ref( SHIP *, SHIP * );
void watch_message( SHIP *, char * );

/* GOD commands */
void space_roster( dbref );
void all_eng_status( dbref );
void all_nav_status( dbref );
void master_eng_list( dbref );
void master_nav_list( dbref );
void shutdown_space( dbref );
void set_ship_flag( SHIP *, dbref, char *, int );
void manual_shutdown( SHIP *, dbref );
void hand_move( SHIP *, dbref, float, float, float );
void get_dbref( SHIP *, dbref, char *, char *, char **);
void full_repair( SHIP *, dbref );
void master_beacon_list( dbref );
void force_contact( SHIP *, dbref, char * );
void armageddon( dbref, int );

/* nebula functions */
int activate_nebula( dbref, dbref );
void deactivate_nebula( NEBULA *, dbref );
void ship_nebula_checks( SHIP * );
void add_nebula( SHIP *, NEBULA * );
void enter_nebula( SHIP *, NEBULA *, struct nebula_contact *, dbref );
void remove_nebula( SHIP *, NEBULA * );
void list_nebulas( SHIP *, dbref );

/* asteroids functions */
int activate_asteroids( dbref, dbref );
void deactivate_asteroids( ASTER *, dbref );
void asteroids_checks( void );
void add_asteroids( SHIP *, ASTER * );
void enter_asteroids( SHIP *, ASTER *, struct asteroids_contact * );
void remove_asteroids( SHIP *, ASTER * );
void list_asteroids( SHIP *, dbref );
char asteroid_damage( SHIP *, struct asteroids_contact * );

/* shockwave functions */
SWCONTACT *find_shockwave_contact( SHIP *, SHOCKWAVE * );
int activate_shockwave( dbref executor, dbref enactor );
int auto_active_shockwave( SHOCKWAVE *temp, int curspace );
void deactivate_shockwave( SHOCKWAVE *shockwave, dbref enactor );
void ship_shockwave_checks( SHIP *ship );
void add_shockwave( SHIP *ship, SHOCKWAVE *shockwave );
void enter_shockwave( SHIP *ship, SWCONTACT *contact );
void shockwave_damage( SHIP *ship, SWCONTACT *contact, dbref navigator );
void remove_shockwave( SHIP *ship, SHOCKWAVE *shockwave );
void list_shockwaves( SHIP *ship, dbref enactor );
int inside_shockwave(SHIP *ship, SHOCKWAVE *shockwave);

/* smart alloc toys */
int requisition_power( SHIP *, int, int );
int free_power( SHIP *, int, int );
int remaining_opt_power( SHIP * );

/* transwarp shit */
char find_tw_beacon( SHIP *, XYZ );
void engage_transwarp( SHIP *, dbref );
void abort_transwarp( SHIP *, dbref );
int compute_tw_cost( SHIP *, XYZ );
void murphy( SHIP * );
char transwarp_jump( SHIP * );

#endif /* use_space */
