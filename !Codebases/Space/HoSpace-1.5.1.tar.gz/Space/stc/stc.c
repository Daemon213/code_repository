/*
 * STC.C
 * 
 *  BiffSpace starship template compiler.
 *
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * JMS  2 Aug 93 - started
 * JMS  4 Aug 93 - #el[se]ifdef, #el[se]ifndef, #if, #el[se]if
 * JMS 12 Aug 93 - read mode
 * JMS 13 Aug 93 - two-column output, listfiles
 * JMS 21 Sep 93 - damage control teams, remote sensor array goodies.
 * JMS 25 Sep 93 - max_clients, xmit range and sensor stuff to floats
 *
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "jmalloc.h"
#include "stc.h"
#include "ship.h"
#include "token.h"
#include "jstring.h"
#include "eval.h"


/* global data */
FLAGS flags;
INSHIP ship;
unsigned int depth;
extern int define_token();
void label_wpns( char *, int );
void assign_wpn_arc( char *, int );
ARC read_arc( char * );

int main( int argc, char *args[] )
{
int ok;
char *infile;

  /* initialize the token stuff */
  initialize_tokens();

  infile = parse_cmdline( argc, args );

  if(( flags.h ) || ( infile == NULL )) {
    display_help();
  }
  else {
    if( flags.r ) {
      /* read an existing binary template */
      read_template( infile );
      if( ship.version == VERSION_CHAR )
	display_info();
      else
	printf( "\nIncompatible file format." );
    }
    else {
      /* process an ASCII template */
      depth = 0;
      ok = process_template( infile );

      if( ok ) {
	if( flags.l )
	  display_info();

	write_ship( infile );
      }
    }
  }

  return( 0 );
}


/*
 * parse_cmdline
 *
 *  input:
 *    int argc, char *args[]                    from the command line
 *
 *  purpose:
 *    parses the command line arguments down into filenames and flags.
 *
 *  returns:
 *    a pointer to the filename given at the command line, or NULL if
 *    none was supplied
 *
 * JMS 28 May 93
 * JMS  2 Aug 93 - adapted for SCC.C
 */

char *parse_cmdline( int argc, char *args[] )
{
int i;
unsigned filename_found;
char *filespec = NULL;

  filename_found = FALSE;

  flags.h = FALSE;
  flags.l = FALSE;
  flags.listfile = NULL;
  flags.o = FALSE;
  flags.outfile = NULL;
  flags.q = FALSE;
  flags.r = FALSE;

  for( i = 1; i < argc; i++ ) {
    switch( tolower( args[i][0] )) {
      case '?':
	flags.h = TRUE;
	break;
      case '/':
      case '-':
	switch( tolower( args[i][1] )) {
	  case '?':
	  case 'h':
	    flags.h = TRUE;
	    break;
	  case 'q':
	    flags.q = TRUE;
	    break;
	  case 'r':
	    flags.r = TRUE;
	    break;
	  case 'o':
	    flags.o = TRUE;
	    flags.outfile = (char *)JMALLOC( strlen( args[i] ));
	    strcpy( flags.outfile, &args[i][2] );
	    break;
	  case 'l':
	    flags.l = TRUE;
	    flags.listfile = (char *)JMALLOC( strlen( args[i] ));
	    strcpy( flags.listfile, &args[i][2] );
	    break;
	  default:
	    printf( "\nUnrecognized command line option: %s", args[i] );
	    flags.h = TRUE;
	    break;
	}
	break;
      default:
	/* must be a filename or something */
	if( !filename_found ) {
	  filespec = (char *)JMALLOC( 1 + strlen( args[i] ));
	  strcpy( filespec, args[i] );
	  filename_found = TRUE;
	}
	else {
	  printf( "\nUnrecognized command line option: %s", args[i] );
	  flags.h = TRUE;
	}
	break;
    }
  }

  return( filespec );
}


/*
 * display_info
 *
 *  purpose:
 *    prints out the ship struct.  debug reasons.
 *
 * JMS  2 Aug 93
 * JMS 13 Aug 93 - two-column output
 */

void display_info( void )
{
  FILE *outfile;

  if(( flags.l ) && ( strlen( flags.listfile ))) {
    outfile = fopen( flags.listfile, "wt" );
    if( outfile == NULL ) {
      outfile = stdout;
      fprintf( stderr, "Error opening %s for writing.  Redirecting "
		       "list file to stdout.", flags.listfile );
    }
  }
  else
    outfile = stdout;

  if( outfile == stdout )
    printf( "\n" );

  fprintf( outfile, "Indentifying data:" );
  fprintf( outfile, "\n class_name:          %-15s", ship.class_name );
  fprintf( outfile, "type:                %s", ship.type );
  fprintf( outfile, "\n builder:             %-15s", ship.builder );
  fprintf( outfile, "owner:               %d", ship.owner );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nHull data:" );
  fprintf( outfile, "\n hull_points:         %-15u", ship.hull_points );
  fprintf( outfile, "hull_size:           %3.1f", ship.hull_size );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nReactor data:" );
  fprintf( outfile, "\n reactor_power:       %-15u", ship.reactor_power );
  fprintf( outfile, "normal_setting:      %u", ship.normal_setting );
  fprintf( outfile, "\n maximum_setting:     %-15u", ship.maximum_setting );
  fprintf( outfile, "overload_penalty:    %3.1f", ship.overload_penalty );
  fprintf( outfile, "\n overload_points:     %u", ship.overload_points );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nBattery data:" );
  fprintf( outfile, "\n battery_power:       %-15u", ship.battery_power );
  fprintf( outfile, "btty_dischg_rate:    %u", ship.battery_discharge_rate );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nDrive data:" );
  fprintf( outfile, "\n warp_factor:         %-15.1f", ship.warp_factor );
  fprintf( outfile, "max_speed:           %3.1f", ship.max_speed );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nSensor data:" );
  fprintf( outfile, "\n sensor_range:        %-15.0f", ship.sensor_range );
  fprintf( outfile, "scanner_range:       %.0f", ship.scanner_range );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nWeapon data:" );
  fprintf( outfile, "\n gun_name:            %-15s", ship.gun_name );
  fprintf( outfile, "num_guns:            %u", ship.num_guns );
  fprintf( outfile, "\n gun_range:           %-15u", ship.gun_range );
  fprintf( outfile, "gun_power:           %u", ship.gun_power );
  fprintf( outfile, "\n gun_delivery:        %-15.2f", ship.gun_delivery );
  fprintf( outfile, "gun_charge_rate:     %u", ship.gun_charge_rate );
  fprintf( outfile, "\n" );
  fprintf( outfile, "\n num_torps:           %-15u", ship.num_torps );
  fprintf( outfile, "torp_range:             %u", ship.torp_range );
  fprintf( outfile, "\n torp_power:          %-15u", ship.torp_power );
  fprintf( outfile, "torp_accuracy:          %4.2f", ship.torp_accuracy );
  fprintf( outfile, "\n torp_charge_rate:    %-15u", ship.torp_charge_rate );
  fprintf( outfile, "torp_reload_time:       %u", ship.torp_reload_time );
  fprintf( outfile, "\n torp_max_num_turns_online:    %-15u", ship.torp_max_num_turns_online );
  fprintf( outfile, "torp_name:              %s", ship.torp_name );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nShield data:" );
  fprintf( outfile, "\n shield_power:        %-15u", ship.shield_power );
  fprintf( outfile, "shield_factor:       %4.2f", ship.shield_factor );
  fprintf( outfile, "\n shield_charge_rate:  %u", ship.shield_charge_rate );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nCommunications data:" );
  fprintf( outfile, "\n transmitter_range:   %-15.0f", ship.transmitter_range );
  fprintf( outfile, "rcvr_sensitivity:    %4.2f", ship.receiver_sensitivity );
  fprintf( outfile, "\n max_clients:         %-15u", ship.max_clients );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nCloak data:" );
  fprintf( outfile, "\n cloak_present:       %-15u", ship.cloak_present );
  fprintf( outfile, "cloak_cost:          %u", ship.cloak_cost );
  fprintf( outfile, "\n" );

  fprintf( outfile, "\nMiscellaneous data:" );
  fprintf( outfile, "\n transporter_range:   %-15u", ship.transporter_range );
  fprintf( outfile, "damcon_teams:        %u", ship.damcon_teams );
  fprintf( outfile, "\n dock_capacity:    %-15.2f", ship.dock_capacity );
  fprintf( outfile, "cargo_capacity:      %u", ship.cargo_capacity );
  fprintf( outfile, "\n landing_capable:  %-15u", ship.landing_capable );
  fprintf( outfile, "\n" );
}


/*
 * display_help
 *
 *  purpose:
 *    displays the help info.
 *
 * JMS 28 May 93
 * JMS  2 Aug 93 - adapted for SCC.C
 * JMS 13 Aug 93 - most recent mod
 */

void display_help( void )
{
  printf( "\nBiffSpace Starship Template Compiler Version %s", VERSION );
  printf( "\nSyntax is: STC [options] filespec" );
  printf( "\n  -h      Help" );
  printf( "\n  -lxxx   List results to file" );
  printf( "\n  -oxxx   Object filename" );
  printf( "\n  -q      Quiet mode.  Don't show filenames" );
  printf( "\n  -r      Read and display a compiled template" );
  printf( "\n" );
}


/*
 * process_template
 *
 *  input:
 *    char *filename                   Filename to load
 *
 *  purpose:
 *    Reads in a file and compiles it.
 *
 * JMS  2 Aug 93
 * JMS 12 Aug 93 - mv process_file process_template
 */

int process_template( char *filespec )
{
FILE *hfile;
char *new_filespec;
char readbuf[161], tfield[512], tdata[2048];
char *field, *data;
unsigned int i;
int ifmode[IF_DEPTH];
int ifdepth, idata;

  depth++;
  ifdepth = 0;
  ifmode[0] = DIR_GOOD;

  if( depth > MAX_DEPTH ) {
    printf( "\nError: Maximum depth exceeded.\n" );
    return FALSE;
  }

  /* first try a raw open */
  hfile = fopen( filespec, "rt" );

  /* if that didn't work, see if we should mess with the filename */
  if( hfile == NULL ) {
    if( !strchr( filespec, '.' )) {
      new_filespec = (char *)JMALLOC( (size_t)5 + strlen( filespec ));
      strcpy( new_filespec, filespec );
      strcat( new_filespec, ".tem" );
      hfile = fopen( new_filespec, "rt" );
    }
  }
  else
    new_filespec = filespec;

  if( hfile == NULL ) {
    printf( "\nError:  Unable to open file %s for reading.", filespec );
    printf( "\n" );
    return FALSE;
  }

  if( !flags.q ) {
    /* indent include directives */
    printf( "\n" );
    for( i = 1; i < depth; i++ )
      printf( "  " );
    printf( "%s:", new_filespec );
  }

  /* whee.  the file is open.  process each line */
  fgets( readbuf, 160, hfile );
  while( !feof( hfile )) {

    /* first make sure that the string is terminated by a double-null.
     * It's long enough to hold the extra.  We may need the extra null
     * later when we isolate field and data strings.
     */
    readbuf[strlen( readbuf ) + 1] = '\0';

    /* change the first semicolon to a null */
    if( strchr( readbuf, ';' ))
      *strchr( readbuf, ';' ) = '\0';

    trim_leading_whitespace( readbuf );
    trim_trailing_whitespace( readbuf );

    /* if there's anything left, process it */
    if( strlen( readbuf )) {

      /* split readbuf into field and data segments */
      field = readbuf;

      for( i = 0; !isspace( readbuf[i] ); i++ );
      readbuf[i] = '\0';

      data = &readbuf[i+1];

      trim_trailing_whitespace( field );
      trim_leading_whitespace( data );
      field = decapitate( field );

      /* if we've got a #directive, remove any spaces between the # and
       * the directive
       */
      if( field[0] == '#' )
	while( isspace( field[1] ))
	  deletechar( field, 1 );

      /* perform token substitution on data, preserve the original */
      strcpy( tdata, data );
      substitute_tokens( tdata );
      strcpy( tfield, field );
      substitute_tokens( tfield );

      /* arith-eval the data */
      idata = arith_eval( tdata );

      /* okay, field is isolated.  try to match it */

      /* first off, process #directives */
      if( !strcmp( field, "#endif" )) {
	ifdepth--;
      }
      else if( !strcmp( field, "#else" )) {
	switch( ifmode[ifdepth] ) {
	  case DIR_DONE:
	    break;
	  case DIR_GOOD:
	    ifmode[ifdepth] = DIR_DONE;
	    break;
	  case DIR_BAD:
	    ifmode[ifdepth] = DIR_GOOD;
	    break;
	}
      }
      else if( !strcmp( field, "#elseifdef" ) || 
	       !strcmp( field, "#elifdef" )) {
	switch( ifmode[ifdepth] ) {
	  case DIR_DONE:
	    break;
	  case DIR_GOOD:
	    ifmode[ifdepth] = DIR_DONE;
	    break;
	  case DIR_BAD:
	    if( lookup_token( data ) == NULL )
	      ifmode[ifdepth] = DIR_BAD;
	    else
	      ifmode[ifdepth] = DIR_GOOD;
	    break;
	}
      }
      else if( !strcmp( field, "#elseif" ) || !strcmp( field, "#elif" )) {
	switch( ifmode[ifdepth] ) {
	  case DIR_DONE:
	    break;
	  case DIR_GOOD:
	    ifmode[ifdepth] = DIR_DONE;
	    break;
	  case DIR_BAD:
	    if( idata == 0 )
	      ifmode[ifdepth] = DIR_BAD;
	    else
	      ifmode[ifdepth] = DIR_GOOD;
	    break;
	}
      }
      else if( !strcmp( field, "#elseifndef" ) ||
	       !strcmp( field, "#elifndef" )) {
	switch( ifmode[ifdepth] ) {
	  case DIR_DONE:
	    break;
	  case DIR_GOOD:
	    ifmode[ifdepth] = DIR_DONE;
	    break;
	  case DIR_BAD:
	    if( lookup_token( data ) == NULL )
	      ifmode[ifdepth] = DIR_GOOD;
	    else
	      ifmode[ifdepth] = DIR_BAD;
	    break;
	}
      }
      else if( !strcmp( field, "#ifdef" )) {
	ifdepth++;
	if( lookup_token( data ) == NULL )
	  ifmode[ifdepth] = DIR_BAD;
	else
	  ifmode[ifdepth] = DIR_GOOD;
      }
      else if( !strcmp( field, "#ifndef" )) {
	ifdepth++;
	if( lookup_token( data ) == NULL )
	  ifmode[ifdepth] = DIR_GOOD;
	else
	  ifmode[ifdepth] = DIR_BAD;
      }
      else if( !strcmp( field, "#if" )) {
	ifdepth++;
	if( idata == 0 )
	  ifmode[ifdepth] = DIR_BAD;
	else
	  ifmode[ifdepth] = DIR_GOOD;
      }
      else if( ifmode[ifdepth] != DIR_GOOD ) {
	/* bwah!  do nothing! */
      }
      else if( !strcmp( field, "#define" )) {
	process_define( data );
      }
      else if( !strcmp( field, "#undef" ))
      {
	if( undefine_token( data ) == TKE_FAIL )
        {
	  printf( "\n" );
	  for( i = 0; i < depth; i++ )
	    printf( "  " );
	  printf( "Warning:  #undefine of token that isn't #defined: %s",
		  data );
        }
      }
      else if( !strcmp( field, "#echo" )) {
	printf( "\n" );
	for( i = 1; i < depth; i++ )
	  printf( "  " );
	printf( "%s", tdata );
      }
      else if( !strcmp( field, "#include" )) {
	/* filename must be in quotes */
	if(( tdata[0] != '"' ) || ( tdata[strlen(tdata)-1] != '"' )) {
	  printf( "\nError: #include filespecs must be in quotes." );
	}
	else {
	  /* remove the quotes */
	  deletechar( tdata, 0 );
	  deletechar( tdata, strlen( tdata ) -1 );

	  process_template( tdata );
	}
      }

      /* identifying data */
      else if( !strcmp( tfield, "class_name" ))
      {
	strncpy( ship.class_name, tdata, 32 );
      }
      else if( !strcmp( tfield, "type" )) {
	strncpy( ship.type, tdata, 32 );
      }
      else if( !strcmp( tfield, "short_type" )) {
        strncpy( ship.short_type, tdata, 4 );
      }
      else if( !strcmp( tfield, "builder" )) {
	strncpy( ship.builder, tdata, 32 );
      }
      else if( !strcmp( tfield, "owner" )) {
	ship.owner = (unsigned int)idata;
      }

      /* hull data */
      else if( !strcmp( tfield, "hull_points" ))
      {
	ship.hull_points = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "hull_size" ))
      {
        ship.hull_size = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "armor_points" ))
      {
        ship.armor_points = (unsigned int)idata;
      }
      else if( !strcmp(  tfield, "armor_type" ) )
      {
        ship.armor_type = (char)idata;
      }
      else if( !strcmp( tfield, "durability" ) )
      {
        ship.durability = (float)atof( tdata );
      }
      /* reactor data */
      else if( !strcmp( tfield, "reactor_power" )) {
	ship.reactor_power = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "normal_setting" )) {
	ship.normal_setting = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "maximum_setting" )) {
	ship.maximum_setting = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "overload_penalty" ))
      {
	ship.overload_penalty = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "overload_points" ))
      {
	ship.overload_points = (unsigned int)idata;
      }
      /* battery data */
      else if( !strcmp( tfield, "battery_power" ))
      {
	ship.battery_power = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "battery_discharge_rate" )) {
	ship.battery_discharge_rate = (unsigned int)idata;
      }

      /* drive data */
      else if( !strcmp( tfield, "warp_factor" ))
      {
	ship.warp_factor = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "max_speed" ))
      {
	ship.max_speed = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "max_impulse" ) )
      {
        ship.max_impulse = UMIN( atof(tdata), 0.99 );
      }
      else if( !strcmp( tfield, "etemp_points" ) )
      {
        ship.etemp_points = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "etemp_speed" ) )
      {
        ship.etemp_speed = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "transwarp_capable" ) )
      {
        ship.transwarp_capable = (char)idata;
      }
      else if( !strcmp( tfield, "transwarp_tolerance" ) )
      {
        ship.transwarp_tolerance = (int)idata;
      }
      else if( !strcmp( tfield, "yaw_dps" ) )
      {
        ship.yaw_dps = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "warp_accel" ) )
      {
       ship.warp_accel = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "warp_decel") )
      {
       ship.warp_decel = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "pitch_dps" ) )
      {
        ship.pitch_dps = (float)atof(tdata);
      }
      /* sensor data */
      else if( !strcmp( tfield, "sensor_range" ))
      {
	ship.sensor_range = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "sensor_arc" ) )
      {
        ship.sensor_arc = read_arc(tdata);
      }
      else if( !strcmp( tfield, "scanner_range" ))
      {
	ship.scanner_range = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "aux_sensor_range" ))
      {
	ship.aux_sensor_range = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "aux_sensor_arc" ) )
      {
        ship.aux_sensor_arc = read_arc(tdata);
      }
      /* weapon data */
      else if( !strcmp( tfield, "gun_name" ))
      {
	strncpy( ship.gun_name, tdata, 29 );
      }
      else if( !strcmp( tfield, "num_guns" ))
      {
	ship.num_guns = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "gun_range" ))
      {
	ship.gun_range = (unsigned long int)idata;
      }
      else if( !strcmp( tfield, "gun_power" ))
      {
	ship.gun_power = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "gun_delivery" ))
      {
	ship.gun_delivery = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "gun_charge_rate" ))
      {
	ship.gun_charge_rate = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "gun_signature" ) )
      {
        ship.gun_signature = (int)idata;
      }
      else if( !strcmp( tfield, "gun_reliability" ) )
      {
	ship.gun_reliability = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "gun_sfactor" ) )
      {
	ship.gun_shield_factor = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "gun_hfactor" ) )
      {
	ship.gun_hull_factor = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "gun_carryover" ) )
      {
	ship.gun_carryover = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "gun_taps" ) )
      {
        ship.gun_taps = UMAX( 1, (int)idata );
      }
      else if( !strcmp( tfield, "gun_label" ) )
      {
        label_wpns( tdata, WPN_GUN );
      }
      else if( !strcmp( tfield, "gun_arc" ) )
      {
        assign_wpn_arc( tdata, WPN_GUN );
      }
      else if( !strcmp( tfield, "torp_name" ))
      {
	strncpy( ship.torp_name, tdata, 29 );
      }
      else if( !strcmp( tfield, "num_torps" ))
      {
	ship.num_torps = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "torp_range" ))
      {
	ship.torp_range = (unsigned long int)idata;
      }
      else if( !strcmp( tfield, "torp_power" )) {
	ship.torp_power = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "torp_accuracy" ))
      {
	ship.torp_accuracy = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "torp_reliability" ) )
      {
	ship.torp_reliability = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "torp_charge_rate" )) {
	ship.torp_charge_rate = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "torp_reload_time" )) {
	ship.torp_reload_time = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "torp_max_num_turns_online" ))
      {
	ship.torp_max_num_turns_online = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "torp_capacity" ) )
      {
        ship.torp_capacity = (int)idata;
      }
      else if( !strcmp( tfield, "torp_signature" ) )
      {
        ship.torp_signature = (int)idata;
      }
      else if( !strcmp( tfield, "torp_sfactor" ) )
      {
	ship.torp_shield_factor = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "torp_hfactor" ) )
      {
	ship.torp_hull_factor = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "torp_carryover" ) )
      {
	ship.torp_carryover = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "torp_taps" ) )
      {
        ship.torp_taps = UMAX( 1, (int)idata );
      }
      else if( !strcmp( tfield, "torp_label" ) )
      {
        label_wpns( tdata, WPN_TORP );
      }
      else if( !strcmp( tfield, "torp_arc" ) )
      {
        assign_wpn_arc( tdata, WPN_TORP );
      }
      else if( !strcmp( tfield, "tractor_range" ) )
      {
        ship.tractor_range = (unsigned int)idata;
      }
      

      /* shield data */
      else if( !strcmp( tfield, "shield_power" )) {
	ship.shield_power = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "shield_factor" )) {
	ship.shield_factor = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "shield_charge_rate" )) {
	ship.shield_charge_rate = (unsigned int)idata;
      }

      /* communications data */
      else if( !strcmp( tfield, "transmitter_range" )) {
	ship.transmitter_range = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "receiver_sensitivity" )) {
	ship.receiver_sensitivity = (float)atof( tdata );
      }
      else if( !strcmp( tfield, "max_clients" )) {
	ship.max_clients = (unsigned int)idata;
      }

      /* cloak data */
      else if( !strcmp( tfield, "cloak_present" ))
      {
        ship.cloak_present = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "cloak_cost" ))
      {
	ship.cloak_cost = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "cloak_ratio" ) )
      {
        ship.cloak_ratio = (float)atof( tdata );
      }
      /* dissipator */
      else if( !strcmp( tfield, "interdict_range" ) )
      {
        ship.interdict_range = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "interdict_speed" ) )
      {
        ship.interdict_speed = (float)atof( tdata );
      }
      /* miscellaneous data */
      else if( !strcmp( tfield, "transporter_range" )) {
	ship.transporter_range = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "damage_control_teams" ))
      {
	ship.damcon_teams = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "fullrepair" ) || !strcmp( tfield, "full_repair" ) )
      {
        ship.fullrepair = (unsigned int)idata ? 1 : 0;
      }
      else if( !strcmp( tfield, "dock_capacity" ))
      {
          ship.dock_capacity = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "dock_max_size" ) )
      {
          ship.dock_max_size = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "shuttlebay_capacity" ) )
      {
         ship.shuttlebay_capacity = (float)atof(tdata);
      }
      else if( !strcmp( tfield, "cargo_capacity" ))
      {
	ship.cargo_capacity = (unsigned int)idata;
      }
      else if( !strcmp( tfield, "landing_capable" ))
      {
	ship.landing_capable = (unsigned int)idata ? 1 : 0;
      }
      else if( !strcmp( tfield, "escape_pods" ) )
      {
        ship.escape_pods = (int)idata;
      }
      /* error */
      else {
	printf( "\nError: Unrecognized field: %s", field );
      }
    }

    fgets( readbuf, 160, hfile );

  }

  fclose( hfile );
  depth--;

  return TRUE;
}


/*
 * process_define
 *
 *  input:
 *    char *data                       symbol and substitution
 *
 *  purpose:
 *    parses the string and defines the token.
 *
 * JMS 2 Aug 93
 * JMS 13 Aug 93 - check for redefinition of token
 */

void process_define( char *data )
{
char match[161];
char *equiv;
unsigned int i;

  /* make our own copy of the input string */
  strncpy( match, data, 160 );

  /* find the end of the first word */
  for( i = 0; (( match[i] ) && !isspace( match[i] )); i++ );

  /* turn it into a null if it isn't already */
  if( match[i] ) {
    match[i] = '\0';
    equiv = &match[i+1];
    trim_leading_whitespace( equiv );
  }
  else {
    /* it's already a null, thus we're defining without and equiv field */
    equiv = &match[i];
  }

  if( lookup_token( match ) != NULL )
    printf( "\nWarning: Redefintion of %s", match );

  define_token( match, equiv );
}


/*
 * write_ship
 *
 *  purpose:
 *    writes the ship struct to a file.
 *
 * JMS 2 Aug 93
 */

void write_ship( char *infile )
{
char *outfile;
FILE *hfile;

  if( flags.o )
    infile = flags.outfile;

  outfile = (char *)JMALLOC( strlen( infile ) + 5 );

  strcpy( outfile, infile );

  if( strchr( outfile, '.' ))
    *strchr( outfile, '.' ) = '\0';

  strcat( outfile, ".bct" );

  if(( hfile = fopen( outfile, "wt" )) == NULL ) {
    printf( "\nError: cannot open file %s for writing.\n" );
    return;
  }

  ship.version = VERSION_CHAR;

  fwrite( &ship, sizeof( INSHIP ), 1, hfile );

  fclose( hfile );

  return;
}

/*
 * read_template
 *
 *  purpose:
 *    reads a binary template into the ship struct.
 *
 * JMS 12 Aug 93
 */

int read_template( char *filespec )
{
  FILE *hfile;
  char *new_filespec;

  /* first try a raw open */
  hfile = fopen( filespec, "rb" );

  /* if that didn't work, see if we should mess with the filename */
  if( hfile == NULL ) {
    if( !strchr( filespec, '.' )) {
      new_filespec = (char *)JMALLOC( (size_t)5 + strlen( filespec ));
      strcpy( new_filespec, filespec );
      strcat( new_filespec, ".bct" );
      hfile = fopen( new_filespec, "rb" );
    }
  }
  else
    new_filespec = filespec;

  if( hfile == NULL ) {
    printf( "\nError:  Unable to open file %s for reading.", filespec );
    printf( "\n" );
    return FALSE;
  }

  /* bitchin'.  it worked.  now read it in */
  fread( &ship, sizeof( INSHIP ), 1, hfile );

  fclose( hfile );

  return TRUE;
}

void label_wpns( char *str, int type )
{
    char arg[30],*x;
    int i;

    str=one_argument(str,arg);
    i = atoi(arg);
    switch( type )
    {
        case WPN_GUN:
            x = ship.gun_label[i];
            break;
        case WPN_TORP:
            x = ship.torp_label[i];
            break;
        default:
            x = arg;
            break;
    }
    strncpy( x, str, 29 );
    return;
}

void assign_wpn_arc( char *str, int type )
{
    char arg[30];
    ARC wpn_arc;
    int i;

    str=one_argument(str,arg);
    i=atoi(arg);
    wpn_arc = read_arc( str );
    switch( type )
    {
        case WPN_GUN:
            ship.gun_arc[i]=wpn_arc;
            break;
        case WPN_TORP:
            ship.torp_arc[i]=wpn_arc;
            break;
    }
    return;
}

ARC read_arc( char *str )
{
    char arg0[30],arg1[30],arg2[30];
    ARC new_arc;

    str=one_argument(str,arg0);
    str=one_argument(str,arg1);
    str=one_argument(str,arg2);

    new_arc.center.bearing = atoi(arg0);
    new_arc.center.elevation = atoi(arg1);
    new_arc.htraverse = atoi(arg2);
    new_arc.vtraverse = atoi(str);
    new_arc.center.range = 1.0;

    return new_arc;
}
