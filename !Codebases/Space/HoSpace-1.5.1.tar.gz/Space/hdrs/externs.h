Add this block to externs.h someplace.

#ifdef USE_SPACE /* JMS 19 Aug 93 */
/* From space.c */
void fun_beacon_cmd( char *, dbref, dbref, char **, int, char **, int );
void fun_comm_cmd( char *, dbref, dbref, char **, int, char **, int );
void fun_damcon_cmd( char *, dbref, dbref, char **, int, char **, int );
void fun_eng_cmd( char *, dbref, dbref, char **, int, char **, int );
void fun_helm_cmd( char *, dbref, dbref, char **, int, char **, int );
void fun_nav_cmd( char *, dbref, dbref, char **, int, char **, int );
void fun_planet_cmd( char *, dbref, dbref, char **, int, char **, int );
void fun_trans_cmd( char *, dbref, dbref, char **, int, char **, int );
void space_update( void );

#endif /* USE_SPACE */
