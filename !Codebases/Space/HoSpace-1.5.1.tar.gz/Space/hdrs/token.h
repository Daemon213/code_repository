/*
 * TOKEN.H
 *
 *  Definitions, declarations, and prototypes for TOKEN.C.
 *
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * JMS 2 Aug 93
 */


/* token function error codes */

#define TKE_FAIL  0
#define TKE_REDEF 1
#define TKE_OKAY  2

extern int initialize_tokens( void );
extern char *lookup_token( char * );
extern int define_token( char *, char * );
extern int undefine_token( char * );
extern char *substitute_tokens( char * );
