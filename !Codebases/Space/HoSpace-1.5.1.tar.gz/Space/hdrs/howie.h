#define WARPSET 1
#if !defined(HOWIE_H)
#define HOWIE_H 1
#define UMAX(a,b)               ((a) > (b) ? (a) : (b))
#define UMIN(a,b)               ((a) < (b) ? (a) : (b))
#define URANGE(a, b, c)         ((b) < (a) ? (a) : ((b) > (c) ? (c) : (b)))

typedef struct sph_coord
{
    float bearing;
    float elevation;
    float range;
} SPH;

typedef struct arc_entry
{
    SPH center;
    float htraverse;
    float vtraverse;
} ARC;

#define MAX_PHASERS  20
#define MAX_PHOTONS  MAX_PHASERS
#define MAX_SEEKERS  MAX_PHASERS

#define WPN_GUN      0
#define WPN_TORP     1
#define WPN_EXPLO    2
#define WPN_RAM      3
#define WPN_KAMIKAZE 4
#define WPN_DISABLER 5
#endif
