/*
 * SHIP.H
 *
 *  Ship struct used by template programs.
 *
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * JMS 2 Aug 93
 */
#include "howie.h"


typedef struct tds_ship
{
  /* stc info */
  char version;

  /* identifying data */
  char class_name[33];
  char type[33];
  char short_type[4]; 
  char builder[33];
  int owner;

  /* hull */
  unsigned int hull_points;
  float hull_size;
  float durability;

  /* armor */
  char armor_type;
  unsigned int armor_points;

  /* reactor */
  unsigned int reactor_power;
  unsigned int normal_setting;
  unsigned int maximum_setting;
  float overload_penalty;
  unsigned int overload_points;

  /* batteries */
  unsigned int battery_power;
  unsigned int battery_discharge_rate;

  /* drive */
  float warp_factor;
  float max_speed;
  float max_impulse;
  unsigned int etemp_points;
  float etemp_speed;
  char transwarp_capable;
  int transwarp_tolerance;
  float yaw_dps;
  float pitch_dps;
  float warp_accel;
  float warp_decel;

  /* sensors */
  float sensor_range;
  float aux_sensor_range;
  float scanner_range;
  ARC sensor_arc;
  ARC aux_sensor_arc;

  /* weapons */
  char gun_name[30];
  char torp_name[30];
  unsigned int num_guns;
  unsigned long int gun_range;
  unsigned int gun_power;
  float gun_delivery;
  unsigned int gun_charge_rate;
  int gun_signature;
  float gun_reliability;
  float gun_shield_factor;
  float gun_hull_factor;
  float gun_carryover;
  int gun_taps;
  char gun_label[MAX_PHASERS][30];
  ARC gun_arc[MAX_PHASERS];

  unsigned int num_torps;
  unsigned long int torp_range;
  unsigned int torp_power;
  float torp_accuracy;
  unsigned int torp_charge_rate;
  unsigned int torp_reload_time;
  unsigned int torp_max_num_turns_online;
  float torp_reliability;
  int torp_capacity;
  int torp_signature;
  float torp_shield_factor;
  float torp_hull_factor;
  float torp_carryover;
  int torp_taps;
  char torp_label[MAX_PHOTONS][30];
  ARC torp_arc[MAX_PHOTONS];

  /* shields */
  unsigned int shield_power;
  float shield_factor;
  unsigned int shield_charge_rate;

  /* communications */
  float transmitter_range;
  float receiver_sensitivity;
  unsigned int max_clients;

  /* cloak */
  unsigned int cloak_present;
  unsigned int cloak_cost;
  float cloak_ratio;

  /* miscellaneous */
  unsigned int transporter_range;
  unsigned int damcon_teams;
  char fullrepair;
  float dock_capacity;
  float dock_max_size;
  float shuttlebay_capacity;
  unsigned int cargo_capacity;
  unsigned int landing_capable;
  unsigned int tractor_range;
  unsigned int interdict_range;
  float interdict_speed;
  int escape_pods;
 
} INSHIP;
