#!/bin/sh

echo Installing HoSpace 1.4

patch -p0 < spaceinstall.patch

cp ../space/space.c ../..

echo If there were no failed hunks, then space is installed.

echo Remember to read the README in here for more instructions. 
