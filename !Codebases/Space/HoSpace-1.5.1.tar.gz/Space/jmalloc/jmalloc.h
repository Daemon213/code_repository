/*
 *    Copyright (C) 1995 Jason M. Skiles
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define MALLOC_DEBUG
#ifdef MALLOC_DEBUG
 #define JMALLOC(x)	jmalloc( x, __FILE__, __LINE__ )
 #define JREALLOC(x,y)	jrealloc( x, y, __FILE__, __LINE__ )
 #define JFREE(x)	jfree( x, __FILE__, __LINE__ )
#else
 #define JMALLOC(x)	malloc(x)
 #define JREALLOC(x,y)	realloc(x,y)
 #define JFREE(x)	free(x)
#endif

void *jmalloc( size_t, char *, int );
void *jrealloc( void *, size_t, char *, int );
void jfree( void *, char *, int );
void dump_alloclist( void );
void check_fences( void );
void dump_block( unsigned int );
