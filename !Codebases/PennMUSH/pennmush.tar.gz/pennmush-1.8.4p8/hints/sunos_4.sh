ccflags="-DSUN_OS -DOLD_ANSI"
