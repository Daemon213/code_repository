loclibpth="/usr/local/lib /usr/gnu/lib /usr/lib32 /usr/lib /lib"
libs="-lc -lm"
has_sigchld='define'
has_sigcld='define'
nm_opt="-B"
