/* Empty file
 * This used to be a header file, but now isn't.
 * We left the empty file to ease the pain for people using
 * *local.c files that include it.
 */
