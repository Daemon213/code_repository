RhostMUSH
=====
RhostMUSH is a security hardened text-based multiplayer RPG server initially based on TinyMUD. It features granular permission systems, a wide and varied set of tools for building your online world, and a continuously developing codebase.

NOTE: Please download https://github.com/RhostMUSH/trunk/archive/master.tar.gz instead of the ZIP file, as the latter breaks the necessary Linux permissions on several files in the downloaded snapshot!

RhostMUSH has a developer hangout MUSH at iweb.localecho.net 4201 - please feel free to connect there if you want to reach us, or need help with anything.

Online help files for RhostMUSH exist. 
=====
This is Ambrosia's branch, and currently the branch were main development of RhostMUSH is happening. This branch will, for now, merge and build up the latest and greatest before release to Master.

Rhost Wiki
=====
We have started a few helpful wiki pages on this site to help with Rhost game owners.

Click the wiki link to the right for a full list.  Feel free to submit issues and suggestions for more.
