#!/bin/sh
nohup ./backup_flat.sh > /dev/null 2>&1 &
