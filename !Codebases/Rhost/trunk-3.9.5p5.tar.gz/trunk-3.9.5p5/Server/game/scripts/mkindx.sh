#!/bin/bash
./mkindx txt/help.txt txt/help.indx
./mkindx txt/wizhelp.txt txt/wizhelp.indx
