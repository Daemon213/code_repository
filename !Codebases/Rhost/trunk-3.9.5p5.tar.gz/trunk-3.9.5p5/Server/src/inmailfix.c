#define INMAIL

#include "mailfix.c"
