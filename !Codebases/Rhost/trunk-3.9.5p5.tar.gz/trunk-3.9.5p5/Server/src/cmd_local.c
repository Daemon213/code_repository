void registerCommand(const char * name, int permission, 
