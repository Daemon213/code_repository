#include <stdio.h>
#include <stdlib.h>
main()
{
   printf("%d\n", sizeof(long));
}
